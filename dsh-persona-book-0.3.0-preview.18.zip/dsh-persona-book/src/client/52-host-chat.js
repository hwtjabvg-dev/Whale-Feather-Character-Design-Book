/** Presentation on DSH's existing nodes. The original input and transport stay owned by DSH. */
let pbNativeMounted = false;
let pbHostSession = '';
let pbHostState = null;
let pbHostUpdate = null;
const pbHostBySession=new Map();
const pbHostListeners = new Set();
const pbHostNotify = () => { for (const notify of pbHostListeners) notify(); };
function useHostState(sessionId=pbHostSession) {
  const [, refresh] = React.useState(0);
  React.useEffect(() => { const notify=()=>refresh(x=>x+1);pbHostListeners.add(notify);return()=>pbHostListeners.delete(notify); },[]);
  return pbHostBySession.get(sessionId||'')||pbHostState;
}
async function pbHostRefresh(sessionId=pbHostSession) {
  pbHostSession=sessionId||'';
  const value=await pbSharedRequest('/host/state?sessionId='+encodeURIComponent(pbHostSession));
  if(!pbNativeMounted)return value;
  pbHostBySession.clear();pbHostBySession.set(pbHostSession,value);pbHostState=value;pbHostNotify();window.dispatchEvent(new Event('persona-book:changed'));return value;
}
async function pbHostChoose(personaId,toneIntensity,sessionId=pbHostSession) {
  pbHostSession=sessionId||'';
  pbHostState=await pbSharedRequest('/host/select',{sessionId:pbHostSession,personaId,...toneIntensity===undefined?{}:{toneIntensity}});
  pbHostBySession.set(pbHostSession,pbHostState);pbHostNotify();window.dispatchEvent(new Event('persona-book:changed'));return pbHostState;
}
function pbHostAsset(file) { return file?.startsWith('media/')?PB_PLAY+'/'+file:PB_PLAY+'/ui/'+file; }
function pbHostBodyClass(moduleName,part) {
  const tag=[...document.querySelectorAll('style[data-plugin-css]')].find(x=>x.dataset.pluginCss.endsWith('/'+moduleName+'.module.css'));
  return tag?.textContent.match(new RegExp('\\.([A-Za-z0-9_]+_'+part+')(?=[{:. ])'))?.[1];
}
const PB_HOST_CSS=`
html[data-pb-host=on] [data-pb-host-region]{background:var(--pb-host-bg);--dsw-alias-bg-overlay:var(--pb-host-panel);--dsw-alias-label-primary:var(--pb-host-text);--dsw-alias-label-secondary:var(--pb-host-muted);--dsw-alias-label-tertiary:var(--pb-host-muted);--dsw-alias-border-l1:var(--pb-host-border);--dsw-alias-interactive-bg-hover:var(--pb-host-mine)}
[data-pb-host-region] [data-composer-card]{background:var(--pb-host-panel);border-color:var(--pb-host-border)}
[data-pb-host-region]::before{content:'';position:absolute;right:18px;bottom:145px;width:220px;height:360px;background:var(--pb-host-art) right bottom/contain no-repeat;opacity:.045;pointer-events:none}
[data-pb-host-region] [data-pb-host-body]{box-sizing:border-box;position:relative;border:1px solid var(--pb-host-border);border-radius:var(--pb-host-radius);padding:14px 18px;max-width:calc(100% - 48px);font-size:var(--pb-host-font);line-height:1.8;box-shadow:0 4px 18px rgb(20 45 80 / .035);margin-top:24px;margin-bottom:var(--pb-host-gap)}
[data-pb-host-region] [data-pb-host-body=assistant]{margin-left:44px;background:var(--pb-host-theirs);color:var(--pb-host-text)}
[data-pb-host-region] [data-pb-host-body=user]{margin-right:44px;margin-left:auto;background:var(--pb-host-mine);color:var(--pb-host-text)}
[data-pb-host-region] [data-pb-host-body]::before{content:'';position:absolute;width:32px;height:32px;top:0;left:-44px;border-radius:11px;border:1px solid var(--pb-host-border);background:var(--pb-host-avatar) var(--pb-host-avatar-position)/var(--pb-host-avatar-size) no-repeat var(--pb-host-panel)}
[data-pb-host-region] [data-pb-host-body=user]::before{content:'你';left:auto;right:-44px;display:grid;place-items:center;color:var(--pb-host-accent);background:var(--pb-host-panel);font-size:13px}
[data-pb-host-region] [data-pb-host-body=assistant]::after{content:attr(data-pb-host-name);position:absolute;top:-24px;left:0;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--pb-host-muted);font-size:11px}
[data-pb-host-region] [data-pb-host-body] pre{max-width:100%;overflow:auto;white-space:pre}
.pb-host-controls{display:flex;align-items:center;gap:6px;min-height:32px;font-size:12px;font-family:inherit;color:var(--dsw-alias-label-secondary);flex-wrap:wrap}
.pb-host-controls button{height:28px;padding:3px 9px;border:1px solid var(--dsw-alias-border-l1);border-radius:14px;background:var(--dsw-alias-bg-overlay);color:inherit;font:inherit;cursor:pointer}
.pb-host-controls button[data-active=true]{color:var(--dsw-alias-brand-primary);background:var(--dsw-alias-interactive-bg-hover)}
.pb-host-controls button[data-update=true]::after{content:'●';color:var(--dsw-alias-brand-primary);font-size:8px;margin-left:5px}
@media(max-width:640px){[data-pb-host-region] [data-pb-host-body]{padding:10px 12px;font-size:14px}.pb-host-controls{gap:4px}.pb-host-controls button{padding:3px 7px}}
`;
function HostSessionControls(props) {
  const state=useHostState(props.sessionId),layout=useRoomLayout(),blank=props.session?.blank===true,menu=React.useRef(null);
  React.useEffect(()=>{pbHostRefresh(props.sessionId||'').catch(()=>{});},[props.sessionId]);
  React.useEffect(()=>{const dismiss=e=>{if(menu.current&&!menu.current.contains(e.target))menu.current.open=false;};document.addEventListener('pointerdown',dismiss);return()=>document.removeEventListener('pointerdown',dismiss);},[]);
  if(blank||!state)return null;
  const roomOpen=!!layout&&!layout.keyboard&&(layout.compact?(layout.world==='night'?!pbRoomNightMobileClosed:pbRoomMobileOpen):!pbRoomClosed);
  const open=(view,tab)=>{if(menu.current)menu.current.open=false;openPanel(view,props.sessionId,tab);};
  return h('div',{className:'pb-host-controls','data-dsh-plugin':'persona-book'},
    h('button',{type:'button',className:'pb-room-role',onClick:()=>open('settings','persona'),'aria-label':'当前聊天人设'},h('span',{className:'pb-room-mini-avatar',style:{backgroundImage:`url("${pbHostAsset(state.avatar.displayFile||state.avatar.file)}")`,backgroundPosition:state.avatar.position||'center',backgroundSize:state.avatar.size||'cover'},'aria-hidden':'true'}),h('span',null,state.role.title.replace(/^DeepSeek娘\s*·\s*/,''))),
    h('div',{className:'pb-room-levels',role:'group','aria-label':'语气档位'},...[["低",3],["中",6],["高",9]].map(([label,value])=>h('button',{key:value,type:'button','data-active':state.role.defaults.toneIntensity===value,'aria-pressed':state.role.defaults.toneIntensity===value,onClick:()=>pbHostChoose(state.role.id,value,props.sessionId).catch(e=>toast(e.message)),title:label+'档语气 '+value},label))),
    h('button',{type:'button',className:'pb-room-quick',onClick:()=>open('settings','theme')},h(PbRoomIcon,{name:'dress'}),h('span',null,'换装')),
    h('button',{type:'button',className:'pb-room-quick',onClick:()=>open('settings','persona')},h(PbRoomIcon,{name:'settings'}),h('span',null,'人设设置')),
    h('button',{type:'button',className:'pb-room-stage-toggle','aria-label':roomOpen?'收起角色立绘':'展开角色立绘','aria-expanded':roomOpen,disabled:layout?.keyboard,onClick:()=>pbRoomToggle(),title:layout?.keyboard?'收起键盘后查看立绘':'角色立绘'},h(PbRoomIcon,{name:'portrait'}),h('span',{className:'pb-room-stage-label'},'立绘')),
    h('details',{className:'pb-room-menu',ref:menu,onKeyDown:e=>{if(e.key==='Escape'){e.currentTarget.open=false;e.currentTarget.querySelector('summary').focus();e.stopPropagation();}}},
      h('summary',{'aria-label':'更多人设操作'},pbHostUpdate?.restartRequired?h('span',{className:'pb-room-update'},'待重启'):pbHostUpdate?.available?h('span',{className:'pb-room-update'},'有更新'):h(PbRoomIcon,{name:'more'})),
      h('div',null,h('button',{type:'button',onClick:()=>{if(menu.current)menu.current.open=false;window.dispatchEvent(new Event('persona-book:companion-touch'));}},h(PbRoomIcon,{name:'portrait'}),'轻轻唤一下'+state.role.title.replace(/^DeepSeek娘\s*·\s*/,'')),h('button',{type:'button',onClick:()=>open('workshop')},h(PbRoomIcon,{name:'dress'}),'创意工坊'),h('button',{type:'button',onClick:()=>open('settings','sound')},h(PbRoomIcon,{name:'volume'}),'角色声音'),h('button',{type:'button',onClick:pbRoomToggleEffects,'aria-pressed':pbRoomEffects},h(PbRoomIcon,{name:'motion'}),pbRoomEffects?'关闭动效':'开启动效'),h('button',{type:'button',onClick:()=>open('updates')},h(PbRoomIcon,{name:'update'}),pbHostUpdate?.restartRequired?'更新已安装，待重启':pbHostUpdate?.available?'发现插件更新':'插件更新'))));
}
function pbMountHostChat() {
  pbNativeMounted=true;
  const disposeFeedback=pbMountFeedback();
  const tag=pbHostStyle(PB_HOST_CSS+PB_ROOM_CSS+PB_NIGHT_CSS+PB_FEEDBACK_CSS);
  const rootAttrs=new Map(['data-pb-world','data-pb-motion','data-pb-scene'].map(k=>[k,document.documentElement.getAttribute(k)]));
  const regions=new Map(),initial=new Set(),played=new Set(),activeTurns=new Set(),arrived=new Set();let disposed=false,scheduled=false,lastSubmit=0;
  const bodyFor=flow=>{const role=flow.dataset.chatFlowKind;const cls=pbHostBodyClass(role==='user'?'MessageItem':'AssistantMarkdown',role==='user'?'bubble':'root');return cls?flow.querySelector('.'+cls):flow.querySelector('[data-message-text]');};
  const play=(file,volume)=>{if(document.hidden||disposed)return;const a=new Audio(pbHostAsset(file));a.volume=volume;a.play().catch(()=>{});};
  const keyFor=flow=>(flow.closest('[data-conversation-session]')?.dataset.conversationSession||pbHostSession)+':'+(flow.dataset.chatTurn||flow.dataset.chatFlowKey||'');
  const visibleReply=body=>[...body.querySelectorAll('p,pre,table,blockquote,img,[data-message-text]')].some(el=>!el.closest('[hidden],[data-turn-process-inline],[class*=thinkBody]')&&(el.innerText?.trim()||el.tagName==='IMG'));
  const paint=()=>{
    scheduled=false;if(disposed||!pbHostState)return;
    const enabled=pbHostState.enabled&&!pbSafeFlag();document.documentElement.dataset.pbHost=enabled?'on':'off';let room=null;
    const hostRegions=[...document.querySelectorAll('[data-conversation-region=chat]')];
    const focused=document.activeElement?.closest?.('[data-conversation-region=chat]');
    const selected=focused||hostRegions.find(el=>el.dataset.conversationSession===pbHostSession)||hostRegions.find(el=>el.getBoundingClientRect().width>0);
    for(const region of hostRegions){
      if(!enabled){for(const name of ['data-pb-host-region','data-pb-room-side','data-pb-world','data-pb-keyboard','data-pb-stage-visible','data-pb-scene'])region.removeAttribute(name);continue;}
      if(!regions.has(region)){regions.set(region,new Map());resizeObserver?.observe(region);for(const flow of region.querySelectorAll('[data-chat-flow-key]'))initial.add(flow.dataset.chatFlowKey);}
      const sid=region.dataset.conversationSession||'',state=pbHostBySession.get(sid)||pbHostState;
      if(!pbHostBySession.has(sid)){pbHostBySession.set(sid,state);pbSharedRequest('/host/state?sessionId='+encodeURIComponent(sid)).then(s=>{if(!disposed){pbHostBySession.set(sid,s);pbHostNotify();schedule();}}).catch(()=>{});}
      const set=(key,value)=>{const name='--pb-host-'+key,old=regions.get(region);if(!old.has(name))old.set(name,[region.style.getPropertyValue(name),region.style.getPropertyPriority(name)]);region.style.setProperty(name,value);};
      region.setAttribute('data-pb-host-region','');let theme=state.theme;
      if(theme.id==='builtin:system'&&matchMedia('(prefers-color-scheme:dark)').matches)theme=state.themes.find(t=>t.id==='builtin:deepsea')||theme;
      const night=['night-room','scene-room'].includes(theme.presentation),scene=theme.scene||{id:'deepsea',title:'深海私语',background:'art/night-bedroom-c.webp'},previousScene=region.dataset.pbScene;region.dataset.pbWorld=night?'night':'base';region.dataset.pbScene=night?scene.id:'base';set('scene',`url("${pbHostAsset(scene.background)}")`);
      if(previousScene&&previousScene!==region.dataset.pbScene&&pbRoomEffects&&!matchMedia('(prefers-reduced-motion:reduce)').matches)region.animate?.([{opacity:.65,filter:'brightness(1.13)'},{opacity:1,filter:'brightness(1)'}],{duration:480,easing:'cubic-bezier(.16,1,.3,1)'});
      for(const [key,value]of Object.entries(theme.tokens))set(key,value);
      const box=region.getBoundingClientRect(),compact=box.width<940,seat=night?Math.min(470,Math.max(320,box.width*.37)):Math.min(340,Math.max(260,box.width*.28));
      region.toggleAttribute('data-pb-room-side',region===selected&&!compact&&!pbRoomClosed);set('seat',seat+'px');
      const keyboard=compact&&((!!window.visualViewport&&window.innerHeight-window.visualViewport.height>160)||box.height<430);
      region.toggleAttribute('data-pb-keyboard',keyboard);region.toggleAttribute('data-pb-stage-visible',night&&!keyboard&&(compact?!pbRoomNightMobileClosed:!pbRoomClosed));
      if(region===selected&&box.width>0&&box.height>0){const gap=night?12:compact?12:24;room={sessionId:sid,world:night?'night':'base',blank:region.dataset.contentPhase==='hero',compact,keyboard,top:Math.round(box.top+gap),right:Math.round(window.innerWidth-box.right+gap),width:Math.round(night?box.width-24:compact?Math.min(box.width-24,380):seat-40),height:Math.round(night?(compact?176:box.height-24):compact?Math.min(box.height*.48,360):box.height-48),tokens:theme.tokens,scene:night?scene:null};}
      const avatar=state.avatar;
      set('art',(state.role.id==='tsundere-kitten-persona'||state.role.presentation?.basePersonaId==='tsundere-kitten-persona')&&avatar.id==='builtin:portrait'?`url("${pbHostAsset('art/whale-welcome-v3.webp')}")`:'none');
      for(const [key,value]of Object.entries({radius:state.settings.bubbleRadius+'px',gap:state.settings.spacing+'px',font:state.settings.fontSize+'px',avatar:`url("${pbHostAsset(avatar.displayFile||avatar.file)}")`,'avatar-position':avatar.position||'center','avatar-size':avatar.size||'cover'}))set(key,value);
      for(const flow of region.querySelectorAll('[data-chat-flow-kind=user],[data-chat-flow-kind=assistant-step]')){
        const body=bodyFor(flow);if(!body)continue;const user=flow.dataset.chatFlowKind==='user',key=keyFor(flow);
        body.dataset.pbHostBody=user?'user':'assistant';if(!user)body.dataset.pbHostName=state.role.title.replace(/^DeepSeek娘\s*·\s*/,'');
        const fresh=!initial.has(flow.dataset.chatFlowKey);
        if(!user&&fresh&&(activeTurns.has(key)||flow.querySelector('[data-streaming]'))&&visibleReply(body)&&!arrived.has(key)){arrived.add(key);body.dataset.pbHostArrive='';window.dispatchEvent(new Event('persona-book:reply-visible'));}
        if(user&&fresh&&Date.now()-lastSubmit<10000&&!played.has('send:'+key)){activeTurns.add(key);played.add('send:'+key);if(state.settings.sound&&state.settings.sentSound)play('sounds/send.wav',state.settings.volume);}
        if(!user&&fresh&&(activeTurns.has(key)||flow.querySelector('[data-streaming]'))&&!played.has('receive:'+key)&&visibleReply(body)&&!body.closest('[hidden]')){played.add('receive:'+key);if(state.settings.sound&&state.settings.receiveVoice)play(pbNextReceive(state),state.settings.volume);}
      }
    }
    const sceneId=enabled&&room?.scene?.id||'base';if(document.documentElement.dataset.pbScene!==sceneId)document.documentElement.dataset.pbScene=sceneId;const world=enabled&&room?.world==='night'?'night':'base',motion=pbRoomEffects?'on':'off';if(document.documentElement.dataset.pbWorld!==world)document.documentElement.dataset.pbWorld=world;if(document.documentElement.dataset.pbMotion!==motion)document.documentElement.dataset.pbMotion=motion;
    if(JSON.stringify(room)!==JSON.stringify(pbRoomLayout)){pbRoomLayout=room;pbHostNotify();}
    if(played.size>512){const newest=[...played].slice(-256);played.clear();newest.forEach(x=>played.add(x));}
  };
  const schedule=()=>{if(!scheduled&&!disposed){scheduled=true;requestAnimationFrame(paint);}};
  // Existing history is baseline, including history loaded on first mount.
  for(const flow of document.querySelectorAll('[data-chat-flow-key]'))initial.add(flow.dataset.chatFlowKey);
  const observer=new MutationObserver(schedule);observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['data-streaming','data-chat-flow-key','data-content-phase','hidden']});
  const focus=e=>{const region=e.target.closest?.('[data-conversation-region=chat]');if(region?.dataset.conversationSession)pbHostSession=region.dataset.conversationSession;schedule();};
  const resizeObserver=typeof ResizeObserver==='undefined'?null:new ResizeObserver(schedule);for(const region of document.querySelectorAll('[data-conversation-region=chat]'))resizeObserver?.observe(region);
  window.addEventListener('resize',schedule);document.addEventListener('focusin',focus);window.visualViewport?.addEventListener('resize',schedule);
  const submit=e=>{if(e.type==='keydown'&&e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.target.closest?.('[data-composer-input],[contenteditable=true]'))lastSubmit=Date.now();if(e.type==='click'&&e.target.closest?.('button')?.getAttribute('aria-label')?.match(/^(发送|Send)/))lastSubmit=Date.now();};
  const refresh=()=>pbHostRefresh().catch(()=>{}),changed=schedule;
  const keepChatAxis=e=>{const el=e.target;if(el instanceof Element&&el.matches('[data-pb-world=night] [data-conversation-scroll]')&&el.scrollLeft!==0)el.scrollLeft=0;};
  document.addEventListener('scroll',keepChatAxis,true);
  document.addEventListener('keydown',submit,true);document.addEventListener('click',submit,true);window.addEventListener('persona-book:changed',changed);
  const timer=setInterval(()=>{if(!document.hidden)refresh();},15000);refresh();
  let updating=false;
  const update=async()=>{if(document.hidden||disposed||updating)return;updating=true;try{let s=await pbSharedRequest('/updates/status');if(s.configured&&(!s.private||s.authorizationConfigured)&&!s.restartRequired&&!['checking','downloading','verifying','installing'].includes(s.phase)&&Date.now()-s.checkedAt>=60000)s=await pbSharedRequest('/updates/check',{});if(!disposed){pbHostUpdate=s;pbHostNotify();}}catch{}finally{updating=false;}};
  const updateTimer=setInterval(update,60000);document.addEventListener('visibilitychange',update);window.addEventListener('online',update);update();
  return()=>{
    disposed=true;document.removeEventListener('visibilitychange',update);window.removeEventListener('online',update);disposeFeedback();pbNativeMounted=false;observer.disconnect();resizeObserver?.disconnect();window.removeEventListener('resize',schedule);document.removeEventListener('focusin',focus);window.visualViewport?.removeEventListener('resize',schedule);clearInterval(timer);clearInterval(updateTimer);document.removeEventListener('keydown',submit,true);document.removeEventListener('click',submit,true);window.removeEventListener('persona-book:changed',changed);tag.remove();document.documentElement.removeAttribute('data-pb-host');
    document.removeEventListener('scroll',keepChatAxis,true);
    for(const [name,value]of rootAttrs){if(value===null)document.documentElement.removeAttribute(name);else document.documentElement.setAttribute(name,value);}
    for(const [region,vars]of regions){for(const name of ['data-pb-host-region','data-pb-room-side','data-pb-world','data-pb-keyboard','data-pb-stage-visible','data-pb-scene'])region.removeAttribute(name);for(const [name,[value,priority]]of vars){if(value)region.style.setProperty(name,value,priority);else region.style.removeProperty(name);}if(!region.style.cssText)region.removeAttribute('style');}
    for(const body of document.querySelectorAll('[data-pb-host-body]')){body.removeAttribute('data-pb-host-body');body.removeAttribute('data-pb-host-name');body.removeAttribute('data-pb-host-arrive');}
    pbRoomLayout=null;pbRoomMobileOpen=false;pbRoomNightMobileClosed=false;pbHostState=null;pbHostUpdate=null;pbHostBySession.clear();pbHostNotify();
  };
}
