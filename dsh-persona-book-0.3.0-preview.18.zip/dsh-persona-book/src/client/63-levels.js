/**
 * Shard 63: the tone-level tab.
 *
 * Levels are the persona's dials. Each row edits name, trigger, strength and
 * example lines; the list can be reordered and pruned. The order here is the
 * order the generated skill presents them in.
 */

/** One editable level. */
function LevelCard({ tr, level, index, total, draft, edit }) {
  const patch = (path, value) => {
    const levels = clone(draft.levels);
    levels[index] = setIn(levels[index], path, value);
    edit(['levels'], levels);
  };
  const move = (delta) => {
    const to = index + delta;
    if (to < 0 || to >= total) return;
    const levels = clone(draft.levels);
    const [moved] = levels.splice(index, 1);
    levels.splice(to, 0, moved);
    edit(['levels'], levels);
  };
  return h(
    'div',
    { className: 'pb-level' },
    h(
      'div',
      { className: 'pb-row', 'data-spread': 'true' },
      h(
        'div',
        { className: 'pb-row' },
        h('span', { className: 'pb-badge' }, `#${index + 1}`),
        h('button', { type: 'button', className: 'pb-btn', 'data-variant': 'ghost', disabled: index === 0, onClick: () => move(-1) }, '↑'),
        h('button', { type: 'button', className: 'pb-btn', 'data-variant': 'ghost', disabled: index === total - 1, onClick: () => move(1) }, '↓'),
      ),
      h(
        'button',
        {
          type: 'button',
          className: 'pb-btn',
          'data-variant': 'danger',
          onClick: () => edit(['levels'], draft.levels.filter((_, at) => at !== index)),
        },
        tr('levels.remove'),
      ),
    ),
    h(
      'div',
      { className: 'pb-grid-2' },
      h(Field, { label: tr('levels.name') }, h(TextInput, { value: level.name, onChange: (value) => patch(['name'], value) })),
      h(Field, { label: tr('levels.id'), hint: tr('advanced.readOnly') }, h(TextInput, { value: level.id, onChange: (value) => patch(['id'], value) })),
    ),
    h(Field, { label: tr('levels.trigger') }, h(TextInput, { value: level.trigger, onChange: (value) => patch(['trigger'], value) })),
    h(
      'div',
      { className: 'pb-grid-2' },
      h(Slider, { label: tr('levels.ratio'), min: 0, max: 1, step: 0.05, value: level.ratio ?? 0.5, onChange: (value) => patch(['ratio'], value) }),
      h(Slider, { label: tr('levels.intensity'), min: 1, max: 10, step: 1, value: level.intensity ?? 5, onChange: (value) => patch(['intensity'], value) }),
    ),
    h(
      'div',
      { className: 'pb-row' },
      h(
        'button',
        {
          type: 'button',
          className: 'pb-btn',
          'data-variant': 'ghost',
          onClick: () => {
            const example = window.prompt(tr('levels.examples'));
            if (example === null || example.trim() === '') return;
            patch(['examples'], [...(level.examples ?? []), example.trim()]);
          },
        },
        `＋ ${tr('levels.examples')}`,
      ),
    ),
    (level.examples ?? []).length === 0
      ? null
      : h(
          'ul',
          { className: 'pb-hint', style: { margin: 0, paddingInlineStart: '18px' } },
          (level.examples ?? []).map((example, at) =>
            h(
              'li',
              { key: `${example}-${at}` },
              example,
              ' ',
              h(
                'button',
                {
                  type: 'button',
                  className: 'pb-btn',
                  'data-variant': 'ghost',
                  onClick: () => patch(['examples'], level.examples.filter((_, index2) => index2 !== at)),
                },
                '✕',
              ),
            ),
          ),
        ),
  );
}

/** The tone-level tab. */
function LevelsPanel({ tr }) {
  const state = useStore();
  const draft = state.draft;
  if (draft === null) return h('p', { className: 'pb-hint' }, tr('list.empty'));
  const levels = draft.levels ?? [];
  return h(
    Section,
    {
      title: tr('levels.heading'),
      hint: tr('levels.hint'),
      actions: h(
        'button',
        {
          type: 'button',
          className: 'pb-btn',
          onClick: () => {
            const id = `level-${levels.length + 1}`;
            editDraft(['levels'], [...levels, { id, name: pbTr('levels.newName', { n: levels.length + 1 }), ratio: 0.5, intensity: 5, trigger: '', examples: [] }]);
          },
        },
        tr('levels.add'),
      ),
    },
    levels.length === 0 ? h('p', { className: 'pb-hint' }, tr('levels.empty')) : null,
    levels.map((level, index) =>
      h(LevelCard, { key: level.id ?? index, tr, level, index, total: levels.length, draft, edit: editDraft }),
    ),
  );
}
