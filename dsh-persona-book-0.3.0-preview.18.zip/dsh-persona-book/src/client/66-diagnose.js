/**
 * Shard 66: the diagnostics tab.
 *
 * One screen that answers "why is my persona not doing anything": paths, counts,
 * the upstream chat setting the bubble skin writes, and the host's own notes.
 */

/** The diagnostics tab. */
function DiagnosePanel({ tr, forms }) {
  const state = useStore();
  const [report, setReport] = React.useState(null);

  React.useEffect(() => {
    let alive = true;
    void apiDiagnose().then(
      (body) => {
        if (alive) setReport(body);
      },
      (error) => {
        if (alive) setReport({ problems: [`${error.code}：${error.message}`] });
      },
    );
    return () => {
      alive = false;
    };
  }, [state.snapshot?.rev]);

  const transcript = forms?.get?.()?.transcriptView ?? null;
  const problems = report?.problems ?? [];
  const copy = () => {
    const text = JSON.stringify({ report, snapshotProblems: state.snapshot?.problems, transcript }, null, 2);
    void navigator.clipboard?.writeText(text).then(
      () => setState({ toast: tr('diagnose.copied') }),
      () => setState({ toast: tr('failed') }),
    );
  };

  return h(
    React.Fragment,
    null,
    h(
      Section,
      {
        title: tr('diagnose.heading'),
        actions: h('button', { type: 'button', className: 'pb-btn', onClick: copy }, tr('diagnose.copy')),
      },
      h(
        'dl',
        { className: 'pb-kv' },
        h('dt', null, tr('diagnose.version')),
        h('dd', null, `${state.snapshot?.version ?? '—'} · ${report?.node ?? '—'}`),
        h('dt', null, tr('diagnose.paths')),
        h(
          'dd',
          null,
          Object.entries(report?.paths ?? {}).map(([key, value]) => h('div', { key }, `${key}: ${value}`)),
        ),
        h('dt', null, tr('diagnose.counts')),
        h(
          'dd',
          null,
          `${tr('diagnose.personas')} ${report?.counts?.personas ?? '—'} · ${tr('diagnose.installed')} ${report?.counts?.installed ?? '—'} · ${tr('diagnose.parked')} ${report?.counts?.parked ?? '—'}`,
        ),
        h('dt', null, tr('diagnose.assets')),
        h('dd', null, `${bytes(report?.assets?.bytes ?? 0)} · ${report?.assets?.files ?? 0} files`),
        h('dt', null, tr('diagnose.upstream')),
        h('dd', null, `transcriptView: ${transcript ?? '—'}`),
      ),
    ),
    h(
      Section,
      { title: tr('diagnose.problems') },
      problems.length === 0 && (state.snapshot?.problems ?? []).length === 0
        ? h('p', { className: 'pb-hint' }, tr('diagnose.noProblems'))
        : h(
            'ul',
            { className: 'pb-hint', style: { margin: 0, paddingInlineStart: '18px' } },
            [...(state.snapshot?.problems ?? []), ...problems].map((line, index) => h('li', { key: `${index}-${line}` }, line)),
          ),
      (state.snapshot?.personas ?? []).some((row) => row.collisions?.length)
        ? h(
            'div',
            null,
            h('p', { className: 'pb-hint' }, tr('list.collisions')),
            h(
              'ul',
              { className: 'pb-hint', style: { margin: 0, paddingInlineStart: '18px' } },
              (state.snapshot?.personas ?? [])
                .filter((row) => row.collisions?.length)
                .flatMap((row) => row.collisions.map((path) => h('li', { key: path }, `${row.id}: ${path}`))),
            ),
          )
        : null,
    ),
  );
}
