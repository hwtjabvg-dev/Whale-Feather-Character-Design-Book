const PB_ROOM_CSS=`
html[data-pb-host=on] [data-pb-host-region]{box-sizing:border-box;--dsw-alias-bg-base:var(--pb-host-bg);--dsw-alias-label-caption:var(--pb-host-muted);--dsw-alias-state-business-primary:var(--pb-host-accent);--dsw-alias-button-info-fill:var(--pb-host-accent);--dsw-alias-button-info-hover:var(--pb-host-accent);--dsw-specific-selector:var(--pb-host-mine);--dsw-specific-codeblock:var(--pb-host-panel);caret-color:var(--pb-host-accent);color:var(--pb-host-text)}
[data-pb-host-region][data-pb-room-side]{padding-inline-end:var(--pb-host-seat)}
[data-pb-host-region]::before{display:none}
[data-pb-host-region] [data-pb-host-body]{box-shadow:none;border:0;line-height:1.85;margin-top:25px;padding:14px 18px;overflow-wrap:anywhere}
[data-pb-host-region] [data-pb-host-body=assistant]{border-radius:4px var(--pb-host-radius) var(--pb-host-radius);background:var(--pb-host-theirs)}
[data-pb-host-region] [data-pb-host-body=user]{border-radius:var(--pb-host-radius) 4px var(--pb-host-radius) var(--pb-host-radius)}
[data-pb-host-region] [data-pb-host-body]::before{border:0;border-radius:11px}
[data-pb-host-region] [data-pb-host-body=assistant]::after{font-size:12px;color:var(--pb-host-muted)}
[data-pb-host-region] [data-pb-host-body] pre{background:var(--pb-host-panel);border-radius:10px;color:var(--pb-host-text)}
[data-pb-host-region] [data-composer-seat]{background:var(--pb-host-bg)}
[data-pb-host-region] [data-composer-card]{border:1px solid var(--pb-host-border);border-radius:16px;box-shadow:0 8px 26px rgb(16 35 60 / .045)}
[data-pb-host-region] ::selection{background:var(--pb-host-mine);color:var(--pb-host-text)}
.pb-host-controls{box-sizing:border-box;width:min(100%,780px);margin:0 auto;padding:9px 18px 10px;gap:12px;color:var(--dsw-alias-label-secondary);font-size:12px;flex-wrap:nowrap;position:relative}
.pb-host-controls>button,.pb-room-menu>summary{border:0;background:transparent;border-radius:8px;padding:6px 8px;height:32px;display:inline-flex;align-items:center;justify-content:center;gap:6px;flex:none;cursor:pointer}
.pb-host-controls>button:hover,.pb-room-menu>summary:hover{background:var(--dsw-alias-interactive-bg-hover)}
.pb-host-controls .pb-room-role{padding-inline:0;min-width:0;max-width:160px;justify-content:start;color:var(--dsw-alias-label-primary)}
.pb-room-role>span:last-child{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pb-room-mini-avatar{width:24px;height:24px;border-radius:8px;background-color:var(--dsw-alias-bg-overlay);background-repeat:no-repeat;flex:none}
.pb-room-levels{display:flex;align-items:center;gap:2px;border:1px solid var(--dsw-alias-border-l1);border-radius:9px;padding:2px;flex:none}
.pb-room-levels button{height:25px;min-width:29px;border:0;border-radius:6px;padding:1px 7px;background:transparent;color:inherit;font:inherit;cursor:pointer}
.pb-room-levels button[data-active=true]{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary);font-weight:600}
.pb-host-controls .pb-room-stage-toggle{margin-left:auto}
.pb-room-menu{position:relative;flex:none}.pb-room-menu>summary{list-style:none}.pb-room-menu>summary::-webkit-details-marker{display:none}
.pb-room-menu[open]>div{position:absolute;bottom:calc(100% + 9px);right:0;min-width:166px;border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-overlay);padding:6px;z-index:20;box-shadow:0 10px 30px rgb(16 35 60 / .12)}
.pb-room-menu[open]>div button{display:flex;width:100%;align-items:center;justify-content:start;gap:10px;border:0;border-radius:7px;padding:10px;font:inherit;background:transparent;color:var(--dsw-alias-label-primary);cursor:pointer;text-align:start;height:auto}
.pb-room-menu[open]>div button:hover{background:var(--dsw-alias-interactive-bg-hover)}
.pb-room-update{font-size:11px;color:var(--dsw-alias-brand-primary)}
.pb-host-controls .pb-room-quick{display:none}
.pb-host-room{box-sizing:border-box;position:fixed;z-index:15;display:flex;flex-direction:column;pointer-events:auto;padding:26px 22px 20px;background:var(--pb-host-panel);color:var(--pb-host-text);border-radius:16px;overflow:hidden;animation:pb-room-arrive 220ms cubic-bezier(.2,.8,.2,1) both;font-family:inherit;isolation:isolate}
.pb-room-heading{display:flex;align-items:start;justify-content:space-between;gap:8px;flex:none}
.pb-room-heading h2{font-size:28px;line-height:1.35;font-weight:600;letter-spacing:0;margin:0;overflow-wrap:anywhere}
.pb-room-heading p{color:var(--pb-host-muted);font-size:12px;margin:8px 0 0;line-height:1.5}
.pb-room-icon{display:grid;place-items:center;border:0;background:transparent;color:var(--pb-host-muted);width:32px;height:32px;border-radius:8px;flex:none;cursor:pointer}
.pb-room-icon:hover{background:var(--pb-host-bg);color:var(--pb-host-text)}
.pb-room-art{position:relative;min-height:0;flex:1;display:flex;align-items:center;justify-content:center;margin:10px -20px 0;overflow:hidden}
.pb-room-art>img{width:100%;height:100%;min-height:0;object-fit:contain;object-position:center bottom;filter:drop-shadow(0 16px 14px rgb(20 45 80 / .08))}
.pb-room-custom-avatar{width:190px;height:190px;max-height:100%;background-repeat:no-repeat;border-radius:16px}
.pb-room-caption{flex:none;display:flex;align-items:center;gap:10px;color:var(--pb-host-muted);font-size:11px;line-height:1.8;padding:12px 0 20px}
.pb-room-line{width:18px;height:1px;background:var(--pb-host-accent);flex:none}
.pb-room-footer{flex:none;border-top:1px solid var(--pb-host-border);padding-top:17px}
.pb-room-current{display:flex;justify-content:space-between;gap:10px;font-size:11px;color:var(--pb-host-muted)}
.pb-room-current strong{font-weight:500;color:var(--pb-host-text);font-variant-numeric:tabular-nums}
.pb-room-actions{display:flex;gap:8px;margin-top:14px}
.pb-room-actions button{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;font:inherit;font-size:12px;min-height:38px;border:0;border-radius:9px;background:var(--pb-host-bg);color:var(--pb-host-text);cursor:pointer}
.pb-room-actions button:hover{background:var(--pb-host-mine)}
.pb-host-room:focus-within,.pb-host-controls:focus-within{outline:none}.pb-host-room button:focus-visible,.pb-host-controls button:focus-visible,.pb-room-menu>summary:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,var(--pb-host-accent));outline-offset:3px}
.pb-host-room[data-compact=true]{box-shadow:0 12px 40px rgb(16 35 60 / .2);padding:18px;display:grid;grid-template-columns:minmax(0,1fr) 42%;grid-template-rows:auto 1fr auto;gap:12px}
.pb-host-room[data-compact=true] .pb-room-heading{grid-column:1;grid-row:1}.pb-host-room[data-compact=true] .pb-room-heading h2{font-size:22px}
.pb-host-room[data-compact=true] .pb-room-art{grid-column:2;grid-row:1/4;height:100%;margin:0 -14px -8px;pointer-events:none}
.pb-host-room[data-compact=true] .pb-room-icon{position:absolute;top:10px;right:10px;z-index:1;background:var(--pb-host-panel);width:36px;height:36px}
.pb-host-room[data-compact=true] .pb-room-caption{grid-column:1;padding:0;align-self:center}.pb-host-room[data-compact=true] .pb-room-footer{grid-column:1;padding-top:12px}.pb-host-room[data-compact=true] .pb-room-current{flex-direction:column;gap:4px}.pb-host-room[data-compact=true] .pb-room-actions{flex-direction:column;margin-top:10px;gap:5px}
@keyframes pb-room-arrive{from{opacity:.8;transform:translateY(8px)}to{opacity:1;transform:none}}
@media(max-width:640px){.pb-host-controls{gap:8px;padding:6px 10px}.pb-host-controls .pb-room-role{max-width:100px}.pb-room-levels{gap:0}.pb-room-levels button{min-width:27px;padding:2px 5px}.pb-host-controls>button,.pb-room-menu>summary{height:38px;padding-inline:5px}.pb-room-stage-label{display:none}.pb-room-menu>summary{min-width:32px}.pb-host-controls .pb-room-role{font-size:12px;gap:6px}[data-pb-host-region] [data-pb-host-body]{padding:11px 13px;max-width:calc(100% - 32px);font-size:var(--pb-host-font)}[data-pb-host-region] [data-pb-host-body=assistant]{margin-left:32px}[data-pb-host-region] [data-pb-host-body=user]{margin-right:32px}[data-pb-host-region] [data-pb-host-body]::before{width:25px;height:25px;left:-32px;border-radius:8px}[data-pb-host-region] [data-pb-host-body=user]::before{right:-32px;left:auto}}
@media(prefers-reduced-motion:reduce){.pb-host-room{animation:none}}
`;
