/**
 * Shard 43: contrast guard.
 *
 * Pure math, no DOM: the panel needs the numbers live while the user drags a
 * slider, so this cannot be a host round trip. The host keeps its own copy for
 * the golden tests; the formulas are the WCAG ones.
 */

/** Parse `#rgb` / `#rrggbb` / `#rrggbbaa` / `rgb()` / `rgba()` into `[r,g,b,a]`. */
function pbcParse(color) {
  if (typeof color !== 'string') return null;
  const text = color.trim();
  const hex = /^#([0-9a-f]{3,8})$/i.exec(text);
  if (hex !== null) {
    const body = hex[1];
    const wide = body.length === 3 || body.length === 4 ? body.split('').map((c) => c + c).join('') : body;
    if (wide.length !== 6 && wide.length !== 8) return null;
    const value = (index) => Number.parseInt(wide.slice(index * 2, index * 2 + 2), 16);
    return [value(0), value(1), value(2), wide.length === 8 ? value(3) / 255 : 1];
  }
  const fn = /^rgba?\(([^)]+)\)$/i.exec(text);
  if (fn !== null) {
    const parts = fn[1].split(/[,/\s]+/).filter((part) => part !== '');
    if (parts.length < 3) return null;
    const channel = (part) => {
      if (part.endsWith('%')) return Math.round((Number.parseFloat(part) / 100) * 255);
      return Math.round(Number.parseFloat(part));
    };
    const rgb = parts.slice(0, 3).map(channel);
    if (rgb.some((n) => !Number.isFinite(n))) return null;
    const alpha = parts[3] === undefined ? 1 : parts[3].endsWith('%') ? Number.parseFloat(parts[3]) / 100 : Number.parseFloat(parts[3]);
    return [rgb[0], rgb[1], rgb[2], Number.isFinite(alpha) ? alpha : 1];
  }
  return null;
}

/** WCAG relative luminance of an `[r,g,b]` triple. */
function pbcLuminance(rgb) {
  const channel = (value) => {
    const srgb = value / 255;
    return srgb <= 0.03928 ? srgb / 12.92 : ((srgb + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * channel(rgb[0]) + 0.7152 * channel(rgb[1]) + 0.0722 * channel(rgb[2]);
}

/** Contrast ratio between two colours (`1` … `21`). */
function pbcRatio(foreground, background) {
  const fg = pbcParse(foreground);
  const bg = pbcParse(background);
  if (fg === null || bg === null) return null;
  const a = pbcLuminance(fg);
  const b = pbcLuminance(bg);
  const light = Math.max(a, b);
  const dark = Math.min(a, b);
  return (light + 0.05) / (dark + 0.05);
}

/** `top` painted over `bottom` (both may carry alpha) → `rgba()` string. */
function pbcComposite(top, bottom) {
  const a = pbcParse(top);
  const b = pbcParse(bottom);
  if (a === null) return bottom;
  if (b === null) return top;
  const alpha = a[3] + b[3] * (1 - a[3]);
  if (alpha === 0) return 'rgba(0, 0, 0, 0)';
  const mix = (index) => Math.round((a[index] * a[3] + b[index] * b[3] * (1 - a[3])) / alpha);
  return `rgba(${mix(0)}, ${mix(1)}, ${mix(2)}, ${Number(alpha.toFixed(3))})`;
}

/** The WCAG grade for a ratio: `AAA` / `AA` / `AA-large` / `fail`. */
function pbcGrade(ratio) {
  if (ratio === null) return 'unknown';
  if (ratio >= 7) return 'AAA';
  if (ratio >= 4.5) return 'AA';
  if (ratio >= 3) return 'AA-large';
  return 'fail';
}

/** The colour a translucent surface actually shows, given the page behind it. */
function pbcSurface(color, opacity, behind) {
  const parsed = pbcParse(color);
  if (parsed === null) return color;
  const alpha = Math.max(0, Math.min(1, Number(opacity)));
  return pbcComposite(`rgba(${parsed[0]}, ${parsed[1]}, ${parsed[2]}, ${Number((parsed[3] * alpha).toFixed(3))})`, behind);
}

/**
 * The colours actually painted for a state. The skin takes its palette from the
 * theme table unless the style says `custom`, so the preview and the self-check
 * must resolve it the same way the host does — otherwise switching theme would
 * look (and self-check) like a failure.
 */
function pbcEffectivePalette(ui, presets) {
  const colors = ui?.bubble?.colors ?? {};
  const raw = ui?.appearance?.theme;
  const named = typeof raw === 'string' ? raw : typeof raw?.id === 'string' ? raw.id : '';
  const style = named !== '' ? named : ui?.bubble?.style ?? 'custom';
  const theme = style === 'custom' ? null : presets?.themes?.[style] ?? null;
  return {
    id: style,
    themed: theme !== null,
    mine: theme?.mine ?? colors.mine,
    mineText: theme?.mineText ?? colors.mineText,
    theirs: theme?.theirs ?? colors.theirs,
    theirsText: theme?.theirsText ?? colors.theirsText,
    accent: theme?.accent ?? colors.accent,
  };
}

/**
 * Grade every text-on-surface pair the skin produces. `behind` is the colour
 * the glass sits on (the wallpaper's representative colour, or the page base).
 */
function pbcAudit(ui, behind, presets) {
  const colors = pbcEffectivePalette(ui, presets);
  const material = ui?.material ?? {};
  const kind = typeof pbMaterialOf === 'function' ? pbMaterialOf(ui) : material.kind;
  const opacity = kind === 'solid' ? 1 : kind === 'transparent' ? 0 : Number(material.opacity ?? 0.55);
  const back = behind ?? 'rgb(247, 248, 250)';
  const rows = [];
  const add = (key, fg, bg, size) => {
    const ratio = pbcRatio(fg, bg);
    rows.push({ key, fg, bg, ratio, grade: pbcGrade(ratio), size, pass: ratio !== null && ratio >= (size === 'large' ? 3 : 4.5) });
  };
  add('mine', colors.mineText ?? '#111111', pbcSurface(colors.mine ?? '#95EC69', opacity, back), 'body');
  add('theirs', colors.theirsText ?? '#111111', pbcSurface(colors.theirs ?? '#FFFFFF', opacity, back), 'body');
  return { rows, palette: colors, worst: rows.reduce((acc, row) => (acc === null || (row.ratio ?? 99) < (acc.ratio ?? 99) ? row : acc), null) };
}

/**
 * The honest fix for a failing pair: keep the surface, darken (or lighten) the
 * text until it passes 4.5:1. We never change the user's colour on our own —
 * the panel offers this behind a button.
 */
function pbcSuggestText(background, text) {
  const bg = pbcParse(background);
  const start = pbcParse(text);
  if (bg === null || start === null) return null;
  const light = pbcLuminance(bg) < 0.5;
  const toward = light ? 255 : 0;
  for (let step = 1; step <= 20; step += 1) {
    const weight = step / 20;
    const rgb = [0, 1, 2].map((index) => Math.round(start[index] + (toward - start[index]) * weight));
    const candidate = `#${rgb.map((value) => value.toString(16).padStart(2, '0')).join('')}`;
    if ((pbcRatio(candidate, background) ?? 0) >= 4.5) return candidate;
  }
  return light ? '#ffffff' : '#000000';
}

/** Raise a surface's opacity in 0.05 steps until the pair passes. */
function pbcSuggestOpacity(background, text, from = 0.35) {
  for (let value = Math.max(0, from); value <= 1.0001; value += 0.05) {
    const surface = pbcSurface(background, value, 'rgb(247, 248, 250)');
    if ((pbcRatio(text, surface) ?? 0) >= 4.5) return Number(value.toFixed(2));
  }
  return 1;
}
