/**
 * Shard 60: the panel shell.
 *
 * Header, master switch, the five-tab bar, footer and the shared primitives
 * every tab builds out of. Later shards append their tab to `EXTRA_TABS` in
 * filename order, so the bar reads: personas, appearance, wallpaper, sound,
 * more — five surfaces instead of the old nine.
 */

/** Tabs contributed by later shards, in shard order. */
const EXTRA_TABS = [];

/** The tab list in display order. */
function tabDefs() {
  return [{ id: 'persona', label: 'tabs.persona', render: (props) => h(PersonaTab, props) }, ...EXTRA_TABS];
}

/** The panel itself: one overlay, one card, one scroll body. */
function Panel({ tr }) {
  const state = useStore();
  const tabs = tabDefs();
  const active = tabs.find((tab) => tab.id === state.tab) ?? tabs[0];

  const onMaster = (on) => {
    void runAction('setMaster', { on }, { keepDraft: true, message: on ? tr('master.on') : tr('master.off') });
  };

  return h(
    'div',
    {
      className: 'pb-scrim',
      onClick: (event) => {
        if (event.target === event.currentTarget && !state.busy) closePanel();
      },
    },
    h(
      'div',
      {
        className: 'pb-card',
        role: 'dialog',
        'aria-modal': 'true',
        'aria-label': tr('title'),
        // The skin reads these two: panel radius / tint, and one accent host.
        'data-pb-panel': '1',
      },
      h(
        'div',
        { className: 'pb-head' },
        h(
          'div',
          { className: 'pb-brand' },
          h(PbAvatar, { ui: state?.snapshot?.profiles?.ui, seat: 'panelLogo', size: 44, fallback: h(BrandMark, { size: 44 }) }),
        ),
        h(
          'div',
          { className: 'pb-head-text' },
          h('h2', { className: 'pb-title' }, tr('title')),
          h('p', { className: 'pb-subtitle' }, tr('subtitle')),
        ),
        h(
          'div',
          { className: 'pb-lang', title: tr('lang.hint') },
          h(PbSeg, {
            label: tr('lang.title'),
            value: pbLangPrefGet(),
            disabled: state.busy,
            options: ['zh', 'en', 'auto'].map((mode) => ({ value: mode, label: tr(`lang.${mode}`) })),
            onChange: (mode) => void setPanelLang(mode),
          }),
        ),
        h(
          'button',
          { type: 'button', className: 'pb-icon-button', title: tr('reload'), disabled: state.busy, onClick: () => void loadSnapshot({ keepDraft: true }) },
          '⟳',
        ),
        h('button', { type: 'button', className: 'pb-icon-button', title: tr('close'), disabled: state.busy, onClick: () => closePanel() }, '✕'),
      ),
      h(
        'div',
        { className: 'pb-toggle-row' },
        h(PbSwitchCtl, {
          label: tr('master.label'),
          on: Boolean(state.snapshot?.profiles?.masterOn),
          disabled: state.busy || state.snapshot === null,
          onChange: (value) => onMaster(value),
        }),
        h(
          'div',
          null,
          h('div', { className: 'pb-toggle-label' }, `${tr('master.label')} · ${state.snapshot?.profiles?.masterOn ? tr('master.on') : tr('master.off')}`),
          h('div', { className: 'pb-toggle-hint' }, tr('master.hint')),
        ),
      ),
      h(
        'div',
        { className: 'pb-tabs', role: 'tablist' },
        tabs.map((tab) =>
          h(
            'button',
            {
              key: tab.id,
              type: 'button',
              role: 'tab',
              className: 'pb-tab',
              'data-active': String(tab.id === active.id),
              'aria-selected': String(tab.id === active.id),
              'data-pb-accent': String(tab.id === active.id),
              onClick: () => setState({ tab: tab.id }),
            },
            tr(tab.label),
          ),
        ),
      ),
      h(
        'div',
        { className: 'pb-body' },
        state.error !== null ? h('pre', { className: 'pb-error' }, state.error) : null,
        state.loading && state.snapshot === null ? h('p', { className: 'pb-hint' }, tr('loading')) : null,
        state.snapshot === null ? null : active.render({ tr, forms: state.forms }),
      ),
      h(
        'div',
        { className: 'pb-footer' },
        h(
          'span',
          { className: 'pb-footer-status' },
          state.busy ? tr('saving') : state.dirty ? tr('unsaved') : state.snapshot === null ? '' : `v${state.snapshot.version} · ${state.snapshot.personas.length} ${tr('list.heading')}`,
        ),
        h('button', { type: 'button', className: 'pb-btn', disabled: state.busy || !state.dirty, onClick: () => void loadSnapshot({ keepDraft: false }) }, tr('reload')),
        h('button', { type: 'button', className: 'pb-btn', 'data-variant': 'primary', disabled: state.busy || !state.dirty, onClick: () => void saveDraft() }, tr('save')),
      ),
      state.toast === null ? null : h('div', { className: 'pb-toast', role: 'status' }, state.toast),
    ),
  );
}

/* ------------------------------------------------------------------ *
 * Shared primitives. Every tab is built from these, so the whole panel
 * keeps one Apple-settings vocabulary: a switch, a segmented control, a
 * slider, a settings row and a folded row.
 * ------------------------------------------------------------------ */

/** A labelled field wrapper (kept for the free-form editors). */
function Field({ label, hint, children }) {
  return h(
    'div',
    { className: 'pb-field' },
    label === undefined ? null : h('label', null, label),
    children,
    hint === undefined ? null : h('span', { className: 'pb-hint' }, hint),
  );
}

/** A single-line text input bound to `value`. */
function TextInput({ value, onChange, placeholder, disabled }) {
  return h('input', {
    className: 'pb-input',
    type: 'text',
    value: value ?? '',
    placeholder,
    disabled: Boolean(disabled),
    onChange: (event) => onChange(event.target.value),
  });
}

/** A multi-line text input bound to `value`. */
function TextArea({ value, onChange, rows = 4, mono = false, placeholder }) {
  return h('textarea', {
    className: 'pb-textarea',
    'data-mono': String(mono),
    rows,
    value: value ?? '',
    placeholder,
    spellCheck: false,
    onChange: (event) => onChange(event.target.value),
  });
}

/** A number input with a slider. */
function Slider({ value, min, max, step = 1, onChange, label }) {
  return h(
    'div',
    { className: 'pb-field' },
    h('label', null, `${label} · ${value}`),
    h('input', {
      className: 'pb-slider',
      type: 'range',
      min,
      max,
      step,
      value,
      onChange: (event) => onChange(Number(event.target.value)),
    }),
  );
}

/** A bordered group with a heading (the old section card, still available). */
function Section({ title, hint, children, actions }) {
  return h(
    'section',
    { className: 'pb-section' },
    h(
      'div',
      { className: 'pb-row', 'data-spread': 'true' },
      h('h3', null, title),
      actions === undefined ? null : actions,
    ),
    hint === undefined ? null : h('p', { className: 'pb-hint' }, hint),
    children,
  );
}

/** An iOS-style card: a small caption over a stack of hairline rows. */
function PbGroup({ title, hint, children }) {
  return h(
    'section',
    { className: 'pb-section pb-group-wrap' },
    title === undefined ? null : h('div', { className: 'pb-group-title' }, title),
    hint === undefined ? null : h('p', { className: 'pb-hint' }, hint),
    h('div', { className: 'pb-group' }, children),
  );
}

/** One settings row: label on the left, control on the right. */
function PbRow({ title, hint, control = null, children = null }) {
  return h(
    'div',
    { className: 'pb-row', 'data-role': 'setting' },
    h(
      'div',
      { className: 'pb-row-text' },
      title === undefined ? null : h('div', { className: 'pb-row-title' }, title),
      hint === undefined || hint === null ? null : h('div', { className: 'pb-row-hint' }, hint),
    ),
    control === null ? null : h('div', { className: 'pb-row-control' }, control),
    children === null ? null : h('div', { className: 'pb-row-body' }, children),
  );
}

/** A settings row that unfolds in place. Collapsed unless told otherwise. */
function PbFold({ name, title, hint, children, initiallyOpen = false, control = null }) {
  const [open, setOpen] = React.useState(Boolean(initiallyOpen));
  return h(
    'div',
    { className: 'pb-fold', 'data-open': String(open), 'data-fold': name },
    h(
      'button',
      { type: 'button', className: 'pb-fold-head', 'aria-expanded': String(open), onClick: () => setOpen(!open) },
      h(
        'div',
        { className: 'pb-row-text' },
        h('div', { className: 'pb-row-title' }, title),
        hint === undefined || hint === null ? null : h('div', { className: 'pb-row-hint' }, hint),
      ),
      control === null ? null : h('div', { className: 'pb-row-control' }, control),
      h('span', { className: 'pb-chevron', 'aria-hidden': 'true' }),
    ),
    open ? h('div', { className: 'pb-fold-body' }, children) : null,
  );
}

/** The switch itself, without its label (the header uses this one). */
function PbSwitchCtl({ label, on, onChange, disabled = false }) {
  return h('button', {
    type: 'button',
    className: 'pb-switch',
    'data-on': String(on === true),
    'aria-pressed': String(on === true),
    'aria-label': label,
    disabled: Boolean(disabled),
    onClick: () => onChange(!on),
  });
}

/** A switch row: the knob plus its label (and an optional hint). */
function PbSwitch({ label, hint, on, checked, onChange, disabled = false }) {
  const value = on === undefined ? checked === true : on === true;
  return h(
    'div',
    { className: 'pb-row', 'data-role': 'setting' },
    h(
      'div',
      { className: 'pb-row-text' },
      h('div', { className: 'pb-row-title' }, label),
      hint === undefined || hint === null ? null : h('div', { className: 'pb-row-hint' }, hint),
    ),
    h('div', { className: 'pb-row-control' }, h(PbSwitchCtl, { label, on: value, onChange, disabled })),
  );
}

/** A segmented control: exactly one option is active. */
function PbSeg({ options, value, onChange, disabled = false, label }) {
  return h(
    'div',
    { className: 'pb-seg', role: 'group', 'aria-label': label },
    options.map((option) =>
      h(
        'button',
        {
          key: String(option.value),
          type: 'button',
          className: 'pb-seg-item',
          'data-active': String(option.value === value),
          'aria-pressed': String(option.value === value),
          disabled: Boolean(disabled),
          onClick: () => onChange(option.value),
        },
        option.label,
      ),
    ),
  );
}

/** Older name for the same control. */
function PbSegmented(props) {
  return h(PbSeg, props);
}

/** A slider that previews on every step and commits when the drag ends. */
function PbSlider({ label, value, min, max, step = 1, suffix = '', onInput, onCommit }) {
  return h(
    'div',
    { className: 'pb-field' },
    h('label', null, `${label} · ${value}${suffix}`),
    h('input', {
      className: 'pb-slider',
      type: 'range',
      min,
      max,
      step,
      value,
      onChange: (event) => onInput(Number(event.target.value)),
      onPointerUp: () => onCommit(),
      onKeyUp: () => onCommit(),
      onBlur: () => onCommit(),
      onTouchEnd: () => onCommit(),
    }),
  );
}

/** A colour swatch with a text field, previewing instantly and committing on change. */
function PbColor({ label, value, onChange }) {
  return h(
    'div',
    { className: 'pb-field' },
    h('label', null, label),
    h(
      'div',
      { className: 'pb-row' },
      h('input', {
        className: 'pb-color',
        type: 'color',
        value: value ?? '#000000',
        onChange: (event) => onChange(event.target.value),
      }),
      h('input', {
        className: 'pb-input',
        type: 'text',
        value: value ?? '',
        spellCheck: false,
        onChange: (event) => {
          if (/^#[0-9a-fA-F]{3,8}$/.test(event.target.value.trim())) onChange(event.target.value.trim());
        },
      }),
    ),
  );
}

/** A primary / ghost / danger button in the Apple style. */
function PbBtn({ children, variant, block = false, disabled = false, onClick, title }) {
  return h(
    'button',
    {
      type: 'button',
      className: 'pb-btn',
      'data-variant': variant,
      'data-block': String(block === true),
      disabled: Boolean(disabled),
      title,
      onClick,
    },
    children,
  );
}

/** A select bound to `value`. */
function Select({ value, options, onChange }) {
  return h(
    'select',
    { className: 'pb-select', value, onChange: (event) => onChange(event.target.value) },
    options.map((option) => h('option', { key: option.value, value: option.value }, option.label)),
  );
}

/** Split a comma / newline separated list string. */
function splitList(text) {
  return String(text ?? '')
    .split(/[\n、,，]/)
    .map((entry) => entry.trim())
    .filter(Boolean);
}

/** Join a list for a textarea / input. */
function joinList(list, separator = '\n') {
  return Array.isArray(list) ? list.join(separator) : '';
}
