/**
 * Shard 68: M2 wiring.
 *
 * Three jobs, all additive: register the appearance tab, give the panel a small
 * user-preset editor, and keep the document in step with the stored appearance
 * from boot onwards (the panel is not the only thing that changes it — a second
 * tab, a hot reload or the safe switch can too).
 */

EXTRA_TABS.push({
  id: 'appearance',
  label: 'tabs.appearance',
  render: (props) => h(AppearanceTab, props),
});

/** Name the current section, or put a saved one back. */
function PresetEditor({ tr, ui, snapshot, sectionCommit }) {
  const state = useStore();
  const [name, setName] = React.useState('');
  const [section, setSection] = React.useState('bubble');
  const mine = Array.isArray(ui.presets?.mine) ? ui.presets.mine : [];
  const sections = ['bubble', 'material', 'appearance'];
  const write = (entries, message) =>
    void runAction('setUi', { section: 'presets', patch: { mine: entries } }, { keepDraft: true, message });
  const save = () => {
    const trimmed = name.trim();
    if (trimmed === '') return;
    const entry = {
      id: `p${Date.now().toString(36)}${mine.length}`,
      name: trimmed,
      section,
      at: Date.now(),
      value: structuredClone(ui[section]),
    };
    write([entry, ...mine.filter((item) => item.name !== trimmed)].slice(0, 20), tr('preset.saved'));
    setName('');
  };
  return h(
    React.Fragment,
    null,
    h(
      Field,
      { label: tr('preset.name'), hint: tr('preset.nameHint') },
      h(
        'div',
        { className: 'pb-row' },
        h(TextInput, { value: name, onChange: setName, placeholder: tr('preset.placeholder'), disabled: state.busy }),
        h(Select, {
          value: section,
          options: sections.map((value) => ({ value, label: tr(`preset.section.${value}`) })),
          onChange: setSection,
        }),
        h('button', { type: 'button', className: 'pb-btn', 'data-variant': 'primary', disabled: state.busy || name.trim() === '', onClick: save }, tr('preset.save')),
      ),
    ),
    mine.length === 0
      ? h('p', { className: 'pb-hint' }, tr('preset.empty'))
      : h(
          'ul',
          { className: 'pb-list' },
          mine.map((entry) =>
            h(
              'li',
              { key: entry.id, className: 'pb-list-row' },
              h(
                'div',
                { className: 'pb-list-text' },
                h('span', { className: 'pb-list-title' }, entry.name),
                h('span', { className: 'pb-hint' }, `${tr(`preset.section.${entry.section}`)} · ${new Date(entry.at).toLocaleString()}`),
              ),
              h(
                'div',
                { className: 'pb-row' },
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'pb-btn',
                    disabled: state.busy,
                    onClick: () =>
                      sectionCommit(entry.section, (next) => {
                        next[entry.section] = structuredClone(entry.value);
                      }),
                  },
                  tr('preset.apply'),
                ),
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'pb-btn',
                    disabled: state.busy,
                    onClick: () => write(mine.filter((item) => item.id !== entry.id), tr('preset.removed')),
                  },
                  tr('preset.remove'),
                ),
              ),
            ),
          ),
        ),
  );
}

/**
 * Keep `documentElement` in step with the stored appearance.
 *
 * Runs once at mount and then on every store change; `rev` is the guard, so a
 * burst of previews (which apply themselves) does not re-fetch the stylesheet.
 */
function pbMountAppearance(ctx) {
  if (pbNativeMounted) return () => {};
  const forms = chatForms(ctx);
  setState({ forms });
  let lastRev = null;
  const sync = () => {
    const snapshot = getState().snapshot;
    const ui = snapshot?.profiles?.ui ?? null;
    if (ui === null || snapshot.rev === lastRev) return;
    lastRev = snapshot.rev;
    if (pbSafeOn(ui)) {
      pbClearAppearance();
      pbRemoveSkin();
      return;
    }
    void pbSyncBubble(ui, forms, snapshot.rev, snapshot.presets);
  };
  // The cues ride on the same lifetime as the skin: one observer, started once.
  pbAttachSound(() => getState().snapshot?.profiles?.ui);
  sync();
  return subscribe(sync);
}

/** Teardown for the appearance effect (closing the tab leaves no attributes). */
function pbUnmountAppearance() {
  pbDetachSound();
  pbClearAppearance();
  pbRemoveSkin();
}
