/**
 * Shard 99: registration.
 *
 * The module's public surface: the dictionary namespace, the sidebar button and
 * the overlay panel. Everything before this shard is definitions; this is where
 * they are handed to the host.
 */

/** Required services (cordis fiber inject). */
const inject = ['slots', 'locale'];

/**
 * A thin wrapper over the official ui-chat config form, so the panel can read
 * (and later restore) the transcript view the bubble skin switches.
 */
function chatForms(ctx) {
  const form = () => {
    try {
      return ctx.configForms?.get?.('ui-chat') ?? null;
    } catch {
      return null;
    }
  };
  return {
    get() {
      try {
        return form()?.getSnapshot?.().value ?? null;
      } catch {
        return null;
      }
    },
    set(key, value) {
      try {
        form()?.set?.(key, value);
      } catch {
        /* the config form is optional: a missing one just means no bubble skin */
      }
    },
    available() {
      return form() !== null;
    },
  };
}

/** Mount the sidebar button and the overlay panel. */
function apply(ctx) {
  // Not ctx.locale.bind: the panel owns its language (see 10-i18n.js), so a
  // Chinese reader on an English app still gets Chinese chrome.
  const t = (key, params) => pbTr(key, params);
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-persona-book: dictionaries');
  ctx.effect(() => {
    return pbMountHostChat();
  }, 'dsh-persona-book: original host chat');
  ctx.effect(() => {
    const disposeStyle = ensureStyle();
    return () => { closePanel(); pbSharedSnapshot = null; disposeStyle(); };
  }, 'dsh-persona-book: native surface');
  ctx.effect(() => {
    // The appearance lives outside the panel: bubbles and materials must stay
    // applied while the panel is closed, so this effect owns them, not the panel.
    const unsubscribe = pbMountAppearance(ctx);
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
      pbUnmountAppearance();
    };
  }, 'dsh-persona-book: appearance');
  ctx.effect(
    () =>
      ctx.slots.inject('shell.overlay', () =>
        ctx.slots.register(
          {
            name: 'shell.overlay',
            id: 'persona-book-panel',
            locale: NS,
            inject: () => ({ tr: t, forms: chatForms(ctx) }),
          },
          PanelSeat,
        ),
      ),
    'dsh-persona-book: panel overlay',
  );
  ctx.effect(
    () =>
      ctx.slots.inject('sidebar.footer.action', () =>
        ctx.slots.register(
          { name: 'sidebar.footer.action', id: 'persona-book', order: 30, locale: NS, inject: () => ({ tr: t }) },
          OpenButton,
        ),
      ),
    'dsh-persona-book: sidebar button',
  );
  ctx.effect(() => pbMountContext(ctx.slots, PersonaContextSeat, () => ({tr:t})), 'dsh-persona-book: context chip');
  ctx.effect(() => ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({name:'conversation.input.dock',id:'persona-book-session-controls',order:20,locale:NS},HostSessionControls)), 'dsh-persona-book: active session controls');
}

/**
 * Pure helpers the bundle tests read through. They are not part of the plugin
 * API: the host must never depend on them.
 */
exports.__debug = {
  pbMountContext,
  pbSharedRole,
  PB_CONTEXT_WAIT,
  tabDefs,
  pbTr,
  pbLangUse,
  pbLangNow,
  pbLangPrefGet,
  setPanelLang,
  getState,
  setState,
  EXTRA_TABS,
  pbWallpaperOf,
  pbWallpaperSpec,
  pbThemeOf,
  pbMaterialOf,
  pbBubbleShapeOf,
  pbAvatarShapeOf,
  pbBubbleRadius,
  PB_THEMES,
  PB_BUBBLE_MATERIALS,
  PB_BUBBLE_SHAPES,
  PB_AVATAR_SHAPES,
  PB_SHAPE_RADIUS,
  PB_EXPORT_FORMATS,
  applyAppearance,
  pbcEffectivePalette,
  pbcAudit,
  pbcSurface,
  pbcRatio,
  pbVarList,
  pbClampList: null,
  pbCueEvents,
  pbCueIds: PB_CUE_IDS,
  pbCueFor,
  pbSoundPlay,
  pbSoundPreview,
  pbSoundState,
};

exports.NS = NS;
exports.apply = apply;
exports.inject = inject;
