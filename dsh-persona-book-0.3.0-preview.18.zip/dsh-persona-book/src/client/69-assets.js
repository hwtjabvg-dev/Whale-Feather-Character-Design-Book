/**
 * Shard 69: the wallpaper tab (and the avatar seats, reused by the look tab).
 *
 * A gallery of full-bleed backgrounds, galgame style: one `+` tile that takes a
 * click or a drop, then a grid of thumbnails where a tap sets the wallpaper and
 * the corner button deletes it. Resolution is never a reason to refuse a file —
 * the host sniffs the real format and the thumbnails use `object-fit`, so a
 * 12000 px panorama and a 64 px icon take the same path.
 */

EXTRA_TABS.push({
  id: 'wallpaper',
  label: 'tabs.wallpaper',
  render: (props) => h(WallpaperTab, props),
});

/** Human size for a byte count, with the unit the panel shows. */
function pbBytes(value) {
  const size = Number(value) || 0;
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${Math.round(size / 102.4) / 10} KB`;
  return `${Math.round(size / 1024 / 104.8576) / 10} MB`;
}

/** One uploadable zone: click or drop, same handler, same busy state. */
function PbDrop({ tr, accept, kind, busy, onFile, children }) {
  const [over, setOver] = React.useState(false);
  const inputRef = React.useRef(null);
  return h(
    'div',
    {
      className: 'pb-drop',
      'data-over': String(over),
      'data-busy': String(busy),
      onClick: () => inputRef.current?.click(),
      onDragOver: (event) => {
        event.preventDefault();
        setOver(true);
      },
      onDragLeave: () => setOver(false),
      onDrop: (event) => {
        event.preventDefault();
        setOver(false);
        const file = event.dataTransfer?.files?.[0];
        if (file !== undefined) onFile(file);
      },
    },
    h('input', {
      ref: inputRef,
      className: 'pb-file',
      type: 'file',
      accept,
      onChange: (event) => {
        const file = event.target.files?.[0];
        event.target.value = '';
        if (file !== undefined) onFile(file);
      },
    }),
    h('div', { className: 'pb-drop-title' }, busy ? tr('wall.uploading') : tr(`assets.drop.${kind}`)),
    h('div', { className: 'pb-drop-hint' }, tr(`assets.accept.${kind}`)),
    children ?? null,
  );
}

/** A thumbnail card for one stored asset. */
function PbAssetCard({ tr, entry, onDelete, onUse, active, action }) {
  return h(
    'div',
    { className: 'pb-asset', 'data-active': String(active === true) },
    h(
      'div',
      { className: 'pb-thumb' },
      entry.kind === 'sound'
        ? h('span', { className: 'pb-thumb-glyph' }, '♪')
        : h('img', { src: entry.preview, alt: entry.name, loading: 'lazy' }),
      entry.extreme === true ? h('span', { className: 'pb-badge', title: tr('assets.extremeHint') }, tr('assets.extreme')) : null,
    ),
    h('div', { className: 'pb-asset-name', title: entry.name }, entry.name),
    h(
      'div',
      { className: 'pb-asset-meta' },
      entry.width === null ? pbBytes(entry.bytes) : `${entry.width}×${entry.height} · ${pbBytes(entry.bytes)}`,
    ),
    h(
      'div',
      { className: 'pb-asset-actions' },
      onUse === undefined ? null : h('button', { type: 'button', className: 'pb-mini', onClick: () => onUse(entry) }, action ?? tr('assets.use')),
      h('button', { type: 'button', className: 'pb-mini pb-mini-danger', onClick: () => onDelete(entry, false) }, tr('assets.remove')),
      h('button', { type: 'button', className: 'pb-mini pb-mini-danger', title: tr('assets.forceHint'), onClick: () => onDelete(entry, true) }, tr('assets.removeForce')),
    ),
  );
}

/**
 * The `+` tile: a click or a drop, in the same shape as the wallpapers around
 * it. Any image format is welcome; the host sniffs the real type.
 */
function PbTile({ tr, busy, onFile }) {
  const [over, setOver] = React.useState(false);
  const inputRef = React.useRef(null);
  return h(
    'div',
    {
      className: 'pb-tile',
      role: 'button',
      tabIndex: 0,
      'data-over': String(over),
      'data-busy': String(busy),
      onClick: () => inputRef.current?.click(),
      onKeyDown: (event) => {
        if (event.key === 'Enter' || event.key === ' ') inputRef.current?.click();
      },
      onDragOver: (event) => {
        event.preventDefault();
        setOver(true);
      },
      onDragLeave: () => setOver(false),
      onDrop: (event) => {
        event.preventDefault();
        setOver(false);
        const file = event.dataTransfer?.files?.[0];
        if (file !== undefined) onFile(file);
      },
    },
    h('input', {
      ref: inputRef,
      className: 'pb-file',
      type: 'file',
      accept: 'image/*',
      onChange: (event) => {
        const file = event.target.files?.[0];
        event.target.value = '';
        if (file !== undefined) onFile(file);
      },
    }),
    h('span', { className: 'pb-tile-plus' }, busy ? '…' : '+'),
    h('span', { className: 'pb-tile-label' }, busy ? tr('wall.uploading') : tr('wall.add')),
  );
}

/**
 * The four avatar seats. Shared: the look tab renders it too, because the
 * picture behind an avatar and the shape in front of it are one decision.
 */
function AvatarSeats({ tr }) {
  const state = useStore();
  const snapshot = state.snapshot;
  const [busy, setBusy] = React.useState(null);
  const [pending, setPending] = React.useState(null);
  const [inUse, setInUse] = React.useState(null);
  const rev = snapshot?.rev ?? null;
  React.useEffect(() => {
    setPending(null);
  }, [rev]);
  const ui = pending ?? snapshot?.profiles?.ui ?? null;
  if (ui === null || snapshot === null) return h('p', { className: 'pb-hint' }, tr('loading'));

  const assets = snapshot.assets ?? { avatars: [], library: {} };
  const seats = [
    { id: 'assistant', label: tr('assets.seat.assistant') },
    { id: 'user', label: tr('assets.seat.user') },
    { id: 'sidebarIcon', label: tr('assets.seat.sidebarIcon') },
    { id: 'panelLogo', label: tr('assets.seat.panelLogo') },
  ];

  const write = (seat, patch, message) => {
    const seatValue = { ...(ui.avatar?.[seat] ?? {}), ...patch };
    applyAppearance({ ...ui, avatar: { ...ui.avatar, [seat]: seatValue } }, { rev });
    void runAction('setUi', { section: 'avatar', patch: { [seat]: seatValue } }, { keepDraft: true, message });
  };

  const upload = async (file) => {
    setBusy('avatar');
    try {
      const result = await apiUpload('avatar', file, file.name);
      await loadSnapshot({ keepDraft: true });
      toast(result.reused ? tr('assets.reused') : tr('assets.uploaded'));
    } catch (error) {
      toast(error.message ?? tr('failed'), 'error');
    } finally {
      setBusy(null);
    }
  };

  const remove = async (entry, force) => {
    try {
      await apiDeleteAsset(entry.id, force);
      setInUse(null);
      await loadSnapshot({ keepDraft: true });
      toast(tr('assets.removed'));
    } catch (error) {
      if (error.code === 'ECONFLICT' && !force) {
        setInUse(entry.id);
        toast(tr('assets.inUse'), 'error');
        return;
      }
      toast(error.message ?? tr('failed'), 'error');
    }
  };

  return h(
    React.Fragment,
    null,
    h(PbDrop, {
      tr,
      kind: 'avatar',
      accept: 'image/*',
      busy: busy === 'avatar',
      onFile: (file) => void upload(file),
    }),
    seats.map((seat) =>
      h(
        'div',
        { key: seat.id, className: 'pb-seat' },
        h('div', { className: 'pb-seat-label' }, seat.label),
        h(
          'div',
          { className: 'pb-grid pb-grid-avatar' },
          (assets.avatars ?? []).length === 0
            ? h('p', { className: 'pb-hint' }, tr('assets.noAvatars'))
            : assets.avatars.map((entry) =>
                h(PbAssetCard, {
                  key: `${seat.id}-${entry.id}`,
                  tr,
                  entry,
                  active: ui.avatar?.[seat.id]?.assetId === entry.id,
                  action: tr('assets.useIcon'),
                  onUse: () => write(seat.id, { assetId: entry.id, fallback: 'builtin:plugin-icon' }, tr('assets.avatarSet')),
                  onDelete: remove,
                }),
              ),
        ),
        h(
          'div',
          { className: 'pb-inline' },
          h(PbSeg, {
            options: [
              { value: 'builtin:plugin-icon', label: tr('assets.fallback.icon') },
              { value: 'initial', label: tr('assets.fallback.initial') },
            ],
            value: ui.avatar?.[seat.id]?.fallback ?? 'builtin:plugin-icon',
            onChange: (fallback) => write(seat.id, { fallback }, tr('assets.saved')),
          }),
          ui.avatar?.[seat.id]?.assetId === null || ui.avatar?.[seat.id]?.assetId === undefined
            ? null
            : h('button', { type: 'button', className: 'pb-mini', onClick: () => write(seat.id, { assetId: null }, tr('assets.saved')) }, tr('assets.clearImage')),
        ),
      ),
    ),
    inUse === null ? null : h('p', { className: 'pb-hint pb-warn' }, tr('assets.inUseHint')),
  );
}

/** The wallpaper tab: the gallery, then fit / fullscreen / dim / blur. */
function WallpaperTab({ tr }) {
  const state = useStore();
  const snapshot = state.snapshot;
  const [busy, setBusy] = React.useState(false);
  const [pending, setPending] = React.useState(null);
  const [inUse, setInUse] = React.useState(null);
  const rev = snapshot?.rev ?? null;
  React.useEffect(() => {
    setPending(null);
  }, [rev]);
  const ui = pending ?? snapshot?.profiles?.ui ?? null;
  const uiRef = React.useRef(ui);
  uiRef.current = ui;
  if (ui === null || snapshot === null) return h('p', { className: 'pb-hint' }, tr('loading'));

  const assets = snapshot.assets ?? { wallpapers: [], usage: {}, limits: {}, library: {} };
  const builtin = snapshot.builtin?.wallpapers ?? [];
  const usage = assets.usage ?? {};
  const quota = usage.quota ?? 512 * 1024 * 1024;
  const used = usage.bytes ?? 0;
  const pct = Math.min(100, Math.round((used / quota) * 100));
  const spec = pbWallpaperSpec(ui);
  const current = pbWallpaperOf(ui);

  /** Write the whole `appearance` row: the host shallow-merges without a section. */
  const look = (mutator, message) => {
    const next = structuredClone(uiRef.current);
    if (next.appearance === null || typeof next.appearance !== 'object') next.appearance = {};
    if (next.appearance.wallpaper === null || typeof next.appearance.wallpaper !== 'object') next.appearance.wallpaper = {};
    mutator(next.appearance.wallpaper);
    uiRef.current = next;
    setPending(next);
    applyAppearance(next, { rev });
    void runAction('setUi', { patch: { appearance: structuredClone(next.appearance) } }, { keepDraft: true, message });
  };

  const upload = async (file, then) => {
    setBusy(true);
    try {
      const result = await apiUpload('wallpaper', file, file.name);
      await loadSnapshot({ keepDraft: true });
      toast(result.reused ? tr('assets.reused') : tr('assets.uploaded'));
      if (then !== undefined && result.entry !== undefined) then(result.entry);
    } catch (error) {
      toast(error.message ?? tr('failed'), 'error');
    } finally {
      setBusy(false);
    }
  };

  const remove = async (entry, force) => {
    try {
      await apiDeleteAsset(entry.id, force);
      setInUse(null);
      await loadSnapshot({ keepDraft: true });
      toast(tr('assets.removed'));
    } catch (error) {
      if (error.code === 'ECONFLICT' && !force) {
        setInUse(entry.id);
        toast(tr('assets.inUse'), 'error');
        return;
      }
      toast(error.message ?? tr('failed'), 'error');
    }
  };

  const useEntry = (id, message) => look((wallpaper) => {
    wallpaper.id = id;
  }, message);

  return h(
    React.Fragment,
    null,
    h(
      PbGroup,
      { title: tr('wall.heading'), hint: tr('wall.hint') },
      h(
        'div',
        { className: 'pb-walls' },
        h(PbTile, {
          tr,
          busy,
          onFile: (file) => void upload(file, (entry) => useEntry(`asset:${entry.id}`, tr('wall.set'))),
        }),
        h(
          'button',
          {
            type: 'button',
            className: 'pb-wall',
            'data-active': String(spec.id === ''),
            onClick: () => useEntry('', tr('wall.current')),
          },
          h('span', { className: 'pb-wall-swatch', 'data-empty': 'true' }),
          h('span', { className: 'pb-wall-label' }, tr('wall.none')),
        ),
        builtin.map((entry) =>
          h(
            'button',
            {
              key: entry.id,
              type: 'button',
              className: 'pb-wall',
              'data-builtin': entry.id,
              'data-active': String(current.kind === 'builtin' && current.id === entry.id),
              onClick: () => useEntry(`builtin:${entry.id}`, tr('wall.set')),
            },
            h('span', { className: 'pb-wall-swatch' }),
            h('span', { className: 'pb-wall-label' }, tr(`assets.wall.${entry.id}`) ?? entry.label),
          ),
        ),
        (assets.wallpapers ?? []).map((entry) =>
          h(
            'div',
            { key: entry.id, className: 'pb-wall', 'data-active': String(spec.id === `asset:${entry.id}`) },
            h(
              'button',
              { type: 'button', className: 'pb-wall-pick', onClick: () => useEntry(`asset:${entry.id}`, tr('wall.set')) },
              h('img', { className: 'pb-wall-img', src: entry.preview, alt: entry.name, loading: 'lazy' }),
              h('span', { className: 'pb-wall-label', title: entry.name }, entry.name),
            ),
            h(
              'button',
              { type: 'button', className: 'pb-wall-del', title: tr('wall.remove'), onClick: () => void remove(entry, false) },
              '✕',
            ),
          ),
        ),
      ),
      (assets.wallpapers ?? []).length === 0 ? h('p', { className: 'pb-hint' }, tr('wall.empty')) : null,
    ),
    h(
      PbGroup,
      { title: tr('wall.fit') },
      h(PbRow, {
        title: tr('wall.fullscreen'),
        hint: tr('wall.fullscreenHint'),
        control: h(PbSwitchCtl, {
          label: tr('wall.fullscreen'),
          on: spec.fullscreen === true,
          disabled: state.busy,
          onChange: (on) => look((wallpaper) => {
            wallpaper.fullscreen = on;
          }),
        }),
      }),
      h(PbRow, {
        title: tr('wall.fit'),
        control: h(PbSeg, {
          label: tr('wall.fit'),
          value: spec.fit,
          disabled: state.busy,
          options: [
            { value: 'cover', label: tr('wall.fitCover') },
            { value: 'contain', label: tr('wall.fitContain') },
            { value: 'tile', label: tr('wall.fitTile') },
          ],
          onChange: (value) => look((wallpaper) => {
            wallpaper.fit = value;
          }),
        }),
      }),
      h(PbSlider, {
        label: tr('wall.dim'),
        value: spec.dim,
        min: 0,
        max: 60,
        suffix: '%',
        onInput: (value) => look((wallpaper) => {
          wallpaper.dim = value;
        }),
        onCommit: () => undefined,
      }),
      h(PbSlider, {
        label: tr('wall.blur'),
        value: spec.blur,
        min: 0,
        max: 60,
        suffix: 'px',
        onInput: (value) => look((wallpaper) => {
          wallpaper.blur = value;
        }),
        onCommit: () => undefined,
      }),
    ),
    h(
      PbGroup,
      { title: tr('assets.libraryTitle'), hint: tr('assets.libraryHint') },
      h(
        'div',
        { className: 'pb-meter' },
        h('div', { className: 'pb-meter-bar' }, h('div', { className: 'pb-meter-fill', style: { width: `${pct}%` } })),
        h(
          'div',
          { className: 'pb-meter-text' },
          `${pbBytes(used)} / ${pbBytes(quota)} · ${tr('assets.files', { count: usage.files ?? 0 })}`,
        ),
      ),
      h(PbRow, {
        title: tr('assets.tab.wallpapers', { count: assets.wallpapers.length, max: assets.library?.wallpaper ?? 60 }),
        hint: tr('assets.tab.avatars', { count: assets.avatars?.length ?? 0, max: assets.library?.avatar ?? 40 }),
      }),
      inUse === null ? null : h('p', { className: 'pb-hint pb-warn' }, tr('assets.inUseHint')),
    ),
  );
}
