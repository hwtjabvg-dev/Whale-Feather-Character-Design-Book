/** dsh-web-all / Git 图 0.4.6 的插槽、令牌与选择器交互基准。 */
const PB_PLAY = `${ENDPOINT}/play`;
const PB_CONTEXT_WAIT = 2000;
let pbSharedSnapshot = null;

async function pbSharedRequest(route, body) {
  const response = await fetch(PB_PLAY + route, {
    method: body === undefined ? 'GET' : 'POST',
    headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const value = await response.json();
  if (!response.ok) throw new Error(value.error?.message || '人设本暂时无法连接，请确认插件已启用。');
  return value;
}

function pbSharedRole(snapshot) {
  const chat = snapshot?.conversations?.find(c => c.id === snapshot.activeConversation);
  return snapshot?.personas?.find(p => p.id === (chat?.activeMember || chat?.members?.[0])) || snapshot?.personas?.[0];
}

/** 有声明时立即注册；缺失时等待后降级，卸载撤销等待、定时器和唯一入口。 */
function pbMountContext(slots, component, injected, clock = globalThis) {
  let mounted = false, disposed = false, timer, waiting, seat;
  const mount = name => {
    if (disposed || mounted) return undefined;
    try {
      const dispose = slots.register({ name, id: 'persona-book-context', order: 110, locale: NS, inject: injected }, component);
      mounted = true;
      seat = dispose;
      return undefined;
    } catch { return undefined; }
  };
  waiting = slots.inject('conversation.input.selector.context', () => mount('conversation.input.selector.context'));
  if (!mounted) timer = clock.setTimeout(() => {
    if (disposed || mounted) return;
    if (typeof waiting === 'function') waiting();
    waiting = slots.inject('conversation.input.dock', () => mount('conversation.input.dock'));
  }, PB_CONTEXT_WAIT);
  return () => {
    disposed = true;
    if (timer !== undefined) clock.clearTimeout(timer);
    if (typeof waiting === 'function') waiting();
    if (typeof seat === 'function') seat();
  };
}

/** 空会话入口；当前会话不放额外选择器，侧栏入口始终保留。 */
function PersonaContextSeat(props) {
  const store = useStore();
  const fromSessions = typeof props.useSessions === 'function'
    ? props.useSessions(s => s.byId?.[props.sessionId]?.blank === true) : false;
  const blank = props.session?.blank === true || fromSessions;
  const dock = 'input' in props && 'session' in props;
  const [expanded, setExpanded] = React.useState(false);
  const [snapshot, setSnapshot] = React.useState(pbSharedSnapshot);
  const [query, setQuery] = React.useState('');
  const [error, setError] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const anchor = React.useRef(null), button = React.useRef(null), search = React.useRef(null);
  const [target, setTarget] = React.useState(null);
  React.useEffect(() => {
    if (!blank) { setExpanded(false); return; }
    let live = true;
    pbSharedRequest('/host/state?sessionId='+encodeURIComponent(props.sessionId||'')).then(s => { if (live) { pbSharedSnapshot = s; setSnapshot(s); } }).catch(e => { if (live) setError(e.message); });
    return () => { live = false; };
  }, [blank, store.open, props.sessionId]);
  React.useEffect(() => {
    if (!dock || !blank) { setTarget(null); return; }
    const find = () => {
      const stack = anchor.current?.closest('[class*="composerStack"], [class*="composerHero"]');
      const row = stack?.querySelector('[class*="heroWorkspaceRow"]');
      setTarget(row || null);
    };
    find();
    const observer = new MutationObserver(find);
    const parent = anchor.current?.parentElement?.parentElement;
    if (parent) observer.observe(parent, { childList: true });
    return () => observer.disconnect();
  }, [dock, blank]);
  React.useEffect(() => {
    if (!expanded) return;
    search.current?.focus();
    const key = event => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); setExpanded(false); button.current?.focus(); }
    };
    document.addEventListener('keydown', key, true);
    return () => document.removeEventListener('keydown', key, true);
  }, [expanded]);
  if (!blank) return null;
  const selected = snapshot?.role || pbSharedRole(snapshot);
  const rows = (snapshot?.personas || []).filter(p => [p.title, p.summary, p.identity?.selfName].join(' ').toLowerCase().includes(query.toLowerCase()));
  const close = () => { setExpanded(false); button.current?.focus(); };
  const open = view => { close(); openPanel(view,props.sessionId); };
  const choose = async id => {
    if (busy) return;
    setBusy(true); setError('');
    try {
      const response = await pbHostChoose(id,undefined,props.sessionId);
      pbSharedSnapshot = response; setSnapshot(response); close();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };
  const content = h('div', { className: 'pb-context-anchor', 'data-dsh-plugin': 'persona-book', 'data-pb-hero': 'true' },
    h('button', { ref: button, type: 'button', className: 'pb-context-chip', 'aria-label': '选择人设', 'aria-expanded': expanded, 'aria-haspopup': 'dialog', onClick: () => { setQuery(''); setExpanded(v => !v); } },
      h(BrandMark, { size: 17 }), h('span', null, selected?.title || '人设本'), h('span', { 'aria-hidden': true }, '⌄')),
    expanded && h(React.Fragment, null,
      h('div', { className: 'pb-context-backdrop', onClick: close }),
      h('div', { className: 'pb-context-popover', style: {left:Math.min(0,window.innerWidth-14-(button.current?.getBoundingClientRect().left||0)-Math.min(280,window.innerWidth-28))}, role: 'dialog', 'aria-label': '人设选择器', onKeyDown: e => {
        if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) return;
        const nodes = [...e.currentTarget.querySelectorAll('button:not([disabled])')];
        if (!nodes.length) return;
        const index = nodes.indexOf(document.activeElement);
        const next = e.key === 'Home' ? 0 : e.key === 'End' ? nodes.length - 1 : (index + (e.key === 'ArrowUp' ? -1 : 1) + nodes.length) % nodes.length;
        e.preventDefault(); nodes[next].focus();
      } },
        h('label', { className: 'pb-context-search' }, h('span', { 'aria-hidden': true }, '⌕'), h('input', { ref: search, value: query, placeholder: '搜索人设…', 'aria-label': '搜索人设', onChange: e => setQuery(e.target.value) })),
        error && h('p', { className: 'pb-context-error', role: 'alert' }, error),
        h('div', { className: 'pb-context-list' }, rows.length ? rows.map(p => h('button', { key: p.id, type: 'button', className: 'pb-context-item', disabled: busy, onClick: () => choose(p.id), 'aria-pressed': p.id === selected?.id },
          h('span', { className: 'pb-context-item-text' }, h('strong', { title: p.title }, p.title), h('small', null, `${p.builtin ? '内置原稿' : '个人版本'} · ${p.defaults?.toneIntensity || 3} 档`)),
          p.id === selected?.id && h('span', { className: 'pb-context-check', 'aria-hidden': true }, '✓'))) : h('p', { className: 'pb-context-empty' }, snapshot ? '没有匹配的人设。' : '正在读取人设…')),
        h('div', { className: 'pb-context-footer' },
          h('button', { type: 'button', onClick: () => {close();document.querySelector('[data-composer-input] [contenteditable=true], [data-composer-input], textarea')?.focus();} }, '回到当前聊天', h('small', null, '↗')),
          h('button', { type: 'button', onClick: () => open('settings') }, '人设与语气设置'),
          h('button', { type: 'button', onClick: () => open('roles') }, '人设库'),
          h('button', { type: 'button', onClick: () => open('workshop') }, '创意工坊')))));
  let portal;
  try { portal = require('react-dom').createPortal; } catch { /* 旧宿主保留 dock 位置。 */ }
  return h('span', { ref: anchor, className: 'pb-context-seat' }, target && portal ? portal(content, target) : content);
}
