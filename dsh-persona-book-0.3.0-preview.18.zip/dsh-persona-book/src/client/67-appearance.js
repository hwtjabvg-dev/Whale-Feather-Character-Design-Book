/**
 * Shard 67: the appearance tab.
 *
 * Three preview cards for the skin, then the two segmented controls that pick a
 * bubble material and a bubble shape — the whole surface, few and large. The
 * fine print (bubble switches, colours, material sliders, saved presets) lives
 * behind one folded row, and the old deformer is gone for good.
 */

/** Two sample bubbles plus the live contrast badges. */
function PreviewStrip({ tr, ui, presets }) {
  const palette = pbcEffectivePalette(ui, presets);
  const kind = pbMaterialOf(ui);
  const opacity = kind === 'solid' ? 1 : kind === 'transparent' ? 0 : Number(ui?.material?.opacity ?? 0.55);
  const radius = kind === 'solid' && false ? 0 : pbBubbleRadius(ui);
  const mine = pbcSurface(palette.mine, opacity, 'rgb(247, 248, 250)');
  const theirs = pbcSurface(palette.theirs, opacity, 'rgb(247, 248, 250)');
  const ratioMine = pbcRatio(palette.mineText, mine);
  const ratioTheirs = pbcRatio(palette.theirsText, theirs);
  const badge = (ratio) => {
    const grade = pbcGrade(ratio);
    return h('span', { className: 'pb-badge', 'data-tone': grade === 'fail' ? 'bad' : grade === 'AA-large' ? 'warn' : 'good' }, `${ratio === null ? '—' : ratio.toFixed(2)}:1 · ${grade}`);
  };
  const cell = (key, text, surface, ratio) =>
    h(
      'div',
      { className: 'pb-preview-row', key, 'data-side': key },
      h(
        'span',
        { className: 'pb-preview-avatar' },
        h(PbAvatar, {
          ui,
          seat: key === 'mine' ? 'user' : 'assistant',
          size: 26,
          fallback: h('span', { className: 'pb-preview-fallback' }, '🐳'),
        }),
      ),
      h(
        'div',
        {
          className: 'pb-preview-bubble',
          'data-material': kind,
          style: {
            background: opacity === 0 ? 'transparent' : surface,
            color: key === 'mine' ? palette.mineText : palette.theirsText,
            borderRadius: `${radius}px`,
            maxWidth: `${ui?.bubble?.shape?.maxWidthPct ?? 75}%`,
          },
        },
        text,
      ),
      badge(ratio),
    );
  return h(
    'section',
    { className: 'pb-section', 'data-variant': 'preview' },
    h('h3', null, tr('preview.heading')),
    h('p', { className: 'pb-hint' }, tr('preview.hint')),
    cell('mine', tr('preview.mine'), mine, ratioMine),
    cell('theirs', tr('preview.theirs'), theirs, ratioTheirs),
  );
}

/** The three theme cards, each with a miniature of its own wallpaper. */
function ThemeCards({ tr, current, onPick, disabled }) {
  const cards = [
    { id: 'deepsea', label: tr('theme.deepsea') },
    { id: 'light', label: tr('theme.light') },
    { id: 'system', label: tr('theme.system') },
  ];
  return h(
    'div',
    { className: 'pb-themes', role: 'group', 'aria-label': tr('look.theme') },
    cards.map((card) =>
      h(
        'button',
        {
          key: card.id,
          type: 'button',
          className: 'pb-theme',
          'data-theme': card.id,
          'data-active': String(card.id === current),
          'aria-pressed': String(card.id === current),
          disabled: Boolean(disabled),
          onClick: () => onPick(card.id),
        },
        h(
          'div',
          { className: 'pb-theme-preview' },
          h('div', { className: 'pb-theme-bubble' }),
          h('div', { className: 'pb-theme-bubble', 'data-side': 'mine' }),
        ),
        h('div', { className: 'pb-theme-name' }, h('span', null, card.label), card.id === current ? h('span', null, '✓') : null),
      ),
    ),
  );
}

/** The appearance tab. */
function AppearanceTab({ tr, forms }) {
  const state = useStore();
  const snapshot = state.snapshot;
  const [pending, setPending] = React.useState(null);
  const rev = snapshot?.rev ?? null;
  React.useEffect(() => {
    setPending(null);
  }, [rev]);
  const ui = pending ?? snapshot?.profiles?.ui ?? null;
  const uiRef = React.useRef(ui);
  uiRef.current = ui;
  if (ui === null) return h('p', { className: 'pb-hint' }, tr('loading'));
  const presets = snapshot?.presets ?? {};
  const apple = presets.apple ?? {};
  const shapes = presets.shapes ?? { radius: { min: 0, max: 24 }, width: { min: 40, max: 92 } };

  /** Build the next state from a mutation, without touching the host. */
  const build = (mutator) => {
    const next = structuredClone(uiRef.current);
    mutator(next);
    return next;
  };
  /** Preview a mutation in the document immediately. */
  const preview = (mutator) => {
    const next = build(mutator);
    uiRef.current = next;
    setPending(next);
    applyAppearance(next, { rev });
    return next;
  };
  /** Commit one whole section to the host. */
  const commit = (section, next = uiRef.current) => {
    const value = next?.[section];
    if (value === undefined) return;
    void runAction('setUi', { section, patch: structuredClone(value) }, { keepDraft: true });
  };
  /**
   * Preview + commit several top-level sections in one request. The host
   * shallow-merges without a `section`, so a patch here always carries the whole
   * sub-object — nested edits therefore cost exactly one revision.
   */
  const setTop = (mutator, sections) => {
    const next = preview(mutator);
    const patch = {};
    for (const key of sections) patch[key] = structuredClone(next[key]);
    void runAction('setUi', { patch }, { keepDraft: true });
  };
  /** Preview + commit in one go (buttons, selects, colours). */
  const set = (section, mutator) => {
    const next = preview(mutator);
    commit(section, next);
  };
  /** Save the pending state, then commit the section a slider belongs to. */
  const settle = (section) => commit(section);

  const bubble = ui.bubble ?? {};
  const material = ui.material ?? {};
  const appearance = ui.appearance ?? {};
  const theme = pbThemeOf(ui);
  const materialKind = pbMaterialOf(ui);
  const bubbleShape = pbBubbleShapeOf(ui);
  const avatarShape = pbAvatarShapeOf(ui);
  const audit = pbcAudit(ui, 'rgb(247, 248, 250)', presets);
  const failing = audit.rows.filter((row) => !row.pass);

  /** One nested edit inside `ui.appearance`, committed as a whole section. */
  const look = (mutator) =>
    setTop((next) => {
      if (next.appearance === null || typeof next.appearance !== 'object') next.appearance = {};
      mutator(next.appearance);
    }, ['appearance']);

  return h(
    React.Fragment,
    null,
    h(PreviewStrip, { tr, ui, presets }),

    h(
      PbGroup,
      { title: tr('look.theme'), hint: tr('look.themeHint') },
      h(
        'div',
        { className: 'pb-fold-body' },
        h(ThemeCards, {
          tr,
          current: theme,
          disabled: state.busy,
          onPick: (id) =>
            look((next) => {
              next.theme = id;
            }),
        }),
      ),
    ),

    h(
      PbGroup,
      { title: tr('look.bubbles') },
      h(PbRow, {
        title: tr('look.material'),
        control: h(PbSeg, {
          label: tr('look.material'),
          value: materialKind,
          disabled: state.busy,
          options: [
            { value: 'transparent', label: tr('look.materialTransparent') },
            { value: 'glass', label: tr('look.materialGlass') },
            { value: 'solid', label: tr('look.materialSolid') },
          ],
          onChange: (value) =>
            look((next) => {
              next.bubble = { ...(next.bubble ?? {}), material: value };
            }),
        }),
      }),
      h(PbRow, {
        title: tr('look.shape'),
        control: h(PbSeg, {
          label: tr('look.shape'),
          value: bubbleShape,
          disabled: state.busy,
          options: [
            { value: 'round', label: tr('look.shapeRound') },
            { value: 'square', label: tr('look.shapeSquare') },
            { value: 'none', label: tr('look.shapeNone') },
          ],
          onChange: (value) =>
            look((next) => {
              next.bubble = { ...(next.bubble ?? {}), shape: value };
            }),
        }),
      }),
      h(PbRow, {
        title: tr('look.avatarShape'),
        control: h(PbSeg, {
          label: tr('look.avatarShape'),
          value: avatarShape,
          disabled: state.busy,
          options: [
            { value: 'circle', label: tr('look.avatarCircle') },
            { value: 'rounded', label: tr('look.avatarRounded') },
            { value: 'square', label: tr('look.avatarSquare') },
          ],
          onChange: (value) =>
            look((next) => {
              next.avatar = { ...(next.avatar ?? {}), shape: value };
            }),
        }),
      }),
    ),

    h(
      PbFold,
      { name: 'look-detail', title: tr('look.more'), hint: tr('look.moreHint') },
      h(PbGroup, { title: tr('bubble.heading'), hint: tr('bubble.hint') },
        h(PbSwitch, {
          label: tr('bubble.on'),
          hint: tr('bubble.onHint'),
          on: bubble.on === true,
          disabled: state.busy,
          onChange: (on) =>
            set('bubble', (next) => {
              next.bubble.on = on;
            }),
        }),
        h(PbSwitch, {
          label: tr('bubble.tail'),
          on: bubble.shape?.tail === true,
          disabled: state.busy,
          onChange: (on) =>
            set('bubble', (next) => {
              next.bubble.shape.tail = on;
            }),
        }),
        h(PbSwitch, {
          label: tr('bubble.avatar'),
          on: bubble.shape?.avatar === true,
          disabled: state.busy,
          onChange: (on) =>
            set('bubble', (next) => {
              next.bubble.shape.avatar = on;
            }),
        }),
        h(PbSwitch, {
          label: tr('bubble.grouping'),
          on: bubble.shape?.grouping === true,
          disabled: state.busy,
          onChange: (on) =>
            set('bubble', (next) => {
              next.bubble.shape.grouping = on;
            }),
        }),
        h(PbSlider, {
          label: tr('bubble.maxWidth'),
          value: bubble.shape?.maxWidthPct ?? 75,
          min: shapes.width?.min ?? 40,
          max: shapes.width?.max ?? 92,
          suffix: '%',
          onInput: (value) =>
            preview((next) => {
              next.bubble.shape.maxWidthPct = value;
            }),
          onCommit: () => settle('bubble'),
        }),
        h(PbSlider, {
          label: tr('bubble.gap'),
          value: bubble.shape?.gap ?? 12,
          min: 4,
          max: 28,
          suffix: 'px',
          onInput: (value) =>
            preview((next) => {
              next.bubble.shape.gap = value;
            }),
          onCommit: () => settle('bubble'),
        }),
      ),
      h(
        PbGroup,
        { title: tr('colors.heading'), hint: tr('colors.hint') },
        h(
          'div',
          { className: 'pb-fold-body' },
          h(PbColor, {
            label: tr('colors.mine'),
            value: bubble.colors?.mine,
            onChange: (value) =>
              set('bubble', (next) => {
                next.bubble.colors.mine = value;
              }),
          }),
          h(PbColor, {
            label: tr('colors.mineText'),
            value: bubble.colors?.mineText,
            onChange: (value) =>
              set('bubble', (next) => {
                next.bubble.colors.mineText = value;
              }),
          }),
          h(PbColor, {
            label: tr('colors.theirs'),
            value: bubble.colors?.theirs,
            onChange: (value) =>
              set('bubble', (next) => {
                next.bubble.colors.theirs = value;
              }),
          }),
          h(PbColor, {
            label: tr('colors.theirsText'),
            value: bubble.colors?.theirsText,
            onChange: (value) =>
              set('bubble', (next) => {
                next.bubble.colors.theirsText = value;
              }),
          }),
          h(PbColor, {
            label: tr('colors.accent'),
            value: bubble.colors?.accent,
            onChange: (value) =>
              set('bubble', (next) => {
                next.bubble.colors.accent = value;
              }),
          }),
          h(
            PbRow,
            {
              title: failing.length === 0 ? tr('colors.ok') : `${tr('colors.warn')}${failing.length}`,
              control: failing.length === 0
                ? null
                : h(PbBtn, {
                    disabled: state.busy,
                    onClick: () => {
                      const suggestion = pbcSuggestText(ui, presets);
                      set('bubble', (next) => {
                        for (const [key, value] of Object.entries(suggestion)) next.bubble.colors[key] = value;
                      });
                    },
                  }, tr('colors.boost')),
            },
          ),
        ),
      ),
      h(
        PbGroup,
        { title: tr('material.heading'), hint: tr('material.hint') },
        h(
          'div',
          { className: 'pb-fold-body' },
          h(PbSlider, {
            label: tr('material.opacity'),
            value: material.opacity ?? 0.55,
            min: 0,
            max: 1,
            step: 0.05,
            onInput: (value) =>
              preview((next) => {
                next.material.opacity = value;
              }),
            onCommit: () => settle('material'),
          }),
          h(PbSlider, {
            label: tr('material.blur'),
            value: material.blurPx ?? 30,
            min: 0,
            max: 80,
            suffix: 'px',
            onInput: (value) =>
              preview((next) => {
                next.material.blurPx = value;
              }),
            onCommit: () => settle('material'),
          }),
          h(PbSlider, {
            label: tr('material.saturate'),
            value: material.saturatePct ?? 180,
            min: 100,
            max: 260,
            suffix: '%',
            onInput: (value) =>
              preview((next) => {
                next.material.saturatePct = value;
              }),
            onCommit: () => settle('material'),
          }),
          h(PbSlider, {
            label: tr('material.brightness'),
            value: material.brightnessPct ?? 104,
            min: 80,
            max: 130,
            suffix: '%',
            onInput: (value) =>
              preview((next) => {
                next.material.brightnessPct = value;
              }),
            onCommit: () => settle('material'),
          }),
          h(PbSlider, {
            label: tr('material.noise'),
            value: material.noise ?? 0.06,
            min: 0,
            max: 0.3,
            step: 0.01,
            onInput: (value) =>
              preview((next) => {
                next.material.noise = value;
              }),
            onCommit: () => settle('material'),
          }),
        ),
      ),
      h(
        PbGroup,
        { title: tr('assets.avatarsTitle'), hint: tr('assets.avatarsHint') },
        h('div', { className: 'pb-fold-body' }, h(AvatarSeats, { tr })),
      ),
      h(PresetEditor, { tr, ui, snapshot, sectionCommit: (section, mutator) => set(section, mutator) }),
    ),
  );
}
