/**
 * Shard 42: the appearance engine.
 *
 * `applyAppearance()` is the **only** place that writes `data-pb-*` attributes
 * and `--pb-*` variables, and the only place that installs the host-generated
 * skin stylesheet. Everything else (tabs, bubble engine, self-check) asks this
 * shard to apply a state; nothing else touches the document root.
 *
 * Values never live here: they arrive from the snapshot, so the host stays the
 * single source of truth for every preset number.
 */

/** The injected skin stylesheet. */
const SKIN_STYLE_ID = 'dsh-persona-book-skin';
/** The stylesheet the host generates from the current state. */
const SKIN_CSS_URL = `${ENDPOINT}/theme.css`;

/** Attributes we own on `<html>`, so safe mode can remove exactly these. */
const PB_ATTRS = [
  'data-pb-skin',
  'data-pb-bubble',
  'data-pb-tail',
  'data-pb-avatar',
  'data-pb-labels',
  'data-pb-style',
  'data-pb-material',
  'data-pb-bub-shape',
  'data-pb-avatar-shape',
  'data-pb-theme',
  'data-pb-bg',
  'data-pb-wallpaper',
  'data-pb-wallpaper-kind',
  'data-pb-wallpaper-fit',
  'data-pb-wallpaper-fullscreen',
  'data-pb-safe',
  'data-pb-caps',
];

/* ------------------------------------------------------------------ *
 * The look contract.
 *
 * `ui.appearance` is { theme, bubble:{material,shape}, avatar:{shape},
 * wallpaper:{id,fit,dim,blur,fullscreen} }. Every reader below is tolerant:
 * when a new field is missing it falls back to the old flat layout, so a
 * half-migrated profile still renders instead of losing its skin.
 * ------------------------------------------------------------------ */

/** The three skins, in panel order. */
const PB_THEMES = ['deepsea', 'light', 'system'];
/** Bubble materials, in panel order. */
const PB_BUBBLE_MATERIALS = ['transparent', 'glass', 'solid'];
/** Bubble shapes, in panel order. */
const PB_BUBBLE_SHAPES = ['round', 'square', 'none'];
/** Avatar shapes, in panel order. */
const PB_AVATAR_SHAPES = ['circle', 'rounded', 'square'];
/** How a wallpaper fills the frame. */
const PB_WALL_FITS = ['cover', 'contain', 'tile'];

/** One enum value, or the fallback when it is not one we know. */
function pbEnum(value, allowed, fallback) {
  return allowed.includes(value) ? value : fallback;
}

/** The skin id, mapping the pre-2.0 names onto the three current ones. */
function pbThemeOf(ui) {
  const raw = ui?.appearance?.theme;
  const id = typeof raw === 'string' ? raw : typeof raw?.id === 'string' ? raw.id : '';
  if (id === 'deep' || id === 'wechat' || id === 'qq') return 'deepsea';
  if (id === 'paper') return 'light';
  return pbEnum(id, PB_THEMES, 'deepsea');
}

/** The bubble material, mapping the old four names onto transparent/glass/solid. */
function pbMaterialOf(ui) {
  const raw = ui?.appearance?.bubble?.material;
  if (PB_BUBBLE_MATERIALS.includes(raw)) return raw;
  const legacy = ui?.material?.kind;
  if (legacy === 'rough') return 'solid';
  if (legacy === 'translucent') return 'transparent';
  if (legacy === 'frosted' || legacy === 'liquid') return 'glass';
  return 'transparent';
}

/** The bubble shape: the enum when present, otherwise read off the old radius. */
function pbBubbleShapeOf(ui) {
  const raw = ui?.appearance?.bubble?.shape;
  if (PB_BUBBLE_SHAPES.includes(raw)) return raw;
  const radius = ui?.bubble?.shape?.cornerRadius;
  if (typeof radius === 'number' && Number.isFinite(radius)) return radius <= 2 ? 'square' : 'round';
  return 'round';
}

/** The avatar shape. */
function pbAvatarShapeOf(ui) {
  const raw = ui?.appearance?.avatar?.shape ?? ui?.avatar?.shape;
  return pbEnum(raw, PB_AVATAR_SHAPES, 'circle');
}

/** Corner radius, in px, for a bubble shape. */
const PB_SHAPE_RADIUS = { round: 18, square: 0, none: 0 };
/** Opacity / blur / saturation for a material. */
const PB_MATERIAL_LOOK = {
  transparent: { opacity: 0, blur: 0, saturate: 100 },
  glass: { opacity: 0.55, blur: 30, saturate: 180 },
  solid: { opacity: 1, blur: 0, saturate: 100 },
};

/** Corner radius in px for the current bubble shape. */
function pbBubbleRadius(ui) {
  const shape = pbBubbleShapeOf(ui);
  return PB_SHAPE_RADIUS[shape] ?? pbNum(ui?.bubble?.shape?.cornerRadius, 18);
}

/**
 * The wallpaper spec for a whole `ui`, or for the legacy flat background row.
 * `id` is either `'builtin:<scene>'`, `'asset:<id>'`, or empty for none.
 */
function pbWallpaperSpec(source) {
  const appearance = source?.appearance;
  const raw = appearance?.wallpaper;
  if (raw !== null && typeof raw === 'object' && raw !== undefined) {
    return {
      id: typeof raw.id === 'string' && raw.id !== '' ? raw.id : '',
      fit: pbEnum(raw.fit, PB_WALL_FITS, 'cover'),
      dim: pbNum(raw.dim, 0),
      blur: pbNum(raw.blur, 0),
      fullscreen: raw.fullscreen === true,
    };
  }
  const background = (appearance !== null && typeof appearance === 'object' ? appearance.background : null) ?? source?.background ?? source ?? {};
  const assetId = typeof background.assetId === 'string' ? background.assetId : '';
  const named = typeof background.wallpaperId === 'string' && background.wallpaperId !== '' ? background.wallpaperId : source?.wallpaper?.id;
  const id = assetId !== '' ? `asset:${assetId}` : typeof named === 'string' ? named : '';
  return {
    id,
    fit: pbEnum(background.fit, PB_WALL_FITS, 'cover'),
    dim: pbNum(background.dimPct ?? background.dim, 0),
    blur: pbNum(background.blurPx ?? background.blur, 0),
    fullscreen: background.fullscreen === true || background.kind === 'wallpaper-full',
  };
}

/** CSS variables we own on `<html>`, so safe mode can clear them again. */
const PB_VARS = [
  '--pb-bub-r',
  '--pb-bub-max',
  '--pb-bub-gap',
  '--pb-bub-avatar',
  '--pb-mine-bg',
  '--pb-mine-fg',
  '--pb-theirs-bg',
  '--pb-theirs-fg',
  '--pb-accent',
  '--pb-avatar-user',
  '--pb-mat-op',
  '--pb-mat-blur',
  '--pb-mat-sat',
  '--pb-mat-bri',
  '--pb-tint',
  '--pb-tint-a',
  '--pb-spec',
  '--pb-noise',
  '--pb-shadow',
  '--pb-panel-r',
  '--pb-bg-dim',
  '--pb-bg-blur',
  '--pb-bg-grain',
  '--pb-bg-image',
];

/** Capability probes, computed once: CSS.supports on the client only. */
const pbCaps = (() => {
  const supports = (probe) => {
    try {
      return typeof CSS !== 'undefined' && typeof CSS.supports === 'function' && CSS.supports(probe);
    } catch {
      return false;
    }
  };
  const list = [];
  if (supports('backdrop-filter: blur(1px)') || supports('-webkit-backdrop-filter: blur(1px)')) list.push('blur');
  if (supports('mask-image: linear-gradient(black, transparent)')) list.push('mask');
  if (supports('background: linear-gradient(in oklab, red, blue)')) list.push('oklab');
  if (typeof globalThis.createImageBitmap === 'function') list.push('bitmap');
  if (typeof globalThis.ResizeObserver === 'function') list.push('ro');
  list.push('dshDesktop' in globalThis ? 'desktop' : 'mobile');
  return list;
})();

/** The document root we write to. */
const pbRoot = () => document.documentElement;

/** A finite number from anywhere, or the fallback. */
function pbNum(value, fallback) {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

/** `true` → '1', anything else → '0'. */
const pbBit = (value) => (value === true ? '1' : '0');

/** The label attribute from the two switches. */
function pbLabelsAttr(labels) {
  const names = labels?.showNames === true;
  const time = labels?.showTimestamps === true;
  if (names && time) return 'both';
  if (names) return 'names';
  if (time) return 'time';
  return 'none';
}

/** Pending variable writes, flushed once per frame. */
let pbVarQueue = null;
let pbVarFrame = 0;

/** Queue one variable write (batched with `requestAnimationFrame`). */
function pbSetVar(name, value) {
  if (pbVarQueue === null) pbVarQueue = new Map();
  pbVarQueue.set(name, value);
  if (pbVarFrame !== 0) return;
  const flush = () => {
    pbVarFrame = 0;
    const queue = pbVarQueue ?? new Map();
    pbVarQueue = null;
    const style = pbRoot().style;
    for (const [key, text] of queue) {
      if (text === null) style.removeProperty(key);
      else style.setProperty(key, text);
    }
  };
  try {
    pbVarFrame = requestAnimationFrame(flush);
  } catch {
    flush();
  }
}

/** Apply every variable for a state, immediately (used by tests and boot). */
function pbApplyVarsNow(ui) {
  const style = pbRoot().style;
  for (const name of PB_VARS) style.removeProperty(name);
  for (const [name, value] of pbVarList(ui)) {
    if (value !== null && value !== undefined) style.setProperty(name, value);
  }
}

/** Public URL of one stored asset (the preview route serves the stored bytes). */
function pbAvatarUrl(assetId) {
  if (typeof assetId !== 'string' || assetId === '') return null;
  return `${ASSETS_ENDPOINT}/${encodeURIComponent(assetId)}/preview`;
}

/**
 * One avatar seat: an uploaded picture when the profile names one, otherwise
 * the caller's own fallback node. The chat bubble gets its copy through
 * `--pb-avatar-user`; the sidebar seat and the panel logo render this directly.
 */
function PbAvatar({ ui, seat, size = 22, className = null, fallback = null }) {
  const url = pbAvatarUrl(ui?.avatar?.[seat]?.assetId);
  if (url === null) return fallback;
  return h('img', {
    className: cx('pb-avatar-img', className),
    src: url,
    alt: '',
    width: size,
    height: size,
    style: { inlineSize: `${size}px`, blockSize: `${size}px`, objectFit: 'cover', borderRadius: '50%' },
  });
}

/**
 * Which wallpaper the stored profile asks for. A builtin is one of the
 * procedural scenes; an upload is an asset id the host serves from disk. Takes
 * either a whole `ui` or the legacy flat background row.
 */
function pbWallpaperOf(source) {
  const spec = pbWallpaperSpec(source);
  const id = spec.id;
  if (id.startsWith('asset:')) {
    const assetId = id.slice('asset:'.length);
    return { id: 'custom', kind: 'image', image: assetId === '' ? null : `url('${pbAvatarUrl(assetId)}')` };
  }
  const scene = id.startsWith('builtin:') ? id.slice('builtin:'.length) : id;
  // An empty id means "no wallpaper at all": the theme paints the backdrop.
  if (scene === '' || scene === 'none' || scene === 'off' || scene === 'custom') return { id: '', kind: 'none', image: null };
  return { id: scene, kind: 'builtin', image: null };
}

/** The `--pb-*` list for a normalised state. */
function pbVarList(ui) {
  const bubble = ui?.bubble ?? {};
  const shape = bubble.shape ?? {};
  const colors = bubble.colors ?? {};
  const material = ui?.material ?? {};
  const tint = Array.isArray(material.tint?.rgb) ? material.tint.rgb : [24, 42, 77];
  const appearance = ui?.appearance ?? {};
  const system = appearance.system ?? {};
  const gaps = {
    none: 'none',
    soft: '0 6px 20px rgba(16, 32, 64 / 0.16)',
    floating: '0 12px 34px rgba(16, 32, 64 / 0.24)',
    glass: '0 10px 30px rgba(16, 32, 64 / 0.20), inset 0 1px 0 rgba(255 255 255 / 0.35)',
  };
  // The 2.0 look wins where it is present; the flat numbers are the fallback.
  const bubbleShape = pbBubbleShapeOf(ui);
  const materialLook = appearance.bubble?.material !== undefined ? PB_MATERIAL_LOOK[pbMaterialOf(ui)] : null;
  const wallpaper = pbWallpaperSpec(ui);
  // 「无气泡」就是真的没有气泡：连底色和投影一起收干净，只剩文字。
  const bare = bubbleShape === 'none';
  return [
    ['--pb-bub-r', `${PB_SHAPE_RADIUS[bubbleShape] ?? pbNum(shape.cornerRadius, 18)}px`],
    ['--pb-bub-max', `${pbNum(shape.maxWidthPct, 75)}%`],
    ['--pb-bub-gap', `${pbNum(shape.gap, 12)}px`],
    ['--pb-bub-avatar', `${pbNum(shape.avatarSize, 28)}px`],
    ['--pb-mine-bg', colors.mine ?? null],
    ['--pb-mine-fg', colors.mineText ?? null],
    ['--pb-theirs-bg', colors.theirs ?? null],
    ['--pb-theirs-fg', colors.theirsText ?? null],
    ['--pb-accent', appearance.accent ?? system.accent ?? colors.accent ?? null],
    ['--pb-mat-op', bare ? '0' : String(pbNum(materialLook?.opacity ?? material.opacity, 0.55))],
    ['--pb-mat-blur', `${pbNum(materialLook?.blur ?? material.blurPx, 30)}px`],
    ['--pb-mat-sat', `${pbNum(materialLook?.saturate ?? material.saturatePct, 180)}%`],
    ['--pb-mat-bri', `${pbNum(material.brightnessPct, 104)}%`],
    ['--pb-tint', tint.join(' ')],
    ['--pb-tint-a', String(pbNum(material.tint?.a, 0.18))],
    ['--pb-spec', String(pbNum(material.specular, 0.35))],
    ['--pb-noise', String(pbNum(material.noise, 0.06))],
    ['--pb-shadow', bare ? 'none' : (gaps[material.shadow] ?? gaps.soft)],
    ['--pb-panel-r', `${pbNum(system.panelRadius, 14)}px`],
    ['--pb-bg-dim', String(pbNum(wallpaper.dim, 0) / 100)],
    ['--pb-bg-blur', `${pbNum(wallpaper.blur, 0)}px`],
    ['--pb-bg-grain', String(pbNum(appearance.background?.grain, 0.06))],
    ['--pb-bg-image', pbWallpaperOf(ui).image],
    ['--pb-avatar-user', pbAvatarUrl(ui?.avatar?.user?.assetId) === null ? null : `url('${pbAvatarUrl(ui.avatar.user.assetId)}')`],
  ];
}

/** Remove every attribute and variable we own. */
function pbClearAppearance() {
  const root = pbRoot();
  for (const name of PB_ATTRS) root.removeAttribute(name);
  for (const name of PB_VARS) root.style.removeProperty(name);
}

/** Remove the injected skin stylesheet (idempotent). */
function pbRemoveSkin() {
  document.getElementById(SKIN_STYLE_ID)?.remove();
  document.querySelector('style[data-plugin="dsh-persona-book"][data-plugin-css="skin"]')?.remove();
}

/** In-memory CSS cache keyed by rev, so a re-apply never refetches. */
let pbSkinCache = { rev: null, css: null };
let pbSkinPending = null;

/**
 * Install (or refresh) the skin stylesheet. Resolves to `true` when the sheet
 * is in the document — safe mode removes it and never calls this.
 */
async function pbEnsureSkin(rev) {
  if (pbSafeNow()) return false;
  const existing = document.getElementById(SKIN_STYLE_ID);
  if (existing !== null && pbSkinCache.rev === rev) return true;
  if (pbSkinPending !== null && pbSkinCache.rev === rev) return pbSkinPending;
  const load = (async () => {
    let css = pbSkinCache.rev === rev ? pbSkinCache.css : null;
    if (css === null) {
      const response = await fetch(`${SKIN_CSS_URL}?rev=${encodeURIComponent(String(rev ?? 0))}`, {
        credentials: 'same-origin',
        headers: { Accept: 'text/css' },
      });
      if (!response.ok) throw new Error(`E${response.status}`);
      css = await response.text();
      pbSkinCache = { rev, css };
    }
    pbRemoveSkin();
    if (pbSafeNow()) return false;
    const tag = document.createElement('style');
    tag.id = SKIN_STYLE_ID;
    tag.setAttribute('data-plugin', PLUGIN_ID);
    tag.setAttribute('data-plugin-css', 'skin');
    tag.textContent = css;
    document.head.append(tag);
    pbLogPush(pbTr('log.skinLoaded', { rev: rev ?? 0, bytes: css.length }));
    return true;
  })();
  pbSkinPending = load;
  try {
    return await load;
  } catch (error) {
    pbLogPush(pbTr('log.skinFailed', { message: error.message }));
    return false;
  } finally {
    if (pbSkinPending === load) pbSkinPending = null;
  }
}

/** Whether safe mode is currently applied to the document root. */
function pbSafeNow() {
  return pbRoot().getAttribute('data-pb-safe') === '1';
}

/**
 * The single exit: write attributes, variables and the stylesheet for a state.
 * Returns a small report the tabs and the diagnostics view can render.
 */
function applyAppearance(ui, { rev = null } = {}) {
  const root = pbRoot();
  const report = { applied: false, safe: false, skin: false, caps: [...pbCaps], missing: [] };
  if (ui === null || ui === undefined) {
    report.missing.push('ui');
    return report;
  }
  // 6.13: the capability probe is always published, safe mode or not.
  root.setAttribute('data-pb-caps', pbCaps.join(','));
  report.safe = ui.safeMode === true;
  if (report.safe) {
    pbRemoveSkin();
    pbClearAppearance();
    root.setAttribute('data-pb-safe', '1');
    root.setAttribute('data-pb-caps', pbCaps.join(','));
    pbLogPush(pbTr('log.safeApplied'));
    return report;
  }
  const wallpaper = pbWallpaperSpec(ui);
  root.removeAttribute('data-pb-safe');
  root.setAttribute('data-pb-skin', 'on');
  root.setAttribute('data-pb-bubble', ui.bubble?.on === true ? 'on' : 'off');
  // "no bubble" means no tail either, whatever the stored switch says.
  root.setAttribute('data-pb-tail', pbBubbleShapeOf(ui) === 'none' ? '0' : pbBit(ui.bubble?.shape?.tail));
  root.setAttribute('data-pb-avatar', pbBit(ui.bubble?.shape?.avatar));
  root.setAttribute('data-pb-labels', pbLabelsAttr(ui.appearance?.labels ?? ui.bubble?.labels));
  root.setAttribute('data-pb-material', pbMaterialOf(ui));
  root.setAttribute('data-pb-bub-shape', pbBubbleShapeOf(ui));
  root.setAttribute('data-pb-avatar-shape', pbAvatarShapeOf(ui));
  root.setAttribute('data-pb-theme', pbThemeOf(ui));
  const scene = pbWallpaperOf(ui);
  // Any chosen wallpaper (builtin scene or upload) rides the skin's `wallpaper`
  // layer; "no wallpaper" falls back to whatever the theme paints.
  root.setAttribute('data-pb-bg', scene.kind === 'builtin' || scene.kind === 'image' ? 'wallpaper' : (ui.appearance?.background?.kind ?? 'sky'));
  root.setAttribute('data-pb-wallpaper', scene.id);
  root.setAttribute('data-pb-wallpaper-kind', scene.kind);
  root.setAttribute('data-pb-wallpaper-fit', wallpaper.fit);
  root.setAttribute('data-pb-wallpaper-fullscreen', pbBit(wallpaper.fullscreen));
  pbApplyVarsNow(ui);
  report.applied = true;
  void pbEnsureSkin(rev).then((ok) => {
    report.skin = ok;
    if (!ok && !ui.safeMode) pbLogPush(pbTr('log.skinMissing'));
  });
  return report;
}

/** Re-apply from the current store state (used by the seat and by the tabs). */
function pbReapply() {
  const snapshot = getState().snapshot;
  if (snapshot === null) return null;
  return applyAppearance(snapshot.profiles?.ui ?? null, { rev: snapshot.rev });
}
