/**
 * The sound engine. Every cue is written down as data — a few oscillators with
 * a start time, a pitch ramp and an envelope — so it can be tested without a
 * browser and played by a ten-line interpreter over WebAudio. Nothing here
 * fetches a file: the eight cues are synthesised on the spot, and only a custom
 * upload goes through the asset route.
 */

/** The eight cues. `off` is a real choice, not a missing value. */
const PB_CUES = {
  'whale-call': {
    dur: 0.45,
    parts: [
      { type: 'sine', from: 880, to: 220, at: 0, dur: 0.45, gain: 0.5, detune: -6 },
      { type: 'sine', from: 880, to: 220, at: 0.02, dur: 0.43, gain: 0.32, detune: 6 },
    ],
  },
  'water-drop': {
    dur: 0.08,
    parts: [
      { type: 'sine', from: 1200, to: 600, at: 0, dur: 0.08, gain: 0.55 },
      { type: 'triangle', from: 2400, to: 900, at: 0, dur: 0.05, gain: 0.18 },
    ],
  },
  'shell-ding': {
    dur: 0.25,
    parts: [
      { type: 'sine', from: 1760, to: 1760, at: 0, dur: 0.25, gain: 0.34 },
      { type: 'sine', from: 2640, to: 2640, at: 0, dur: 0.18, gain: 0.2 },
    ],
  },
  bubble: {
    dur: 0.12,
    parts: [{ type: 'sine', from: 300, to: 900, at: 0, dur: 0.12, gain: 0.4 }],
  },
  'whale-song': {
    dur: 0.6,
    parts: [
      { type: 'sine', from: 392, to: 392, at: 0, dur: 0.22, gain: 0.3 },
      { type: 'sine', from: 523, to: 523, at: 0.18, dur: 0.22, gain: 0.3 },
      { type: 'sine', from: 659, to: 659, at: 0.36, dur: 0.24, gain: 0.28 },
    ],
  },
  'star-tap': {
    dur: 0.06,
    parts: [{ type: 'noise', at: 0, dur: 0.06, gain: 0.32, highpass: 1800 }],
  },
  'bell-cat': {
    dur: 0.3,
    parts: [
      { type: 'triangle', from: 1568, to: 1568, at: 0, dur: 0.14, gain: 0.3, vibrato: 22 },
      { type: 'triangle', from: 2093, to: 2093, at: 0.1, dur: 0.2, gain: 0.26, vibrato: 22 },
    ],
  },
  off: { dur: 0, parts: [] },
};

const PB_CUE_IDS = Object.keys(PB_CUES);
const PB_EVENTS = ['sent', 'received', 'error', 'done'];
const PB_SOUND_LOG_MAX = 12;

/** The plainest possible reading of one cue: absolute-time events, no browser. */
function pbCueEvents(id) {
  const cue = PB_CUES[id] ?? PB_CUES.off;
  return cue.parts.map((part) => {
    const at = Number(part.at) || 0;
    const dur = Math.max(0.01, Number(part.dur) || 0.05);
    return {
      kind: part.type === 'noise' ? 'noise' : 'tone',
      wave: part.type === 'noise' ? null : part.type,
      from: Number(part.from ?? 0),
      to: Number(part.to ?? part.from ?? 0),
      at,
      until: at + dur,
      gain: Math.min(1, Math.max(0, Number(part.gain ?? 0.3))),
      detune: Number(part.detune ?? 0),
      vibrato: Number(part.vibrato ?? 0),
      highpass: Number(part.highpass ?? 0),
    };
  });
}

/** Custom uploads are addressed as `custom:<id>` inside an event slot. */
function pbCustomRef(value) {
  return typeof value === 'string' && value.startsWith('custom:') ? value.slice(7) : null;
}

/** Which cue an event is bound to, or null when the slot is silent/off. */
function pbCueFor(ui, event) {
  const sound = ui?.sound;
  if (sound === null || sound === undefined || sound.enabled !== true) return null;
  const bound = sound.events?.[event];
  if (bound === null || bound === undefined || bound === '' || bound === 'off') return null;
  const custom = pbCustomRef(bound);
  if (custom !== null) return { custom, volume: pbVolume(sound) };
  if (!PB_CUE_IDS.includes(bound)) return null;
  return { cue: bound, volume: pbVolume(sound) };
}

function pbVolume(sound) {
  const value = Number(sound?.volume);
  return Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : 0.6;
}

/* ── the browser side ───────────────────────────────────────────────────── */

let pbAudio = null;
let pbLastPlay = 0;
let pbPlaying = 0;
let pbObserver = null;
let pbSoundLog = [];

function pbNowMs() {
  return typeof performance !== 'undefined' && typeof performance.now === 'function'
    ? performance.now()
    : Date.now();
}

function pbAudioGraph() {
  const Ctor = globalThis.AudioContext ?? globalThis.webkitAudioContext;
  if (typeof Ctor !== 'function') return null;
  if (pbAudio === null) {
    try {
      pbAudio = { ctx: new Ctor(), master: null };
      pbAudio.master = pbAudio.ctx.createGain();
      pbAudio.master.gain.value = 1;
      pbAudio.master.connect(pbAudio.ctx.destination);
    } catch {
      pbAudio = null;
    }
  }
  return pbAudio;
}

/** WebAudio starts suspended until a real gesture; this is the polite unlock. */
function pbUnlockAudio() {
  const graph = pbAudioGraph();
  if (graph === null) return false;
  if (graph.ctx.state === 'suspended') void graph.ctx.resume().catch(() => {});
  return true;
}

function pbNoiseBuffer(ctx, seconds) {
  const length = Math.max(1, Math.floor(ctx.sampleRate * seconds));
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i += 1) data[i] = Math.random() * 2 - 1;
  return buffer;
}

/** Play one cue now. Jitter keeps repeats from sounding like a machine. */
function pbPlayCue(id, volume = 0.6) {
  const graph = pbAudioGraph();
  if (graph === null) return false;
  const events = pbCueEvents(id);
  if (events.length === 0) return false;
  const { ctx } = graph;
  const jitter = 1 + (Math.random() * 0.06 - 0.03);
  const level = Math.min(1, Math.max(0, volume));
  const start = ctx.currentTime + 0.001;
  for (const event of events) {
    const gain = ctx.createGain();
    const peak = event.gain * level;
    const attack = Math.min(0.02, (event.until - event.at) / 3);
    gain.gain.setValueAtTime(0.0001, start + event.at);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), start + event.at + attack);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + event.until);
    let node;
    let tail = gain;
    if (event.kind === 'noise') {
      node = ctx.createBufferSource();
      node.buffer = pbNoiseBuffer(ctx, event.until - event.at);
      if (event.highpass > 0) {
        const filter = ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.value = event.highpass;
        node.connect(filter);
        tail = filter;
      }
    } else {
      node = ctx.createOscillator();
      node.type = event.wave;
      const from = Math.max(20, event.from * jitter);
      const to = Math.max(20, event.to * jitter);
      node.frequency.setValueAtTime(from, start + event.at);
      if (to !== from) node.frequency.exponentialRampToValueAtTime(to, start + event.until);
      if (event.detune !== 0) node.detune.value = event.detune;
    }
    node.connect(tail);
    if (tail !== gain) tail.connect(gain);
    gain.connect(graph.master);
    node.start(start + event.at);
    node.stop(start + event.until + 0.01);
  }
  return true;
}

/** A custom upload plays through a plain element: no decode, no copy. */
function pbPlayCustom(entry, volume = 0.6) {
  if (typeof Audio !== 'function' || entry === null || entry === undefined) return false;
  const element = new Audio(`${ASSETS_ENDPOINT}/${entry.id}`);
  element.volume = Math.min(1, Math.max(0, volume));
  void element.play?.().catch(() => {});
  pbSoundLogPush(`custom:${entry.id}`);
  return true;
}

function pbSoundLogPush(line) {
  pbSoundLog = [...pbSoundLog.slice(-(PB_SOUND_LOG_MAX - 1)), line];
}

/* ── the public surface ─────────────────────────────────────────────────── */

/** Play for one conversation event, honouring mute / rate limit / hidden tab. */
function pbSoundPlay(ui, event) {
  const picked = pbCueFor(ui, event);
  if (picked === null) return false;
  const sound = ui?.sound ?? {};
  if (sound.muteWhenHidden === true && typeof document !== 'undefined' && document.hidden === true) {
    return false;
  }
  const limit = Number.isFinite(Number(sound.rateLimitMs)) ? Number(sound.rateLimitMs) : 400;
  const now = pbNowMs();
  if (now - pbLastPlay < limit) return false;
  pbLastPlay = now;
  if (pbPlaying > 2) return false;
  pbPlaying += 1;
  try {
    if (picked.custom !== undefined) {
      const entry = (ui?.sound?.custom ?? []).find((item) => item.id === picked.custom);
      return pbPlayCustom(entry ?? null, picked.volume);
    }
    const ok = pbPlayCue(picked.cue, picked.volume);
    if (ok) pbSoundLogPush(picked.cue);
    return ok;
  } finally {
    pbPlaying -= 1;
  }
}

/** 试听: deliberately ignores the rate limit and the mute-while-hidden rule. */
function pbSoundPreview(ui, cueId) {
  const sound = { ...(ui?.sound ?? {}) };
  const custom = pbCustomRef(cueId);
  if (custom !== null) {
    const entry = (sound.custom ?? []).find((item) => item.id === custom);
    return pbPlayCustom(entry ?? null, pbVolume(sound));
  }
  if (!PB_CUE_IDS.includes(cueId)) return false;
  const ok = pbPlayCue(cueId, pbVolume(sound));
  if (ok) pbSoundLogPush(cueId);
  return ok;
}

function pbSoundLogList() {
  return [...pbSoundLog];
}

function pbSoundState() {
  const graph = pbAudio;
  return {
    available: typeof (globalThis.AudioContext ?? globalThis.webkitAudioContext) === 'function',
    resumed: graph !== null && graph.ctx.state === 'running',
    played: pbSoundLog.length,
    cues: PB_CUE_IDS,
    events: PB_EVENTS,
    custom: pbCustomIds(),
  };
}

function pbCustomIds() {
  return (getState?.()?.snapshot?.profiles?.ui?.sound?.custom ?? []).map((item) => item.id);
}

/**
 * Watch the chat for the four moments worth a sound. The anchors are the
 * official ones the appearance engine already relies on, so this file adds no
 * new contract of its own.
 */
function pbAttachSound(readUi) {
  if (typeof MutationObserver !== 'function' || typeof document === 'undefined') return null;
  pbDetachSound();
  const see = (ui) => ui;
  const onAdded = (node) => {
    if (!(node instanceof Element)) return;
    const kind = node.getAttribute?.('data-chat-flow-kind');
    const inside = kind === null && node.querySelector?.('[data-chat-flow-kind]');
    const user = kind === 'user' || inside?.getAttribute('data-chat-flow-kind') === 'user';
    const failed = kind === 'turn-error' || inside?.getAttribute('data-chat-flow-kind') === 'turn-error';
    const reply = kind === 'assistant-step' || inside?.getAttribute('data-chat-flow-kind') === 'assistant-step';
    if (failed) pbSoundPlay(see(readUi()), 'error');
    else if (user) pbSoundPlay(see(readUi()), 'sent');
    else if (reply) pbSoundPlay(see(readUi()), 'received');
  };
  pbObserver = new MutationObserver((records) => {
    for (const record of records) {
      if (record.type === 'attributes') {
        if (record.attributeName === 'data-streaming' && record.target instanceof Element) {
          if (!record.target.hasAttribute('data-streaming')) pbSoundPlay(see(readUi()), 'done');
        }
        continue;
      }
      for (const node of record.addedNodes) onAdded(node);
    }
  });
  pbObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['data-streaming'],
  });
  return pbObserver;
}

function pbDetachSound() {
  if (pbObserver !== null) {
    pbObserver.disconnect();
    pbObserver = null;
  }
}

function pbResetSound() {
  pbLastPlay = 0;
  pbSoundLog = [];
}
