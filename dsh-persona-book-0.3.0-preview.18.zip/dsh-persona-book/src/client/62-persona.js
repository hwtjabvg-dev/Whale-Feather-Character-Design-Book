/**
 * Shard 62: the persona tab.
 *
 * Three things, top to bottom: the persona list (avatar, name, tick), the three
 * big strength buttons that set the default tone intensity, and one folded
 * "details" row that hides everything that used to be its own tab — identity,
 * free-form sections, anchors, the tone-level table and the default settings.
 */

/** One row in the persona list. */
function PersonaRow({ tr, row, active, selected }) {
  const emoji = row.emoji || '🐳';
  return h(
    'div',
    {
      className: 'pb-prow',
      'data-selected': String(selected),
      'data-active': String(active),
      role: 'button',
      tabIndex: 0,
      onClick: () => void selectPersona(row.id),
      onKeyDown: (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          void selectPersona(row.id);
        }
      },
    },
    row.avatar?.assetId
      ? h('img', { className: 'pb-prow-avatar', src: pbAvatarUrl(row.avatar.assetId), alt: '' })
      : h('span', { className: 'pb-prow-avatar' }, emoji),
    h(
      'div',
      { className: 'pb-prow-text' },
      h('div', { className: 'pb-prow-name' }, row.title),
      h(
        'div',
        { className: 'pb-prow-sub' },
        active
          ? `${tr('list.active')} · ${pbTr('persona.lvCount', { count: row.levels?.length ?? 0 })}`
          : `${row.id} · ${pbTr('persona.lvCount', { count: row.levels?.length ?? 0 })}`,
      ),
    ),
    row.broken ? h('span', { className: 'pb-badge', 'data-tone': 'warn' }, tr('list.broken')) : null,
    row.collisions?.length ? h('span', { className: 'pb-badge', 'data-tone': 'warn', title: row.collisions.join('\n') }, tr('list.collisions')) : null,
    selected ? h('span', { className: 'pb-check', 'aria-label': tr('list.active') }, '✓') : null,
  );
}

/** The list plus the create/duplicate/delete controls. */
function PersonaList({ tr }) {
  const state = useStore();
  const [newTitle, setNewTitle] = React.useState('');
  const rows = state.snapshot?.personas ?? [];
  const activeId = state.snapshot?.profiles?.active ?? null;
  const selectedId = state.draftId;

  const create = () => {
    const title = newTitle.trim();
    if (title === '') return;
    const id = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 40) || `persona-${Date.now().toString(36)}`;
    setNewTitle('');
    void runAction('createPersona', { id, title }, { message: title });
  };

  return h(
    PbGroup,
    {
      title: tr('list.heading'),
      hint: rows.length === 0 ? tr('list.empty') : null,
    },
    rows.map((row) =>
      h(PersonaRow, {
        key: row.id,
        tr,
        row,
        active: row.id === activeId,
        selected: row.id === selectedId,
      }),
    ),
    h(
      'div',
      { className: 'pb-row', 'data-role': 'setting' },
      h(TextInput, { value: newTitle, onChange: setNewTitle, placeholder: tr('list.newTitlePlaceholder') }),
      h(PbBtn, { disabled: state.busy || newTitle.trim() === '', onClick: create }, tr('list.create')),
      activeId === selectedId || selectedId === null
        ? null
        : h(
            PbBtn,
            { variant: 'primary', disabled: state.busy, onClick: () => void runAction('setActive', { id: selectedId }, { message: tr('list.active') }) },
            tr('list.activate'),
          ),
    ),
    rows.length === 0
      ? null
      : h(
          'div',
          { className: 'pb-row', 'data-role': 'setting' },
          h(
            'div',
            { className: 'pb-row-text' },
            h('div', { className: 'pb-row-title' }, tr('list.duplicate')),
            h('div', { className: 'pb-row-hint' }, tr('list.removeHint')),
          ),
          h('div', { className: 'pb-row-control' }, h(PbBtn, { variant: 'ghost', disabled: state.busy || selectedId === null, onClick: () => {
            if (selectedId === null) return;
            void runAction('duplicatePersona', { id: selectedId }, { message: tr('list.duplicate') });
          } }, tr('list.duplicate'))),
          h('div', { className: 'pb-row-control' }, h(PbBtn, { variant: 'danger', disabled: state.busy || selectedId === null, onClick: () => {
            if (selectedId === null) return;
            if (!window.confirm(tr('list.confirmRemove'))) return;
            void runAction('deletePersona', { id: selectedId });
          } }, tr('list.remove'))),
        ),
  );
}

/** The three big strength buttons: low / mid / high. */
function PersonaQuick({ tr, draft }) {
  const [busy, setBusy] = React.useState(false);
  const current = Number(draft?.defaults?.toneIntensity ?? 5);
  const bands = [
    { key: 'low', value: 3 },
    { key: 'mid', value: 6 },
    { key: 'high', value: 9 },
  ];
  const nearest = bands.reduce((best, band) => (Math.abs(band.value - current) < Math.abs(best.value - current) ? band : best), bands[0]);

  const apply = async (value) => {
    if (draft === null || busy) return;
    setBusy(true);
    editDraft(['defaults', 'toneIntensity'], value);
    await saveDraft();
    setBusy(false);
  };

  return h(
    PbGroup,
    { title: tr('quick.heading'), hint: tr('quick.hint') },
    h(
      'div',
      { className: 'pb-fold-body' },
      h(
        'div',
        { className: 'pb-quick' },
        bands.map((band) =>
          h(
            'button',
            {
              key: band.key,
              type: 'button',
              className: 'pb-quick-btn',
              'data-active': String(band.value === nearest.value),
              'aria-pressed': String(band.value === nearest.value),
              disabled: busy,
              onClick: () => void apply(band.value),
            },
            h('span', { className: 'pb-quick-value' }, String(band.value)),
            h('span', { className: 'pb-quick-label' }, tr(`quick.${band.key}`)),
          ),
        ),
      ),
    ),
  );
}

/** Everything the old persona/levels/defaults tabs held, behind one row. */
function PersonaDetail({ tr }) {
  const state = useStore();
  const draft = state.draft;
  const edit = (path, value) => editDraft(path, value);

  if (draft === null) return null;

  return h(
    PbFold,
    { name: 'persona-detail', title: tr('detail.title'), hint: tr('detail.hint') },
    h(
      PbGroup,
      { title: tr('basic.heading'), hint: tr('basic.hint') },
      h(
        'div',
        { className: 'pb-fold-body' },
        h(
          'div',
          { className: 'pb-grid-2' },
          h(Field, { label: tr('list.newTitlePlaceholder') }, h(TextInput, { value: draft.title, onChange: (value) => edit(['title'], value) })),
          h(Field, { label: tr('defaults.emoji') }, h(TextInput, { value: draft.emoji, onChange: (value) => edit(['emoji'], value) })),
          h(Field, { label: tr('defaults.version') }, h(TextInput, { value: draft.version, onChange: (value) => edit(['version'], value) })),
          h(Field, { label: tr('defaults.whenToUse') }, h(TextInput, { value: draft.whenToUse, onChange: (value) => edit(['whenToUse'], value) })),
        ),
        h(Field, { label: tr('defaults.summary') }, h(TextArea, { value: draft.summary, rows: 2, onChange: (value) => edit(['summary'], value) })),
      ),
    ),
    h(
      Section,
      { title: tr('identity.heading') },
      h(
        'div',
        { className: 'pb-grid-2' },
        h(Field, { label: tr('identity.selfName') }, h(TextInput, { value: draft.identity?.selfName, onChange: (value) => edit(['identity', 'selfName'], value) })),
        h(Field, { label: tr('identity.userName') }, h(TextInput, { value: draft.identity?.userName, onChange: (value) => edit(['identity', 'userName'], value) })),
        h(Field, { label: tr('identity.lang') }, h(TextInput, { value: draft.identity?.lang, onChange: (value) => edit(['identity', 'lang'], value) })),
        h(Field, { label: tr('identity.roleLine') }, h(TextInput, { value: draft.identity?.roleLine, onChange: (value) => edit(['identity', 'roleLine'], value) })),
      ),
    ),
    h(
      Section,
      {
        title: tr('blocks.heading'),
        actions: h(
          PbBtn,
          {
            variant: 'ghost',
            onClick: () => {
              const blocks = [...(draft.blocks ?? []), { id: `block-${Date.now().toString(36)}`, title: pbTr('persona.newBlock'), body: '' }];
              edit(['blocks'], blocks);
            },
          },
          tr('blocks.add'),
        ),
      },
      (draft.blocks ?? []).length === 0 ? h('p', { className: 'pb-hint' }, '—') : null,
      (draft.blocks ?? []).map((block, index) =>
        h(
          'div',
          { key: block.id ?? index, className: 'pb-level' },
          h(
            'div',
            { className: 'pb-row', 'data-spread': 'true' },
            h(TextInput, {
              value: block.title,
              onChange: (value) => {
                const blocks = clone(draft.blocks);
                blocks[index].title = value;
                edit(['blocks'], blocks);
              },
            }),
            h(
              PbBtn,
              { variant: 'danger', onClick: () => edit(['blocks'], draft.blocks.filter((_, at) => at !== index)) },
              tr('blocks.remove'),
            ),
          ),
          h(TextArea, {
            value: block.body,
            rows: 3,
            onChange: (value) => {
              const blocks = clone(draft.blocks);
              blocks[index].body = value;
              edit(['blocks'], blocks);
            },
          }),
        ),
      ),
    ),
    h(
      Section,
      { title: tr('anchors.heading') },
      h(
        'div',
        { className: 'pb-grid-2' },
        h(Field, { label: tr('anchors.visual') }, h(TextArea, { value: joinList(draft.anchors?.visual), rows: 3, onChange: (value) => edit(['anchors', 'visual'], splitList(value)) })),
        h(Field, { label: tr('anchors.voice') }, h(TextArea, { value: joinList(draft.anchors?.voice), rows: 3, onChange: (value) => edit(['anchors', 'voice'], splitList(value)) })),
      ),
    ),
    h(LevelsPanel, { tr }),
    h(DefaultsPanel, { tr }),
  );
}

/** The persona tab: list, strength buttons, details. */
function PersonaTab({ tr }) {
  const state = useStore();
  return h(
    React.Fragment,
    null,
    h(PersonaList, { tr }),
    state.draft === null ? null : h(PersonaQuick, { tr, draft: state.draft }),
    h(PersonaDetail, { tr }),
  );
}
