/**
 * Shard 41: the bubble engine.
 *
 * Opening the bubble view is three steps (remember the official transcript
 * view → ask ui-chat for `compact` → inject the skin), and closing is the
 * exact reverse. Because the skin rides on host-owned `data-*` anchors, we
 * verify it ~300ms after injection and roll ourselves back when the anchors
 * moved: a skin that misses must never leave the chat in a bad state.
 *
 * This shard also owns the escape hatch: safe mode (URL `?pb-safe=1`, a button,
 * or a remembered localStorage flag) tears every injection down before the
 * snapshot has even arrived.
 */

/** The remembered safe-mode flag, read before the first request. */
const PB_SAFE_KEY = 'dsh-persona-book.safe';
/** How long we wait for the skin to prove itself. */
const PB_SELFCHECK_MS = 320;
/** How many operations the ring buffer keeps for the diagnostics view. */
const PB_LOG_MAX = 10;

/** The runtime facts of the current bubble session (never persisted). */
const pbBubbleRuntime = {
  on: false,
  appliedAt: 0,
  timer: null,
  rollback: null,
  lastCheck: null,
  retrying: false,
};

/** The last operations, newest first. */
const pbOpLog = [];

/** Append one line to the ring buffer. */
function pbLogPush(message) {
  const stamp = new Date().toTimeString().slice(0, 8);
  pbOpLog.unshift(`${stamp} ${message}`);
  if (pbOpLog.length > PB_LOG_MAX) pbOpLog.length = PB_LOG_MAX;
}

/** The ring buffer, newest first. */
function pbLogList() {
  return [...pbOpLog];
}

/** The remembered safe flag. */
function pbSafeFlag() {
  try {
    return localStorage.getItem(PB_SAFE_KEY) === '1';
  } catch {
    return false;
  }
}

/** Remember (or forget) safe mode across reloads. */
function pbRememberSafe(on) {
  try {
    if (on) localStorage.setItem(PB_SAFE_KEY, '1');
    else localStorage.removeItem(PB_SAFE_KEY);
  } catch {
    /* private mode: the URL switch still works for this session */
  }
}

/** Boot: honour `?pb-safe=1` before the snapshot can possibly arrive. */
(function pbBootSafeCheck() {
  try {
    const params = new URLSearchParams(location.search);
    if (params.get('pb-safe') === '1') {
      pbRememberSafe(true);
      pbLogPush(pbTr('log.safeFromLink'));
    } else if (params.get('pb-safe') === '0') {
      pbRememberSafe(false);
    }
  } catch {
    /* no location (tests): nothing to do */
  }
  if (pbSafeFlag()) {
    document.documentElement.setAttribute('data-pb-safe', '1');
    pbLogPush(pbTr('log.safeRemembered'));
  }
})();

/** Whether injections must stay off right now. */
function pbSafeOn(ui) {
  return ui?.safeMode === true || pbSafeFlag();
}

/** The ui-chat transcript view we switched away from (`null` = official default). */
let pbPrevView = null;

/** Ask the host to remember the previous view once per session. */
let pbPrevPersisted = false;

/** One bubble state change: the whole open/close/self-check flow. */
async function pbSyncBubble(ui, forms, rev, presets) {
  const safe = pbSafeOn(ui);
  const bubble = ui?.bubble ?? null;
  if (bubble === null) return pbBubbleRuntime.lastCheck;
  const want = bubble.on === true && !safe && pbBubbleRuntime.rollback === null && forms !== null && forms.available();
  const observed = forms?.get?.()?.transcriptView ?? null;
  if (want) {
    if (pbBubbleRuntime.on && pbBubbleRuntime.appliedAt > 0 && document.getElementById(SKIN_STYLE_ID) !== null) {
      applyAppearance({ ...ui, safeMode: false }, { rev });
      return pbBubbleRuntime.lastCheck;
    }
    pbBubbleRuntime.on = true;
    if (!pbPrevPersisted) {
      pbPrevView = observed ?? 'detailed';
      pbPrevPersisted = true;
      if (bubble.prevTranscriptView === null || bubble.prevTranscriptView === undefined) {
        void runAction('setUi', { section: 'bubble', patch: { prevTranscriptView: pbPrevView } }, { keepDraft: true });
      } else {
        pbPrevView = bubble.prevTranscriptView;
      }
    }
    if (observed !== 'compact') forms.set('transcriptView', 'compact');
    pbLogPush(pbTr('log.bubbleOn', { prev: pbPrevView }));
    applyAppearance({ ...ui, safeMode: false }, { rev });
    pbScheduleSelfCheck(ui, presets);
    return pbBubbleRuntime.lastCheck;
  }
  if (pbBubbleRuntime.on) {
    await pbCloseBubble(forms, { keepRollback: true });
  }
  // 气泡没开（或刚回滚）也要把材质、主题、面板圆角落到文档上：
  // 皮肤样式表里气泡规则是按 `[data-pb-bubble='on']` 收口的，不会误伤官方视图。
  applyAppearance({ ...ui, safeMode: safe }, { rev });
  return pbBubbleRuntime.lastCheck;
}

/** Close the bubble view: remove the skin, then restore the official view. */
async function pbCloseBubble(forms, { keepRollback = false } = {}) {
  const wasRollback = pbBubbleRuntime.rollback;
  if (!keepRollback) pbBubbleRuntime.rollback = null;
  pbRemoveSkin();
  const root = pbRoot();
  root.setAttribute('data-pb-bubble', 'off');
  if (pbBubbleRuntime.on) {
    const target = pbPrevView ?? 'detailed';
    if (forms !== null && forms.available()) forms.set('transcriptView', target);
    pbLogPush(pbTr('log.bubbleOff', { target }));
  }
  pbBubbleRuntime.on = false;
  pbBubbleRuntime.appliedAt = 0;
  if (pbBubbleRuntime.timer !== null) {
    clearTimeout(pbBubbleRuntime.timer);
    pbBubbleRuntime.timer = null;
  }
  if (wasRollback !== null && keepRollback) {
    root.removeAttribute('data-pb-skin');
  }
  return pbBubbleRuntime.lastCheck;
}

/** Wait a beat, then check whether the skin actually landed. */
function pbScheduleSelfCheck(ui, presets) {
  if (pbBubbleRuntime.timer !== null) clearTimeout(pbBubbleRuntime.timer);
  pbBubbleRuntime.appliedAt = Date.now();
  pbBubbleRuntime.timer = setTimeout(() => {
    pbBubbleRuntime.timer = null;
    const result = pbSelfCheck(ui, presets);
    pbBubbleRuntime.lastCheck = result;
    if (!result.ok) void pbRollback(result.reason, ui);
  }, PB_SELFCHECK_MS);
}

/**
 * The self-check. We only roll back on *positive* evidence of a mismatch: an
 * empty chat is "no evidence yet", not a failure (a false rollback would be
 * worse than a skin that needs a second look).
 */
function pbSelfCheck(ui, presets) {
  const root = pbRoot();
  if (ui?.safeMode === true || pbSafeFlag()) return { ok: false, reason: 'safe', evidence: pbTr('audit.safeOn') };
  if (root.getAttribute('data-pb-force-bad') === '1') {
    return { ok: false, reason: 'forced', evidence: pbTr('audit.forced') };
  }
  if (document.getElementById(SKIN_STYLE_ID) === null) {
    return { ok: false, reason: 'nostyle', evidence: pbTr('audit.noStyleTag') };
  }
  const probe = document.querySelector('[data-chat-flow-kind="user"]');
  if (probe === null) return { ok: true, reason: null, evidence: pbTr('audit.noMessage') };
  // The skin paints the theme's colour, not the raw `colors.mine`, whenever a
  // theme is active — so the probe must compare against the effective palette.
  const palette = pbcEffectivePalette(ui, presets);
  const parsed = pbcParse(palette.mine);
  if (parsed === null) return { ok: true, reason: null, evidence: pbTr('audit.noMineBackground') };
  const seen = pbcParse(getComputedStyle(probe).backgroundColor);
  if (seen === null) return { ok: false, reason: 'unstyled', evidence: pbTr('audit.emptyComputed') };
  const same = seen.slice(0, 3).every((value, index) => Math.abs(value - parsed[index]) <= 2);
  if (!same) {
    return {
      ok: false,
      reason: 'mismatch',
      evidence: pbTr('audit.mismatch', { expected: parsed.slice(0, 3).join(', '), actual: seen.slice(0, 3).join(', ') }),
    };
  }
  return { ok: true, reason: null, evidence: pbTr('audit.match') };
}

/** Undo an injection that did not prove itself, and say so in the panel. */
async function pbRollback(reason, ui) {
  pbBubbleRuntime.rollback = { reason, at: Date.now(), evidence: pbBubbleRuntime.lastCheck?.evidence ?? '' };
  pbLogPush(pbTr('log.auditFailed', { reason }));
  pbRemoveSkin();
  pbClearAppearance();
  await pbCloseBubble(null, { keepRollback: true });
  return pbBubbleRuntime.rollback;
}

/** The "try once more" button: forget the rollback and inject again. */
async function pbRetryBubble(ui, forms, rev, presets) {
  pbBubbleRuntime.rollback = null;
  pbBubbleRuntime.on = false;
  pbPrevPersisted = false;
  pbLogPush(pbTr('log.retry'));
  return pbSyncBubble(ui, forms, rev, presets);
}

/** Turn safe mode on or off (state write + immediate local effect). */
async function pbSetSafeMode(on) {
  pbRememberSafe(on);
  if (on) {
    pbRemoveSkin();
    pbClearAppearance();
    pbRoot().setAttribute('data-pb-safe', '1');
    pbLogPush(pbTr('log.safeOn'));
  } else {
    pbRoot().removeAttribute('data-pb-safe');
    pbLogPush(pbTr('log.safeOff'));
  }
  return runAction('setUi', { section: undefined, patch: { safeMode: on } }, { keepDraft: true });
}

/** Everything the appearance tab and the diagnostics view show. */
function pbBubbleStatus() {
  return {
    on: pbBubbleRuntime.on,
    rollback: pbBubbleRuntime.rollback,
    lastCheck: pbBubbleRuntime.lastCheck,
    safe: pbRoot().getAttribute('data-pb-safe') === '1',
    caps: pbRoot().getAttribute('data-pb-caps') ?? '',
    style: document.getElementById(SKIN_STYLE_ID) !== null,
    log: pbLogList(),
  };
}
