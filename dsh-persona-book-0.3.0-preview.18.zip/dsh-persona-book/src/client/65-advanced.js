/**
 * Shard 65: the advanced tab.
 *
 * The generated SKILL.md (exactly what the loader will read), the raw persona
 * JSON for direct edits, and the source documents the character sheet lives in.
 */

/** The advanced tab. */
function AdvancedPanel({ tr }) {
  const state = useStore();
  const skill = state.draftId === null ? null : state.snapshot?.personaSkills?.[state.draftId] ?? null;
  const [raw, setRaw] = React.useState(state.rawJson ?? '');
  const [rawError, setRawError] = React.useState(null);

  // Re-seed the raw buffer when the selected persona changes.
  React.useEffect(() => {
    setRaw(state.rawJson ?? '');
    setRawError(null);
  }, [state.draftId, state.rawJson]);

  const applyRaw = () => {
    try {
      const parsed = JSON.parse(raw);
      replaceDraft(parsed);
      setRawError(null);
      setState({ toast: tr('saved') });
    } catch (error) {
      setRawError(tr('advanced.jsonInvalid'));
    }
  };

  const copy = (text) => {
    void navigator.clipboard?.writeText(text).then(
      () => setState({ toast: tr('diagnose.copied') }),
      () => setState({ toast: tr('failed') }),
    );
  };

  return h(
    React.Fragment,
    null,
    h(
      Section,
      { title: tr('advanced.skill'), hint: tr('advanced.hint') },
      h('pre', { className: 'pb-code-block' }, skill?.text ?? tr('loading')),
      h(
        'div',
        { className: 'pb-row' },
        h('button', { type: 'button', className: 'pb-btn', onClick: () => copy(skill?.text ?? '') }, tr('diagnose.copy')),
        skill?.problems?.length ? h('span', { className: 'pb-badge', 'data-tone': 'warn' }, skill.problems.join(' / ')) : null,
      ),
    ),
    h(
      Section,
      {
        title: tr('advanced.personaJson'),
        actions: h('button', { type: 'button', className: 'pb-btn', 'data-variant': 'primary', disabled: state.busy, onClick: applyRaw }, tr('save')),
      },
      h(TextArea, { value: raw, rows: 12, mono: true, onChange: setRaw }),
      rawError === null ? null : h('pre', { className: 'pb-error' }, rawError),
    ),
    h(
      Section,
      { title: tr('advanced.docs') },
      (state.snapshot?.docs ?? []).map((doc) =>
        h(
          'div',
          { key: doc.id, className: 'pb-level' },
          h('div', { className: 'pb-row', 'data-spread': 'true' }, h('strong', null, doc.label), h('span', { className: 'pb-badge' }, doc.missing ? tr('list.broken') : bytes(doc.size))),
          h('pre', { className: 'pb-code-block' }, doc.preview || '—'),
        ),
      ),
    ),
  );
}
