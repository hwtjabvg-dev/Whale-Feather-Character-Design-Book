/**
 * Shard 64: the defaults tab.
 *
 * The persona's baseline voice — sentence enders, catchphrases, taboos, the emoji
 * policy and the emotion vocabulary — plus the hard boundaries, which the panel
 * shows but refuses to edit because every generated skill must keep them.
 */

/** The defaults tab. */
function DefaultsPanel({ tr }) {
  const state = useStore();
  const draft = state.draft;
  if (draft === null) return h('p', { className: 'pb-hint' }, tr('list.empty'));
  const defaults = draft.defaults ?? {};
  const edit = (path, value) => editDraft(['defaults', ...path], value);

  const emotionText = Object.entries(defaults.emotionWords ?? {})
    .map(([key, words]) => `${key} = ${words}`)
    .join('\n');

  return h(
    React.Fragment,
    null,
    h(
      Section,
      { title: tr('defaults.heading') },
      h(
        'div',
        { className: 'pb-grid-2' },
        h(
          Field,
          { label: tr('defaults.sentenceEnders'), hint: tr('defaults.commaHint') },
          h(TextInput, { value: joinList(defaults.sentenceEnders, '、'), onChange: (value) => edit(['sentenceEnders'], splitList(value)) }),
        ),
        h(
          Field,
          { label: tr('defaults.catchphrases'), hint: tr('defaults.commaHint') },
          h(TextInput, { value: joinList(defaults.catchphrases, '、'), onChange: (value) => edit(['catchphrases'], splitList(value)) }),
        ),
        h(
          Field,
          { label: tr('defaults.taboos'), hint: tr('defaults.commaHint') },
          h(TextInput, { value: joinList(defaults.taboos, '、'), onChange: (value) => edit(['taboos'], splitList(value)) }),
        ),
        h(Field, { label: tr('defaults.punctuation') }, h(TextInput, { value: defaults.punctuation, onChange: (value) => edit(['punctuation'], value) })),
      ),
      h(
        'div',
        { className: 'pb-grid-2' },
        h(Slider, {
          label: tr('defaults.intensity'),
          min: 1,
          max: 10,
          step: 1,
          value: defaults.toneIntensity ?? 5,
          onChange: (value) => edit(['toneIntensity'], value),
        }),
        h(
          Field,
          { label: tr('defaults.emojiPolicy') },
          h(Select, {
            value: defaults.emojiPolicy ?? 'sparse',
            onChange: (value) => edit(['emojiPolicy'], value),
            options: [
              { value: 'sparse', label: tr('defaults.emojiSparse') },
              { value: 'none', label: tr('defaults.emojiNone') },
              { value: 'free', label: tr('defaults.emojiFree') },
            ],
          }),
        ),
      ),
      h(
        Field,
        { label: tr('defaults.emotionWords'), hint: tr('defaults.emotionHint') },
        h(TextArea, {
          value: emotionText,
          rows: 4,
          onChange: (value) => {
            const words = {};
            for (const line of value.split('\n')) {
              const [key, rest] = line.split('=');
              if (key === undefined || rest === undefined) continue;
              const name = key.trim();
              if (name === '') continue;
              words[name] = rest.trim();
            }
            edit(['emotionWords'], words);
          },
        }),
      ),
    ),
    h(
      Section,
      { title: tr('defaults.boundaries'), hint: tr('defaults.boundariesHint') },
      h(
        'ul',
        { className: 'pb-hint', style: { margin: 0, paddingInlineStart: '18px' } },
        (defaults.boundaries ?? []).map((boundary, index) => h('li', { key: `${boundary}-${index}` }, boundary)),
      ),
    ),
  );
}
