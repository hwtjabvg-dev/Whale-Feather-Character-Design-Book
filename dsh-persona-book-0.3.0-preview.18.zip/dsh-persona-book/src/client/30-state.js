/**
 * Shard 30: panel state.
 *
 * A tiny store with one render loop: `update` merges a patch and notifies the
 * panel, which is the only component that subscribes. Drafts live here too, so a
 * tab switch never loses an edit.
 */

/** The store's initial shape. */
const initialState = {
  open: false,
  tab: 'persona',
  loading: false,
  busy: false,
  error: null,
  toast: null,
  snapshot: null,
  /** Working copy of the selected persona. */
  draft: null,
  /** `id` the draft belongs to. */
  draftId: null,
  dirty: false,
  /** Raw persona.json editing buffer (advanced tab). */
  rawJson: '',
  rawError: null,
  docId: 'book',
  doc: null,
  diagnose: null,
  /** The chat config form, captured when the plugin mounts. */
  forms: null,
};

let state = initialState;
const listeners = new Set();

/** Current state, read-only by convention. */
function getState() {
  return state;
}

/** Merge a patch (or the result of a function) and notify subscribers. */
function setState(patch) {
  const next = typeof patch === 'function' ? patch(state) : patch;
  state = { ...state, ...next };
  for (const listener of listeners) listener();
}

/** Subscribe to changes; returns the unsubscribe function. */
function subscribe(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** React hook: the panel re-renders on every store change. */
function useStore() {
  const [, force] = React.useState(0);
  React.useEffect(
    () =>
      subscribe(() => {
        force((value) => value + 1);
      }),
    [],
  );
  return state;
}

/** Show a transient toast under the panel header. */
let toastTimer = null;
function toast(text) {
  if (toastTimer !== null) clearTimeout(toastTimer);
  setState({ toast: text });
  toastTimer = setTimeout(() => setState({ toast: null }), 2600);
}

/** The active persona row inside the current snapshot. */
function activeRow(current = state) {
  const id = current.snapshot?.profiles?.active;
  return current.snapshot?.personas?.find((row) => row.id === id) ?? null;
}

/** The persona row currently open in the editor. */
function draftRow(current = state) {
  return current.snapshot?.personas?.find((row) => row.id === current.draftId) ?? null;
}

/** Fetch the snapshot and (re)seed the draft if the user is not editing. */
async function loadSnapshot({ keepDraft = false } = {}) {
  setState({ loading: true, error: null });
  try {
    const snapshot = await apiGet(ENDPOINT);
    const keep = keepDraft && state.dirty && state.draft !== null;
    const selected = state.draftId ?? snapshot.profiles.active ?? snapshot.personas[0]?.id ?? null;
    const doc = selected === null ? null : (snapshot.personaDocs?.[selected] ?? null);
    // The panel's language is a profile setting, not a host locale: it lands
    // with the snapshot and every later render reads it through pbTr().
    pbLangUse(snapshot?.profiles?.ui?.panel?.lang);
    const draft = keep ? state.draft : doc === null ? null : clone(doc);
    setState({
      snapshot,
      loading: false,
      error: null,
      draft,
      draftId: keep ? state.draftId : selected,
      dirty: keep ? state.dirty : false,
      rawJson: draft === null ? '' : JSON.stringify(draft, null, 2),
      rawError: null,
    });
  } catch (error) {
    setState({ loading: false, error: `${error.code}：${error.message}` });
  }
}

/** Remember the panel language: optimistically first, then in the profile. */
async function setPanelLang(mode) {
  pbLangUse(mode);
  setState({});
  try {
    await runAction('setUi', { section: 'panel', patch: { lang: pbLangPrefGet() } }, { keepDraft: true });
  } catch (error) {
    toast(`${pbTr('failed')}${error.message}`);
  }
}

/** Load one persona document from the snapshot's document map. */
async function apiGetPersona(id) {
  if (state.snapshot === null) await loadSnapshot({ keepDraft: true });
  const doc = state.snapshot?.personaDocs?.[id];
  return doc === undefined ? null : clone(doc);
}

/** Select a persona for editing. */
async function selectPersona(id) {
  if (id === state.draftId) return;
  if (state.dirty && !window.confirm('当前人设有未保存修改。放弃修改并切换？')) return;
  setState({ busy: true, error: null });
  try {
    const persona = await apiGetPersona(id);
    setState({
      busy: false,
      draftId: id,
      draft: persona,
      dirty: false,
      rawJson: persona === null ? '' : JSON.stringify(persona, null, 2),
      rawError: null,
    });
  } catch (error) {
    setState({ busy: false, error: `${error.code}：${error.message}` });
  }
}

/** Apply a change to the draft in memory. */
function editDraft(path, value) {
  setState((current) => {
    if (current.draft === null) return {};
    const draft = setIn(current.draft, path, value);
    return {
      draft,
      dirty: true,
      rawJson: JSON.stringify(draft, null, 2),
    };
  });
}

/** Replace the whole draft (used by the raw editor and by list operations). */
function replaceDraft(draft) {
  setState({ draft, dirty: true, rawJson: JSON.stringify(draft, null, 2), rawError: null });
}

/** Save the draft as the selected persona document. */
async function saveDraft() {
  if (state.draft === null) return;
  setState({ busy: true, error: null });
  try {
    const baseRev = state.snapshot?.personas?.find((row) => row.id === state.draftId)?.rev;
    await apiAction('updatePersona', { id: state.draft.id, def: state.draft, baseRev });
    setState({ busy: false, dirty: false });
    setState({ toast: pbTr('saved') });
    await loadSnapshot({ keepDraft: false });
  } catch (error) {
    setState({ busy: false, error: `${error.code}：${error.message}` });
    toast(`${pbTr('failed')}${error.message}`);
  }
}

/** Run one action and refresh the snapshot. */
async function runAction(action, payload, { keepDraft = false, message = null } = {}) {
  setState({ busy: true, error: null });
  try {
    const result = await apiAction(action, payload, state.snapshot?.rev);
    setState({ busy: false });
    if (message !== null) toast(message);
    await loadSnapshot({ keepDraft });
    return result;
  } catch (error) {
    setState({ busy: false, error: `${error.code}：${error.message}` });
    toast(`${pbTr('failed')}${error.message}`);
    return null;
  }
}
