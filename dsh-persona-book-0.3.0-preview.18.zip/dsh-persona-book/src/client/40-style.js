/**
 * Shard 40: the panel's stylesheet.
 *
 * Injected once as `<style data-plugin="dsh-persona-book" data-plugin-css="panel">`,
 * so removing the plugin removes the styles. Colours come from the official
 * `--dsw-*` tokens with literal fallbacks: the panel follows the host theme for
 * free, and a host that renames a token only loses the tint, not the layout.
 */

/** Marker attribute on our style element. */
const STYLE_MARK = 'data-plugin-css';

/** The stylesheet, written once and reused. */
const PANEL_CSS = `
.pb-scrim {
  position: fixed;
  inset: 0;
  z-index: 9000;
  background: var(--dsw-alias-scrim, rgb(0 0 0 / 0.42));
  display: flex;
  align-items: stretch;
  justify-content: flex-end;
  animation: pb-fade 120ms ease-out;
}
.pb-card {
  --pb-pad: 16px;
  position: relative;
  display: flex;
  flex-direction: column;
  font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  width: min(940px, 100%);
  height: 100%;
  max-height: 100%;
  background: var(--pb-panel-bg, var(--dsw-alias-bg-base, #f7f8fa));
  color: var(--dsw-alias-label-primary, #111111);
  border-left: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.08));
  box-shadow: var(--dsw-elevation-panel, -8px 0 32px rgb(0 0 0 / 0.18));
  border-radius: var(--pb-panel-radius, 0px) 0 0 var(--pb-panel-radius, 0px);
  overflow: hidden;
  animation: pb-slide 160ms cubic-bezier(0.22, 1, 0.36, 1);
}
.pb-card[data-pb-material='frosted'],
.pb-card[data-pb-material='liquid'],
.pb-card[data-pb-material='rough'],
.pb-card[data-pb-material='translucent'] {
  --pb-panel-bg: var(--pb-panel-tint, rgb(247 248 250 / 0.62));
  backdrop-filter: blur(var(--pb-panel-blur, 24px)) saturate(var(--pb-panel-saturate, 160%));
  -webkit-backdrop-filter: blur(var(--pb-panel-blur, 24px)) saturate(var(--pb-panel-saturate, 160%));
}
.pb-head {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 14px var(--pb-pad);
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.07));
}
.pb-brand {
  flex: 0 0 auto;
  width: 44px;
  height: 44px;
  border-radius: 12px;
  overflow: hidden;
  background: var(--dsw-alias-bg-layer-1, #eef1f6);
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.08));
}
.pb-brand img,
.pb-brand svg {
  display: block;
  width: 100%;
  height: 100%;
}
.pb-head-text {
  flex: 1 1 auto;
  min-width: 0;
}
.pb-title {
  margin: 0;
  font-size: 16px;
  font-weight: 650;
  letter-spacing: 0.01em;
}
.pb-subtitle {
  margin: 2px 0 0;
  font-size: 12px;
  line-height: 1.5;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-icon-button {
  flex: 0 0 auto;
  width: 32px;
  height: 32px;
  border: 1px solid transparent;
  border-radius: 10px;
  background: transparent;
  color: inherit;
  font-size: 16px;
  line-height: 1;
  cursor: pointer;
}
.pb-icon-button:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.06));
}
.pb-icon-button:focus-visible,
.pb-button:focus-visible,
.pb-input:focus-visible,
.pb-toggle:focus-visible,
.pb-chip:focus-visible {
  outline: 2px solid var(--dsw-focus-ring-color, #4a90d9);
  outline-offset: 1px;
}
.pb-toggle-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px var(--pb-pad);
  background: var(--dsw-alias-bg-layer-1, rgb(0 0 0 / 0.02));
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.07));
}
.pb-toggle {
  position: relative;
  flex: 0 0 auto;
  width: 44px;
  height: 26px;
  border-radius: 999px;
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.12));
  background: var(--dsw-alias-interactive-bg-hover-solid, #d9dde4);
  cursor: pointer;
  transition: background 160ms ease;
}
.pb-toggle[data-on='true'] {
  background: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
}
.pb-toggle::after {
  content: '';
  position: absolute;
  top: 2px;
  left: 2px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: var(--dsw-alias-label-primary-inverted, #fff);
  box-shadow: 0 1px 3px rgb(0 0 0 / 0.28);
  transition: transform 160ms cubic-bezier(0.22, 1, 0.36, 1);
}
.pb-toggle[data-on='true']::after {
  transform: translateX(18px);
}
.pb-toggle-label {
  font-size: 13px;
  font-weight: 600;
}
.pb-toggle-hint {
  font-size: 11.5px;
  line-height: 1.5;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-tabs {
  display: flex;
  gap: 6px;
  padding: 8px var(--pb-pad);
  overflow-x: auto;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.07));
  scrollbar-width: none;
}
.pb-tabs::-webkit-scrollbar {
  display: none;
}
.pb-tab {
  flex: 0 0 auto;
  padding: 6px 12px;
  border-radius: 999px;
  border: 1px solid transparent;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #3c4250);
  font-size: 13px;
  cursor: pointer;
  white-space: nowrap;
}
.pb-tab:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.05));
}
.pb-tab[data-active='true'] {
  background: var(--pb-accent-soft, rgb(47 111 208 / 0.14));
  border-color: var(--pb-accent-border, rgb(47 111 208 / 0.32));
  color: var(--dsw-alias-label-primary, #111);
  font-weight: 600;
}
.pb-body {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  padding: var(--pb-pad);
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.pb-grid-2 {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 12px;
}
.pb-section {
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.08));
  border-radius: var(--dsw-radius-lg, 14px);
  background: var(--dsw-alias-bg-layer-1, rgb(255 255 255 / 0.5));
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.pb-section > h3 {
  margin: 0;
  font-size: 13.5px;
  font-weight: 650;
}
.pb-hint {
  font-size: 11.5px;
  line-height: 1.55;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-field {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}
.pb-field > label {
  font-size: 12px;
  font-weight: 600;
  color: var(--dsw-alias-label-secondary, #3c4250);
}
.pb-input,
.pb-textarea,
.pb-select {
  width: 100%;
  box-sizing: border-box;
  padding: 8px 10px;
  font: inherit;
  font-size: 13px;
  color: inherit;
  background: var(--dsw-alias-bg-base, #fff);
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.14));
  border-radius: var(--dsw-radius-md, 10px);
}
.pb-textarea {
  min-height: 74px;
  resize: vertical;
  line-height: 1.55;
  font-family: var(--dsw-font-family, inherit);
}
.pb-textarea[data-mono='true'] {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
}
.pb-row {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.pb-row[data-spread='true'] {
  justify-content: space-between;
}
.pb-button {
  padding: 7px 12px;
  font: inherit;
  font-size: 13px;
  border-radius: var(--dsw-radius-md, 10px);
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.14));
  background: var(--dsw-alias-bg-base, #fff);
  color: inherit;
  cursor: pointer;
}
.pb-button:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.05));
}
.pb-button[data-variant='primary'] {
  background: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
  border-color: transparent;
  color: var(--dsw-alias-label-primary-inverted, #fff);
  font-weight: 600;
}
.pb-button[data-variant='ghost'] {
  border-color: transparent;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #3c4250);
}
.pb-button[data-variant='danger'] {
  border-color: var(--dsw-alias-state-error-primary, #d9534f);
  color: var(--dsw-alias-state-error-primary, #d9534f);
  background: transparent;
}
.pb-button:disabled,
.pb-icon-button:disabled {
  opacity: 0.5;
  cursor: default;
}
.pb-persona-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 10px;
  border-radius: var(--dsw-radius-md, 10px);
  border: 1px solid transparent;
  cursor: pointer;
}
.pb-persona-row:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.05));
}
.pb-persona-row[data-selected='true'] {
  border-color: var(--pb-accent-border, rgb(47 111 208 / 0.34));
  background: var(--pb-accent-soft, rgb(47 111 208 / 0.12));
}
.pb-persona-emoji {
  width: 30px;
  height: 30px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  font-size: 17px;
  border-radius: 9px;
  background: var(--dsw-alias-bg-base, #fff);
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.08));
  overflow: hidden;
}
.pb-persona-meta {
  flex: 1 1 auto;
  min-width: 0;
}
.pb-persona-name {
  font-size: 13.5px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.pb-persona-sub {
  font-size: 11.5px;
  color: var(--dsw-alias-label-tertiary, #6a7280);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.pb-badge {
  flex: 0 0 auto;
  padding: 2px 7px;
  border-radius: 999px;
  font-size: 10.5px;
  font-weight: 600;
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.12));
  color: var(--dsw-alias-label-secondary, #3c4250);
  white-space: nowrap;
}
.pb-badge[data-tone='accent'] {
  border-color: var(--pb-accent-border, rgb(47 111 208 / 0.34));
  background: var(--pb-accent-soft, rgb(47 111 208 / 0.14));
  color: var(--pb-accent-strong, #2f6fd0);
}
.pb-badge[data-tone='warn'] {
  border-color: var(--dsw-alias-state-warn-primary, #b8860b);
  color: var(--dsw-alias-state-warn-primary, #b8860b);
}
.pb-badge[data-tone='error'] {
  border-color: var(--dsw-alias-state-error-primary, #d9534f);
  color: var(--dsw-alias-state-error-primary, #d9534f);
}
.pb-level {
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.1));
  border-radius: var(--dsw-radius-md, 10px);
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  background: var(--dsw-alias-bg-base, rgb(255 255 255 / 0.6));
}
.pb-slider {
  width: 100%;
  accent-color: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
}
.pb-footer {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px var(--pb-pad);
  border-top: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.07));
  background: var(--dsw-alias-bg-layer-1, transparent);
}
.pb-footer-status {
  flex: 1 1 auto;
  min-width: 0;
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-error {
  margin: 0;
  padding: 8px 10px;
  border-radius: var(--dsw-radius-md, 10px);
  border: 1px solid var(--dsw-alias-state-error-primary, #d9534f);
  color: var(--dsw-alias-state-error-primary, #d9534f);
  font-size: 12.5px;
  line-height: 1.5;
  white-space: pre-wrap;
}
.pb-toast {
  position: absolute;
  left: 50%;
  bottom: 68px;
  transform: translateX(-50%);
  padding: 7px 14px;
  border-radius: 999px;
  background: var(--dsw-alias-button-floating-fill, rgb(20 22 28 / 0.86));
  color: var(--dsw-alias-label-primary-inverted, #fff);
  font-size: 12.5px;
  pointer-events: none;
  animation: pb-fade 160ms ease-out;
}
.pb-sidebar-button {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 6px 8px;
  border: 1px solid transparent;
  border-radius: var(--dsw-radius-md, 10px);
  background: transparent;
  color: inherit;
  font: inherit;
  font-size: 13px;
  cursor: pointer;
}
.pb-sidebar-button:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.06));
}
.pb-sidebar-button > svg,
.pb-sidebar-button > img {
  width: 22px;
  height: 22px;
  flex: 0 0 auto;
  border-radius: 6px;
}
.pb-sidebar-button[data-wide='false'] {
  justify-content: center;
  padding: 6px;
}
.pb-sidebar-button[data-wide='false'] .pb-sidebar-label {
  display: none;
}
.pb-code-block {
  margin: 0;
  max-height: 340px;
  overflow: auto;
  padding: 10px;
  border-radius: var(--dsw-radius-md, 10px);
  background: var(--dsw-alias-markdown-code-block, rgb(0 0 0 / 0.05));
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 11.5px;
  line-height: 1.55;
  white-space: pre-wrap;
  word-break: break-word;
}
.pb-kv {
  display: grid;
  grid-template-columns: minmax(120px, 34%) 1fr;
  gap: 4px 10px;
  font-size: 12.5px;
}
.pb-kv dt {
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-kv dd {
  margin: 0;
  word-break: break-all;
}
@keyframes pb-fade {
  from { opacity: 0; }
  to { opacity: 1; }
}
@keyframes pb-slide {
  from { transform: translateX(18px); opacity: 0.6; }
  to { transform: translateX(0); opacity: 1; }
}
/* M2: chips, colour rows, the live preview and the small list rows. */
.pb-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 4px 0;
}
.pb-chip {
  padding: 5px 11px;
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.14));
  border-radius: 999px;
  background: var(--dsw-alias-bg-layer-1, rgb(255 255 255 / 0.6));
  color: var(--dsw-alias-text-primary, rgb(24 32 48));
  font-size: 12px;
  line-height: 1.4;
  cursor: pointer;
}
.pb-chip[data-active='true'] {
  border-color: var(--pb-accent, rgb(47 111 208));
  background: var(--pb-accent-soft, rgb(47 111 208 / 0.14));
  color: var(--pb-accent-strong, rgb(47 111 208));
  font-weight: 600;
}
.pb-chip:disabled {
  opacity: 0.5;
  cursor: default;
}
/* The language switch sits in the header: three chips, always visible. */
.pb-lang {
  display: flex;
  gap: 4px;
  align-items: center;
  margin-inline-end: 2px;
}
.pb-lang .pb-chip {
  padding: 3px 8px;
  font-size: 11px;
}
.pb-color {
  flex: 0 0 auto;
  width: 36px;
  height: 30px;
  padding: 0;
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.14));
  border-radius: var(--dsw-radius-sm, 8px);
  background: transparent;
  cursor: pointer;
}
.pb-preview-row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 5px 0;
}
.pb-preview-row[data-side='mine'] {
  flex-direction: row-reverse;
}
.pb-preview-bubble {
  flex: 0 1 auto;
  padding: 8px 12px;
  font-size: 13px;
  line-height: 1.5;
  overflow-wrap: anywhere;
}
.pb-badge[data-tone='good'] {
  border-color: rgb(46 160 67 / 0.45);
  color: rgb(30 128 50);
}
.pb-badge[data-tone='bad'] {
  border-color: var(--dsw-alias-state-error-primary, rgb(217 83 79 / 0.6));
  color: var(--dsw-alias-state-error-primary, rgb(193 62 58));
}
.pb-hint[data-tone='warn'] {
  color: var(--dsw-alias-state-warn-primary, rgb(150 108 12));
}
.pb-hint[data-tone='good'] {
  color: var(--dsw-alias-state-success-primary, rgb(30 128 50));
}
.pb-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin: 6px 0 0;
  padding: 0;
  list-style: none;
}
.pb-list-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 7px 9px;
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.08));
  border-radius: var(--dsw-radius-md, 10px);
  background: var(--dsw-alias-bg-layer-1, rgb(0 0 0 / 0.02));
}
.pb-list-text {
  display: flex;
  flex-direction: column;
  gap: 1px;
  min-width: 0;
}
.pb-list-title {
  font-size: 13px;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.pb-details {
  margin-top: 6px;
  font-size: 12px;
}
.pb-details > summary {
  cursor: pointer;
  color: var(--dsw-alias-text-secondary, rgb(102 112 133));
}
.pb-details[open] > summary {
  margin-bottom: 6px;
}
.pb-section[data-variant='preview'] {
  background: var(--dsw-alias-bg-layer-1, rgb(0 0 0 / 0.02));
}
@media (max-width: 640px) {
  .pb-card { width: 100%; border-left: none; }
  .pb-head { padding: 12px; }
  .pb-body { padding: 12px; }
}
@media (prefers-reduced-motion: reduce) {
  .pb-scrim, .pb-card, .pb-toast { animation: none; }
  .pb-toggle, .pb-toggle::after { transition: none; }
}
@media (prefers-contrast: more) {
  .pb-section, .pb-level { border-color: var(--dsw-alias-border-l3, currentColor); }
}
/* --- assets tab ------------------------------------------------------- */
.pb-cols {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 12px;
}
.pb-sub {
  font-size: 12px;
  font-weight: 600;
  color: var(--dsw-alias-label-secondary, #3c4250);
  margin-block-end: 6px;
}
.pb-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(104px, 1fr));
  gap: 8px;
}
.pb-grid-avatar {
  grid-template-columns: repeat(auto-fill, minmax(84px, 1fr));
}
.pb-inline {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
}
.pb-drop {
  border: 1px dashed var(--dsw-alias-border-l3, rgb(0 0 0 / 0.22));
  border-radius: var(--dsw-radius-lg, 14px);
  padding: 10px;
  text-align: center;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 2px;
  background: var(--dsw-alias-bg-layer-1, rgb(255 255 255 / 0.4));
}
.pb-drop[data-over='true'] {
  border-color: var(--pb-accent, #2f6fd0);
  background: var(--pb-accent-soft, rgb(47 111 208 / 0.12));
}
.pb-drop[data-busy='true'] {
  opacity: 0.7;
  cursor: progress;
}
.pb-drop-title {
  font-size: 12px;
  font-weight: 600;
}
.pb-drop-hint {
  font-size: 11px;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-file {
  display: none;
}
.pb-wall {
  display: flex;
  flex-direction: column;
  gap: 4px;
  align-items: stretch;
  padding: 3px;
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.08));
  border-radius: var(--dsw-radius-lg, 14px);
  background: var(--dsw-alias-bg-layer-1, rgb(255 255 255 / 0.5));
  cursor: pointer;
  font: inherit;
  color: inherit;
}
.pb-wall[data-active='true'] {
  border-color: var(--pb-accent, #2f6fd0);
  box-shadow: 0 0 0 1px var(--pb-accent, #2f6fd0);
}
.pb-wall-swatch {
  display: block;
  block-size: 42px;
  border-radius: var(--dsw-radius-md, 10px);
  background: linear-gradient(160deg, var(--dsw-alias-bg-layer-2, rgb(230 238 248)), var(--dsw-alias-bg-layer-1, rgb(255 255 255)));
}
.pb-wall[data-builtin='deep-light'] .pb-wall-swatch {
  background-color: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  background-image: var(--pb-wall-deep-light, linear-gradient(180deg, rgb(11 37 69), rgb(18 58 99) 60%, rgb(27 84 128)));
  background-size: cover;
}
.pb-wall[data-builtin='whale-fall'] .pb-wall-swatch {
  background-color: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  background-image: var(--pb-wall-whale-fall, radial-gradient(circle at 30% 30%, rgb(43 75 122), rgb(10 26 47) 70%));
  background-size: cover;
}
.pb-wall[data-builtin='sea-glints'] .pb-wall-swatch {
  background-color: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  background-image: var(--pb-wall-sea-glints, linear-gradient(200deg, rgb(127 200 232), rgb(47 127 176) 70%));
  background-size: cover;
}
.pb-wall[data-builtin='aurora'] .pb-wall-swatch {
  background-color: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  background-image: var(--pb-wall-aurora, linear-gradient(160deg, rgb(18 58 99), rgb(47 158 143) 55%, rgb(122 91 208)));
  background-size: cover;
}
.pb-wall[data-builtin='coral-warm'] .pb-wall-swatch {
  background-color: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  background-image: var(--pb-wall-coral-warm, linear-gradient(170deg, rgb(255 181 154), rgb(226 112 122) 70%));
  background-size: cover;
}
.pb-wall[data-builtin='moon-sea'] .pb-wall-swatch {
  background-color: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  background-image: var(--pb-wall-moon-sea, linear-gradient(180deg, rgb(16 35 61), rgb(42 74 114) 65%, rgb(201 216 234)));
  background-size: cover;
}
.pb-wall[data-builtin='bubbles'] .pb-wall-swatch {
  background-color: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  background-image: var(--pb-wall-bubbles, radial-gradient(circle at 25% 75%, rgb(207 233 255), rgb(63 127 189) 65%, rgb(22 54 92)));
  background-size: cover;
}
.pb-wall[data-builtin='deep-grid'] .pb-wall-swatch {
  background-color: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  background-image: var(--pb-wall-deep-grid, repeating-linear-gradient(0deg, rgb(140 190 230 / 0.3) 0 1px, transparent 1px 12px), repeating-linear-gradient(90deg, rgb(140 190 230 / 0.3) 0 1px, transparent 1px 12px), rgb(13 37 64));
  background-size: cover;
}
.pb-wall-label {
  font-size: 11.5px;
  padding-block-end: 2px;
  color: var(--dsw-alias-label-secondary, #3c4250);
}
.pb-asset {
  display: flex;
  flex-direction: column;
  gap: 3px;
  padding: 4px;
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.08));
  border-radius: var(--dsw-radius-lg, 14px);
  background: var(--dsw-alias-bg-layer-1, rgb(255 255 255 / 0.5));
  min-width: 0;
}
.pb-asset[data-active='true'] {
  border-color: var(--pb-accent, #2f6fd0);
}
.pb-thumb {
  position: relative;
  block-size: 62px;
  border-radius: var(--dsw-radius-md, 10px);
  overflow: hidden;
  background: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.05));
  display: flex;
  align-items: center;
  justify-content: center;
}
.pb-thumb > img {
  inline-size: 100%;
  block-size: 100%;
  object-fit: cover;
  display: block;
}
.pb-thumb-glyph {
  font-size: 22px;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-asset .pb-badge {
  position: absolute;
  inset-block-start: 3px;
  inset-inline-end: 3px;
}
.pb-asset-name {
  font-size: 11.5px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.pb-asset-meta {
  font-size: 10.5px;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-asset-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}
.pb-mini {
  font: inherit;
  font-size: 11px;
  padding: 3px 7px;
  border-radius: var(--dsw-radius-sm, 8px);
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.14));
  background: var(--dsw-alias-bg-base, #fff);
  color: inherit;
  cursor: pointer;
}
.pb-mini[data-active='true'] {
  border-color: var(--pb-accent, #2f6fd0);
  color: var(--pb-accent, #2f6fd0);
}
.pb-mini-danger {
  color: var(--dsw-alias-label-error, #b4232a);
}
.pb-seat {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-block-end: 8px;
  border-block-end: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.06));
}
.pb-seat:last-child {
  border-block-end: 0;
  padding-block-end: 0;
}
.pb-seat-label {
  font-size: 12px;
  font-weight: 650;
}
.pb-meter {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.pb-meter-bar {
  block-size: 6px;
  border-radius: 999px;
  background: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.08));
  overflow: hidden;
}
.pb-meter-fill {
  block-size: 100%;
  border-radius: 999px;
  background: var(--pb-accent, #2f6fd0);
}
.pb-meter-text {
  font-size: 11px;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-sound-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-block-end: 8px;
}
.pb-sound-label {
  flex: 0 0 7.5em;
  font-size: 13px;
}
.pb-sound-row > .pb-select,
.pb-sound-row > select {
  flex: 1 1 auto;
  min-inline-size: 0;
}
.pb-drop-icon {
  font-size: 20px;
  line-height: 1;
}
.pb-list-row {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.pb-button[data-tone='danger'] {
  color: var(--dsw-alias-label-error, rgb(190 60 60));
  border-color: var(--dsw-alias-border-l3, rgb(0 0 0 / 0.2));
}
.pb-preview-avatar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  inline-size: 26px;
  block-size: 26px;
  flex: 0 0 auto;
}
.pb-preview-fallback {
  font-size: 18px;
  line-height: 1;
}
.pb-warn {
  color: var(--dsw-alias-label-warning, #9a6400);
}

/* ------------------------------------------------------------------ *
 * Apple-ish controls: one segmented control, one switch, one slider,
 * one settings row, one folded row, one tile. Big targets, few chips.
 * ------------------------------------------------------------------ */

.pb-seg {
  display: inline-flex;
  align-items: stretch;
  gap: 2px;
  padding: 2px;
  border-radius: 10px;
  background: var(--dsw-alias-bg-layer-1, rgb(0 0 0 / 0.05));
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.06));
  max-inline-size: 100%;
}
.pb-seg-item {
  appearance: none;
  border: 0;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #3c4250);
  font: inherit;
  font-size: 13px;
  line-height: 1.2;
  padding: 7px 13px;
  border-radius: 8px;
  cursor: pointer;
  white-space: nowrap;
}
.pb-seg-item[data-active='true'] {
  background: var(--dsw-alias-bg-base, #ffffff);
  color: var(--dsw-alias-label-primary, #111111);
  font-weight: 600;
  box-shadow: 0 1px 3px rgb(0 0 0 / 0.14);
}
.pb-seg-item:disabled {
  opacity: 0.5;
  cursor: default;
}
.pb-seg-item:focus-visible {
  outline: 2px solid var(--dsw-focus-ring-color, #4a90d9);
  outline-offset: 1px;
}

.pb-switch {
  position: relative;
  flex: 0 0 auto;
  inline-size: 51px;
  block-size: 31px;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: var(--dsw-alias-interactive-bg-hover-solid, #d9dde4);
  cursor: pointer;
  transition: background 160ms ease;
}
.pb-switch::after {
  content: '';
  position: absolute;
  inset-block-start: 2px;
  inset-inline-start: 2px;
  inline-size: 27px;
  block-size: 27px;
  border-radius: 50%;
  background: var(--dsw-alias-label-primary-inverted, #ffffff);
  box-shadow: 0 3px 8px rgb(0 0 0 / 0.18);
  transition: transform 160ms ease;
}
.pb-switch[data-on='true'] {
  background: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
}
.pb-switch[data-on='true']::after {
  transform: translateX(20px);
}
.pb-switch:disabled {
  opacity: 0.5;
  cursor: default;
}
.pb-switch:focus-visible {
  outline: 2px solid var(--dsw-focus-ring-color, #4a90d9);
  outline-offset: 2px;
}

.pb-btn {
  appearance: none;
  font: inherit;
  font-size: 13px;
  padding: 9px 14px;
  border-radius: var(--dsw-radius-md, 10px);
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.14));
  background: var(--dsw-alias-bg-base, #ffffff);
  color: inherit;
  cursor: pointer;
}
.pb-btn:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.05));
}
.pb-btn[data-variant='primary'] {
  background: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
  border-color: transparent;
  color: var(--dsw-alias-label-primary-inverted, #ffffff);
  font-weight: 600;
}
.pb-btn[data-variant='ghost'] {
  border-color: transparent;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #3c4250);
}
.pb-btn[data-variant='danger'] {
  border-color: var(--dsw-alias-state-error-primary, #d9534f);
  color: var(--dsw-alias-state-error-primary, #d9534f);
  background: transparent;
}
.pb-btn[data-block='true'] {
  display: block;
  inline-size: 100%;
}
.pb-btn:disabled {
  opacity: 0.5;
  cursor: default;
}
.pb-btn:focus-visible {
  outline: 2px solid var(--dsw-focus-ring-color, #4a90d9);
  outline-offset: 1px;
}

.pb-group {
  display: flex;
  flex-direction: column;
  border-radius: var(--dsw-radius-lg, 14px);
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.08));
  background: var(--dsw-alias-bg-layer-1, rgb(255 255 255 / 0.5));
  overflow: hidden;
}
.pb-group-title {
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.02em;
  color: var(--dsw-alias-label-tertiary, #6a7280);
  padding: 0 4px 6px;
  text-transform: uppercase;
}
.pb-row[data-role='setting'] {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: nowrap;
  padding: 11px 14px;
  min-block-size: 46px;
  border-block-end: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.07));
  box-sizing: border-box;
}
.pb-row[data-role='setting']:last-child {
  border-block-end: 0;
}
.pb-row-text {
  flex: 1 1 auto;
  min-inline-size: 0;
}
.pb-row-title {
  font-size: 14px;
  font-weight: 500;
}
.pb-row-hint {
  font-size: 12px;
  line-height: 1.35;
  color: var(--dsw-alias-label-tertiary, #6a7280);
  margin-block-start: 2px;
}
.pb-row-control {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 8px;
}
.pb-row[data-role='setting'] > .pb-input,
.pb-row[data-role='setting'] > .pb-seg {
  flex: 0 1 auto;
}

.pb-fold {
  border-radius: var(--dsw-radius-lg, 14px);
  border: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.08));
  background: var(--dsw-alias-bg-layer-1, rgb(255 255 255 / 0.5));
  overflow: hidden;
}
.pb-fold-head {
  display: flex;
  align-items: center;
  gap: 12px;
  inline-size: 100%;
  text-align: start;
  font: inherit;
  color: inherit;
  padding: 13px 14px;
  min-block-size: 46px;
  border: 0;
  border-block-end: 1px solid transparent;
  background: transparent;
  cursor: pointer;
}
.pb-fold[data-open='true'] .pb-fold-head {
  border-block-end-color: var(--dsw-alias-border-l1, rgb(0 0 0 / 0.07));
}
.pb-fold-head:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.04));
}
.pb-chevron {
  flex: 0 0 auto;
  inline-size: 18px;
  block-size: 18px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--dsw-alias-label-tertiary, #6a7280);
  transition: transform 160ms ease;
}
.pb-chevron::before {
  content: '\\203A';
  font-size: 20px;
  line-height: 1;
  transform: rotate(90deg);
}
.pb-fold[data-open='true'] .pb-chevron {
  transform: rotate(90deg);
}
.pb-fold-body {
  padding: 12px 14px 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.pb-quick {
  display: flex;
  gap: 10px;
}
.pb-quick-btn {
  flex: 1 1 0;
  appearance: none;
  font: inherit;
  cursor: pointer;
  padding: 18px 8px;
  border-radius: var(--dsw-radius-lg, 14px);
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.12));
  background: var(--dsw-alias-bg-base, #ffffff);
  color: inherit;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}
.pb-quick-btn[data-active='true'] {
  border-color: transparent;
  background: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
  color: var(--dsw-alias-label-primary-inverted, #ffffff);
  box-shadow: 0 6px 18px rgb(0 0 0 / 0.16);
}
.pb-quick-value {
  font-size: 20px;
  font-weight: 650;
  line-height: 1;
}
.pb-quick-label {
  font-size: 12.5px;
}

.pb-prow {
  display: flex;
  align-items: center;
  gap: 12px;
  inline-size: 100%;
  text-align: start;
  font: inherit;
  color: inherit;
  padding: 10px 12px;
  border: 0;
  border-block-end: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.07));
  background: transparent;
  cursor: pointer;
  box-sizing: border-box;
}
.pb-prow:last-child {
  border-block-end: 0;
}
.pb-prow[data-selected='true'] {
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.04));
}
.pb-prow-avatar {
  flex: 0 0 auto;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  inline-size: 34px;
  block-size: 34px;
  border-radius: 50%;
  overflow: hidden;
  background: var(--dsw-alias-bg-layer-1, rgb(0 0 0 / 0.05));
  font-size: 19px;
}
.pb-prow-text {
  flex: 1 1 auto;
  min-inline-size: 0;
}
.pb-prow-name {
  font-size: 14.5px;
  font-weight: 550;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.pb-prow-sub {
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-check {
  flex: 0 0 auto;
  inline-size: 22px;
  block-size: 22px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  color: var(--dsw-alias-label-primary-inverted, #ffffff);
  background: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
}

.pb-themes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
}
.pb-theme {
  appearance: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  padding: 10px;
  border-radius: var(--dsw-radius-lg, 14px);
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.12));
  background: var(--dsw-alias-bg-base, #ffffff);
  display: flex;
  flex-direction: column;
  gap: 8px;
  align-items: stretch;
}
.pb-theme[data-active='true'] {
  border-color: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
  box-shadow: 0 0 0 2px var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
}
.pb-theme-preview {
  block-size: 62px;
  border-radius: 10px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 6px;
  padding: 8px;
  box-sizing: border-box;
  background: var(--dsw-alias-bg-layer-1, rgb(0 0 0 / 0.05));
}
.pb-theme[data-theme='deepsea'] .pb-theme-preview {
  background: linear-gradient(160deg, var(--pb-theme-deep-a, #0a1a30), var(--pb-theme-deep-b, #16405f));
}
.pb-theme[data-theme='light'] .pb-theme-preview {
  background: linear-gradient(160deg, var(--pb-theme-light-a, #f4f6fa), var(--pb-theme-light-b, #dfe6f2));
}
.pb-theme[data-theme='system'] .pb-theme-preview {
  background: linear-gradient(160deg, var(--pb-theme-light-a, #f4f6fa) 0 50%, var(--pb-theme-deep-b, #16405f) 50% 100%);
}
.pb-theme-bubble {
  block-size: 14px;
  border-radius: 7px;
  inline-size: 72%;
  background: var(--dsw-alias-bg-base, #ffffff);
}
.pb-theme-bubble[data-side='mine'] {
  align-self: flex-end;
  background: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
}
.pb-theme-name {
  font-size: 12.5px;
  font-weight: 550;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
}

.pb-walls {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(104px, 1fr));
  gap: 10px;
}
.pb-wall {
  appearance: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  position: relative;
  padding: 0;
  border-radius: var(--dsw-radius-lg, 14px);
  border: 1px solid var(--dsw-alias-border-l2, rgb(0 0 0 / 0.12));
  background: var(--dsw-alias-bg-layer-1, rgb(0 0 0 / 0.05));
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.pb-wall[data-active='true'] {
  border-color: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
  box-shadow: 0 0 0 2px var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
}
.pb-wall-swatch {
  display: block;
  block-size: 74px;
  inline-size: 100%;
  background: var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.08));
}
.pb-wall-img {
  display: block;
  inline-size: 100%;
  block-size: 74px;
  object-fit: cover;
}
.pb-wall-label {
  display: block;
  font-size: 12px;
  padding: 6px 8px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: start;
}
.pb-wall-del {
  position: absolute;
  inset-block-start: 4px;
  inset-inline-end: 4px;
  inline-size: 24px;
  block-size: 24px;
  border-radius: 50%;
  border: 0;
  cursor: pointer;
  font-size: 13px;
  line-height: 1;
  color: var(--dsw-alias-label-primary-inverted, #ffffff);
  background: var(--dsw-alias-scrim, rgb(0 0 0 / 0.42));
}
.pb-tile {
  appearance: none;
  cursor: pointer;
  inline-size: 100%;
  min-block-size: 104px;
  border-radius: var(--dsw-radius-lg, 14px);
  border: 1px dashed var(--dsw-alias-border-l3, rgb(0 0 0 / 0.2));
  background: transparent;
  color: var(--dsw-alias-label-secondary, #3c4250);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  font: inherit;
  padding: 8px;
  box-sizing: border-box;
}
.pb-tile[data-over='true'] {
  border-color: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
  background: var(--dsw-alias-interactive-bg-hover, rgb(0 0 0 / 0.04));
}
.pb-tile-plus {
  font-size: 26px;
  line-height: 1;
  color: var(--dsw-alias-label-tertiary, #6a7280);
}
.pb-tile-label {
  font-size: 12px;
  text-align: center;
}

.pb-wall-pick {
  appearance: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  inline-size: 100%;
  padding: 0;
  border: 0;
  background: transparent;
  text-align: start;
}
.pb-wall-swatch[data-empty='true'] {
  background-image: linear-gradient(135deg, var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.08)) 25%, transparent 25%, transparent 50%, var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.08)) 50%, var(--dsw-alias-bg-layer-2, rgb(0 0 0 / 0.08)) 75%, transparent 75%);
  background-size: 12px 12px;
}

/* Folds stacked inside one group share the card: hairlines, no inner borders. */
.pb-group > .pb-fold {
  border: 0;
  border-radius: 0;
  background: transparent;
  border-block-end: 1px solid var(--dsw-alias-border-l1, rgb(0 0 0 / 0.07));
}
.pb-group > .pb-fold:last-child {
  border-block-end: 0;
}
.pb-group > .pb-fold[data-open='true'] .pb-fold-head {
  border-block-end-color: transparent;
}

.pb-slider {
  accent-color: var(--pb-accent, var(--dsw-alias-state-business-primary, #2f6fd0));
  inline-size: 100%;
  min-inline-size: 120px;
}

@media (max-width: 640px) {
  .pb-themes {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .pb-quick {
    gap: 8px;
  }
  .pb-quick-btn {
    padding: 14px 6px;
  }
}
/* 基于 dsh-web Git 图 0.4.6 的设计令牌重新实现；Apache-2.0 来源见项目说明。 */
.pb-context-seat,.pb-context-anchor{display:inline-flex;align-items:center;position:relative;font-family:inherit}
.pb-context-chip{display:inline-flex;align-items:center;gap:4px;min-height:28px;max-width:240px;padding:0 8px;border:0;border-radius:16px;background:transparent;color:var(--dsw-alias-label-primary,#182a4d);font-family:inherit;font-weight:500;font-size:13px;line-height:20px;cursor:pointer}
.pb-context-chip>span:first-of-type{max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pb-context-chip>span:last-child{color:var(--dsw-alias-label-tertiary,#738299)}
.pb-context-chip:hover,.pb-context-chip[aria-expanded=true]{background:var(--dsw-alias-interactive-bg-hover,rgb(0 0 0 / .05))}
.pb-context-backdrop{position:fixed;inset:0;z-index:30}
.pb-context-popover{position:absolute;top:calc(100% + 4px);left:0;z-index:100;width:min(280px,calc(100vw - 28px));max-height:360px;display:flex;flex-direction:column;padding:4px;border:1px solid var(--dsw-alias-border-l2,rgb(0 0 0 / .12));border-radius:12px;background:var(--dsw-specific-menu,var(--dsw-alias-bg-overlay,#ffffff));color:var(--dsw-alias-label-primary,#182a4d);box-shadow:var(--dsw-shadow-lv3,0 12px 32px rgb(0 0 0 / .14));box-sizing:border-box}
.pb-context-search{display:flex;align-items:center;gap:6px;margin:8px;padding:6px 10px;border:2px solid transparent;border-radius:8px;background:var(--dsw-alias-interactive-bg-hover-solid,#f1f3f5)}
.pb-context-search:focus-within{border-color:var(--dsw-alias-brand-primary,#335c8d)}
.pb-context-search input{flex:1;min-width:0;border:0;outline:none;background:none;color:var(--dsw-alias-label-primary,#182a4d);font:inherit;font-size:13px}
.pb-context-list{flex:1;min-height:64px;overflow:auto;padding:2px 6px 6px;scrollbar-width:thin}
.pb-context-item{display:flex;align-items:center;gap:8px;width:100%;border:0;border-radius:8px;padding:7px 8px;background:transparent;color:inherit;text-align:left;cursor:pointer;font:inherit}
.pb-context-item-text{flex:1;min-width:0}
.pb-context-item strong{display:block;font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pb-context-item small{display:block;margin-top:2px;color:var(--dsw-alias-label-tertiary,#738299);font-size:11px}
.pb-context-check{color:var(--dsw-alias-brand-primary,#335c8d)}
.pb-context-footer{display:flex;flex-direction:column;gap:2px;border-top:1px solid var(--dsw-alias-border-l1,rgb(0 0 0 / .08));padding:6px}
.pb-context-footer button{display:flex;align-items:center;gap:8px;padding:7px 10px;border:0;border-radius:8px;background:none;color:inherit;font:inherit;font-size:13px;text-align:left;cursor:pointer}
.pb-context-footer small{margin-left:auto;color:var(--dsw-alias-label-tertiary,#738299)}
.pb-context-item:hover,.pb-context-footer button:hover,.pb-native-header button:hover{background:var(--dsw-alias-interactive-bg-hover,rgb(0 0 0 / .05))}
.pb-context-empty{padding:14px 10px;text-align:center;font-size:12px;color:var(--dsw-alias-label-tertiary,#738299)}
.pb-context-error{font-size:12px;margin:0 8px 8px;padding:6px 10px;border-radius:8px;color:var(--dsw-alias-state-error-primary,#af505a);background:color-mix(in srgb,var(--dsw-alias-state-error-primary,#af505a) 12%,transparent)}
.pb-context-chip:focus-visible,.pb-context-item:focus-visible,.pb-context-footer button:focus-visible,.pb-native-header button:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#335c8d);outline-offset:2px}
.pb-context-item:disabled{opacity:.55;cursor:wait}
.pb-native-scrim{position:fixed;inset:0;z-index:9000;display:grid;place-items:center;padding:24px;background:var(--dsw-alias-bg-mask-2,rgb(0 0 0 / .42));box-sizing:border-box}
.pb-native-dialog{width:min(1180px,100%);height:min(820px,90vh);height:min(820px,90dvh);min-height:0;display:flex;flex-direction:column;overflow:hidden;border:1px solid var(--dsw-alias-border-l2,rgb(0 0 0 / .12));border-radius:12px;background:var(--dsw-alias-bg-overlay,#f8faff);color:var(--dsw-alias-label-primary,#182a4d);box-shadow:var(--dsw-shadow-lv3,0 12px 32px rgb(0 0 0 / .18));font-family:inherit}
.pb-native-dialog[data-full=true]{width:100%;height:100%;max-height:100%}
.pb-native-header{display:flex;align-items:center;gap:10px;padding:12px 16px;border-bottom:1px solid var(--dsw-alias-border-l1,rgb(0 0 0 / .08));flex:none}
.pb-native-heading{flex:1;min-width:0}
.pb-native-heading h3{font-size:15px;font-weight:600;margin:0 0 2px}
.pb-native-heading p{font-size:12px;color:var(--dsw-alias-label-secondary,#738299);margin:0}
.pb-native-header button{border:0;border-radius:8px;background:none;color:var(--dsw-alias-label-secondary,#738299);cursor:pointer;font:inherit}
.pb-native-text{font-size:12px;padding:6px 9px}
.pb-native-icon{width:28px;height:28px;display:grid;place-items:center;font-size:20px}
.pb-native-frame{display:block;width:100%;flex:1;min-height:0;border:0}
@media(max-width:640px){.pb-native-scrim{padding:8px;height:var(--pb-native-height,100vh);bottom:auto}.pb-native-dialog{height:100%}.pb-native-header{padding:10px;gap:7px}.pb-native-heading p{font-size:10px}.pb-native-text{font-size:10px;padding:5px}.pb-context-chip>span:first-of-type{max-width:135px}}

`;

/** Inject the stylesheet once; returns a disposer. */
function pbHostStyle(css) { const tag=document.createElement('style');tag.dataset.plugin=PLUGIN_ID;tag.dataset.pluginCss='native-chat';tag.textContent=css;document.head.append(tag);return tag; }
function ensureStyle() {
  if (typeof document === 'undefined') return () => {};
  const existing = document.querySelector(`style[data-plugin="${PLUGIN_ID}"][${STYLE_MARK}="panel"]`);
  if (existing !== null) return () => {};
  const tag = document.createElement('style');
  tag.setAttribute('data-plugin', PLUGIN_ID);
  tag.setAttribute(STYLE_MARK, 'panel');
  tag.textContent = PANEL_CSS;
  document.head.append(tag);
  return () => {
    tag.remove();
  };
}
