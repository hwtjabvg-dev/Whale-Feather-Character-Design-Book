/**
 * Shard 71: the "more" tab.
 *
 * One iOS settings page: a row per job, a control or a chevron on the right,
 * hairline separators, everything that needs room folded away until asked for.
 * Import, the five export shapes, the self-check and the repair switch, the raw
 * persona JSON, and the way out.
 */

EXTRA_TABS.push({ id: 'more', label: 'tabs.more', render: (props) => h(MoreTab, props) });

const PB_EXPORT_FORMATS = ['persona', 'skill', 'stcard', 'bundle', 'prompt'];

/** The self-check card: safe mode, the last rollback, and the operation log. */
function SafePanel({ tr }) {
  const state = useStore();
  const snapshot = state.snapshot;
  const ui = snapshot?.profiles?.ui ?? null;
  const [status, setStatus] = React.useState(null);
  React.useEffect(() => {
    setStatus(pbBubbleStatus());
  }, [snapshot?.rev]);
  const safe = ui === null ? true : pbSafeOn(ui);
  const rollback = status?.rollback ?? null;
  const lastCheck = status?.lastCheck ?? null;
  return h(
    React.Fragment,
    null,
    h(PbSwitch, {
      label: tr('safe.toggle'),
      hint: tr('safe.toggleHint'),
      on: safe,
      disabled: state.busy,
      onChange: (on) => void pbSetSafeMode(on),
    }),
    h(PbRow, {
      title: `${tr('safe.status')}${status?.caps === '' || status?.caps === undefined ? '—' : status.caps}`,
      hint: status?.style === true ? tr('safe.styleOn') : tr('safe.styleOff'),
      control: h(PbBtn, {
        disabled: state.busy || safe,
        onClick: () => void pbRetryBubble(ui, state.forms, snapshot?.rev, snapshot?.presets),
      }, tr('safe.retry')),
    }),
    lastCheck === null
      ? h('p', { className: 'pb-hint' }, tr('safe.neverChecked'))
      : h('p', { className: 'pb-hint' }, `${tr('safe.lastCheck')}${lastCheck}`),
    rollback === null || rollback === undefined
      ? null
      : h('p', { className: 'pb-hint', 'data-tone': 'warn' }, `${tr('safe.rolledBack')}${rollback}`),
    (status?.log ?? []).length === 0
      ? null
      : h('pre', { className: 'pb-code-block' }, [tr('safe.log'), ...status.log].join('\n')),
  );
}

function MoreTab({ tr, forms }) {
  const state = useStore();
  const snapshot = state.snapshot;
  const [busy, setBusy] = React.useState(false);
  const [staged, setStaged] = React.useState(null);
  const [idText, setIdText] = React.useState('');
  const [titleText, setTitleText] = React.useState('');
  const [showPreview, setShowPreview] = React.useState(false);
  const [failure, setFailure] = React.useState('');
  const [note, setNote] = React.useState('');

  if (snapshot === null) return h('p', { className: 'pb-hint' }, tr('loading'));
  const personas = snapshot.personas ?? [];
  const target = snapshot.activePersona?.id ?? state.activeId ?? personas[0]?.id ?? '';
  const targetRow = personas.find((row) => row.id === target) ?? null;

  /** Download one shape of the chosen persona. */
  const download = (format) => {
    if (target === '') return;
    window.location.href = apiExportUrl(format, target);
  };

  /** Copy the plain system prompt, so it works in any other chat box. */
  const copyPrompt = async () => {
    try {
      const text = await apiExportText('prompt', target);
      await navigator.clipboard.writeText(text);
      toast(tr('port.copied'));
    } catch (error) {
      setFailure(error.message ?? String(error));
    }
  };

  /** Hand the file to the host and show what it recognised. */
  const stage = async (file) => {
    if (!file) return;
    setBusy(true);
    setFailure('');
    setNote('');
    try {
      const result = await apiImport(file, file.name);
      setStaged(result);
      setIdText(result.persona?.id ?? '');
      setTitleText(result.persona?.title ?? '');
      setShowPreview(false);
    } catch (error) {
      setStaged(null);
      setFailure(error.message ?? String(error));
    } finally {
      setBusy(false);
    }
  };

  /** Confirm: the host writes the persona and files the original bytes away. */
  const commit = async () => {
    if (staged === null) return;
    setBusy(true);
    setFailure('');
    try {
      const result = await apiImportCommit({
        token: staged.token,
        name: staged.name,
        id: idText.trim(),
        title: titleText.trim(),
      });
      await loadSnapshot({ keepDraft: true });
      selectPersona(result.id);
      setNote([tr('port.done'), ...(result.problems ?? [])].join(' '));
      setStaged(null);
    } catch (error) {
      setFailure(error.message ?? String(error));
    } finally {
      setBusy(false);
    }
  };

  const recognized = staged === null ? [] : [
    `${tr('port.recognizedAs')}${staged.source}`,
    ...(staged.images?.length > 0 ? [tr('port.images').replace('{n}', String(staged.images.length))] : []),
  ];

  return h(
    PbGroup,
    { title: tr('tabs.more') },
    h(
      PbFold,
      { name: 'more-import', title: tr('more.import'), hint: tr('more.importHint') },
      h(
        PbDrop,
        { tr, accept: '.json,.zip,.png,.md,.txt,.card,application/json', kind: 'import', busy, onFile: stage },
        h('span', null, busy ? tr('port.reading') : tr('port.dropHint')),
      ),
      failure !== '' ? h('p', { className: 'pb-error' }, failure) : null,
      note !== '' ? h('p', { className: 'pb-hint', 'data-tone': 'good' }, note) : null,
      staged === null
        ? null
        : h(
            'div',
            { className: 'pb-card' },
            h('p', { className: 'pb-hint' }, ...recognized),
            h(
              'div',
              { className: 'pb-grid' },
              h(Field, { label: tr('port.titleLabel') }, h(TextInput, { value: titleText, onChange: setTitleText })),
              h(Field, { label: tr('port.idLabel'), hint: tr('port.idHint') }, h(TextInput, { value: idText, onChange: setIdText })),
            ),
            staged.problems?.length > 0
              ? h(
                  'div',
                  null,
                  h('p', { className: 'pb-hint' }, tr('port.problemsTitle')),
                  h('ul', { className: 'pb-list' }, ...staged.problems.map((line, index) => h('li', { key: index }, line))),
                )
              : null,
            h(
              'div',
              { className: 'pb-inline' },
              h(PbBtn, { variant: 'primary', disabled: busy, onClick: commit }, tr('port.confirm')),
              h(PbBtn, { onClick: () => setStaged(null) }, tr('port.cancel')),
              h(PbBtn, { onClick: () => setShowPreview(!showPreview) }, showPreview ? tr('port.hidePreview') : tr('port.showPreview')),
            ),
            showPreview ? h('pre', { className: 'pb-code-block' }, staged.preview ?? '') : null,
          ),
    ),

    h(
      PbFold,
      { name: 'more-export', title: tr('more.export'), hint: tr('more.exportHint') },
      h(PbRow, {
        title: tr('port.exportTitle'),
        hint: tr('port.exportHint'),
        control: targetRow === null ? null : h('span', { className: 'pb-badge' }, targetRow.title),
      }),
      target === ''
        ? h('p', { className: 'pb-hint' }, tr('port.needPersona'))
        : h(
            React.Fragment,
            null,
            h(
              'div',
              { className: 'pb-inline' },
              ...PB_EXPORT_FORMATS.map((format) =>
                h(PbBtn, { key: format, onClick: () => download(format) }, tr(`port.format.${format}`)),
              ),
            ),
            h('p', { className: 'pb-hint' }, tr('port.formatHint')),
            h(
              'div',
              { className: 'pb-inline' },
              h(PbBtn, { onClick: copyPrompt }, tr('port.copyPrompt')),
              h(PbBtn, { onClick: () => { window.location.href = `${ENDPOINT}/ppt`; } }, tr('port.ppt')),
            ),
            h('p', { className: 'pb-hint' }, tr('port.pptHint')),
          ),
    ),

    h(
      PbFold,
      { name: 'more-checkup', title: tr('more.checkup'), hint: tr('more.checkupHint') },
      h(DiagnosePanel, { tr, forms }),
      h(SafePanel, { tr }),
    ),

    h(
      PbFold,
      { name: 'more-advanced', title: tr('more.advanced'), hint: tr('more.advancedHint') },
      h(AdvancedPanel, { tr }),
    ),

    h(PbRow, {
      title: tr('more.uninstall'),
      hint: tr('more.uninstallHint'),
      control: h(PbBtn, {
        variant: 'danger',
        disabled: busy,
        onClick: async () => {
          if (!window.confirm(tr('port.uninstallConfirm'))) return;
          setBusy(true);
          try {
            const result = await apiAction('uninstall', {}, snapshot.rev);
            await loadSnapshot({ keepDraft: true });
            setNote((result?.instructions ?? []).join(' '));
          } catch (error) {
            setFailure(error.message ?? String(error));
          } finally {
            setBusy(false);
          }
        },
      }, tr('port.uninstallButton')),
    }),
    failure === '' || staged !== null ? null : h('p', { className: 'pb-error' }, failure),
  );
}
