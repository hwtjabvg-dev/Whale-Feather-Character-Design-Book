/**
 * Shard 00: constants and tiny helpers.
 *
 * Every shard below is concatenated (in file-name order) into the single file
 * `lib/client.js` by `tools/build-client.mjs`, so they all share one closure:
 * `React`, `h` and `require` come from the module factory in the banner.
 */

/** Dictionary namespace owned by this plugin. */
const NS = 'personaBook';

/** The host route the panel reads and writes through. */
const ENDPOINT = '/api/persona-book';

/** Route for the raw document readers (advanced tab). */
const ASSETS_ENDPOINT = `${ENDPOINT}/assets`;
const DOCS_ENDPOINT = '/api/persona-book/docs';

/** Route for the self-check payload. */
const DIAGNOSE_ENDPOINT = '/api/persona-book/diagnose';

/** Sidebar seat id, also used as the injected `<style>` marker. */
const PLUGIN_ID = 'dsh-persona-book';

/** Join class names, dropping falsy entries. */
function cx(...parts) {
  return parts.filter(Boolean).join(' ');
}

/** Clamp a number into a range, tolerating strings from inputs. */
function clamp(value, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return min;
  return Math.min(max, Math.max(min, number));
}

/** Deep-clone a plain JSON value (no functions, nothing exotic). */
function clone(value) {
  return value === undefined ? value : JSON.parse(JSON.stringify(value));
}

/** Set a nested path on a copy of `source`. */
function setIn(source, path, value) {
  const next = clone(source);
  let cursor = next;
  for (let index = 0; index < path.length - 1; index += 1) {
    const key = path[index];
    if (typeof cursor[key] !== 'object' || cursor[key] === null) cursor[key] = {};
    cursor = cursor[key];
  }
  cursor[path[path.length - 1]] = value;
  return next;
}

/** Read a nested path, with a fallback. */
function getIn(source, path, fallback) {
  let cursor = source;
  for (const key of path) {
    if (cursor === undefined || cursor === null) return fallback;
    cursor = cursor[key];
  }
  return cursor === undefined ? fallback : cursor;
}

/** Bytes → human string. */
function bytes(value) {
  if (!Number.isFinite(value)) return '—';
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(1)} MB`;
}
