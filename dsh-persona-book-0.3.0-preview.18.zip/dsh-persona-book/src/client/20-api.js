/**
 * Shard 20: the host API client.
 *
 * One place that knows the route shapes, turns `{ error: { code, message } }`
 * into an Error carrying both, and never throws a bare string.
 */

/** An error from the host, carrying its stable code. */
class ApiError extends Error {
  constructor(code, message, status) {
    super(message || code);
    this.code = code || 'EINTERNAL';
    this.status = status ?? 0;
  }
}

/** Decode a response body, tolerating an empty or non-JSON payload. */
async function decode(response) {
  const text = await response.text();
  if (text === '') return {};
  try {
    return JSON.parse(text);
  } catch {
    return { error: { code: 'EINTERNAL', message: text.slice(0, 200) } };
  }
}

/** GET JSON from the host. */
async function apiGet(path) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
  } catch (error) {
    throw new ApiError('ENETWORK', pbTr('err.network', { message: error.message }));
  }
  const body = await decode(response);
  if (!response.ok) throw new ApiError(body?.error?.code, body?.error?.message, response.status);
  return body;
}

/** Send one action to the host. */
async function apiAction(action, payload, baseRev) {
  let response;
  try {
    response = await fetch(ENDPOINT, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ action, baseRev, ...(payload ?? {}) }),
    });
  } catch (error) {
    throw new ApiError('ENETWORK', pbTr('err.network', { message: error.message }));
  }
  const body = await decode(response);
  if (!response.ok) throw new ApiError(body?.error?.code, body?.error?.message, response.status);
  return body;
}

/** Read one whitelisted source document. */
function apiDoc(id) {
  return apiGet(`${DOCS_ENDPOINT}?doc=${encodeURIComponent(id)}`);
}

/** Read the diagnostics payload. */
function apiDiagnose() {
  return apiGet(DIAGNOSE_ENDPOINT);
}

/**
 * Upload one file. The bytes travel as the request body (never base64 in JSON),
 * so a 100 MB wallpaper is streamed rather than inflated by a third.
 */
async function apiUpload(kind, file, name = file?.name ?? '') {
  const path = `${ASSETS_ENDPOINT}?kind=${encodeURIComponent(kind)}&name=${encodeURIComponent(name)}`;
  let response;
  try {
    response = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream', Accept: 'application/json' },
      credentials: 'same-origin',
      body: file,
    });
  } catch (error) {
    throw new ApiError('ENETWORK', pbTr('err.network', { message: error.message }));
  }
  const body = await decode(response);
  if (!response.ok) throw new ApiError(body?.error?.code, body?.error?.message, response.status);
  return body;
}

/** Delete one asset; `force` removes it even while a profile still points at it. */
async function apiDeleteAsset(id, force = false) {
  let response;
  try {
    response = await fetch(`${ASSETS_ENDPOINT}/${encodeURIComponent(id)}${force ? '?force=1' : ''}`, {
      method: 'DELETE',
      headers: { Accept: 'application/json' },
      credentials: 'same-origin',
    });
  } catch (error) {
    throw new ApiError('ENETWORK', pbTr('err.network', { message: error.message }));
  }
  const body = await decode(response);
  if (!response.ok) throw new ApiError(body?.error?.code, body?.error?.message, response.status);
  return body;
}

/**
 * Stage an import. The host sniffs the file, says what it thinks it is, and
 * keeps the bytes until the user confirms — nothing is written yet.
 */
async function apiImport(file, name = file?.name ?? 'import.bin') {
  let response;
  try {
    response = await fetch(`${ENDPOINT}/import?name=${encodeURIComponent(name)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream', Accept: 'application/json' },
      credentials: 'same-origin',
      body: file,
    });
  } catch (error) {
    throw new ApiError('ENETWORK', pbTr('err.network', { message: error.message }));
  }
  const body = await decode(response);
  if (!response.ok) throw new ApiError(body?.error?.code, body?.error?.message, response.status);
  return body;
}

/** Turn a staged import into a persona. */
async function apiImportCommit(payload) {
  let response;
  try {
    response = await fetch(`${ENDPOINT}/import/commit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(payload ?? {}),
    });
  } catch (error) {
    throw new ApiError('ENETWORK', pbTr('err.network', { message: error.message }));
  }
  const body = await decode(response);
  if (!response.ok) throw new ApiError(body?.error?.code, body?.error?.message, response.status);
  return body;
}

/** Read an export as text (for the clipboard) instead of downloading it. */
async function apiExportText(format, id) {
  let response;
  try {
    response = await fetch(
      `${ENDPOINT}/export?format=${encodeURIComponent(format)}&id=${encodeURIComponent(id)}`,
      { headers: { Accept: '*/*' }, credentials: 'same-origin' },
    );
  } catch (error) {
    throw new ApiError('ENETWORK', pbTr('err.network', { message: error.message }));
  }
  const text = await response.text();
  if (!response.ok) {
    const body = (() => {
      try {
        return JSON.parse(text);
      } catch {
        return {};
      }
    })();
    throw new ApiError(body?.error?.code, body?.error?.message, response.status);
  }
  return text;
}

/** Where a format downloads from — used for the plain `<a download>` buttons. */
function apiExportUrl(format, id) {
  return `${ENDPOINT}/export?format=${encodeURIComponent(format)}&id=${encodeURIComponent(id)}`;
}
