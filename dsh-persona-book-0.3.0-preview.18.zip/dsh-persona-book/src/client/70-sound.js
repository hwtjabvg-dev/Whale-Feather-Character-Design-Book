/**
 * The sound tab: which cue fires on which moment, how loud, and the uploads.
 * The recipes themselves live in 44-sound.js; this file is only knobs and a few
 * preview buttons. Simplified: one switch, one volume slider, one row per event.
 */

const PB_EVENT_LABELS = {
  sent: 'sound.event.sent',
  received: 'sound.event.received',
  error: 'sound.event.error',
  done: 'sound.event.done',
};

/** The host owns the cue list; the panel only knows how to label each id. */
function pbCueIds(presets) {
  const rows = Array.isArray(presets?.cues) ? presets.cues : [];
  return rows.length > 0 ? rows.map((cue) => cue.id) : ['whale-call', 'water-drop', 'shell-ding', 'bubble', 'whale-song', 'star-tap', 'bell-cat', 'off'];
}

function pbCueOptions(tr, custom, presets) {
  const rows = pbCueIds(presets).map((id) => ({ value: id, label: `${tr(`sound.cue.${id}`)}` }));
  for (const item of custom ?? []) rows.push({ value: `custom:${item.id}`, label: `${item.name}${pbTr('sound.uploadSuffix')}` });
  return rows;
}

function SoundTab({ tr }) {
  const state = useStore();
  const snapshot = state.snapshot;
  const ui = snapshot?.profiles?.ui ?? null;
  const sound = ui?.sound ?? {};
  const presets = snapshot?.presets ?? {};
  const [busy, setBusy] = React.useState(false);
  const [pending, setPending] = React.useState({});
  const uiRef = React.useRef(ui);
  uiRef.current = ui;
  React.useEffect(() => setPending({}), [snapshot?.rev]);
  const view = { ...sound, ...pending };
  const viewRef = React.useRef(view);
  viewRef.current = view;

  const set = (mutator, message) => {
    const base = structuredClone(uiRef.current ?? {});
    base.sound = base.sound ?? {};
    mutator(base.sound);
    setPending((current) => ({ ...current, ...(base.sound ?? {}) }));
    setBusy(true);
    void runAction('setUi', { section: 'sound', patch: base.sound }, { keepDraft: true, message })
      .catch(() => {})
      .finally(() => setBusy(false));
  };

  const preview = (cueId) => {
    pbUnlockAudio();
    pbSoundPreview({ ...(uiRef.current ?? {}), sound: view }, cueId);
  };

  const events = Object.keys(PB_EVENT_LABELS);
  const options = pbCueOptions(tr, view.custom, presets);

  return h(
    React.Fragment,
    null,
    h(
      PbGroup,
      { title: tr('sound.title'), hint: tr('sound.hint') },
      h(PbSwitch, {
        label: tr('sound.enabled'),
        on: view.enabled === true,
        disabled: busy,
        onChange: (on) => {
          if (on) pbUnlockAudio();
          set((draft) => {
            draft.enabled = on;
          }, on ? tr('sound.on') : tr('sound.off'));
        },
      }),
      h(PbSlider, {
        label: tr('sound.volume'),
        min: 0,
        max: 100,
        step: 5,
        suffix: '%',
        value: Math.round((Number(view.volume) || 0) * 100),
        onInput: (value) => {
          const next = { ...viewRef.current, volume: value / 100 };
          viewRef.current = next;
          setPending(next);
        },
        onCommit: () =>
          set((draft) => {
            draft.volume = Number(viewRef.current.volume) || 0;
          }, tr('sound.volumeSaved')),
      }),
    ),
    h(
      PbGroup,
      { title: tr('sound.events'), hint: tr('sound.eventsHint') },
      events.map((event) =>
        h(PbRow, {
          key: event,
          title: tr(PB_EVENT_LABELS[event]),
          control: h(
            React.Fragment,
            null,
            h(Select, {
              value: view.events?.[event] ?? 'off',
              options,
              onChange: (value) =>
                set((draft) => {
                  draft.events = { ...(draft.events ?? {}), [event]: value };
                }, tr('sound.bound')),
            }),
            h(
              PbBtn,
              {
                disabled: (view.events?.[event] ?? 'off') === 'off',
                onClick: () => preview(view.events?.[event] ?? 'off'),
              },
              tr('sound.preview'),
            ),
          ),
        }),
      ),
    ),
    h(
      PbGroup,
      { title: tr('assets.tab.sounds'), hint: tr('sound.uploadsHint') },
      h(
        PbDrop,
        { tr, kind: 'sound', accept: 'audio/*', busy, onFile: (file) => void upload(file) },
        h('span', { className: 'pb-drop-icon' }, '🎵'),
        h('span', null, tr('sound.drop')),
      ),
      (view.custom ?? []).length === 0
        ? h('p', { className: 'pb-hint' }, tr('sound.noUploads'))
        : h(
            'div',
            { className: 'pb-list' },
            (view.custom ?? []).map((item) =>
              h(
                'div',
                { className: 'pb-list-row', key: item.id },
                h('span', { className: 'pb-list-title' }, item.name),
                h('span', { className: 'pb-hint' }, pbBytes(item.bytes ?? 0)),
                h(PbBtn, { onClick: () => preview(`custom:${item.id}`) }, tr('sound.preview')),
                h(PbBtn, { variant: 'danger', onClick: () => void remove(item) }, tr('assets.remove')),
              ),
            ),
          ),
    ),
    h(
      PbGroup,
      { title: tr('sound.behaviour'), hint: tr('sound.behaviourHint') },
      h(PbSwitch, {
        label: tr('sound.muteWhenHidden'),
        on: view.muteWhenHidden !== false,
        disabled: busy,
        onChange: (on) =>
          set((draft) => {
            draft.muteWhenHidden = on;
          }, tr('sound.muteSaved')),
      }),
      h(PbSlider, {
        label: tr('sound.rateLimit'),
        min: 0,
        max: 2000,
        step: 50,
        suffix: ' ms',
        value: Number(view.rateLimitMs) || 0,
        onInput: (value) => {
          const next = { ...viewRef.current, rateLimitMs: value };
          viewRef.current = next;
          setPending(next);
        },
        onCommit: () =>
          set((draft) => {
            draft.rateLimitMs = Number(viewRef.current.rateLimitMs) || 0;
          }, tr('sound.rateSaved')),
      }),
      h('p', { className: 'pb-hint' }, soundStatusLine(tr)),
    ),
  );

  async function upload(file) {
    if (file === null || file === undefined) return;
    setBusy(true);
    try {
      const result = await apiUpload('sound', file, file.name);
      await loadSnapshot({ keepDraft: true });
      const entry = result?.entry;
      if (entry !== undefined) {
        const next = [...(uiRef.current?.sound?.custom ?? []), { id: entry.id, name: entry.name, bytes: entry.bytes }];
        set((draft) => {
          draft.custom = next;
        }, result?.reused === true ? tr('assets.reused') : tr('sound.uploaded'));
      }
    } catch (error) {
      toast(error instanceof ApiError ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  }

  async function remove(item) {
    setBusy(true);
    try {
      await apiDeleteAsset(item.id, true);
      const next = (uiRef.current?.sound?.custom ?? []).filter((row) => row.id !== item.id);
      set((draft) => {
        draft.custom = next;
        for (const event of Object.keys(draft.events ?? {})) {
          if (draft.events[event] === `custom:${item.id}`) draft.events = { ...draft.events, [event]: 'off' };
        }
      }, tr('assets.removed'));
      await loadSnapshot({ keepDraft: true });
    } catch (error) {
      toast(error instanceof ApiError ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  }
}

function soundStatusLine(tr) {
  const status = pbSoundState();
  return status.available ? tr('sound.statusReady') : tr('sound.statusUnsupported');
}

EXTRA_TABS.push({ id: 'sound', label: 'tabs.sound', render: (props) => h(SoundTab, props) });
