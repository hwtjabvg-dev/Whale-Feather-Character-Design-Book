/** Smoke-test the actual extracted package, with isolated data and host routes. */
import {createServer} from 'node:http';
import {mkdtemp, readFile, rm, writeFile} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root=resolve(process.argv[2]||''),resultFile=process.argv[3];
if(!process.argv[2])throw Error('请指定已解压的插件目录。');
const data=await mkdtemp(join(tmpdir(),'pb-mobile-package-'));
process.env.DSH_PERSONA_BOOK_DIR=join(data,'personas');
process.env.DSH_AGENTS_HOME=join(data,'agents');
const checks={},routes=[],effects=[];
let server;
try{
 const checked=await promisify(execFile)(process.execPath,[join(root,'mobile/check-package.mjs')]);
 assert.match(checked.stdout,/校验通过/);checks.fileManifest=true;
 const pkg=JSON.parse(await readFile(join(root,'package.json'),'utf8'));
 const plugin=await import(pathToFileURL(join(root,pkg.main)));
 const scope={effect:fn=>{const dispose=fn();if(typeof dispose==='function')effects.push(dispose);return dispose;},webServer:{register:route=>{routes.push(route);return()=>{};}},connection:{requestRejection:()=>undefined}};
 plugin.apply({inject:(_services,fn)=>fn(scope)});
 assert.ok(routes.find(x=>x.path==='/api/persona-book/play'));checks.originalDshEntry=true;
 server=createServer((req,res)=>{const path=new URL(req.url,'http://localhost').pathname;const exact=routes.find(r=>r.kind==='exact'&&r.path===path),prefix=routes.filter(r=>r.kind==='prefix'&&(path===r.path||path.startsWith(r.path+'/'))).sort((a,b)=>b.path.length-a.path.length)[0];const route=exact||prefix;if(!route){res.writeHead(404).end();return;}Promise.resolve(route.handler(req,res)).catch(e=>{res.writeHead(500).end(e.message);});});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const base='http://127.0.0.1:'+server.address().port+'/api/persona-book/play';
 const stateRes=await fetch(base+'/state');assert.equal(stateRes.status,200);const state=await stateRes.json();
 assert.equal(state.themes.filter(x=>x.builtin).length,6);assert.equal(state.avatars.filter(x=>x.builtin).length,6);checks.defaultResources=true;
 const ui=await fetch(base+'/ui/index.html');assert.equal(ui.status,200);assert.match(await ui.text(),/人设本/);checks.hostedUi=true;
 const voice=await fetch(base+'/ui/sounds/voice/messagegakiteruyo1.mp3');assert.equal(voice.status,200);assert.ok((await voice.arrayBuffer()).byteLength>1000);checks.localVoice=true;
 for(const file of ['receive-low.wav','receive-mid.wav','receive-high.wav'])assert.equal((await fetch(base+'/ui/sounds/'+file)).status,404);assert.ok(!state.voicePacks.some(p=>p.id==='legacy'));checks.originalSyntheticVoiceRemoved=true;
 const response=await fetch(base+'/turn',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({conversationId:state.activeConversation,text:'手机插件包自检'})});assert.equal(response.status,200);const stream=await response.text();assert.match(stream,/message.end/);assert.match(stream,/turn.end/);checks.sharedChatStream=true;
 const {installMedia}=await import(pathToFileURL(join(root,'app/media.mjs')));
 const image=await readFile(join(root,'app/public/avatars/portrait.png'));
 const pngAsset=await installMedia({atomic:async(rel,bytes)=>{assert.ok(bytes.length);}},image,'sample.png','avatar');assert.equal(pngAsset.format,'png');checks.bundledWasmDecode=true;
 const manifest=JSON.parse(await readFile(join(root,'mobile/package-manifest.json'),'utf8'));
 assert.ok(!manifest.files.some(f=>/\.(?:exe|dll|node|jks|apk)$/i.test(f.path)||/^(data|runtime)\//.test(f.path)));checks.noWindowsRuntimeOrUserData=true;
 const report={version:pkg.version,packageDirectory:root,environment:'Windows Node + packaged DSH entry + isolated host route contract; NOT Android device',androidDeviceTested:false,checks,at:new Date().toISOString()};
 if(resultFile)await writeFile(resolve(resultFile),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}finally{
 for(const stop of effects.reverse())stop();
 if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}
 if(!data.startsWith(join(tmpdir(),'pb-mobile-package-')))throw Error('验收数据目录越界。');
 await rm(data,{recursive:true,force:true});
}
