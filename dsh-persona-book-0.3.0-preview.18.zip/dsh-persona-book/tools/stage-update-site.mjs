/** Build/sign and stage one tested release. Hosted deployment uses the connected Sites tools. */
import {cp,mkdir,mkdtemp,readFile,readdir,rename,rm,writeFile} from 'node:fs/promises';
import {createHash,verify} from 'node:crypto';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {compareVersions} from '../app/updater.mjs';

export async function stageRelease({siteRoot,releaseDirectory,channel,projectId,expectedVersion}){
 const site=resolve(siteRoot);
 const hosting=JSON.parse(await readFile(join(site,'.openai/hosting.json'),'utf8'));
 const runtime=!hosting.static&&hosting.r2==='RELEASES',dist=join(site,runtime?'release-assets':'dist');
 if(hosting.project_id!==projectId||(!runtime&&hosting.static?.directory!=='dist'))throw Error('更新站点身份或静态目录不匹配。');
 await mkdir(dist,{recursive:true});
 if(typeof channel.private!=='boolean')throw Error('更新通道必须明确声明公开或私人。');
 const envelope=JSON.parse(await readFile(join(releaseDirectory,'latest.json'),'utf8'));
 const encoded=Buffer.from(envelope.payload,'base64');
 if(!verify(null,encoded,channel.publicKey,Buffer.from(envelope.signature,'base64')))throw Error('更新目录签名校验失败。');
 const payload=JSON.parse(encoded.toString('utf8')),name=payload.package?.url;
 if(payload.format!=='persona-book-update/v1'||payload.name!=='dsh-persona-book'||payload.version!==expectedVersion)throw Error('更新目录版本不匹配。');
 if(name!==`dsh-persona-book-${expectedVersion}.zip`||!/^[\w.-]+\.zip$/.test(name))throw Error('更新包名称校验失败。');
 const bytes=await readFile(join(releaseDirectory,name));
 const sha256=createHash('sha256').update(bytes).digest('hex');
 if(bytes.length!==payload.package.bytes||sha256!==payload.package.sha256||bytes.length>=(runtime?64:25)*1024*1024)throw Error('更新包大小或哈希校验失败。');
 let installer;
 if(payload.installer){if(!/^install-whale-[\w.-]+\.mjs$/.test(payload.installer.url))throw Error('安装器路径校验失败。');installer=await readFile(join(releaseDirectory,payload.installer.url));if(installer.length!==payload.installer.bytes||createHash('sha256').update(installer).digest('hex')!==payload.installer.sha256)throw Error('在线安装器校验失败。');}
 const old=await readFile(join(dist,'release-info.json'),'utf8').then(JSON.parse).catch(e=>{if(e.code==='ENOENT')return {};throw e;});
 if(old.version&&compareVersions(payload.version,old.version)<0)throw Error('不能将更新站点回退到较旧版本。');
 if(old.version===payload.version){
  const previous=await readFile(join(dist,name));
  if(createHash('sha256').update(previous).digest('hex')!==sha256)throw Error('同一版本不能覆盖成不同内容，请递增版本。');
 }
 const stage=await mkdtemp(join(site,'.release-stage-')),backup=stage+'-previous';let moved=false,committed=false;
 try{
  await cp(dist,stage,{recursive:true});
  for(const file of await readdir(stage))if(/^dsh-persona-book-\d+\.\d+\.\d+(?:-[\w.]+)?\.zip$/.test(file))await rm(join(stage,file));
  await writeFile(join(stage,name),bytes);
  if(installer)await writeFile(join(stage,payload.installer.url),installer);
  await writeFile(join(stage,'latest.json'),JSON.stringify(envelope,null,2)+'\n');
  await writeFile(join(stage,'release-info.json'),JSON.stringify({title:'鲸语人设本',version:payload.version,notes:payload.notes,package:name,sha256,publishedAt:payload.publishedAt},null,2)+'\n');
  await writeFile(join(stage,'_headers'),'/latest.json\n  Cache-Control: no-store\n/release-info.json\n  Cache-Control: no-store\n/dsh-persona-book-*.zip\n  Cache-Control: private, max-age=31536000, immutable\n  Content-Type: application/zip\n');
  await rename(dist,backup);moved=true;await rename(stage,dist);committed=true;
 }catch(error){if(moved&&!committed)await rename(backup,dist);throw error;}
 finally{await rm(stage,{recursive:true,force:true});if(committed)await rm(backup,{recursive:true,force:true});}
 return {project_id:projectId,version:payload.version,package:name,bytes:bytes.length,sha256,siteRoot:site,assetDirectory:dist,published:false,next:runtime?'部署现有私人 Worker，再按包、安装器、latest.json 的顺序上传到私人文件存储，验证真实安装；暂存不算发布。':'使用现有私人站点的源同步与部署工具发布，并验证真实下载；仅暂存不算发布。'};
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),args=process.argv.slice(2);
 const option=name=>{const at=args.indexOf(name);return at<0?undefined:args[at+1];};
 const version=option('--version')||JSON.parse(await readFile(join(root,'package.json'),'utf8')).version;
 const output=resolve(option('--output')||join(root,'../../outputs/鲸语更新发布'));
 const siteRoot=option('--site-root')||resolve(root,'../persona-book-update-site');
 const projectId='appgprj_6acf51a6cee08191acc1ccb958b70ea7';
 const run=promisify(execFile);
 // A failed build/check/test cannot replace the staged website catalog.
 await run(process.execPath,[join(root,'tools/prepare-update-release.mjs'),'--version',version,'--output',output,'--notes',option('--notes')||'鲸语人设本功能与体验更新。'],{cwd:root,maxBuffer:4*1024*1024});
 await run(process.execPath,[join(root,'tools/check.mjs')],{cwd:root,maxBuffer:4*1024*1024});
 const tests=(await readdir(join(root,'tests'))).filter(x=>x.endsWith('.test.js')).map(x=>join(root,'tests',x));
 const tested=await run(process.execPath,['--test',...tests],{cwd:root,maxBuffer:8*1024*1024});
 await mkdir(output,{recursive:true});await writeFile(join(output,'发布测试.txt'),tested.stdout+tested.stderr);
 const result=await stageRelease({siteRoot,releaseDirectory:join(output,'人设本-更新发布',version),channel:JSON.parse(await readFile(join(root,'resources/update-channel.json'),'utf8')),projectId,expectedVersion:version});
 await writeFile(join(output,'发布暂存校验.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}
