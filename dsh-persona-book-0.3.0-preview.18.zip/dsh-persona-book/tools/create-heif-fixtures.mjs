import * as m from '@imagemagick/magick-wasm';import{createRequire}from'node:module';import{readFile,writeFile}from'node:fs/promises';
const require=createRequire(import.meta.url);await m.initializeImageMagick(await readFile(require.resolve('@imagemagick/magick-wasm/magick.wasm')));const png=await readFile('tests/fixtures/formats/avatar.png');
for(const format of ['Heic','Heif']){let result;m.ImageMagick.read(png,img=>img.write(m.MagickFormat[format],b=>result=Buffer.from(b)));await writeFile('tests/fixtures/formats/sample.'+format.toLowerCase(),result);console.log(format,result.length);}
