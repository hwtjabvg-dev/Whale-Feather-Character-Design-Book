import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {homedir} from 'node:os';
import {join,dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {generateKeyPairSync,createPublicKey,createHash} from 'node:crypto';
import {updateUrl} from '../app/updater.mjs';
export const defaultKey=join(homedir(),'.codex','release-keys','dsh-persona-book-ed25519.pem');
export async function initChannel(url,keyFile=defaultKey){
 let key;try{key=await readFile(keyFile,'utf8');}catch(e){if(e.code!=='ENOENT')throw e;await mkdir(dirname(keyFile),{recursive:true});key=generateKeyPairSync('ed25519').privateKey.export({type:'pkcs8',format:'pem'});await writeFile(keyFile,key,{flag:'wx',mode:0o600});}
 const publicKey=createPublicKey(key).export({type:'spki',format:'pem'}),channelFile=new URL('../resources/update-channel.json',import.meta.url);
 const previous=await readFile(channelFile,'utf8').then(JSON.parse).catch(e=>{if(e.code==='ENOENT')return {};throw e;});
 if(previous.publicKey&&previous.publicKey!==publicKey)throw Error('当前发布密钥与已安装版本的公钥不匹配，请恢复原发布密钥。');
 const channel={format:'persona-book-update-channel/v1',channel:'preview',private:previous.private===true,url:url===undefined?(previous.url||''):(url?updateUrl(url):''),publicKey};
 await writeFile(channelFile,JSON.stringify(channel,null,2)+'\n');return {channel,keyFile,fingerprint:createHash('sha256').update(publicKey).digest('hex')};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const result=await initChannel(process.argv[2]);console.log(JSON.stringify({url:result.channel.url||'尚未配置',keyFile:result.keyFile,publicKeyFingerprint:result.fingerprint},null,2));
}
