import {readFile,writeFile} from 'node:fs/promises';
async function patch(file,a,b){const s=await readFile(file,'utf8');if(!s.includes(a))throw Error('未找到 '+a.slice(0,100));await writeFile(file,s.replace(a,b));}
await patch('app/ui/main.jsx','assetUrl(resource?.file)','assetUrl(resource?.displayFile||resource?.file)');
await patch('app/ui/main.jsx',"p=state.personas.find(x=>x.id===c.members[0])","p=state.personas.find(x=>x.id===(c.mode==='group'?(c.activeMember||c.members[0]):c.members[0]))");
await patch('app/ui/main.jsx',"let messages=c.messages.map", "let messages=(c.mode==='group'?c.messages.filter(m=>m.role==='user'?(!m.recipientId||m.recipientId===p.id):m.personaId===p.id):c.messages).map");
await patch('app/service.mjs',"const p=s.personas.find(p=>p.id===c.members[0]);","const p=s.personas.find(p=>p.id===(c.mode==='group'?(c.activeMember||c.members[0]):c.members[0]));");
await patch('app/service.mjs',"quote:body.quote||null}","quote:body.quote||null,recipientId:c.mode==='group'?(c.activeMember||c.members[0]):null}");
await patch('app/service.mjs',"const history=replace?cc.messages.slice(0,cc.messages.findIndex(m=>m.id===replace.id)):cc.messages;", "let history=replace?cc.messages.slice(0,cc.messages.findIndex(m=>m.id===replace.id)):cc.messages;if(cc.mode==='group')history=history.filter(m=>m.role==='user'?(!m.recipientId||m.recipientId===p.id):m.personaId===p.id);");
await patch('app/service.mjs',"else{tools.push(event);emit({...event,turnId,messageId:msgId,personaId:p.id});}", "else if(event.type==='image'){const payload=event.image||event;const bytes=payload.b64_json||payload.base64?Buffer.from(payload.b64_json||payload.base64,'base64'):await downloadResource(payload.url,16*1024*1024);const asset=await installMedia(this.store,bytes,'agent-image.png','avatar');const image={...asset,id:uid(),personaId:p.id,prompt:payload.prompt||'',title:payload.title||'Agent 图片',createdAt:Date.now()};await this.store.transact(d=>{d.galleries.unshift(image);this.conversation(d,id).messages.find(m=>m.id===msgId).image=image;});emit({type:'image',turnId,messageId:msgId,image});}else{tools.push(event);emit({...event,turnId,messageId:msgId,personaId:p.id});}");
await patch('app/service.mjs',"if(!text)throw new DomainError", "if(!text&&this.conversation(this.store.state,id).messages.find(m=>m.id===msgId)?.image)text='图片已发送。';if(!text)throw new DomainError");
await patch('app/service.mjs',"if(meta.kind!=='theme'&&!s.assets.some(a=>a.id===r.id))s.assets.push(r)","if(meta.kind!=='theme'&&!s.assets.some(a=>a.hash===r.hash))s.assets.push({...r,id:r.assetId||r.id})");
await patch('app/service.mjs',"!['openai','ollama','agent','demo'].includes(c.kind)","!['openai','ollama','agent','demo'].includes(c.kind)&&!hasTextAdapter(c.kind)");
await patch('app/service.mjs',"import {generate,generateImage}","import {generate,generateImage,hasTextAdapter}");
await patch('app/service.mjs',"async generateSpeech({personaId,text,voice,connection})","async generateSpeech({personaId,text,voice})");
await patch('app/service.mjs',"const config=connection||this.store.state.ttsConnection||{}","const config=this.store.state.ttsConnection||{}");
await patch('app/service.mjs',"async generateSpeech({personaId,text,voice})", "async generateSpeech({personaId,text,voice})");
console.log('已修复独立群成员上下文、非原生头像预览与 Agent 图片事件。');
