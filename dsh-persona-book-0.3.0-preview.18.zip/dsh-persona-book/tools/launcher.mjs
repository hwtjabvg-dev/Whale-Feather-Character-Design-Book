import {readFile,mkdir,open,access} from 'node:fs/promises';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),data=resolve(root,process.env.PB_DATA_DIR||'data'),stop=process.argv.includes('--stop');
async function running(){try{const launch=JSON.parse(await readFile(join(data,'launch.json'),'utf8')),url=new URL(launch.url);if(url.hostname!=='127.0.0.1')return null;const headers={Authorization:'Bearer '+url.searchParams.get('token')},res=await fetch(url.origin+'/api/health',{headers,signal:AbortSignal.timeout(1200)});if(!res.ok||!/^0\.3\.0-preview\.\d+$/.test((await res.json()).version))return null;return{launch,url,headers};}catch{return null;}}
const poll=async(ms,until)=>{const deadline=Date.now()+ms;while(Date.now()<deadline){const result=await until();if(result)return result;await new Promise(r=>setTimeout(r,80));}return null;};
try{let live=await running();if(stop){if(live){const res=await fetch(live.url.origin+'/api/shutdown',{method:'POST',headers:live.headers,signal:AbortSignal.timeout(3000)});if(!res.ok)throw Error('服务未能停止');await poll(3000,async()=>!(await running()));console.log('人设本已停止。');}else console.log('此目录的人设本当前未运行。');}
else{if(!live){await mkdir(data,{recursive:true});const log=await open(join(root,'启动日志.txt'),'w'),error=await open(join(root,'启动错误.txt'),'w');const child=spawn(process.execPath,[join(root,'app/server.mjs')],{cwd:root,detached:true,windowsHide:true,stdio:['ignore',log.fd,error.fd],env:{...process.env,PB_DATA_DIR:data}});child.on('error',e=>console.error('启动失败：'+e.message));child.unref();await log.close();await error.close();live=await poll(12000,running);if(!live)throw Error('启动失败，请查看启动错误.txt；端口被占用时可更换 PB_PORT。');}
let edge;for(const candidate of ['C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe','C:/Program Files/Microsoft/Edge/Application/msedge.exe'])try{await access(candidate);edge=candidate;break;}catch{}
if(edge){const child=spawn(edge,[live.launch.url],{detached:true,stdio:'ignore',windowsHide:false});child.on('error',()=>console.error('浏览器未能打开，请使用启动日志中的链接。'));child.unref();}else console.log('请在浏览器打开：'+live.launch.url);}}
catch(e){console.error(e.message);process.exitCode=1;}
