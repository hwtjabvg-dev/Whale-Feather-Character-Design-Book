import {readFile,writeFile} from 'node:fs/promises';
let s=await readFile('app/ui/main.jsx','utf8');
// Keyboard dialog handling and host-context bridge are bound to the current UI state.
const anchor=" const play=async(file,previewing=false)=>";
s=s.replace(anchor," useEffect(()=>{const onKey=e=>{if(!panel)return;if(e.key==='Escape'){e.preventDefault();open(()=>{setPanel('');setRoleEdit(null);});}if(e.key==='Tab'){const dialog=document.querySelector('[role=dialog]');const nodes=dialog?.querySelectorAll('button:not([disabled]),input:not([type=file]),textarea,select,a[href],summary');if(!nodes?.length)return;const first=nodes[0],last=nodes[nodes.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}};document.addEventListener('keydown',onKey);return()=>document.removeEventListener('keydown',onKey);},[panel,roleEdit?.dirty]);\n useEffect(()=>{const bridge=e=>{if(e.origin!==location.origin||e.source!==window.parent||e.data?.type!=='persona-book:host-context-result')return;act('updateConversation',{id:state.activeConversation,patch:{hostContext:String(e.data.text||'')}}).then(()=>notify('已读取宿主当前聊天的可见上下文。'));};window.addEventListener('message',bridge);return()=>window.removeEventListener('message',bridge);},[state?.activeConversation]);\n"+anchor);
s=s.replace('<Field label="宿主上下文"><textarea','<Field label="宿主上下文"><button type="button" disabled={window.parent===window} onClick={()=>window.parent.postMessage({type:\'persona-book:host-context\'},location.origin)}>读取宿主当前聊天</button><textarea');
s=s.replace("const preview=await", "const preview=await");
s=s.replace("<Toggle label=\"隐藏模型思考标签\"", "<Toggle label=\"情绪影响送达与输入时间\" value={state.settings.roleTiming} onChange={v=>act('settings',{patch:{roleTiming:v}})}/><Toggle label=\"隐藏模型思考标签\"");
s=s.replace("act('settings',{patch:{}}).then(()=>act('connection',{connection:conn,useDefault:true}))","act('connection',{connection:conn,useDefault:true})");
await writeFile('app/ui/main.jsx',s);
let qa=await readFile('tools/ui-acceptance.mjs','utf8');qa=qa.replace(".fill('小鲸');", ".fill('小鲸'+Date.now());");await writeFile('tools/ui-acceptance.mjs',qa);
// Remove preparation scripts that were only used for this implementation from release source later.
console.log('已补充键盘操作、宿主上下文桥接和消息时间设置。');
