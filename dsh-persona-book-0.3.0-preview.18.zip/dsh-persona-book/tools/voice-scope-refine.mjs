import{readFile,writeFile}from'node:fs/promises';let ui=await readFile('app/ui/main.jsx','utf8');
ui=ui.replace("request('/voice/generate',{text:v.phrase,voice:v.voiceId})", "request('/voice/generate',{personaId:p.id,text:v.phrase,voice:v.voiceId})");
ui=ui.replace("value={state.settings.receiveSoundId||''} onChange={e=>act('settings',{patch:{receiveSoundId:e.target.value}})}", "value={p.voice?.assetId||state.settings.receiveSoundId||''} onChange={e=>act('roleVoice',{personaId:p.id,patch:{assetId:e.target.value}})}");
ui=ui.replace("upload(f,'sound').then(a=>a&&act('settings',{patch:{receiveSoundId:a.id}}))", "upload(f,'sound').then(a=>a&&act('roleVoice',{personaId:p.id,patch:{assetId:a.id}}))");
await writeFile('app/ui/main.jsx',ui);
