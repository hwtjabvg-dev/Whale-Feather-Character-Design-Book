﻿param([switch]$Stop)
$ErrorActionPreference='Stop'
$pbRoot=Split-Path $PSScriptRoot -Parent
$pbData=if($env:PB_DATA_DIR){$env:PB_DATA_DIR}else{Join-Path $pbRoot 'data'}
$pbLaunchFile=Join-Path $pbData 'launch.json'
function Get-PbRunning {
  if(!(Test-Path -LiteralPath $pbLaunchFile)){return $null}
  try{
    $pbLaunch=Get-Content -LiteralPath $pbLaunchFile -Raw -Encoding UTF8|ConvertFrom-Json
    $pbUri=[Uri]$pbLaunch.url
    if($pbUri.Host -ne '127.0.0.1'){return $null}
    $pbKey=$pbUri.Query.TrimStart('?').Substring(6)
    $pbHeaders=@{Authorization=('Bearer '+$pbKey)}
    $pbHealth=Invoke-RestMethod -Uri ($pbUri.GetLeftPart([UriPartial]::Authority)+'/api/health') -Headers $pbHeaders -TimeoutSec 2
    if($pbHealth.version -ne '0.3.0-preview.1'){return $null}
    return @{Launch=$pbLaunch;Headers=$pbHeaders;Base=$pbUri.GetLeftPart([UriPartial]::Authority)}
  }catch{return $null}
}
try{
  $pbRunning=Get-PbRunning
  if($Stop){
    if($pbRunning){Invoke-RestMethod -Uri ($pbRunning.Base+'/api/shutdown') -Method Post -Headers $pbRunning.Headers|Out-Null;Write-Host '人设本已停止。'}else{Write-Host '此目录的人设本当前未运行。'}
    exit 0
  }
  if(!$pbRunning){
    $pbRuntime=Join-Path $pbRoot 'runtime/node.exe'
    if(!(Test-Path -LiteralPath $pbRuntime)){$pbRuntime=(Get-Command node -ErrorAction Stop).Source}
    Start-Process -FilePath $pbRuntime -ArgumentList @('app/server.mjs') -WorkingDirectory $pbRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $pbRoot '启动日志.txt') -RedirectStandardError (Join-Path $pbRoot '启动错误.txt')|Out-Null
    $pbDeadline=[DateTime]::UtcNow.AddSeconds(12)
    while([DateTime]::UtcNow -lt $pbDeadline){$pbRunning=Get-PbRunning;if($pbRunning){break};Start-Sleep -Milliseconds 80}
    if(!$pbRunning){throw '启动失败，请查看启动错误.txt；端口被占用时可更换 PB_PORT。'}
  }
  $pbEdge='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'
  if(!(Test-Path -LiteralPath $pbEdge)){$pbEdge='C:/Program Files/Microsoft/Edge/Application/msedge.exe'}
  if(Test-Path -LiteralPath $pbEdge){& $pbEdge $pbRunning.Launch.url}else{Write-Host ('请在浏览器打开 '+$pbRunning.Launch.url)}
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;exit 1}
