/** Browser + actual full-package signed update; all writes are isolated. */
import {cp,mkdtemp,mkdir,readFile,writeFile,readdir,rm} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {generateKeyPairSync,createHash,sign} from 'node:crypto';
import {createServer} from 'node:http';
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {writeZip} from '../lib/zip.js';
import {PersonaService} from '../app/service.mjs';
import {PluginUpdater} from '../app/updater.mjs';
import {createHandler} from '../app/http.mjs';
const reportFile=resolve('../../outputs/安卓插件安装包校验.json'),pack=JSON.parse(await readFile(reportFile,'utf8'));
const data=await mkdtemp(join(tmpdir(),'pb-updates-ui-')),root=join(data,'installed-plugin'),userData=join(data,'user-data');
await cp(pack.unpacked,root,{recursive:true});
const keys=generateKeyPairSync('ed25519'),publicKey=keys.publicKey.export({type:'spki',format:'pem'}),channel={url:'',publicKey};
await writeFile(join(root,'resources/update-channel.json'),JSON.stringify(channel));
const manifest=JSON.parse(await readFile(join(root,'mobile/package-manifest.json'),'utf8')),files=[];
const nextVersion=pack.version.replace(/preview\.(\d+)$/,(_,n)=>'preview.'+(Number(n)+1)),sha=data=>createHash('sha256').update(data).digest('hex');
for(const file of manifest.files){let bytes=await readFile(join(root,file.path));if(file.path==='package.json'){const pkg=JSON.parse(bytes);pkg.version=nextVersion;bytes=Buffer.from(JSON.stringify(pkg));}if(file.path==='package-lock.json'){const pkg=JSON.parse(bytes);pkg.version=nextVersion;pkg.packages[''].version=nextVersion;bytes=Buffer.from(JSON.stringify(pkg));}files.push({path:file.path,data:bytes});}
const newManifest={...manifest,version:nextVersion,files:files.map(f=>({path:f.path,bytes:f.data.length,sha256:sha(f.data)}))};
files.push({path:'mobile/package-manifest.json',data:Buffer.from(JSON.stringify(newManifest))});
const zip=writeZip(files.map(f=>({name:'dsh-persona-book/'+f.path,data:f.data}))),payload=Buffer.from(JSON.stringify({format:'persona-book-update/v1',name:'dsh-persona-book',version:nextVersion,nodeMinimum:22,notes:'本地验收示例：更新按钮与整包安装。此版本没有公开发布。',package:{url:'update.zip',bytes:zip.length,sha256:sha(zip)}}));
const feed=JSON.stringify({payload:payload.toString('base64'),signature:sign(null,payload,keys.privateKey).toString('base64')});
const service=new PersonaService(userData);service.updater=new PluginUpdater({root,dataDir:userData,canInstall:true});await service.open();
await service.action({action:'theme',id:'builtin:deepsea'});
const handler=createHandler(service,{base:'/api/persona-book/play',trusted:true,publicDir:join(root,'app/public')});
const server=createServer((req,res)=>{if(req.url==='/latest.json'){res.setHeader('Content-Type','application/json');res.end(feed);}else if(req.url==='/update.zip'){res.setHeader('Content-Type','application/zip');res.end(zip);}else handler(req,res);});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const origin='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true}),page=await browser.newPage({viewport:{width:390,height:844}}),errors=[];
page.on('pageerror',e=>errors.push(e.message));const checks={},shots=resolve('../../outputs/审核截图');await mkdir(shots,{recursive:true});
try{
 await page.addInitScript(()=>localStorage.pbDrafts=JSON.stringify({welcome:'更新以后也要保留这条草稿'}));
 await page.goto(origin+'/api/persona-book/play/ui/index.html?view=updates');
 await page.getByText('发布地址尚未配置。接入后，手机会自动提示新版本。',{exact:true}).waitFor();checks.unconfiguredHonest=true;
 await page.getByText('更新来源',{exact:true}).click();await page.getByPlaceholder('HTTPS 地址，指向 latest.json').fill(origin+'/latest.json');await page.getByRole('button',{name:'保存来源',exact:true}).click();await page.getByText('更新来源已保存。',{exact:true}).waitFor();
 await page.getByRole('button',{name:'检查更新',exact:true}).click();await page.getByRole('button',{name:'更新到 '+nextVersion,exact:true}).waitFor();assert.equal(await page.getByTitle('插件更新').innerText(),'有更新');checks.newVersionBadge=true;
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);checks.mobileNoOverflow=true;
 await page.screenshot({animations:'disabled',path:join(shots,'12-mobile-plugin-update.png')});
 await page.getByRole('button',{name:'更新到 '+nextVersion,exact:true}).click();await page.getByRole('heading',{name:nextVersion+' 已安装',exact:true}).waitFor({timeout:30000});checks.clickInstallsFullPackage=true;
 assert.equal(service.updater.status().currentVersion,pack.version);assert.equal(service.updater.status().pendingVersion,nextVersion);checks.runningVersionAndRestartSeparate=true;
 assert.equal(JSON.parse(await readFile(join(root,'package.json'),'utf8')).version,nextVersion);
 assert.equal(service.snapshot().settings.themeId,'builtin:deepsea');assert.equal(JSON.parse(await readFile(join(userData,'state.json'),'utf8')).settings.themeId,'builtin:deepsea');checks.userSettingsPreserved=true;
 await page.screenshot({animations:'disabled',path:join(shots,'13-mobile-plugin-update-installed.png')});
 await page.getByRole('button',{name:'关闭',exact:true}).click();assert.equal(await page.getByPlaceholder(/说点什么/).inputValue(),'更新以后也要保留这条草稿');checks.draftPreserved=true;
 await page.getByTitle('插件更新').click();await page.getByRole('heading',{name:nextVersion+' 已安装',exact:true}).waitFor();checks.reopenRemembersPendingUpdate=true;
 assert.deepEqual(errors,[]);
 const report={version:pack.version,exampleUpdateVersion:nextVersion,environment:'Edge mobile viewport + local signed feed + full extracted package replacement; not an Android device or public release',publicFeedConfigured:false,androidDeviceTested:false,checks,errors,at:new Date().toISOString()};await writeFile(resolve('../../outputs/插件更新界面验收.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}finally{await browser.close();service.close();server.closeAllConnections();await new Promise(r=>server.close(r));assert.ok(data.startsWith(join(tmpdir(),'pb-updates-ui-')));await rm(data,{recursive:true,force:true});}
