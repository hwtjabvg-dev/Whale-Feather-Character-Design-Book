from pathlib import Path
import urllib.request,concurrent.futures,json,hashlib
root=Path(__file__).resolve().parents[1]
items={
'moonlit-glimmer.json':'https://raw.githubusercontent.com/RivelleDays/SillyTavern-MoonlitEchoesTheme/main/theme/Glimmer%20-%20by%20Rivelle.json',
'moonlit-extension.json':'https://raw.githubusercontent.com/RivelleDays/SillyTavern-MoonlitEchoesTheme/main/theme/%5BMoonlit%5D%20Glimmer%20-%20by%20Rivelle.json',
'violet-light.json':'https://raw.githubusercontent.com/Mr-Benedict/SillyTavern-VioletGlassTheme/main/dist/Violet%20Glass%20Light.json',
'violet-dark.json':'https://raw.githubusercontent.com/Mr-Benedict/SillyTavern-VioletGlassTheme/main/dist/Violet%20Glass%20Dark.json'}
def get(item):
    name,url=item;p=root/'resources/themes'/name
    for u in [url,url.replace('https://raw.githubusercontent.com/','https://cdn.jsdelivr.net/gh/').replace('/main/','@main/')]:
        try:
            b=urllib.request.urlopen(u,timeout=25).read();json.loads(b);p.write_bytes(b)
            return {'file':name,'source':url,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
        except Exception as e: error=e
    raise error
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:rows=list(pool.map(get,items.items()))
(root/'resources/themes/source.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(rows)
