import{readFile,writeFile,copyFile}from'node:fs/promises';
await copyFile('icon.svg','resources/original-icon.svg');await copyFile('app/public/logo.svg','icon.svg');
await copyFile('README.md','docs/README-原0.2版本.md');await copyFile('README-第一版.md','README.md');
const pkg=JSON.parse(await readFile('package.json','utf8'));pkg.icon='./icon.svg';await writeFile('package.json',JSON.stringify(pkg,null,2)+'\n');
let s=await readFile('src/client/50-seats.js','utf8');const start=s.indexOf('function BrandMark('),end=s.indexOf('/** The sidebar entry point.',start);if(start<0||end<0)throw Error('Logo 锚点不存在');s=s.slice(0,start)+`function BrandMark({ size = 22, className = null }) {
  return h('svg',{viewBox:'0 0 64 64',width:size,height:size,className,role:'img','aria-label':'人设本'},
    h('rect',{width:64,height:64,rx:20,fill:'#335c8d'}),
    h('path',{d:'M14 29c0-10 10-17 22-13 8 3 13 12 10 21 6-3 7-8 7-8 5 10-3 20-13 18-14 7-29-2-26-18Z',fill:'#f8faff'}),
    h('path',{d:'M27 17c-1-6 6-11 11-8-6 1-8 4-6 9',fill:'none',stroke:'#f8faff',strokeWidth:3,strokeLinecap:'round'}),
    h('circle',{cx:25,cy:29,r:2.5,fill:'#335c8d'}),
    h('path',{d:'m32 43-7 5v-9l7 4 7-4v9z',fill:'#5fa3d1'}));
}

`+s.slice(end);await writeFile('src/client/50-seats.js',s);
const n=2646,wav=Buffer.alloc(44+n*2);wav.write('RIFF');wav.writeUInt32LE(36+n*2,4);wav.write('WAVEfmt ',8);wav.writeUInt32LE(16,16);wav.writeUInt16LE(1,20);wav.writeUInt16LE(1,22);wav.writeUInt32LE(22050,24);wav.writeUInt32LE(44100,28);wav.writeUInt16LE(2,32);wav.writeUInt16LE(16,34);wav.write('data',36);wav.writeUInt32LE(n*2,40);for(let i=0;i<n;i++)wav.writeInt16LE(Math.round(4000*Math.exp(-i/500)*Math.sin(2*Math.PI*(820-250*i/n)*i/22050)),44+2*i);await writeFile('app/public/sounds/send.wav',wav);
