import asyncio, pathlib, wave, math, struct
import edge_tts
ROOT=pathlib.Path(__file__).resolve().parents[1]/'app/public/sounds'
ROOT.mkdir(parents=True,exist_ok=True)
async def main():
    for level,text in [('low','收到啦，主人。'),('mid','哼，包在人家身上！'),('high','才、才不是特意等主人消息呢！')]:
        out=ROOT/f'receive-{level}.mp3'
        if not out.exists():
            for attempt in range(3):
                try:
                    await edge_tts.Communicate(text,'zh-CN-XiaoyiNeural',rate='+10%',pitch='+3Hz').save(str(out))
                    break
                except Exception:
                    if attempt==2: raise
        print(out.name,out.stat().st_size)
    with wave.open(str(ROOT/'send.wav'),'wb') as w:
        w.setparams((1,2,22050,0,'NONE','not compressed'))
        w.writeframes(b''.join(struct.pack('<h',int(4000*math.exp(-i/500)*math.sin(2*math.pi*(820-250*i/2646)*i/22050))) for i in range(2646)))
asyncio.run(main())
