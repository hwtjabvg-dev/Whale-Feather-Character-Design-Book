from pathlib import Path
import urllib.request, concurrent.futures, json, shutil, re, subprocess

root = Path(__file__).resolve().parents[1]
upstream = root.parent / 'echotext-upstream'
vendor = root / 'app/vendor'
vendor.mkdir(parents=True, exist_ok=True)
for name in ['emotion-system.js', 'memory-system.js', 'proactive-messaging.js', 'emotions.json']:
    shutil.copy2(upstream / 'lib' / name, vendor / name)
# Export the original trigger evaluator for the server scheduler; leave algorithms intact.
p = vendor / 'proactive-messaging.js'
s = p.read_text(encoding='utf-8').replace('            getDateKeyLocal,', '            evaluateProactiveTrigger, getMergedProactiveConfig, getProactiveConversationState,\n            getDateKeyLocal,', 1)
p.write_text(s, encoding='utf-8')
shutil.copy2(upstream / 'LICENSE', vendor / 'LICENSE-EchoText.txt')

urls = {
 'app/public/avatars/portrait.png': 'https://raw.githubusercontent.com/YunYueSama/codex-deepseek-pet/main/assets/whale/portrait.png',
 'app/public/avatars/idle-front.png': 'https://raw.githubusercontent.com/YunYueSama/codex-deepseek-pet/main/assets/whale/idle-front.png',
 'app/public/avatars/expressions.png': 'https://raw.githubusercontent.com/YunYueSama/codex-deepseek-pet/main/assets/whale/expressions.png',
 'app/public/avatars/actions.png': 'https://raw.githubusercontent.com/YunYueSama/codex-deepseek-pet/main/assets/whale/actions.png',
 'resources/licenses/avatar-license.md': 'https://raw.githubusercontent.com/YunYueSama/codex-deepseek-pet/main/ASSET_LICENSE.md',
 'resources/licenses/avatar-LICENSE.txt': 'https://raw.githubusercontent.com/YunYueSama/codex-deepseek-pet/main/LICENSE',
 'resources/licenses/Moonlit-AGPL.txt': 'https://raw.githubusercontent.com/RivelleDays/SillyTavern-MoonlitEchoesTheme/main/LICENSE',
 'resources/licenses/Violet-MIT.txt': 'https://raw.githubusercontent.com/Mr-Benedict/SillyTavern-VioletGlassTheme/main/LICENSE',
}
def download(item):
    rel, url = item
    target = root / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.stat().st_size > 100:
        return {'file':rel, 'source':url, 'bytes':target.stat().st_size}
    fallback = url.replace('https://raw.githubusercontent.com/', 'https://cdn.jsdelivr.net/gh/').replace('/main/', '@main/')
    error = None
    for address in [url, fallback, url]:
        try:
            data = urllib.request.urlopen(urllib.request.Request(address, headers={'User-Agent':'PersonaBook/0.3'}), timeout=20).read()
            break
        except Exception as exc:
            error = exc
    else: raise error
    target.write_bytes(data)
    return {'file':rel, 'source':url, 'bytes':len(data)}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
    records = list(pool.map(download, urls.items()))
(root / 'resources/source-registry.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
shutil.copy2(root / 'icon.png', root / 'app/public/avatars/original-whale.png')
script = "import {readFile,writeFile} from 'node:fs/promises';import {parseSkill} from './lib/generate.js';import {normalizePersona} from './lib/schema.js';const raw=await readFile('resources/original/04-傲娇小猫语气-SKILL-完整规范版.md','utf8');const p=normalizePersona(parseSkill(raw).value).value;p.presentation={avatarId:'builtin:portrait'};p.voice={receive:['receive-low.mp3','receive-mid.mp3','receive-high.mp3'],phrase:'收到啦，主人～',voiceId:'zh-CN-XiaoyiNeural'};await writeFile('resources/default-persona.json',JSON.stringify(p,null,2));"
subprocess.run(['node','--input-type=module','-e',script],cwd=root,check=True)
print('Prepared original core modules, default persona and attributed network assets.')
