import {build} from 'esbuild';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
await build({entryPoints:['app/ui/main.jsx'],bundle:true,format:'esm',target:['es2022'],outfile:'app/public/app.js',minify:true,sourcemap:true,jsx:'automatic'});
let html=await readFile('app/public/index.html','utf8');for(const file of ['app.js','app.css','premium.css']){const version=createHash('sha256').update(await readFile('app/public/'+file)).digest('hex').slice(0,12);html=html.replace(new RegExp(file.replace('.','\\.')+'(?:\\?v=[^"\\s]+)?','g'),file+'?v='+version);}await writeFile('app/public/index.html',html);
console.log('已构建共享 React 聊天界面。');
