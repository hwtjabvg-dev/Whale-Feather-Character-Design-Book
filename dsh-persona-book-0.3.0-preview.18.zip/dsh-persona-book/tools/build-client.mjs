/**
 * Build `lib/client.js` from the shards in `src/client/`.
 *
 * The host loads exactly one client file (`exports["./client"]`), and a plugin
 * may not add dependencies, so the shards are concatenated in file-name order
 * into the module-loader banner the browser expects. Deterministic: same shards,
 * same bytes — `tools/check.mjs` re-runs this build and compares.
 */
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const shardDir = join(root, 'src', 'client');
const target = join(root, 'lib', 'client.js');

/** The module-loader banner the browser evaluates. */
const HEADER = `window.__ModuleLoader__.load({
\tid: "dsh-persona-book",
\tfactory: (require) => {
\t\tvar module = { exports: {} };
\t\tvar exports = module.exports;
\t\tconst React = require("react");
\t\tconst h = React.createElement;

`;

const FOOTER = `
\t\treturn module.exports;
\t},
});
`;

/** Read every shard in order and stitch the bundle. */
export async function build() {
  const files = (await readdir(shardDir)).filter((name) => name.endsWith('.js')).sort();
  const parts = [];
  for (const name of files) {
    const text = await readFile(join(shardDir, name), 'utf8');
    parts.push(`\t\t/* ===== ${name} ===== */\n${text.trimEnd()}\n`);
  }
  return `${HEADER}${parts.join('\n')}${FOOTER}`;
}

const banner = `/**
 * GENERATED FILE — do not edit.
 *
 * Built from src/client/*.js by tools/build-client.mjs. Edit a shard and run
 * \`node tools/build-client.mjs\`; tools/check.mjs fails when this file and the
 * shards disagree.
 */
`;

const output = `${banner}${await build()}`;

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  await writeFile(target, output, 'utf8');
  const shards = (await readdir(shardDir)).filter((name) => name.endsWith('.js')).length;
  process.stdout.write(`built lib/client.js from ${shards} shards (${Buffer.byteLength(output)} bytes)\n`);
}
