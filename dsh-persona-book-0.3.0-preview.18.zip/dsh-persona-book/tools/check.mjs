/**
 * Static checks that keep the plugin honest.
 *
 * Run with `node tools/check.mjs`. Every rule here exists because breaking it
 * fails silently at runtime: a stale client bundle, a translation key that is
 * only in one language, an error code with no message, a selector that fights the
 * host with `!important`, a stylesheet that hard-codes a colour the official
 * tokens already define.
 */
import { readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { build } from './build-client.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const failures = [];
const notes = [];

/** Record a failure with the rule it came from. */
const fail = (rule, detail) => failures.push(`${rule}: ${detail}`);

/** Read a file relative to the plugin root. */
const read = (relative) => readFile(join(root, relative), 'utf8');

// ---------------------------------------------------------------- client build

const shards = (await readdir(join(root, 'src', 'client'))).filter((name) => name.endsWith('.js')).sort();
const expectedBundle = `${await read('lib/client.js').then((text) => text.slice(0, text.indexOf('window.__ModuleLoader__')))}${await build()}`;
const actualBundle = await read('lib/client.js');
if (actualBundle !== expectedBundle) {
  fail('client-bundle', 'lib/client.js differs from the shards — run `node tools/build-client.mjs`');
} else {
  notes.push(`client bundle matches ${shards.length} shards`);
}

const bundleBytes = Buffer.byteLength(actualBundle);
// 320 KiB: four scene variants, interaction feedback and voice selection; native chat, night-stage styling and the existing settings surface.
// Previously 280 KiB: the bundle carries five tabs (persona, tone, appearance, assets,
// sound, import/export) and the skin interpreter. Still one small file over the
// wire, and the check keeps it within its declared companion UI budget.
if (bundleBytes > 320 * 1024) fail('client-size', `lib/client.js is ${bundleBytes} bytes (budget 320 KiB including the native night stage)`);
else notes.push(`client bundle is ${(bundleBytes / 1024).toFixed(1)} KiB`);

// ------------------------------------------------------------------ red lines

const forbidden = [
  [/setPointerCapture/, 'setPointerCapture redirects click events and breaks delegated handlers'],
  [/!important/, '`!important` fights the host cascade — use :where() and tokens instead'],
  [/require\(["']sharp["']\)/, 'sharp is not resolvable from a plugin package'],
  [/from ["']@deepseek-ai\//, 'plugins must not import host internals'],
  [/require\(["']@deepseek-ai\//, 'plugins must not import host internals'],
];
for (const [pattern, why] of forbidden) {
  if (pattern.test(actualBundle)) fail('forbidden-in-client', `${why} (${pattern})`);
}

// The injected stylesheet may name a literal colour only as a `var()` fallback.
const cssMatch = /const PANEL_CSS = `([\s\S]*?)`;/.exec(await read('src/client/40-style.js'));
if (cssMatch === null) {
  fail('style-shard', 'PANEL_CSS not found in 40-style.js');
} else {
  const stripped = cssMatch[1].replace(/var\([^()]*\)/g, 'var()');
  const literals = stripped.match(/#[0-9a-fA-F]{3,8}\b/g) ?? [];
  if (literals.length > 0) fail('style-hex', `PANEL_CSS hard-codes ${literals.join(', ')} outside a var() fallback`);
  else notes.push('panel stylesheet keeps colours in tokens');
}

if (/#[0-9a-fA-F]{3,8}\b/.test(actualBundle.match(/const BUBBLE_CSS = `([\s\S]*?)`;/)?.[1] ?? '')) {
  fail('bubble-hex', 'BUBBLE_CSS must be colourless — every colour comes from the user settings');
}

// --------------------------------------------------------------- dictionaries

const i18nSource = await read('src/client/10-i18n.js');
const probe = join(root, 'src', 'client', '.i18n-probe.mjs');
await writeFile(probe, `${i18nSource}\nexport { en, zh };\n`, 'utf8');
const { en, zh } = await import(pathToFileURL(probe).href);
await rm(probe, { force: true });

/** Flatten a nested dictionary into dotted keys. */
function flatten(value, prefix = '') {
  const out = {};
  for (const [key, entry] of Object.entries(value)) {
    const path = prefix === '' ? key : `${prefix}.${key}`;
    if (typeof entry === 'string') out[path] = entry;
    else Object.assign(out, flatten(entry, path));
  }
  return out;
}

const flatEn = flatten(en);
const flatZh = flatten(zh);
for (const key of Object.keys(flatZh)) {
  if (!(key in flatEn)) fail('i18n', `en is missing "${key}"`);
}
for (const key of Object.keys(flatEn)) {
  if (!(key in flatZh)) fail('i18n', `zh is missing "${key}"`);
}

const usedKeys = new Set();
for (const name of shards) {
  const text = await readFile(join(root, 'src', 'client', name), 'utf8');
  for (const match of text.matchAll(/\btr\(['"]([^'"]+)['"]\)/g)) usedKeys.add(match[1]);
  for (const match of text.matchAll(/label: '([a-zA-Z0-9.]+)'/g)) usedKeys.add(match[1]);
}
for (const key of usedKeys) {
  if (!(key in flatZh)) fail('i18n', `"${key}" is used by the client but missing from the dictionaries`);
}
notes.push(`${usedKeys.size} translation keys in use`);

// -------------------------------------------------------------------- host

const constants = await read('lib/constants.js');
// Two shards own style tags: the panel stylesheet and the fetched skin sheet.
const STYLE_OWNERS = new Set(['40-style.js', '42-appearance.js']);
for (const name of shards) {
  const text = await readFile(join(root, 'src', 'client', name), 'utf8');
  if (/(?:setAttribute\(['"]data-plugin-css|dataset\.pluginCss\s*=)/.test(text) && !STYLE_OWNERS.has(name)) {
    fail('style-marker', `${name} writes the style marker outside 40-style.js / 42-appearance.js`);
  }
}

const hostSources = ['lib/index.js', 'lib/repo.js', 'lib/http.js', 'lib/schema.js', 'lib/generate.js', 'lib/media.js'];
const hostText = (await Promise.all(hostSources.map((name) => read(name)))).join('\n');
const errorCodes = new Set(Object.keys(await import(pathToFileURL(join(root, 'lib', 'constants.js')).href)).length > 0 ? [] : []);
const declaredCodes = new Set([...constants.matchAll(/^  ([A-Z][A-Z0-9]+): '/gm)].map((match) => match[1]));
for (const match of hostText.matchAll(/new RequestError\(\s*\d+,\s*'([A-Z]+)'/g)) {
  if (!declaredCodes.has(match[1])) fail('error-code', `"${match[1]}" has no Chinese message in constants.js`);
}
notes.push(`${declaredCodes.size} error codes declared`);
void errorCodes;

// ------------------------------------------------------------------ manifest

const pkg = JSON.parse(await read('package.json'));
if (pkg.icon === undefined) fail('manifest', 'package.json has no icon');
else {
  const iconPath = pkg.icon.replace(/^\.\//, '');
  const icon = await read(iconPath);
  const iconBytes = Buffer.byteLength(icon);
  if (iconBytes > 256 * 1024) fail('manifest', 'icon exceeds the 256 KiB loader limit');
  // The editable vector source stays small; the shipped raster icon is allowed
  // to be a normal PNG, so only the SVG carries the soft budget.
  if (iconPath.endsWith('.svg') && iconBytes > 6 * 1024) {
    notes.push(`${iconPath} is ${(iconBytes / 1024).toFixed(1)} KiB (soft budget 6 KiB)`);
  }
}
for (const key of ['.', './client', './locale/*.json', './package.json']) {
  if (!(key in (pkg.exports ?? {}))) fail('manifest', `exports is missing "${key}"`);
}
for (const lang of ['zh', 'en']) {
  const locale = JSON.parse(await read(`locale/${lang}.json`));
  if (typeof locale?.meta?.title !== 'string' || locale.meta.title === '') fail('manifest', `locale/${lang}.json has no meta.title`);
}

// --------------------------------------------------------------------- report

if (failures.length > 0) {
  process.stdout.write(`\n${failures.length} check(s) failed:\n`);
  for (const line of failures) process.stdout.write(`  ✖ ${line}\n`);
  process.exitCode = 1;
} else {
  process.stdout.write('\nAll checks passed.\n');
}
for (const line of notes) process.stdout.write(`  · ${line}\n`);
