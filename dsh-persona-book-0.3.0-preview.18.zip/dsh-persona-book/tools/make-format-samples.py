from pathlib import Path
from PIL import Image,ImageDraw
import urllib.request,subprocess,json
root=Path(__file__).resolve().parents[1];folder=root/'tests/fixtures/formats';folder.mkdir(parents=True,exist_ok=True)
im=Image.new('RGBA',(64,64),(95,163,209,0));d=ImageDraw.Draw(im);d.ellipse((8,8,56,56),fill=(51,92,141,200));d.ellipse((22,23,26,27),fill='white')
frames=[im,im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)]
for fmt,ext in [('PNG','png'),('JPEG','jpg'),('JPEG','jfif'),('WEBP','webp'),('AVIF','avif'),('BMP','bmp'),('ICO','ico'),('TIFF','tiff')]:
    try:(im.convert('RGB')if fmt in ['JPEG','BMP']else im).save(folder/f'avatar.{ext}',format=fmt)
    except Exception as e:print(fmt,e)
for fmt,ext in [('GIF','gif'),('PNG','apng'),('WEBP','animated.webp')]:
    im.save(folder/f'avatar.{ext}',format=fmt,save_all=True,append_images=frames[1:],duration=120,loop=0)
(folder/'avatar.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="24" fill="#335c8d"/></svg>',encoding='utf8')
try:
    b=urllib.request.urlopen('https://raw.githubusercontent.com/strukturag/libheif/master/examples/example.heic',timeout=20).read();(folder/'sample.heic').write_bytes(b)
except Exception as e: print('HEIC fixture download:',e)
ffmpeg=Path('C:/Users/heqi/AppData/Local/Programs/ChatCut/resources/app.asar.unpacked/node_modules/ffmpeg-ffprobe-static/ffmpeg.exe')
for ext,opts in [('mp3',['-c:a','libmp3lame']),('wav',['-c:a','pcm_s16le']),('ogg',['-c:a','libvorbis']),('opus',['-c:a','libopus']),('flac',['-c:a','flac']),('aac',['-c:a','aac']),('m4a',['-c:a','aac']),('webm',['-c:a','libopus'])]:
    subprocess.run([str(ffmpeg),'-hide_banner','-loglevel','error','-y','-i',str(root/'app/public/sounds/receive-low.wav'),*opts,str(folder/f'voice.{ext}')],check=True)
print('Created',len(list(folder.iterdir())),'real format samples')
