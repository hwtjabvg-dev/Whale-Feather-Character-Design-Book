import {readFile,writeFile} from 'node:fs/promises';
let s=await readFile('app/ui/main.jsx','utf8');
s="import ProactivePanel from './proactive.jsx';\n"+s;
const start=s.indexOf("   {panel==='proactive'&&"),end=s.indexOf('\n  </div></section>',start);if(start<0||end<0)throw Error('找不到主动消息页');
s=s.slice(0,start)+"   {panel==='proactive'&&<ProactivePanel state={state} persona={p} act={act} request={request} notify={notify} Toggle={Toggle} Field={Field}/>}"+s.slice(end);
s=s.replace("onBegin={()=>setRoleEdit({...structuredClone(roleEdit||p),dirty:false})}","onBegin={()=>setRoleEdit(prev=>prev||{...structuredClone(p),dirty:false})}");
s=s.replace("{preview.themes?.map", "{preview.cached&&<p className=\"warning\">网络下载失败，当前预览使用随包保存的来源快照。</p>}{preview.avatars?.map(a=><Avatar key={a.id} resource={{...a,file:a.preview}} size={80}/>)}{preview.themes?.map");
s=s.replace("{url:item.url,kind:item.kind}","{url:item.url,kind:item.kind,metadata:item}");
s=s.replace("const bottom=useRef()", "const responseText=useRef({});const bottom=useRef()");
s=s.replace("setBusy(true);setStream({});", "setBusy(true);responseText.current={};setStream({});");
s=s.replace("if(e.type==='text.delta'){receiveCue(e);", "if(e.type==='text.delta'){responseText.current[e.messageId]=(responseText.current[e.messageId]||'')+e.text;const visibleText=state.settings.reasoningFilter?responseText.current[e.messageId].replace(/<(think|thinking|thought|reasoning|reason)>[\\s\\S]*?(?:<\\/\\1>|$)/gi,''):responseText.current[e.messageId];if(visibleText.trim()&&!/^<(?:think|thinking|thought|reasoning|reason)?$/i.test(visibleText.trim()))receiveCue(e);");
s=s.replace("const reload=async()=>{const s=await request('/state');setState(s);return s;};", "const reload=async()=>{const s=await request('/state');if(state&&!document.hidden){const seen=new Set(state.conversations.flatMap(c=>c.messages.map(m=>m.id)));for(const message of s.conversations.flatMap(c=>c.messages))if(message.proactive&&!seen.has(message.id)&&message.status==='done')receiveCue({...message,turnId:message.turnId||message.id});}setState(s);return s;};");
// Poll reads the newest closure, avoiding stale settings and repeated proactive audio.
s=s.replace("useEffect(()=>{reload().catch(notify);const timer=setInterval(()=>{if(!document.hidden)reload().catch(()=>{});},15000);return()=>clearInterval(timer);},[]);", "const reloadRef=useRef(reload);reloadRef.current=reload;useEffect(()=>{reloadRef.current().catch(notify);const timer=setInterval(()=>{if(!document.hidden)reloadRef.current().catch(()=>{});},15000);const focus=()=>{if(!document.hidden)reloadRef.current().catch(()=>{});};document.addEventListener('visibilitychange',focus);return()=>{clearInterval(timer);document.removeEventListener('visibilitychange',focus);};},[]);");
await writeFile('app/ui/main.jsx',s);
console.log('已补齐实际触发条件、诊断预测、头像预览与流式提示音去重。');
