/** Build a portable DSH directory plugin without user data or native binaries. */
import {cp, mkdir, mkdtemp, readFile, readdir, rename, rm, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname, join, relative, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {writeZip} from '../lib/zip.js';

const source = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = resolve(process.argv[2] || join(source, 'outputs'));
await mkdir(output, {recursive:true});
const temporary = await mkdtemp(join(output, '.pb-plugin-stage-'));
const root = join(temporary, 'dsh-persona-book');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const runtimeDeps = ['@imagemagick/magick-wasm', 'react', 'react-dom', 'scheduler', 'loose-envify', 'js-tokens'];

async function filesUnder(dir, base=dir) {
  const files = [];
  for (const item of (await readdir(dir, {withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))) {
    const path = join(dir, item.name);
    if (item.isSymbolicLink()) throw Error(`不允许资源软链接：${relative(base,path)}`);
    if (item.isDirectory()) files.push(...await filesUnder(path,base));
    else files.push({path:relative(base,path).replaceAll('\\','/'),data:await readFile(path)});
  }
  return files;
}

try {
  await mkdir(root, {recursive:true});
  // Explicit allowlist: no data/, credentials, Windows runtime or dev tooling.
  for (const item of ['lib','app','locale','resources','docs','mobile','src','tests','tools','examples','PRODUCT.md','DESIGN.md','README.md','README-第一版.md','THIRD_PARTY_NOTICES.md','LICENSE','icon.svg','cordis.patch.yml','package.json','package-lock.json']) {
    await cp(join(source,item), join(root,item), {recursive:true,filter:path=>!path.endsWith('.tmp') && !path.endsWith('.map') && !path.replaceAll('\\','/').endsWith('/mobile/package-manifest.json')});
  }
  for (const dep of runtimeDeps) await cp(join(source,'node_modules',dep),join(root,'node_modules',dep), {recursive:true,filter:path=>!(dep==='@imagemagick/magick-wasm'&&path.replaceAll('\\','/').includes('/dist/x64'))});
  const files = await filesUnder(root);
  const forbidden = files.filter(f=>/\.(?:exe|dll|node|apk|jks|pem|key|keystore)$/i.test(f.path) || /(?:^|\/)(?:data|\.git|\.credentials[^/]*)(?:\/|$)/.test(f.path));
  if (forbidden.length) throw Error(`安装包包含不应交付的文件：${forbidden.map(x=>x.path).join(', ')}`);
  const pkg = JSON.parse(await readFile(join(root,'package.json'),'utf8'));
  const manifest = {
    format:'dsh-persona-book-directory/v1', version:pkg.version,
    delivery:'plugin-inside-android-dsh', nodeMinimum:22, profile:'web',
    hostReference:'woaiys3/deepseek-harness-android-app / v1.19.6 README / DSH 0.2.0-rc.2',
    verification:{androidDevice:false,hostReferenceOnly:true},
    files:files.map(f=>({path:f.path,bytes:f.data.length,sha256:hash(f.data)})),
  };
  const manifestBytes = Buffer.from(JSON.stringify(manifest,null,2)+'\n');
  await writeFile(join(root,'mobile/package-manifest.json'),manifestBytes);
  files.push({path:'mobile/package-manifest.json',data:manifestBytes});
  const guide = await readFile(join(source,'docs/v1/10-安卓插件安装说明.md'));
  const zip = writeZip([...files.map(f=>({name:'dsh-persona-book/'+f.path,data:f.data})), {name:'安卓插件安装说明.md',data:guide}]);
  const zipFile = join(output,'人设本-安卓DSH插件安装包.zip');
  await writeFile(zipFile+'.tmp',zip);
  await rename(zipFile+'.tmp',zipFile);
  const final = join(output, `人设本-安卓DSH插件-${pkg.version}`);
  // Preserve old packages instead of deleting an existing review artifact.
  const destination = await readdir(output).then(names=>names.includes(`人设本-安卓DSH插件-${pkg.version}`)?final+'-'+Date.now():final);
  await rename(root,destination);
  const report = {version:pkg.version,zip:zipFile,unpacked:destination,files:files.length,bytes:zip.length,sha256:hash(zip),productionDependencies:runtimeDeps,androidDeviceTested:false};
  await writeFile(join(output,'安卓插件安装包校验.json'),JSON.stringify(report,null,2)+'\n');
  await writeFile(join(output,'安卓插件安装说明.md'),guide);
  console.log(JSON.stringify(report,null,2));
} finally {
  if (!temporary.startsWith(join(output,'.pb-plugin-stage-'))) throw Error('暂存路径超出交付目录。');
  await rm(temporary,{recursive:true,force:true});
}
