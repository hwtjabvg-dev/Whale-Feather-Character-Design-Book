/** Prepare signed release assets locally; publishing remains an explicit step. */
import {mkdir,readFile,writeFile,copyFile} from 'node:fs/promises';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {sign,createHash} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {initChannel} from './init-update-channel.mjs';
import {compareVersions} from '../app/updater.mjs';
import {build} from 'esbuild';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),args=process.argv.slice(2);
const option=name=>{const at=args.indexOf(name);return at<0?undefined:args[at+1];};
const pkgFile=join(root,'package.json'),pkg=JSON.parse(await readFile(pkgFile,'utf8'));
const version=option('--version')||pkg.version;compareVersions(version,pkg.version);
if(compareVersions(version,pkg.version)<0)throw Error('发布版本不能低于当前源码版本。');
if(version!==pkg.version){pkg.version=version;await writeFile(pkgFile,JSON.stringify(pkg,null,2)+'\n');const lockFile=join(root,'package-lock.json'),lock=JSON.parse(await readFile(lockFile,'utf8'));lock.version=version;lock.packages[''].version=version;await writeFile(lockFile,JSON.stringify(lock,null,2)+'\n');}
const channel=await initChannel(option('--feed-url'));
const run=promisify(execFile),output=resolve(option('--output')||join(root,'outputs'));
for(const script of ['build-client.mjs','build-app.mjs','pack-plugin.mjs']){const args=[join(root,'tools',script)];if(script==='pack-plugin.mjs')args.push(output);await run(process.execPath,args,{cwd:root,maxBuffer:2*1024*1024});}
const report=JSON.parse(await readFile(join(output,'安卓插件安装包校验.json'),'utf8'));
const releaseDir=join(output,'人设本-更新发布',version);await mkdir(releaseDir,{recursive:true});
const name=`dsh-persona-book-${version}.zip`,bytes=await readFile(report.zip);
const payload={format:'persona-book-update/v1',name:'dsh-persona-book',version,nodeMinimum:22,notes:option('--notes')||'新增插件更新入口、自动检查与失败回退；保留聊天和个人资源。',publishedAt:new Date().toISOString(),package:{url:name,bytes:bytes.length,chunkBytes:524288,sha256:createHash('sha256').update(bytes).digest('hex')}};
const installerName=`install-whale-${version}.mjs`;
await build({entryPoints:[join(root,'mobile/online-install.mjs')],outfile:join(releaseDir,installerName),platform:'node',target:'node22',format:'esm',bundle:true,minify:false,legalComments:'none'});
const installer=await readFile(join(releaseDir,installerName));payload.installer={url:installerName,bytes:installer.length,sha256:createHash('sha256').update(installer).digest('hex')};
const encoded=Buffer.from(JSON.stringify(payload)),key=await readFile(channel.keyFile);
const envelope={payload:encoded.toString('base64'),signature:sign(null,encoded,key).toString('base64')};
await copyFile(report.zip,join(releaseDir,name));await writeFile(join(releaseDir,'latest.json'),JSON.stringify(envelope,null,2)+'\n');
await writeFile(join(releaseDir,'发布说明.md'),`# 人设本 ${version} 更新发布\n\n${payload.notes}\n\n将 latest.json 和 ${name} 上传到同一 HTTPS 更新目录，保持既有访问范围。私人站点的手机后台需要先配置设备授权。发布签名已经生成，私钥没有随包交付。\n\n当前内置更新源：${channel.channel.url||'未配置；联网更新需要先接入实际发布地址。'}\n\n本工具只准备文件，没有上传或发布。\n`);
console.log(JSON.stringify({version,releaseDirectory:releaseDir,manifest:join(releaseDir,'latest.json'),package:join(releaseDir,name),feedUrl:channel.channel.url||null,published:false},null,2));
