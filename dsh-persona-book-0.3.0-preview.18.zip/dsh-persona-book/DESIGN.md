---
name: "设定集／人设本 · 鲸娘陪伴"
description: "原 DSH 会话中的四景陪伴、近景头像与轻声反馈系统"
colors:
  accent: "#315b88"
  bg: "#f2f6fc"
  panel: "#ffffff"
  text: "#17304b"
  muted: "#526982"
  mine: "#dceaf8"
  border: "#d7e2ef"
  deepsea-bg: "#101d30"
  deepsea-panel: "#14243c"
  deepsea-text: "#edf3fb"
  deepsea-muted: "#b2c3db"
  deepsea-accent: "#a5ceff"
  deepsea-mine: "#2b466e"
  deepsea-theirs: "#172942"
  deepsea-border: "#425b7d"
  night-shell: "#0c172a"
  night-sidebar: "#0d1b30"
  night-overlay: "#15243b"
  night-shell-border: "#344b6c"
  night-hover: "#233a5b"
  night-label-soft: "#a8bad3"
  night-assistant: "rgb(24 47 79 / .90)"
  night-user: "rgb(63 99 153 / .90)"
  night-bubble-border: "rgb(126 158 200 / .28)"
  night-user-text: "#f4f7ff"
  night-composer: "rgb(13 28 49 / .94)"
  night-composer-border: "#90a7c8"
  night-action: "#152b49"
  night-action-hover: "#233a5b"
  night-action-text: "#e6f0ff"
  night-action-border: "#5e789c"
  night-segment: "#182c49"
  night-selected: "#c1dcff"
  night-selected-text: "#11294a"
  night-field: "#0f1d32"
  night-field-border: "#607998"
  night-primary: "#bddaff"
  night-primary-text: "#11233f"
  night-code: "#0c1b30"
  night-code-text: "#d7e4f8"
  night-code-keyword: "#b8bfff"
  night-code-string: "#b9dfb2"
  night-code-function: "#add8ff"
  night-code-constant: "#f2cea8"
  night-code-comment: "#a2b5d0"
  night-ornament: "#a4c6e7"
  night-title: "#edf5ff"
  logo-stream: "#e4f1ff"
  logo-current: "#edf5ff"
  logo-moon: "#d8eaff"
  logo-whale: "#9fc9f5"
  paper-bg: "#f6f7f9"
  paper-panel: "#ffffff"
  paper-text: "#243047"
  paper-muted: "#596474"
  paper-accent: "#315b88"
  paper-mine: "#e3edf8"
  paper-theirs: "#ffffff"
  paper-border: "#e4e8ef"
  moonsea-bg: "#e7edf8"
  moonsea-panel: "#f4f7fd"
  moonsea-text: "#24375b"
  moonsea-muted: "#526480"
  moonsea-accent: "#527da5"
  moonsea-mine: "#ccdcf1"
  moonsea-theirs: "#f5f8fe"
  moonsea-border: "#ccd7e9"
  rose-bg: "#f6eceb"
  rose-panel: "#fff6f2"
  rose-text: "#4c3547"
  rose-muted: "#765c71"
  rose-accent: "#9d4d72"
  rose-mine: "#ecd3df"
  rose-theirs: "#fff5ef"
  rose-border: "#d7b8c8"
  scene-light-shell: "#edf2f8"
  scene-light-sidebar: "#e8eef6"
  scene-light-panel: "#fff"
  scene-light-text: "#233853"
  scene-light-muted: "#526680"
  scene-light-border: "#bbcada"
  scene-light-border-strong: "#b2c3d9"
  scene-light-accent: "#315e8f"
  scene-light-hover: "#dce7f3"
  scene-light-hover-elevated: "#c9d9ec"
  scene-light-assistant: "rgb(255 253 250 / .93)"
  scene-light-composer: "rgb(250 253 255 / .96)"
  scene-light-composer-border: "#859dbb"
  scene-light-avatar-bg: "#e6eff9"
  scene-light-avatar-border: "#9cb4cf"
  scene-light-avatar-label: "#35597e"
  scene-light-placeholder: "#5c718d"
  scene-light-control-text: "#35516f"
  scene-light-title: "#233d61"
  scene-light-caption: "#405a7a"
  scene-light-dialog: "#f8fbff"
  scene-light-dialog-header: "#edf3fb"
  scene-light-close-bg: "#edf4fc"
  companion-line-bg: "rgb(17 36 63 / .96)"
  companion-line-border: "#8ba7cb"
  companion-line-text: "#edf5ff"
typography:
  display:
    fontFamily: "WhaleNightDisplay, serif"
    fontSize: "clamp(30px, 3vw, 42px)"
    fontWeight: 500
    lineHeight: 1.5
    letterSpacing: ".1em"
  display-compact:
    fontFamily: "WhaleNightDisplay, serif"
    fontSize: "27px"
    fontWeight: 500
    lineHeight: 1.5
    letterSpacing: ".06em"
  night-subtitle:
    fontFamily: "WhaleNightDisplay, serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.9
    letterSpacing: ".06em"
  headline:
    fontSize: "28px"
    fontWeight: 600
    lineHeight: 1.35
    letterSpacing: "0"
  headline-compact:
    fontSize: "22px"
  title:
    fontSize: "20px"
    fontWeight: 600
    lineHeight: 1.5
    letterSpacing: "0"
  section-title:
    fontSize: "18px"
  body:
    fontSize: "16px"
    lineHeight: 1.85
  night-body:
    fontSize: "var(--pb-host-font)"
    lineHeight: 1.8
  settings-body:
    fontFamily: "\"Segoe UI\", \"Microsoft YaHei\", sans-serif"
    fontSize: "13px"
    lineHeight: 1.8
  label:
    fontSize: "12px"
  caption:
    fontSize: "11px"
    lineHeight: 1.8
rounded:
  segment: "6px"
  control: "8px"
  action: "9px"
  field: "10px"
  card: "12px"
  night-bubble: "14px"
  room: "16px"
  bubble-default: "18px"
  night-pill: "18px"
  night-segment: "15px"
  night-composer: "26px"
  companion-line: "14px 14px 14px 3px"
spacing:
  tight: "4px"
  icon: "6px"
  control: "8px"
  compact: "12px"
  resource-gap: "14px"
  section: "18px"
  panel: "24px"
  content: "28px"
components:
  button-primary:
    backgroundColor: "{colors.accent}"
    textColor: "{colors.panel}"
    rounded: "{rounded.field}"
    padding: "9px 12px"
  button-room:
    backgroundColor: "{colors.bg}"
    textColor: "{colors.text}"
    rounded: "{rounded.action}"
    typography: "{typography.label}"
  button-room-hover:
    backgroundColor: "{colors.mine}"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.muted}"
    rounded: "{rounded.control}"
    size: "32px"
  tone-segment:
    backgroundColor: "transparent"
    rounded: "{rounded.segment}"
    height: "25px"
    padding: "1px 7px"
  tone-segment-active:
    backgroundColor: "{colors.mine}"
    textColor: "{colors.text}"
  field:
    backgroundColor: "{colors.bg}"
    textColor: "{colors.text}"
    rounded: "{rounded.field}"
    padding: "11px 12px"
  settings-nav:
    textColor: "{colors.muted}"
    rounded: "{rounded.field}"
    padding: "12px 13px"
  resource-card:
    backgroundColor: "{colors.panel}"
    textColor: "{colors.text}"
    rounded: "{rounded.card}"
    padding: "10px 10px 16px"
  status-tag:
    backgroundColor: "{colors.bg}"
    textColor: "{colors.muted}"
    rounded: "{rounded.segment}"
    padding: "4px 8px"
  room:
    backgroundColor: "{colors.panel}"
    textColor: "{colors.text}"
    rounded: "{rounded.room}"
    padding: "26px 22px 20px"
  night-button-room:
    backgroundColor: "{colors.night-action}"
    textColor: "{colors.night-action-text}"
    rounded: "{rounded.night-pill}"
    typography: "{typography.label}"
    padding: "4px 11px"
    height: "32px"
  night-button-room-hover:
    backgroundColor: "{colors.night-action-hover}"
  night-button-primary:
    backgroundColor: "{colors.night-primary}"
    textColor: "{colors.night-primary-text}"
    rounded: "{rounded.field}"
    padding: "9px 12px"
  night-field:
    backgroundColor: "{colors.night-field}"
    textColor: "{colors.deepsea-text}"
    rounded: "{rounded.field}"
    padding: "11px 12px"
  night-tone-active:
    backgroundColor: "{colors.night-selected}"
    textColor: "{colors.night-selected-text}"
    rounded: "{rounded.night-segment}"
    height: "25px"
    padding: "1px 6px"
  night-assistant-bubble:
    backgroundColor: "{colors.night-assistant}"
    textColor: "{colors.deepsea-text}"
    rounded: "4px 14px 14px"
    padding: "12px 16px"
    typography: "{typography.night-body}"
  night-user-bubble:
    backgroundColor: "{colors.night-user}"
    textColor: "{colors.night-user-text}"
    rounded: "14px 4px 14px 14px"
    padding: "12px 16px"
    typography: "{typography.night-body}"
  night-composer:
    backgroundColor: "{colors.night-composer}"
    rounded: "{rounded.night-composer}"
    width: "100%"
  scene-light-assistant-bubble:
    backgroundColor: "{colors.scene-light-assistant}"
    textColor: "var(--pb-host-text)"
    rounded: "4px 14px 14px"
    padding: "12px 16px"
    typography: "{typography.night-body}"
  scene-light-composer:
    backgroundColor: "{colors.scene-light-composer}"
    rounded: "{rounded.night-composer}"
    width: "100%"
  voice-pack-selected:
    backgroundColor: "{colors.mine}"
    textColor: "{colors.text}"
    rounded: "{rounded.card}"
    padding: "17px"
  companion-feedback:
    backgroundColor: "{colors.companion-line-bg}"
    textColor: "{colors.companion-line-text}"
    rounded: "{rounded.companion-line}"
    padding: "12px 17px"
---
# Design System: 设定集／人设本 · 鲸娘陪伴

## Overview

**Creative North Star: "深海私语 · 月夜卧室"**

藏蓝帘幕、月海卧室、暖灯和蓝银细线形成安静的睡前陪伴世界。成年蓝白鲸鱼女仆以横卧姿态融入同一场景；标题是克制的中文衬线题字，消息保持稳定的阅读色面。鲸鳍耳、鲸尾、渐变卷发、单呆毛与蓝白女仆服延续品牌身份。

当前记录合并 preview.10 的陪伴体验实现，沿已确认 C 图世界扩展为深海私语、晴海会客、蔷薇黄昏、晴窗手记四套场景；月海轻玻璃、跟随系统两个简洁主题与个人主题继续保留。C 图仍约束深海布局，其他场景复用同一阅读、输入与控制带语法。原 DSH 会话、输入、模型、Agent、工具和工作区继续承载功能。表面合同见 `.impeccable/surfaces/native-companion-feedback.md` 及 `native-night-room.md`。私人更新站点仍为 preview.7；浏览器和协议验证不等同安卓真机或真实账号、真实模型验收。

**Key Characteristics:**

- 横卧鲸娘与月海卧室分别合成，蓝银角饰统一场景边界。
- 衬线子集只用于短题字，正文、工具、代码遵循宿主阅读体系。
- 原 transcript 与全宽原输入共同承载会话，装饰不接管操作。
- 顶部紧凑舞台、键盘时收起、极窄容器控制栏可换行。
- 四场景与两个简洁主题；四张近景头像及原 Q 版、鲸鱼图标共六个选项。
- 真人日语短回应与克制操作音，声音、动效分别控制。
- 角色装饰不拦截宿主，背景轻触与可键盘访问的更多入口形成轻回应。

## Colors

默认蓝白界面使用海蓝与雪白；深海私语使用藏蓝、月光浅蓝和银白。晴海、晴窗与蔷薇场景统一采用浅色宿主外壳，消息继续读取各主题基础色；蔷薇保留暖粉强调。暖灯属于背景画，角色金边属于插画，不扩展成通用操作强调色。

### Primary

- **海蓝强调**（accent）：默认设置主操作、选中轮廓与焦点。
- **月光强调**（deepsea-accent）：夜景交互和宿主品牌别名；night-primary 与 night-selected 分别用于设置确认和语气选中状态。
- **蔷薇强调**（rose-accent）：蔷薇主题的个人化强调。paper-accent、moonsea-accent 保留各主题对象本来的角色。
- **晴景宿主海蓝**（scene-light-accent）：三套浅色场景的全局宿主别名，不覆盖角色主题令牌。

### Secondary

- **月弧／鲸形／海流**（logo-moon、logo-whale、logo-stream、logo-current）：新 SVG 的分层色；宿主内联海流和鲸尾继承 currentColor。
- **蓝银角饰与题字**（night-ornament、night-title）：场景四角细线与银白标题。
- **代码语义色**（night-code-*）：字符串表达式共用字符串色，链接共用函数色，参数共用常量色。

### Neutral

- **浅海与雪白**（bg、panel、text、muted、mine、border）：默认界面的正文、辅助文字、用户消息和边界。
- **深海基础色**（deepsea-*）：主题对象、预览及共享状态色源，与夜景宿主的透明合成材料分开记录。
- **宿主夜壳**（night-shell、night-sidebar、night-overlay、night-shell-border、night-hover、night-label-soft）：背景、侧栏、菜单、边界与辅助标签。
- **月夜气泡与输入**（night-assistant、night-user、night-composer 及其边界）：高不透明度表面隔开文字与卧室细节。
- **字段与胶囊操作**（night-field*、night-action*、night-segment）：设置表单和原输入内的角色控制。
- **保留的主题色组**（paper-*、rose-*、moonsea-*）：晴窗、蔷薇与月海简洁主题八项色源。蓝白女仆和跟随系统共享默认八色；跟随系统可按系统状态切换。
- **晴景外壳与阅读面**（scene-light-*）：三套浅景的明亮背景、侧栏、弹窗、近白角色气泡与输入；浅景角色消息文字读当前主题 text，用户气泡读当前主题 mine。
- **短回应**（companion-line-*）：角色附近的藏蓝小气泡，浅景也沿用这套稳定阅读材料。

**The Theme Source Rule.** 主题基础色源是 app/themes.mjs；55-night-style.js 提供共享场景布局和深海材料，56-feedback.js 的浅景宿主、侧栏、消息、输入与弹窗覆盖随后生效。设置由 app/ui/main.jsx、app/public/app.css 与 premium.css 的最终级联负责；个人主题保留各自令牌。

sidecar 的八阶 OKLCH 色条是展示元数据；透明色按 RGB 通道生成色条，不代表叠在任意背景图上都有同一对比度。

## Typography

**Display Font:** WhaleNightDisplay, serif；实际本地文件 `app/public/fonts/whale-night-serif.woff2` 为 Noto Serif SC 字符子集，font-display:swap。注册字重（400），标题声明（500），浏览器可能合成该字重，不代表已提供另一字体文件。许可为 `app/public/fonts/NotoSerifSC-OFL.txt`；来源及字符覆盖见 `resources/provenance/night-c-rebuild.json`。旧 Ma Shan Zheng 文件保留，但不是当前 C 题字源。

**Body Font:** 原消息与角色控制继承 DSH；设置使用 settings-body 的中文系统字体栈。  
**Label/Mono Font:** 标签继承正文，聊天代码由宿主管理，独立界面代码保留 Consolas, monospace。

### Hierarchy

- **Display / Display Compact**：桌面采用响应字号与疏朗字距；紧凑形态使用 display-compact。副题为 night-subtitle，紧凑副题（10px）、行高（1.8）。
- **Headline / Headline Compact**：非夜景角色名；Title / Section Title 用于设置标题和分区。
- **Body / Night Body**：body 是默认用户字号，原消息实际读取用户设置；夜景最终行高使用 night-body。原输入文字（13px）、行高（24px）。
- **Settings Body / Label / Caption**：设置、操作、说明保留各自角色；移动设置正文另有（12px）覆盖。

**The Reading First Rule.** 原会话遵循用户字号；衬线子集只覆盖品牌短题字。字符串与字符串表达式共享浅绿语义色，长代码保留自身横向滚动。

## Layout

四套场景共用原会话舞台语法；下述夜景指内部共享场景布局（world=night），浅景也采用该布局。深海原会话构成完整卧室。容器达到（940px）且舞台展开时，transcript 占左侧约（48%）、最小（440px），流内边距（28px 28px 20px）。角色舞台四周留（12px）、贯穿会话区域；横卧角色靠右下展开，宽（59%）、右移（60px）、底部距（116px），下缘从（88%）渐隐。标题位于右上，最大宽（42%）。三套浅景使用直立立绘，桌面宽（49%）、高（75%）、右侧（1%）、底部（115px）；紧凑形态使用人物上部（50% 16%）裁切。收起舞台后 transcript 恢复全宽，夜景不再预留固定右侧席位。

原 composer 跨底部全宽，外侧留（28px）、下侧（14px）。第一行共置原输入、头像、低中高、换装、人设设置、立绘开关、更多和原发送；原附件、模型、Agent、权限及工具保留在紧邻的第二行。桌面输入滚动区宽（100% - 460px）、最大高（180px），不新增替代输入。

容器窄于（940px）时，夜景默认显示顶部（176px）舞台，聊天为其留出（190px）并独立滚动；消息恢复全宽、左右留（14px）。舞台可收起和展开，人物在右裁切、题字在左。输入最大高（130px），角色控制位于输入下方一行。容器不超过（339px）时控制栏换行、隐藏栏内头像，原工具行上方留（72px）。容器宽与屏幕宽不同，宿主侧栏会消耗可用宽度。

visualViewport 比 window.innerHeight 少超过（160px），或窄会话区域高低于（430px）时，判断为键盘/空间受限，隐藏舞台并禁用展开。夜景窄舞台默认可见，非夜景窄面板默认收起，二者不能混写。屏幕不超过（940px）时背景另采用（70% top）定位；容器断点负责组件布局。

两个简洁主题与无场景的个人主题保留原席位：桌面区域宽的（28%），限制（260–340px），实际卡片宽为席位减（40px）；窄区展开为宽不超过（380px）的短面板。设置导航桌面（168px）、窄桌面（148px），屏幕不超过（720px）时横向滚动，移动字段最小高（42px）。

仅夜景对稳定外壳 `[data-rightbar-collapsed]:has(> [data-rightbar-col])` 使用 overflow:clip，避免宿主侧栏容器引入横滚。滚动监听只将夜景原 `[data-conversation-scroll]` 的 scrollLeft 归零；代码块自身仍可横向滚动。卸载移除监听并恢复原属性/变量，不以宿主散列类名识别这一外壳。

## Elevation & Depth

背景明暗、透明角色和高不透明消息构成层次。场景框与紧凑舞台均不投影；菜单、输入和设置对话框承担必要的柔和阴影。正文与原工具保持稳定。

### Shadow Vocabulary

- **蓝白输入**：`0 8px 26px rgb(16 35 60 / .045)`；**蓝白菜单**：`0 10px 30px rgb(16 35 60 / .12)`；**蓝白紧凑席位**：`0 12px 40px rgb(16 35 60 / .2)`。
- **蓝白角色 filter**：`drop-shadow(0 16px 14px rgb(20 45 80 / .08))`。
- **夜景输入**：`0 12px 32px rgb(0 6 18 / .2)`；**夜景菜单**：`0 14px 32px rgb(0 5 18 / .35)`；**夜景设置对话框**：`0 24px 72px rgb(0 4 14 / .5)`。
- **资源悬停**：`0 8px 18px rgb(10 27 50 / .12)`，配合短位移提供可选中反馈。
- **横卧角色 filter**：`drop-shadow(-10px 18px 20px rgb(0 5 20 / .25))`；是图像轮廓效果，不是 box-shadow。

**The Quiet Surface Rule.** 场景消息不加阴影；角色层透明且不接管指针，投影只辅助输入、菜单、对话框与角色轮廓的层次。资源卡悬停可短暂抬起，静止时保持轻边界。

## Shapes

蓝白消息一侧保留（4px）小角，其余读取用户圆角；夜景两种气泡采用 frontmatter 各自固定角形。夜景消息头像为圆形（30px）、左侧偏移（40px）。场景双线框外圆角（13px）、内线（9px）；角饰桌面（86px）、紧凑（55px）。自定义头像桌面（190px）、紧凑（120px），圆角（16px）并保留自身裁切。

夜景原输入桌面使用 night-composer 大圆角，紧凑改为（16px）；胶囊操作与分段分别用 night-pill、night-segment。发送为圆形（32px），仍执行宿主行为。

操作图标为（24×24）视框、（1.6）描边的内联 SVG，通常显示（18px）。新 Logo 是（96×96）月弧、鲸形、鲸尾和海流路径；宿主入口（22px）、设置壳（24px），与线性工具图标分开使用。旧文件保留于 `app/public/logo-legacy.svg`、`icon-legacy.svg`。

## Components

### Buttons

夜景换装和人设设置为输入同带胶囊，使用 night-button-room 和单像素边界；窄区文字（11px）、内边距（3px 7px）。hover 使用夜间宿主悬停色，焦点为月光强调色（2px）轮廓、偏移（3px）。设置确认继续使用 night-button-primary，禁用透明度（.5）。原宿主按钮通过 WAAPI 提供（230ms）的 scale(.94)→1 回弹，设置内按钮为（220ms）的 scale(.96)→1；CSS 的 active 状态另提供轻按压。动效关闭与系统减少动态均生效。

### Chips

低／中／高对应（3／6／9），使用 aria-pressed。夜景分段外框（18px）、内边距（2px）；选中用 night-tone-active 与（600）字重。桌面每项最小宽（28px），窄区（24px）。状态标签仍是信息。

### Cards / Containers

主题和头像资源卡保留 card 圆角、轻边界、（2px）选中轮廓和（2px）偏移；hover 上移（3px），active 缩至（.97），过渡以最终 premium.css 的（220ms）变换及（180ms）边界、背景、阴影为准。资源网格展开为（320ms）裁切揭示。头像预览最终为圆形。夜间设置保留藏蓝材料，浅景同步浅色宿主外壳；原消息不包额外卡片。资源选择不重置人设、语气、原输入草稿或聊天。

### Inputs / Fields

设置字段使用 field / night-field，标签、边界、焦点明确，移动字段保留最小高度。原输入草稿、发送、模型、附件、Agent、权限、工具和工作区仍由 DSH 管理。

### Navigation

设置选中项由色面与字重指示，移动导航横向滚动。设置 iframe 同步宿主主题、深色与动效，并验证同源及父窗口。更多菜单向上打开，可用键盘访问「轻轻唤一下」角色入口，外侧点击或 Esc 收起，Esc 后焦点返回 summary；更新和待重启显示真实状态。

### 月夜角色舞台

默认人设和默认 portrait 组合使用 `app/public/art/whale-recline-c.webp`；卧室使用 `app/public/art/night-bedroom-c.webp`，四角使用 `app/public/art/night-corner.svg`。两幅图为本轮 image_gen 新作，角色 WebP 保留 alpha；PNG 原稿在审核输出素材原稿目录，prompt 与来源见 `resources/provenance/night-c-prompts.json`。运行时以 WebP 引用为准，较早 provenance 清单的 PNG 名称不是运行时路径。

三套浅景分别复用みんちりえ的 `salon-day.webp`、`rose-dusk.webp`、`quiet-library.webp`，立绘复用 `whale-welcome-v3.webp`。生产资源使用 WebP，原 PNG 归档保留；来源、许可和原稿与审核资料随项目保存。四张（512×512）近景头像为温柔微笑、月下轻靠、开心、思考：前两张从既有鲸娘插画裁切，后两张从已授权 YunYueSama 表情素材裁切；原 Q 版与鲸鱼图标仍可选，旧图集保留个人版本兼容。自定义人设或头像展示自己的资源及裁切；不因换主题强制回鲸娘。人设原稿、旧 Logo 和旧字体继续保留。

装饰层 pointer-events:none，收起按钮单独可操作。人物上不放透明覆盖按钮；宿主 document 的点击只在人物边界内且属于非交互背景时触发，排除链接、输入、可编辑区、composer、消息正文与过程区。更多菜单提供等价键盘入口。角色轻回应为本地状态气泡，不写入模型会话；轻点头（700ms），短句停留（2300ms），气泡入场（320ms）。

蓝白席位入场（220ms）；共享场景舞台（420ms）从右（14px）进入，角色/头像容器采用（480ms）clip-path 揭示；切换场景另有（480ms）亮度／透明度过渡。设置壳（260ms）、设置内容（220ms）、菜单（180ms）、新回复（180ms）均为一次性短过渡。新回复按会话与轮次去重，历史和流式增量不重播；设备开关与 prefers-reduced-motion 均关闭对应动画/过渡。没有常驻粒子、强制 BGM 或循环呼吸。

### 声音反馈

声音是独立于动效的可控反馈，设置明确标明语言和中文含义。默认选用 soft「轻声回应」，効果音ラボ六条真人日语原声分三组、每组两条轮换：轻声回应（好呀／叫人家了吗）、甜甜轻笑（嘿嘿／轻笑）、俏皮应答（好～／在叫人家吗）。第四组为旧中文系统合成音，按低中高档位选择；自定义上传优先。真人原声未合成、未变调，不描述为中文真人配音。

每轮首条可见正文只播放一次接收短语音，发送仍为普通短消息音。Kenney CC0 的 tap／select／open 对应轻按、选择与菜单，操作音有独立开关和音量，默认音量（.22）、上限（.5），并受总声音开关控制。声音素材仅作为应用实际反馈，不能扩展为独立音源库。9 个新音频（6 语音＋3 操作音）的实际浏览器解码记录与四场景截图保存在 `outputs/陪伴体验升级`。

## Do's and Don'ts

### Do:

- **Do** 依照 C 图的月夜卧室、横卧角色与蓝银角饰组织深海 presentation。
- **Do** 使用原 transcript 和原输入，保留模型、Agent、附件、权限、工具及工作区操作。
- **Do** 让手机顶部舞台默认可见、可收起，键盘出现时隐藏装饰；极窄容器控制栏换行。
- **Do** 保留低／中／高 3／6／9、可见焦点、Esc、设备动效开关和系统减少动态偏好。
- **Do** 为自定义人设和头像显示对应资源及裁切，保留四近景头像、原 Q 版、鲸鱼图标、旧图集、人设和旧 Logo。
- **Do** 将题字限定为已覆盖的 Noto Serif SC 本地子集，正文继承宿主与用户字号。
- **Do** 保持四场景和两个简洁主题并存，浅景外壳、侧栏、弹窗同步明暗；让音量、音效与动效分别可控。
- **Do** 真人日语标明语言和中文含义，复用素材保留来源、许可及归档原稿。

### Don't:

- **Don't** 把 C 图仅当配色参考，或以旧直立图和侧栏留白描述当前深海布局。
- **Don't** 将比较图的介绍栏或横幅比例直接搬入正常桌面宿主。
- **Don't** 新增第二个聊天输入框，或让角色与装饰覆盖消息、输入和工具操作。
- **Don't** 将猫咪语气改成猫外观，或以默认横卧鲸娘替代用户头像。
- **Don't** 对宿主外壳或代码块全局横向归零，夜景裁切与原聊天修复须保持作用范围。
- **Don't** 将静态素材和短过渡宣传为 Live2D、口型同步、循环呼吸或常驻粒子。
- **Don't** 将 preview.10 审核包描述为已发布站点，或把浏览器/模拟协议检查描述为安卓真机、真实账号和真实模型验收。
- **Don't** 用透明角色按钮覆盖宿主操作；背景 hit-test 与更多菜单入口必须保留。

文档从 app/themes.mjs、src/client/50/52/53/54/55 与 app/public 的最终级联抽取。当前 preview.9 为审核版，私人更新站点仍为 preview.7。截图与验收资料在工作区 outputs/深海私语重制；旧轮次截图只说明当时状态，不作为最新偏移修复的最终验收。浏览器、协议模拟和包检查不等同安卓真机、真实模型账号或所有宿主插件组合验收。
