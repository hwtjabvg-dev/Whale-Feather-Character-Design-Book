/** Read-only package check; never prints credentials or changes host settings. */
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root = new URL('../', import.meta.url);
const major = Number(process.versions.node.split('.')[0]);
if (major < 22) throw Error('人设本要求 Node 22 或更新版本，请更新安卓 DSH 宿主。');
const manifest = JSON.parse(await readFile(new URL('mobile/package-manifest.json', root), 'utf8'));
for (const file of manifest.files) {
  if (file.path.startsWith('/') || file.path.split('/').includes('..') || file.path.includes('\\')) throw Error('资源清单路径无效。');
  const bytes = await readFile(new URL(file.path, root));
  if (bytes.length !== file.bytes || createHash('sha256').update(bytes).digest('hex') !== file.sha256) throw Error(`文件不完整：${file.path}`);
}
const pkg = JSON.parse(await readFile(new URL('package.json', root), 'utf8'));
if (pkg.name !== 'dsh-persona-book' || pkg.dsh?.client?.platform !== 'web') throw Error('不是人设本 DSH 插件包。');
console.log(`人设本 ${pkg.version}：${manifest.files.length} 个文件校验通过。`);
console.log(`插件目录：${fileURLToPath(root)}`);
console.log('本包保留 DSH 服务端入口和客户端入口，运行依赖已随包提供。安卓真机兼容状态请查看安装说明。');
