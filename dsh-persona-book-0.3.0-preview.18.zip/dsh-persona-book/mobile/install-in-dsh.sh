#!/system/bin/sh
# 在安卓 DSH 自带终端执行：sh /绝对路径/dsh-persona-book/mobile/install-in-dsh.sh
set -eu
PB_PLUGIN_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
if ! command -v node >/dev/null 2>&1; then
  printf '%s\n' '当前终端没有 Node 运行时。请使用安卓 DSH 宿主自带的终端。'
  exit 1
fi
node "$PB_PLUGIN_DIR/mobile/install-local.mjs"
