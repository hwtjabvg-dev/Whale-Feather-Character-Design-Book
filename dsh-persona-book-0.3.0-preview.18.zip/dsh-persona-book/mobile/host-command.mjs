/** Resolve the host runtime without installing Node, npm packages or a proxy. */
import {stat} from 'node:fs/promises';
import {join,dirname,delimiter} from 'node:path';
import {homedir} from 'node:os';
import {spawn} from 'node:child_process';

export async function resolveHostCommand({executable,entry,env=process.env,home=homedir(),node=process.execPath,platform=process.platform}={}){
 if(executable||entry)return {executable:executable||node,entry:Array.isArray(entry)?entry:entry?[entry]:[]};
 const file=async p=>stat(p).then(s=>s.isFile(),()=>false);
 // Android supplies a dsh wrapper in its own PATH; use that before guessing paths.
 for(const folder of (env.PATH||env.Path||'').split(delimiter).filter(Boolean)){
  const wrapper=join(folder,platform==='win32'?'dsh.exe':'dsh');
  if(await file(wrapper))return {executable:wrapper,entry:[]};
  for(const path of [join(folder,'node_modules/@deepseek-ai/dsh/lib/bin.js'),join(folder,'../lib/node_modules/@deepseek-ai/dsh/lib/bin.js')])if(await file(path))return {executable:node,entry:[path]};
 }
 for(const base of [join(home,'.npm-global'),join(home,'payload/dshroot'),join(home,'dshroot'),join(dirname(node),'..')]){
  const path=join(base,'lib/node_modules/@deepseek-ai/dsh/lib/bin.js');
  if(await file(path))return {executable:node,entry:[path]};
 }
 if(platform==='win32'&&env.LOCALAPPDATA){
  const base=join(env.LOCALAPPDATA,'Programs/DeepSeek Harness'),exe=join(base,'DeepSeek Harness.exe');
  if(await file(exe))return {executable:exe,entry:['--expose-internals',join(base,'resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-desktop-host/lib/cli.js')],electron:true};
 }
 throw Error('未找到 DeepSeek Harness 引擎。请让宿主内的 AI 执行安装，或使用 --dsh-executable 指定已有引擎；无需另装 Node、VPN 或代理。');
}

export function runHostCommand(command,args,{env=process.env,timeout=60000}={}){
 const safeEnv={...env};delete safeEnv.DSH_PERSONA_BOOK_UPDATE_TOKEN;
 if(command.electron)safeEnv.ELECTRON_RUN_AS_NODE='1';
 return new Promise((done,reject)=>{
  const child=spawn(command.executable,[...(command.entry||[]),...args],{env:safeEnv,stdio:['ignore','pipe','pipe'],shell:false,windowsHide:true});
  let output='',settled=false;
  const finish=(error)=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):done(output);};
  const timer=setTimeout(()=>{child.kill();finish(Error('宿主安装命令超时。请确认 DSH 引擎正常运行后重试；已下载的插件文件保留。'));},timeout);
  child.stdout.on('data',b=>{output+=b;if(output.length>2*1024*1024){child.kill();finish(Error('宿主输出异常，已停止安装。'));}});
  child.stderr.resume();
  child.once('error',()=>finish(Error('无法启动 DSH 命令。请在宿主内执行安装，或指定已有引擎路径。')));
  child.once('close',code=>finish(code===0?null:Error('DSH 未完成安装。请检查宿主插件管理后重试；已校验文件保留。')));
 });
}
