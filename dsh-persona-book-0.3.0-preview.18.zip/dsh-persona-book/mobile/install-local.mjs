/** Offline installation from an already downloaded, trusted plugin directory. */
import {cp,mkdir,mkdtemp,rename,rm,realpath,stat} from 'node:fs/promises';
import {resolve,join,dirname} from 'node:path';
import {homedir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {verifyInstalled,registerDsh} from './online-install.mjs';
import {resolveHostCommand,runHostCommand} from './host-command.mjs';
import {compareVersions} from '../app/updater.mjs';
export async function installLocal({source=resolve(dirname(fileURLToPath(import.meta.url)),'..'),dshHome=process.env.DSH_HOME||join(homedir(),'.dsh'),profile='web',command,register=registerDsh}={}){
 if(Number(process.versions.node.split('.')[0])<22)throw Error('请更新 DSH 宿主的 Node 运行时至 22 或以上。');
 if(!/^[a-z0-9_-]+$/i.test(profile))throw Error('DSH 配置名称不正确。');
 const pkg=await verifyInstalled(source),env={...process.env,DSH_HOME:resolve(dshHome)};
 command=command||await resolveHostCommand();
 await runHostCommand(command,['--profile',profile,'--dump-config'],{env});
 const parent=join(resolve(dshHome),'plugins');await mkdir(parent,{recursive:true});
 const root=join(await realpath(parent),'dsh-persona-book'),src=await realpath(source);
 const present=await stat(root).then(()=>true,e=>{if(e.code==='ENOENT')return false;throw e;});
 if(present&&compareVersions(pkg.version,(await verifyInstalled(root)).version)<0)throw Error('已安装版本更新，已停止降级。');
 if(src!==root){
  const stage=await mkdtemp(join(parent,'.whale-local-')),backup=stage+'-previous';let moved=false,committed=false;
  try{
   const staged=join(stage,'plugin');await cp(source,staged,{recursive:true,dereference:false});await verifyInstalled(staged);
   if(present){await rename(root,backup);moved=true;}
   try{await rename(staged,root);committed=true;}catch(e){if(moved)await rename(backup,root);throw e;}
  }finally{await rm(stage,{recursive:true,force:true});if(committed&&moved)await rm(backup,{recursive:true,force:true});}
 }
 // A registration failure keeps the verified persistent copy available for retry.
 const registration=await register(root,{profile,command,env});
 return {name:pkg.name,version:pkg.version,pluginRoot:root,...registration,restartRequired:true,offline:true,next:'安装完成，请在宿主菜单重启 DSH 引擎。原下载目录可删除。'};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{console.log(JSON.stringify(await installLocal(),null,2));}catch(e){console.error(e.message);process.exitCode=1;}
}
