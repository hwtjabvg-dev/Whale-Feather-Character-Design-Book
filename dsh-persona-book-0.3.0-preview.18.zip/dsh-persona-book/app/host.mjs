import {receiveFiles,interactionFiles} from './feedback.mjs';
/** Persona and presentation for the existing DSH session; no second chat transport. */
import {renderSkill} from '../lib/generate.js';
import {DomainError} from './store.mjs';
import {THEMES,AVATARS} from './themes.mjs';
const validSession=id=>{if(typeof id!=='string'||id.length>200||['__proto__','constructor','prototype'].includes(id)||/[\u0000-\u001f]/.test(id))throw new DomainError(400,'ESESSION','会话标识不正确。');return id;};
export function hostRole(state,sessionId=''){
 const prefs=state.host||{},id=prefs.sessions?.[sessionId]?.personaId||prefs.defaultPersonaId;
 const persona=state.personas.find(p=>p.id===id)||state.personas.find(p=>p.builtin)||state.personas[0];
 const intensity=prefs.sessions?.[sessionId]?.toneIntensity;
 return Number.isFinite(intensity)?{...persona,defaults:{...persona.defaults,toneIntensity:intensity}}:persona;
}
export function hostSnapshot(service,sessionId=''){
 validSession(sessionId);const state=service.store.read(),role=hostRole(state,sessionId);
 const theme=state.themes.find(t=>t.id===state.settings.themeId)||THEMES[0];
 const avatar=state.avatars.find(a=>a.id===(role.presentation?.avatarId||state.settings.avatarId))||AVATARS[0];
 const cues=receiveFiles(state,role);
 const level=role.defaults?.toneIntensity||3;
 return {rev:state.rev,enabled:state.settings.hostEnabled!==false,sessionId,role,theme,avatar,themes:state.themes.filter(t=>t.builtin),personas:state.personas.map(p=>({id:p.id,title:p.title,summary:p.summary,defaults:p.defaults,builtin:p.builtin})),settings:{fontSize:state.settings.fontSize,bubbleRadius:state.settings.bubbleRadius,spacing:state.settings.spacing,sound:state.settings.sound,sentSound:state.settings.sentSound,receiveVoice:state.settings.receiveVoice,volume:state.settings.volume,interactionSound:state.settings.interactionSound!==false,interactionVolume:state.settings.interactionVolume??0.22},interactionFiles:interactionFiles(state.settings),receiveFile:cues[0],receiveFiles:cues};
}
export async function selectHostPersona(service,{sessionId='',personaId,toneIntensity,makeDefault=false}){
 validSession(sessionId);if(!service.store.state.personas.some(p=>p.id===personaId))throw new DomainError(404,'ENOTFOUND','人设不存在。');
 if(toneIntensity!==undefined&&![3,6,9].includes(toneIntensity))throw new DomainError(400,'ETONE','请选择低／中／高档。');
 await service.store.transact(s=>{s.host ||= {sessions:{}};s.host.sessions ||= {};if(sessionId)s.host.sessions[sessionId]={personaId,...toneIntensity===undefined?{}:{toneIntensity}};if(!sessionId||makeDefault)s.host.defaultPersonaId=personaId;});
 service.hostChanged?.();return hostSnapshot(service,sessionId);
}
export function hostPrompt(service,context){
 const state=service.store.state;if(!state||state.settings.hostEnabled===false)return '';
 const agent=context?.agent;if(agent?.session?.kind==='subagent')return '';
 const id=agent?.session?.id||agent?.id||context?.sessionId||'',role=hostRole(state,id);
 // Export metadata is for round-trip preservation, not useful model instructions.
 const text=renderSkill(role).replace(/^---\n[\s\S]*?\n---\n/,'').replace(/<!--pb-json:[\s\S]*?-->/g,'').trim();
 const memories=[...(state.engine.globalMemories||[]),...(state.engine.characterMemories?.[role.id]||[])].filter(m=>m.content).map(m=>m.content).slice(-20);
 return '以下是用户为当前 DSH 会话选择的表达风格。沿用宿主的模型、工具、权限、工作区和任务流程；保持回答准确、任务执行完整。\n当前默认语气强度：'+role.defaults.toneIntensity+'/10。明确的当前请求优先于默认口吻。\n\n'+text+(memories.length?'\n\n用户保存的角色记忆：\n'+memories.map(m=>'- '+m).join('\n'):'');
}
export function installHostPrompt(scope,getService){
 if(typeof scope.on!=='function')return ()=>{};
 return scope.on('system-prompt/assemble',async(assembly,context,next)=>{
  const resolved=await next(),service=await getService(),text=hostPrompt(service,context);
  if(!text)return resolved;
  return {...resolved,sections:[...resolved.sections.filter(s=>s.name!=='plugin:persona-book'),{name:'plugin:persona-book',text,interpolate:false}]};
 });
}
