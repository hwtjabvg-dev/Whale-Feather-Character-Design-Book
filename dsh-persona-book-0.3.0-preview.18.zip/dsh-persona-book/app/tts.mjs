import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {readFile,rm} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {DomainError} from './store.mjs';
const exec=promisify(execFile);
export async function speech(store,{text,voice='Microsoft Huihui Desktop',baseUrl,apiKey,model='tts-1',speed=1}){
 text=String(text||'').trim();if(!text||text.length>120)throw new DomainError(400,'ETTS','提示短句需要 1 至 120 字。');
 if(baseUrl){const res=await fetch(String(baseUrl).replace(/\/$/,'')+'/audio/speech',{method:'POST',headers:{'Content-Type':'application/json',...(apiKey?{Authorization:'Bearer '+apiKey}:{})},body:JSON.stringify({model,input:text,voice,speed,response_format:'mp3'}),signal:AbortSignal.timeout(60000)});if(!res.ok)throw new DomainError(502,'ETTS','语音接口生成失败：'+res.status);const b=Buffer.from(await res.arrayBuffer());if(b.length>8*1024*1024)throw new DomainError(413,'ETTS','语音文件过大。');return {data:b,name:'提示短语音.mp3'};}
 if(process.platform!=='win32')throw new DomainError(400,'ETTS','此系统请配置兼容 TTS 接口或上传短语音。');
 const file=store.path('staging/voice-'+randomUUID()+'.wav');
 const quote=x=>"'"+x.replaceAll("'","''")+"'";
 const xml=text.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
 const ps=`$v=New-Object -ComObject SAPI.SpVoice; $chosen=$v.GetVoices()|Where-Object{$_.GetDescription() -like ${quote('*'+voice+'*')}}|Select-Object -First 1; if(!$chosen){throw '找不到指定的本机音色'}; $v.Voice=$chosen; $v.Rate=1; $stream=New-Object -ComObject SAPI.SpFileStream; $stream.Open(${quote(file)},3); $v.AudioOutputStream=$stream; $v.Speak(${quote('<pitch absmiddle="3">'+xml+'</pitch>')},8)|Out-Null; $stream.Close();`;
 await store.atomic('staging/.keep','');try{await exec('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(ps,'utf16le').toString('base64')],{windowsHide:true,timeout:30000});return {data:await readFile(file),name:'提示短语音.wav'};}catch{throw new DomainError(502,'ETTS','本机语音生成失败，请选择已安装的中文音色或配置 TTS 接口。');}finally{await rm(file,{force:true});}
}
