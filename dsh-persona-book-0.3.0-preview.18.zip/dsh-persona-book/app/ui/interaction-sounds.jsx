import React,{useRef,useEffect} from 'react';
import {INTERACTION_PACKS,interactionFiles} from '../feedback.mjs';
export default function InteractionSounds({settings,assetUrl,onSelect,notify}){
 const audio=useRef(null);
 useEffect(()=>()=>audio.current?.pause(),[]);
 const preview=async(pack,kind)=>{audio.current?.pause();const a=new Audio(assetUrl(interactionFiles({interactionPack:pack.id})[kind]));audio.current=a;a.volume=Math.min(.5,Math.max(0,settings.interactionVolume??.22));try{await a.play();}catch{notify('无法播放音效，请检查设备音量后重试。');}};
 return <section className="interaction-library" aria-label="操作音效模板" data-pb-silent>
  <h3>操作音效模板</h3><p className="muted">先试听轻按、选择和展开，再选用。试听不会修改当前声音。</p>
  {INTERACTION_PACKS.map(pack=><div className="installed" key={pack.id}>
   <div><strong>{pack.name}</strong><small>{pack.note}</small><div className="button-row">{[['tap','轻按'],['select','选择'],['open','展开']].map(([kind,label])=><button type="button" key={kind} aria-label={'试听'+pack.name+' · '+label} onClick={()=>preview(pack,kind)}>{label}</button>)}</div></div>
   <button type="button" aria-pressed={(settings.interactionPack||'classic')===pack.id} onClick={()=>onSelect(pack.id)}>{(settings.interactionPack||'classic')===pack.id?'使用中':'选用'}</button>
  </div>)}
  <p className="muted">素材：<a href="https://kenney.nl/assets/interface-sounds" target="_blank" rel="noreferrer">Kenney Interface Sounds</a> · CC0。下载随插件保存，切换和播放无需联网。</p>
 </section>;
}
