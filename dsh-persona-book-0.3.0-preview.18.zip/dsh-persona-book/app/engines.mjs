import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const scripts=['emotion-system','memory-system','proactive-messaging'].map(n=>readFileSync(new URL('./vendor/'+n+'.js',import.meta.url),'utf8'));
const keywords=JSON.parse(readFileSync(new URL('./vendor/emotions.json',import.meta.url),'utf8'));
const chinese={love:['喜欢','爱你','主人','想你','珍惜'],joy:['开心','高兴','太棒了','哈哈','好耶'],trust:['信任','可靠','放心','谢谢','帮忙'],fear:['害怕','担心','紧张','焦虑'],surprise:['惊讶','竟然','没想到','哇'],sadness:['难过','伤心','孤独','哭'],disgust:['讨厌','恶心','不喜欢'],anger:['生气','烦死','你好笨','不理我'],anticipation:['期待','好奇','希望','想试试']};
function context({now=()=>Date.now(),random=Math.random,chineseKeywords=true}={}){
 const window={};const math=Object.create(Math);math.random=random;
 class Clock extends Date {constructor(...args){super(...(args.length?args:[now()]));}static now(){return now();}}
 class XHR {open(){}send(){this.status=200;this.responseText=JSON.stringify(Object.fromEntries(Object.entries(keywords).map(([k,v])=>[k,[...(Array.isArray(v)?v:Object.values(v).flat()),...(chineseKeywords?chinese[k]||[]:[])]])));}}
 const noOp=new Proxy(function(){return noOp;},{get:(_,k)=>k==='length'?0:k==='0'?undefined:()=>noOp});
 const ctx=vm.createContext({window,XMLHttpRequest:XHR,console:{warn(){},log(){}},Date:Clock,Math:math,setTimeout,clearTimeout,setInterval,clearInterval,jQuery:noOp,document:{querySelector(){return null;},addEventListener(){},removeEventListener(){},hidden:false},requestAnimationFrame:()=>0});
 for(const script of scripts)vm.runInContext(script,ctx);return window;
}
export function engines(state,persona,conversation,options={}){
 const win=context(options);const history=()=>conversation.messages.map(m=>({is_user:m.role==='user',mes:m.text,send_date:m.createdAt,meta:{proactive:m.proactive,proactiveType:m.triggerType}}));
 const api={baseUrl:'',getSettings:()=>state.engine,saveSettings(){},getCharacterKey:()=>persona.id,getCurrentCharacter:()=>({name:persona.title,description:persona.summary,personality:persona.identity.roleLine,scenario:persona.context?.scenario||''}),getCharacterName:()=>persona.title,getChatHistory:history,isPanelOpen:()=>false,isTetheredMode:()=>true,findLastUserMessageIndex:h=>h.findLastIndex(m=>m.is_user),expandTimeDateMacros:t=>t,replaceMacros:t=>t.replaceAll('{{char}}',persona.title).replaceAll('{{user}}',persona.identity.userName),log(){}};
 const emotion=win.EchoTextEmotionSystem.createEmotionSystem(api);api.getEmotionState=()=>emotion.getEmotionState();
 const memory=win.EchoTextMemorySystem.createMemorySystem(api);const proactive=win.EchoTextProactiveMessaging.createProactiveMessaging(api);
 return {emotion,memory,proactive};
}
export const EXPRESSION_LABELS=['开心','兴奋','温柔','思考','惊讶','生气','困惑','宕机'];
export function expressionOf(s){if(!s)return '开心';const names=['love','joy','trust','fear','surprise','sadness','disgust','anger','anticipation'];const key=names.reduce((a,b)=>(s[b]||0)>(s[a]||0)?b:a,'joy');return ({love:'温柔',joy:s.joy>65?'兴奋':'开心',trust:'温柔',fear:'困惑',surprise:'惊讶',sadness:'温柔',disgust:'生气',anger:'生气',anticipation:'思考'})[key];}
export function chineseMemoryCandidates(text){return (text.match(/(?:我(?:喜欢|最爱|不喜欢|住在|叫|是|最近|正在|打算)|记住|我们上次)[^。！？\n]{2,70}/g)||[]).slice(0,4).map(content=>({category:'custom',label:content.slice(0,18),content}));}
