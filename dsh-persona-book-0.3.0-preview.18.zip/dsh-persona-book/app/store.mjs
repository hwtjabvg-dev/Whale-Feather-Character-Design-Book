import {mkdir,readFile,writeFile,rename,readdir,rm,copyFile} from 'node:fs/promises';
import {join,resolve,dirname} from 'node:path';
import {randomUUID} from 'node:crypto';
export class DomainError extends Error {constructor(status,code,message){super(message);this.status=status;this.code=code;}}
export class Store {
 constructor(dir,seed){this.dir=resolve(dir);this.seed=seed;this.tail=Promise.resolve();this.state=null;}
 async open(){await mkdir(this.dir,{recursive:true});try{this.state=JSON.parse(await readFile(join(this.dir,'state.json'),'utf8'));}catch(e){if(e.code!=='ENOENT')throw new DomainError(500,'ESTORAGE','数据文件无法读取，请从备份恢复。');this.state=structuredClone(this.seed);await this.atomic('state.json',JSON.stringify(this.state));}return this;}
 async atomic(rel,data){const target=this.path(rel);await mkdir(dirname(target),{recursive:true});const tmp=target+'.tmp-'+randomUUID();try{await writeFile(tmp,data,{mode:0o600});await rename(tmp,target);}finally{await rm(tmp,{force:true}).catch(()=>{});}}
 path(rel){const p=resolve(this.dir,rel);if(p!==this.dir&&!p.startsWith(this.dir+ '\\')&&!p.startsWith(this.dir+'/'))throw new DomainError(400,'EPATH','文件路径不合法。');return p;}
 read(){return structuredClone(this.state);}
 transact(fn,baseRev){const job=this.tail.then(async()=>{if(Number.isInteger(baseRev)&&baseRev!==this.state.rev)throw new DomainError(409,'ESTALE','设置已在另一处修改，请刷新后重试。');const draft=structuredClone(this.state);const result=await fn(draft);draft.rev=(this.state.rev||0)+1;const hist='history/'+Date.now()+'-'+randomUUID()+'.json';await this.atomic(hist,JSON.stringify(this.state));await this.atomic('state.json',JSON.stringify(draft));this.state=draft;const old=(await readdir(this.path('history'))).sort();for(const f of old.slice(0,-20))await rm(this.path('history/'+f),{force:true});return result;});this.tail=job.catch(()=>{});return job;}
 async importMigrationMarker(){const p=this.path('migration-v2-original.json');try{await readFile(p);}catch(e){if(e.code==='ENOENT')await this.atomic('migration-v2-original.json',JSON.stringify(this.state,null,2));}}
}
