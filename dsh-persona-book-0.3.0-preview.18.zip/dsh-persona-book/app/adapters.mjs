import {DomainError} from './store.mjs';
const textAdapters=new Map(),imageAdapters=new Map();
export function registerTextAdapter(kind,adapter){textAdapters.set(kind,adapter);return()=>textAdapters.delete(kind);}
export function registerImageAdapter(kind,adapter){imageAdapters.set(kind,adapter);return()=>imageAdapters.delete(kind);}
export const hasTextAdapter=kind=>textAdapters.has(kind);
export async function requestRemote(url,options={}){try{return await fetch(url,options);}catch(e){if(options.signal?.aborted)throw options.signal.reason;throw new DomainError(502,'ENETWORK','无法连接服务，请检查接口地址和网络。');}}
export async function* streamJson(response,format='sse'){
 if(!response.ok){const detail=(await response.text()).slice(0,300);throw new DomainError(502,'EPROVIDER',`接口返回 ${response.status}：${detail.replace(/sk-[\w-]+/g,'[已隐藏]')}`);}
 const decoder=new TextDecoder();let buffer='';
 for await(const bytes of response.body){buffer+=decoder.decode(bytes,{stream:true});const lines=buffer.split('\n');buffer=lines.pop();for(let line of lines){line=line.trim();if(!line||line.startsWith(':')||line.startsWith('event:'))continue;if(format==='sse'){if(!line.startsWith('data:'))continue;line=line.slice(5).trim();}if(line==='[DONE]')return;try{yield JSON.parse(line);}catch{throw new DomainError(502,'ESTREAM','接口返回了无法识别的流式数据。');}}}
 buffer+=decoder.decode();if(buffer.trim()&&buffer.trim()!=='data: [DONE]'){const line=buffer.trim().replace(/^data:\s*/,'');try{yield JSON.parse(line);}catch{throw new DomainError(502,'ESTREAM','回复数据不完整。');}}
}
export async function* generate(conn,messages,{signal,verbosity='medium'}={}){
 if(textAdapters.has(conn.kind)){yield* textAdapters.get(conn.kind)(conn,messages,{signal,verbosity});return;}
 if(conn.kind==='demo'){const last=messages.filter(m=>m.role==='user').at(-1)?.content||'';let text=demoReply(last,verbosity);const config=messages.find(m=>m.role==='system')?.content||'';const names=/自称([^，\n]{1,40})，称用户([^。\n]{1,40})。/.exec(config);if(names)text=text.replaceAll('主人',()=>names[2]).replaceAll('人家',()=>names[1]);const level=Number(/语气强度(\d+)/.exec(config)?.[1]||3);if(level>=9)text='才、才不是特意等你的消息呢！\n'+text;else if(level>=6)text=('哼，这种小事交给'+(names?.[1]||'人家')+'就好啦。\n')+text;for(const chunk of text.match(/.{1,18}/gs)||[]){if(signal?.aborted)throw signal.reason;yield {type:'text.delta',text:chunk};await new Promise(r=>setTimeout(r,18));}return;}
 const root=String(conn.baseUrl||'').replace(/\/$/,'');if(!/^https?:\/\//.test(root))throw new DomainError(400,'ECONFIG','请填写服务地址。');
 const headers={'Content-Type':'application/json',...(conn.apiKey?{'Authorization':'Bearer '+conn.apiKey}:{})};
 const endpoint=conn.kind==='ollama'?root+'/api/chat':conn.kind==='agent'?root+'/turns':root+'/chat/completions';
 const body=conn.kind==='agent'?{messages,stream:true}:{model:conn.model,messages,stream:true,...(conn.kind==='ollama'?{options:{num_predict:verbosity==='short'?250:verbosity==='long'?1400:700}}:{max_tokens:verbosity==='short'?250:verbosity==='long'?1400:700})};
 const res=await requestRemote(endpoint,{method:'POST',headers,body:JSON.stringify(body),signal});
 if(!res.headers.get('content-type')?.includes('text/event-stream')&&conn.kind!=='ollama'&&res.ok){const b=await res.json();const text=b.choices?.[0]?.message?.content||b.text;if(typeof text!=='string')throw new DomainError(502,'EFORMAT','接口未返回文本回复。');yield {type:'text.delta',text};return;}
 for await(const event of streamJson(res,conn.kind==='ollama'?'ndjson':'sse')){
  if(conn.kind==='agent'){if(['text.delta','tool.start','tool.end','image','error'].includes(event.type))yield event;continue;}
  if(event.error)throw new DomainError(502,'EPROVIDER',String(event.error.message||event.error));
  const text=conn.kind==='ollama'?event.message?.content:event.choices?.[0]?.delta?.content;if(text)yield {type:'text.delta',text};
 }
}
function demoReply(t,length){
 const head='收到啦，主人～';
 if(/你好|在吗|早上好/.test(t))return '主人来啦～ 人家已经把聊天窗口收拾好了。想聊点日常，还是一起把手上的事情做完呀？';
 if(/图片|自拍|照片/.test(t))return '想看人家的照片呀？先在「更多 → 生图连接」配置图片服务，然后就能把图片直接发到聊天里啦。当前是演示连接，不会伪装成真实生成。';
 if(/主题|头像|工坊/.test(t))return head+' 点击左侧导航的「创意工坊」，先预览再安装。已经安装的主题与头像随时能切换，删除正在用的资源包也会回到默认。';
 if(/代码|测试/.test(t))return head+' 先把输入、预期结果和实际现象对齐，再定位问题。\n\n```js\nconst greeting = "你好，主人";\nconsole.log(greeting);\n```\n\n这是演示回复；连接真实模型或 Agent 后，工具执行状态会单独显示。';
 const s=head+' 人家记下了：「'+t.slice(0,70)+'」。可以继续说，也可以把重要的内容保存成记忆。';return length==='short'?s:length==='long'?s+'\n\n当前为离线演示，用于检查聊天、主题、档位和存档操作。设置真实接口后，你输入的内容才会交给选定的模型。':s;
}
export async function generateImage(conn,prompt,{signal}={}){
 if(imageAdapters.has(conn.kind))return imageAdapters.get(conn.kind)(conn,prompt,{signal});
 const root=String(conn.baseUrl||'').replace(/\/$/,'');if(!root)throw new DomainError(400,'ECONFIG','请先配置生图服务。');
 if(conn.kind==='comfyui'){
  const workflow=structuredClone(conn.workflow);if(!workflow)throw new DomainError(400,'ECONFIG','请上传 ComfyUI API 工作流。');const node=workflow[conn.promptNode];if(!node?.inputs)throw new DomainError(400,'ECONFIG','工作流正向提示词节点不正确。');node.inputs[conn.promptField||'text']=prompt;
  const submitted=await requestRemote(root+'/prompt',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt:workflow}),signal});const job=await submitted.json();if(!submitted.ok||!job.prompt_id)throw new DomainError(502,'EIMAGE','ComfyUI 未接受工作流。');
  for(let i=0;i<180;i++){await new Promise(r=>setTimeout(r,1000));signal?.throwIfAborted();const res=await requestRemote(root+'/history/'+encodeURIComponent(job.prompt_id),{signal});const h=(await res.json())[job.prompt_id];if(h?.status?.status_str==='error')throw new DomainError(502,'EIMAGE','ComfyUI 任务失败。');for(const out of Object.values(h?.outputs||{}))if(out.images?.length){const q=new URLSearchParams(out.images[0]);const image=await requestRemote(root+'/view?'+q,{signal});return {data:Buffer.from(await image.arrayBuffer()),mime:image.headers.get('content-type')||'image/png',prompt};}}
  throw new DomainError(504,'ETIMEOUT','图片生成超时。');
 }
 const res=await requestRemote(root+'/images/generations',{method:'POST',headers:{'Content-Type':'application/json',...(conn.apiKey?{Authorization:'Bearer '+conn.apiKey}:{})},body:JSON.stringify({model:conn.model,prompt,n:1,size:conn.size||'1024x1024'}),signal});const body=await res.json();if(!res.ok)throw new DomainError(502,'EIMAGE','生图接口未完成请求：'+res.status);const item=body.data?.[0];if(item?.b64_json)return {data:Buffer.from(item.b64_json,'base64'),mime:'image/png',prompt};if(item?.url){const image=await requestRemote(item.url,{signal});return {data:Buffer.from(await image.arrayBuffer()),mime:image.headers.get('content-type')||'image/png',prompt};}throw new DomainError(502,'EIMAGE','接口未返回图片。');
}
