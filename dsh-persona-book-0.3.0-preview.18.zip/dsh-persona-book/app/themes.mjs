import {createHash,randomUUID} from 'node:crypto';
import {DomainError} from './store.mjs';
import {readZip} from '../lib/zip.js';
export const THEMES=[
 {id:'builtin:maid',name:'蓝白女仆',description:'晴海会客 · 清晨的陪伴',presentation:'scene-room',scene:{id:'day',title:'晴海会客',caption:'今天想做的事，\n就陪主人一起慢慢完成。',background:'art/salon-day.webp',portrait:'art/whale-welcome-v3.webp',pose:'standing',light:true},builtin:true,tokens:{bg:'#f2f6fc',panel:'#ffffff',text:'#17304b',muted:'#526982',accent:'#315b88',mine:'#dceaf8',theirs:'#ffffff',border:'#d7e2ef'}},
 {id:'builtin:deepsea',name:'深海',description:'深海私语 · 月夜剧场',presentation:'night-room',scene:{id:'deepsea',title:'深海私语',caption:'这一份温柔的夜晚，\n只想说给你听。',background:'art/night-bedroom-c.webp',portrait:'art/whale-recline-c.webp',pose:'recline',light:false},builtin:true,tokens:{bg:'#101d30',panel:'#14243c',text:'#edf3fb',muted:'#b2c3db',accent:'#a5ceff',mine:'#2b466e',theirs:'#172942',border:'#425b7d'}},
 {id:'builtin:light',name:'纸质白',description:'晴窗手记 · 安静的午后',presentation:'scene-room',scene:{id:'paper',title:'晴窗手记',caption:'把今天的小事写下来，\n人家会认真记住的。',background:'art/quiet-library.webp',portrait:'art/whale-welcome-v3.webp',pose:'standing',light:true},builtin:true,tokens:{bg:'#f6f7f9',panel:'#ffffff',text:'#243047',muted:'#596474',accent:'#315b88',mine:'#e3edf8',theirs:'#ffffff',border:'#e4e8ef'}},
 {id:'builtin:moonsea',name:'月海轻玻璃',description:'月夜海蓝 · 柔和玻璃',builtin:true,tokens:{bg:'#e7edf8',panel:'#f4f7fd',text:'#24375b',muted:'#526480',accent:'#527da5',mine:'#ccdcf1',theirs:'#f5f8fe',border:'#ccd7e9'},blur:12},
 {id:'builtin:rose',name:'蔷薇黄昏',description:'暖粉落日 · 一点心动',presentation:'scene-room',scene:{id:'rose',title:'蔷薇黄昏',caption:'夕阳还没有落下，\n再陪人家说一会儿吧。',background:'art/rose-dusk.webp',portrait:'art/whale-welcome-v3.webp',pose:'standing',light:true},builtin:true,tokens:{bg:'#f6eceb',panel:'#fff6f2',text:'#4c3547',muted:'#765c71',accent:'#9d4d72',mine:'#ecd3df',theirs:'#fff5ef',border:'#d7b8c8'}},
 {id:'builtin:system',name:'跟随系统',description:'自动切换深浅色',builtin:true,tokens:{bg:'#f2f6fc',panel:'#ffffff',text:'#17304b',muted:'#526982',accent:'#315b88',mine:'#dceaf8',theirs:'#ffffff',border:'#d7e2ef'}}
];
export const AVATARS=[
 {id:'builtin:portrait',name:'小鲸鲸 · 温柔微笑',file:'avatars/face-smile.webp',format:'webp',builtin:true,position:'center',size:'cover'},
 {id:'builtin:idle',name:'小鲸鲸 · 月下轻靠',file:'avatars/face-moon.webp',format:'webp',builtin:true,position:'center',size:'cover'},
 {id:'builtin:happy',name:'小鲸鲸 · 开心',file:'avatars/face-happy.webp',format:'webp',builtin:true,position:'center',size:'cover'},
 {id:'builtin:thinking',name:'小鲸鲸 · 思考',file:'avatars/face-thought.webp',format:'webp',builtin:true,position:'center',size:'cover'},
 {id:'builtin:chibi',name:'原版Q版鲸娘',file:'avatars/portrait.png',builtin:true,position:'center',size:'cover'},
 {id:'builtin:whale',name:'原版小鲸鱼',file:'avatars/original-whale.png',builtin:true,position:'center',size:'contain'}
];
export const WORKSHOP=[
 {id:'moonlit-glimmer',kind:'theme',name:'月下回声 · 微光',author:'RivelleDays',sourceUrl:'https://github.com/RivelleDays/SillyTavern-MoonlitEchoesTheme',url:'https://raw.githubusercontent.com/RivelleDays/SillyTavern-MoonlitEchoesTheme/main/theme/Glimmer%20-%20by%20Rivelle.json',license:'AGPL-3.0',description:'月下回声的灰蓝主题预设，兼容颜色和材质映射。',downloadCount:null},
 {id:'violet-light',kind:'theme',name:'紫晶轻玻璃 · 浅色',author:'Mr-Benedict',sourceUrl:'https://github.com/Mr-Benedict/SillyTavern-VioletGlassTheme',url:'https://raw.githubusercontent.com/Mr-Benedict/SillyTavern-VioletGlassTheme/main/dist/Violet%20Glass%20Light.json',license:'MIT',description:'细边框、玻璃材质与柔和层次。',downloadCount:null},
 {id:'violet-dark',kind:'theme',name:'紫晶轻玻璃 · 深色',author:'Mr-Benedict',sourceUrl:'https://github.com/Mr-Benedict/SillyTavern-VioletGlassTheme',url:'https://raw.githubusercontent.com/Mr-Benedict/SillyTavern-VioletGlassTheme/main/dist/Violet%20Glass%20Dark.json',license:'MIT',description:'适合夜间角色聊天的深色玻璃主题。',downloadCount:null},
 {id:'whale-avatar',kind:'avatar',name:'鲸鱼娘 · 角色肖像',author:'YunYueSama',sourceUrl:'https://github.com/YunYueSama/codex-deepseek-pet',url:'https://raw.githubusercontent.com/YunYueSama/codex-deepseek-pet/main/assets/whale/portrait.png',license:'大肥鱼项目署名许可 1.0',description:'深蓝白色女仆形象，作者新增角色素材。',downloadCount:null}
];
const color=v=>typeof v==='string'&&/^(#[\da-f]{3,8}|rgba?\([\d\s.,%/]+\)|hsla?\([\d\s.,%/]+\))$/i.test(v.trim())?v.trim():null;
export function normalizeTheme(input,name='导入主题'){
 if(typeof input==='string')input={name,custom_css:input};
 const warnings=[];const source=input?.settings||input||{};const tokens={...THEMES[0].tokens};
 const fields={bg:['bg','primary','chat_tint_color','sheldBackgroundColor','customBgColor1'],panel:['panel','primary','blur_tint_color','customTopBarColor'],text:['text','main_text_color','Drawer-iconColor'],muted:['muted','italics_text_color'],accent:['accent','quote_text_color','customThemeColor'],mine:['mine','secondary','user_mes_blur_tint_color','customBgColor1'],theirs:['theirs','secondary','bot_mes_blur_tint_color','customBgColor2'],border:['border','border_color']};
 for(const [key,names]of Object.entries(fields))for(const n of names){const v=color(input?.tokens?.[n]??source[n]);if(v){tokens[key]=v;break;}}
 let css=String(input.custom_css||input.css||'');
 if(css){warnings.push('原平台专属选择器仅映射聊天组件；未映射的效果不生效。');css=mapCss(css);}
 return {id:'theme:'+randomUUID(),name:String(input.name||input.label||input.presetName||name).slice(0,80),tokens,css,blur:Math.min(20,Math.max(0,Number(source.blur_strength||source.sheldBlurStrength||0))),builtin:false,warnings,format:input.moonlitEchoesPreset?'moonlit':input.main_text_color?'sillytavern':input.primary?'echotext':'persona-book'};
}
export function mapCss(css){
 css=css.replace(/\/\*[\s\S]*?\*\//g,'').replace(/@import[^;]+;/g,'').replace(/@font-face\s*\{[^}]*\}/g,'').replace(/url\([^)]*\)/g,'none');
 const mappings={'--SmartThemeBodyColor':'--pb-text','--SmartThemeQuoteColor':'--pb-accent','--SmartThemeBlurTintColor':'--pb-panel','--SmartThemeBorderColor':'--pb-border','--SmartThemeChatTintColor':'--pb-bg'};
 for(const[a,b]of Object.entries(mappings))css=css.replaceAll(a,b);
 const selected=[];
 for(const m of css.matchAll(/([^{}]+)\{([^{}]*)\}/g)){
  let selector=m[1].trim();if(selector.startsWith('@')||!/(\.mes_text|\.mes_block|\.mes\b|#send_form|\.avatar\b|\.message-text|\.bubble\b|\.composer|\.echotext-message)/.test(selector))continue;
  selector=selector.replaceAll('.echotext-message-bubble','.bubble').replaceAll('.echotext-message-text','.message-text').replaceAll('.echotext-message','.message');
  selector=selector.replaceAll('#send_form','.composer').replaceAll('.mes_text','.message-text').replaceAll('.mes_block','.bubble').replace(/\.mes\b/g,'.message').replaceAll('.avatar','.avatar').replace(/#chat\b/g,'.messages').replace(/\bbody(?:\.[\w-]+)*/g,'[data-pb-root]');
  selector=selector.split(',').map(s=>s.includes('[data-pb-root]')?s:'[data-pb-root] '+s.trim()).join(',');
  const body=m[2].split(';').filter(d=>/^\s*(color|background(?:-color)?|border(?:-radius|-color|-width|-style)?|box-shadow|font(?:-size|-family|-weight)?|line-height|padding|margin|opacity|backdrop-filter)\s*:/.test(d)).join(';');
  if(body)selected.push(`${selector}{${body.replace(/!important/g,'')}}`);
 }
 return selected.join('\n');
}
export function decodeThemePackage(buffer,name){
 if(name.toLowerCase().endsWith('.zip')){const entries=readZip(buffer);if(!entries)throw new DomainError(400,'EFORMAT','压缩包无法识别。');const themes=[];for(const e of entries.filter(e=>/\.(json|css)$/i.test(e.name)&&!/(?:package|manifest|lock|source)\.json$/i.test(e.name))){try{const doc=/\.css$/i.test(e.name)?e.data.toString():JSON.parse(e.data.toString());if(typeof doc==='string'||doc.tokens||doc.main_text_color||doc.moonlitEchoesPreset||doc.primary||doc.custom_css)themes.push(normalizeTheme(doc,e.name.split('/').pop()));}catch{}}if(!themes.length)throw new DomainError(400,'EFORMAT','包内没有可识别的主题文件。');return themes.slice(0,30);}
 try{return [normalizeTheme(/\.css$/i.test(name)?buffer.toString():JSON.parse(buffer.toString()),name.replace(/\.[^.]+$/,''))];}catch(e){if(e instanceof DomainError)throw e;throw new DomainError(400,'EFORMAT','主题需要是 JSON、CSS 或主题 ZIP。');}
}
export const THEME_CACHE={'moonlit-glimmer':'moonlit-glimmer.json','violet-light':'violet-light.json','violet-dark':'violet-dark.json'};
export const digest=data=>createHash('sha256').update(data).digest('hex');
export async function downloadResource(url,max=32*1024*1024){let u;try{u=new URL(url);}catch{throw new DomainError(400,'EURL','下载地址不正确。');}if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw new DomainError(400,'EURL','请使用 HTTP 或 HTTPS 下载地址。');const res=await fetch(u,{signal:AbortSignal.timeout(25000),headers:{'User-Agent':'PersonaBook/0.3'}});if(!res.ok)throw new DomainError(502,'EDOWNLOAD','资源下载失败：'+res.status);const parts=[];let size=0;for await(const c of res.body){size+=c.length;if(size>max)throw new DomainError(413,'ETOOLARGE','下载文件超过大小限制。');parts.push(c);}return Buffer.concat(parts);}
