export const INTERACTION_PACKS=[
 {id:'classic',name:'轻触',note:'保留当前操作音',files:{tap:'tap.wav',select:'select.wav',open:'open.wav'}},
 {id:'moon',name:'月光玻璃',note:'清亮玻璃与轻选定，适合深海夜景',files:{tap:'glass_001.ogg',select:'select_003.ogg',open:'open_002.ogg'}},
 {id:'soft',name:'柔和拨弦',note:'短拨弦与轻切换，适合长时间聊天',files:{tap:'pluck_001.ogg',select:'pluck_002.ogg',open:'maximize_001.ogg'}},
 {id:'drop',name:'水滴轻响',note:'下落、弹选与展开，轻快有层次',files:{tap:'drop_001.ogg',select:'select_006.ogg',open:'open_004.ogg'}}
];
export function interactionFiles(settings={}){const pack=INTERACTION_PACKS.find(p=>p.id===settings.interactionPack)||INTERACTION_PACKS[0];return Object.fromEntries(Object.entries(pack.files).map(([k,v])=>[k,'sounds/ui/'+v]));}
export const VOICE_PACKS=[
 {id:'message',name:'A · 元气新消息',note:'真人日语 · 有消息来啦 · 1.34 秒',files:['voice/messagegakiteruyo1.mp3']},
 {id:'greeting',name:'B · 少女打招呼',note:'真人日语 · 呀吼／嗨 · 1.01 秒',files:['voice/yoho1.mp3']},
 {id:'hum',name:'D · 轻唤嗯？',note:'非词句人声 · 嗯？ · 1.01 秒',files:['voice/n1.mp3']},
 {id:'dingdong',name:'F · 人声叮咚',note:'真人拟声 · 模仿叮咚提示 · 2.56 秒',files:['voice/pinponpanpon1.mp3']}
];
export function selectedVoicePack(state,role){return VOICE_PACKS.find(x=>x.id===(role.voice?.packId||state.settings.receivePack))||VOICE_PACKS[0];}
export function receiveFiles(state,role){
 const custom=state.assets.find(a=>a.id===(role.voice?.assetId||state.settings.receiveSoundId));if(custom)return[custom.file];
 const pack=selectedVoicePack(state,role);
 return pack.files.map(f=>'sounds/'+f);
}
export function retireLegacyVoice(state){
 let changed=false;
 const retired=['legacy','soft','sweet','playful'];
 const oldFile=f=>/^(?:sounds\/)?receive-(?:low|mid|high)\.wav$/.test(f)||/^(?:sounds\/)?voice\/(?:hai1|yobimashita1|ehehe1|kusukusu1|haihaai1|yondakana1)\.mp3$/.test(f);
 if(retired.includes(state.settings.receivePack)){state.settings.receivePack='message';changed=true;}
 for(const role of state.personas){
  if(!role.voice)continue;
  if(retired.includes(role.voice.packId)){role.voice.packId='message';changed=true;}
  if(role.voice.receive?.some(oldFile)){
   const retained=role.voice.receive.filter(f=>!oldFile(f));
   role.voice.receive=retained.length?retained:[...VOICE_PACKS[0].files];changed=true;
  }
 }
 return changed;
}
