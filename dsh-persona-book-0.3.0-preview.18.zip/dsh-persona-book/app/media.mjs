import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {dirname,join} from 'node:path';
import {probe,svgDanger} from '../lib/media.js';
import {DomainError} from './store.mjs';
import {digest} from './themes.mjs';
let initialized;
async function magick(){const m=await import('@imagemagick/magick-wasm');if(!initialized){const require=createRequire(import.meta.url);initialized=m.initializeImageMagick(await readFile(require.resolve('@imagemagick/magick-wasm/magick.wasm')));}await initialized;return m;}
export function identify(data,name=''){
 let info;try{info=probe(data);}catch{throw new DomainError(400,'EFORMAT','文件内容不完整或格式不正确。');}
 if(!info&&data.length>8&&((data[0]===0x49&&data[1]===0x49&&data[2]===42)||(data[0]===0x4d&&data[1]===0x4d&&data[3]===42)))info={format:'tiff',mime:'image/tiff',kind:'image'};
 if(!info&&data.length>6&&data[0]===0&&data[1]===0&&data[2]===1&&data[3]===0)info={format:'ico',mime:'image/x-icon',kind:'image'};
 if(data.length>12&&data.subarray(4,8).toString()==='ftyp'&&['M4A ','M4B ','mp42','isom'].includes(data.subarray(8,12).toString())&&/\.(m4a|aac)$/i.test(name))info={format:'m4a',mime:'audio/mp4',kind:'audio'};
 if(data.length>2&&data[0]===255&&(data[1]&0xf6)===0xf0)info={format:'aac',mime:'audio/aac',kind:'audio'};
 if(info?.format==='webm'&&/A_(?:OPUS|VORBIS)/.test(data.subarray(0,1200).toString('latin1'))&&!/V_(?:VP8|VP9|AV1|MPEG)/.test(data.subarray(0,1200).toString('latin1')))info={...info,kind:'audio',mime:'audio/webm'};
 if(!info)throw new DomainError(400,'EFORMAT','无法识别文件格式，请选择有效的图片或音频。');
 return info;
}
export async function installMedia(store,data,name,kind){
 const info=identify(data,name);if(kind==='sound'&&info.kind!=='audio')throw new DomainError(400,'EFORMAT','这里需要音频文件。');if(kind!=='sound'&&!['image','svg'].includes(info.kind))throw new DomainError(400,'EFORMAT','这里需要图片文件。');
 if(data.length>(kind==='sound'?8:16)*1024*1024)throw new DomainError(413,'ETOOLARGE',kind==='sound'?'音频最大 8 MB。':'头像最大 16 MB。');
 if(info.format==='svg'){const bad=svgDanger(data);if(bad)throw new DomainError(400,'ESVG','SVG 包含不支持的脚本或外部引用。');}
 const hash=digest(data);const ext=info.format==='jpeg'?'jpg':info.format;const rel='media/'+hash+'.'+ext;
 await store.atomic(rel,data);let preview=rel;
 if(kind!=='sound'){
  try{const m=await magick();let png;const decode=info.format==='ico'?icoImage(data):data;m.ImageMagick.read(decode,img=>{img.autoOrient();if(img.width>512||img.height>512)img.resize(512,512);img.write(m.MagickFormat.Png,b=>png=Buffer.from(b));});preview='media/'+hash+'-preview.png';await store.atomic(preview,png);}catch(e){if(info.format!=='svg')throw new DomainError(422,'ECODEC','该图片无法生成兼容预览，请检查文件是否完整。');}
 }
 return {id:'asset:'+hash.slice(0,24),name:String(name).slice(0,100),file:rel,preview,displayFile:['heic','heif','tiff','ico'].includes(info.format)?preview:rel,bytes:data.length,hash,kind,format:info.format,mime:info.mime,animated:info.variant==='animated',builtin:false,createdAt:Date.now()};
}
function icoImage(data){const count=data.readUInt16LE(4);if(count<1||count>256||6+count*16>data.length)throw Error('ICO 目录不完整');const entries=[];for(let i=0;i<count;i++){const pos=6+i*16,size=data.readUInt32LE(pos+8),offset=data.readUInt32LE(pos+12);if(offset+size>data.length)throw Error('ICO 图像越界');entries.push({size,offset,width:data[pos]||256,height:data[pos+1]||256});}const best=entries.sort((a,b)=>b.width*b.height-a.width*a.height)[0],part=data.subarray(best.offset,best.offset+best.size);if(part.subarray(1,4).toString()==='PNG')return part;const bmp=Buffer.alloc(14+part.length);bmp.write('BM');bmp.writeUInt32LE(bmp.length,2);bmp.writeUInt32LE(14+part.readUInt32LE(0),10);part.copy(bmp,14);bmp.writeInt32LE(best.height,14+8);return bmp;}
