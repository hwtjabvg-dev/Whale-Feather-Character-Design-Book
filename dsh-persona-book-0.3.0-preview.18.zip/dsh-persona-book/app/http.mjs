import {readFile,stat} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {DomainError} from './store.mjs';
import {VERSION} from './version.mjs';
import {hostSnapshot,selectHostPersona} from './host.mjs';
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.avif':'image/avif','.gif':'image/gif','.mp3':'audio/mpeg','.wav':'audio/wav','.ogg':'audio/ogg','.m4a':'audio/mp4','.webm':'audio/webm','.flac':'audio/flac','.aac':'audio/aac','.json':'application/json'};
const json=(res,value,status=200)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));};
async function body(req,max=34*1024*1024){let size=0;const parts=[];for await(const c of req){size+=c.length;if(size>max)throw new DomainError(413,'ETOOLARGE','文件超过大小限制。');parts.push(c);}return Buffer.concat(parts);}
async function params(req){try{return JSON.parse((await body(req,1024*1024)).toString()||'{}');}catch(e){if(e.status)throw e;throw new DomainError(400,'EJSON','请求内容不是有效 JSON。');}}
export function createHandler(service,{base='/api',publicDir=new URL('./public/',import.meta.url),trusted=false,token='',onShutdown}={}){
 const root=resolve(typeof publicDir==='string'?publicDir:decodeURIComponent(publicDir.pathname.replace(/^\/([A-Z]:)/,'$1')));
 return async(req,res)=>{try{
  const url=new URL(req.url,'http://localhost'),path=url.pathname;
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');
  if(!trusted){const cookies=String(req.headers.cookie||'').split(';').map(x=>x.trim());const authorized=cookies.includes('pb_session='+token)||req.headers.authorization==='Bearer '+token;if(url.searchParams.get('token')===token&&token){res.setHeader('Set-Cookie',`pb_session=${token}; HttpOnly; SameSite=Strict; Path=/`);res.writeHead(302,{Location:url.pathname});res.end();return;}if(!authorized){json(res,{error:{code:'EAUTH',message:'请使用启动器提供的链接打开人设本。'}},401);return;}
   if(!['GET','HEAD'].includes(req.method)&&req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)throw new DomainError(403,'EORIGIN','请从当前人设本页面操作。');
  }
  const route=path.startsWith(base)?path.slice(base.length):null;
  if(route==='/state'&&req.method==='GET'){json(res,service.snapshot());return;}
  if(route==='/host/state'&&req.method==='GET'){json(res,hostSnapshot(service,url.searchParams.get('sessionId')||''));return;}
  if(route==='/host/select'&&req.method==='POST'){json(res,await selectHostPersona(service,await params(req)));return;}
  if(route==='/action'&&req.method==='POST'){const input=await params(req),result=await service.action(input);if(['uninstallPackage','deleteAvatar','deletePersona','gallery','message'].includes(input.action))await service.collectUnusedMedia();json(res,{result,state:service.snapshot()});return;}
  if(route==='/turn'&&req.method==='POST'){const input=await params(req);res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});res.flushHeaders();const emit=e=>{if(!res.destroyed)res.write('data: '+JSON.stringify(e)+'\n\n');};res.on('close',()=>{if(!res.writableEnded)service.stop(input.conversationId);});await service.turn(input,emit);res.end();return;}
  if(route==='/stop'&&req.method==='POST'){service.stop((await params(req)).conversationId);json(res,{ok:true});return;}
  if(route==='/upload'&&req.method==='POST'){json(res,await service.upload(await body(req),url.searchParams.get('name')||'文件',url.searchParams.get('kind')||'avatar'));return;}
  if(route==='/persona/import'&&req.method==='POST'){json(res,await service.importPersona(await body(req),url.searchParams.get('name')||'persona.md'));return;}
  if(route==='/persona/export'&&req.method==='GET'){const out=await service.exportPersona(url.searchParams.get('id'),url.searchParams.get('format')||'bundle');res.writeHead(200,{'Content-Type':out.mime,'Content-Disposition':`attachment; filename="${out.filename}"`});res.end(out.data);return;}
  if(route==='/chat/export'&&req.method==='GET'){const format=url.searchParams.get('format')||'json';res.writeHead(200,{'Content-Type':format==='json'?'application/json':'text/markdown; charset=utf-8','Content-Disposition':`attachment; filename="chat.${format==='json'?'json':'md'}"`});res.end(service.exportChat(url.searchParams.get('id'),format));return;}
  if(route==='/chat/import'&&req.method==='POST'){json(res,await service.importChat((await body(req)).toString()));return;}
  if(route==='/workshop'&&req.method==='GET'){json(res,await service.workshop());return;}
  if(route==='/workshop/preview'&&req.method==='POST'){const p=req.headers['content-type']?.startsWith('application/json')?await params(req):{data:await body(req),name:url.searchParams.get('name'),kind:url.searchParams.get('kind')};json(res,await service.stage(p));return;}
  if(route==='/workshop/install'&&req.method==='POST'){const result=await service.commitStage((await params(req)).token);await service.collectUnusedMedia();json(res,result);return;}
  if(route==='/connection/test'&&req.method==='POST'){json(res,await service.connectionTest((await params(req)).id));return;}
  if(route==='/voice/generate'&&req.method==='POST'){json(res,await service.generateSpeech(await params(req)));return;}
  if(route==='/proactive/insights'&&req.method==='GET'){json(res,service.proactiveInsights(url.searchParams.get('personaId')));return;}
  if(route==='/updates/status'&&req.method==='GET'){json(res,service.updater.status());return;}
  if(route==='/updates/source'&&req.method==='POST'){json(res,await service.updater.configure((await params(req)).url));return;}
  if(route==='/updates/access'&&req.method==='POST'){json(res,await service.updater.configureAccess((await params(req)).token));return;}
  if(route==='/updates/check'&&req.method==='POST'){json(res,await service.updater.check());return;}
  if(route==='/updates/install'&&req.method==='POST'){const idle=()=>{if(service.running.size||service.hostIsBusy?.())throw new DomainError(409,'EBUSY','请先等待聊天回复完成或停止生成，再更新插件。');};idle();json(res,await service.updater.install((await params(req)).version,idle));return;}
  if(route==='/health'){json(res,{ok:true,version:VERSION,schema:2});return;}
  if(route==='/shutdown'&&req.method==='POST'&&onShutdown){json(res,{ok:true});setTimeout(onShutdown,100);return;}
  let file;if(route?.startsWith('/media/'))file=service.store.path(route.slice(1));else if(trusted&&route?.startsWith('/ui/'))file=resolve(root,route.slice(4)||'index.html');else if(!trusted)file=resolve(root,path==='/'?'index.html':path.slice(1));else throw new DomainError(404,'ENOTFOUND','页面不存在。');
  if(!file.startsWith(root)&&!file.startsWith(service.store.path('media')+'\\')&&!file.startsWith(service.store.path('media')+'/'))throw new DomainError(403,'EPATH','文件路径不合法。');
  const bytes=await readFile(file);res.writeHead(200,{'Content-Type':mime[extname(file).toLowerCase()]||'application/octet-stream','Cache-Control':extname(file)==='.html'?'no-cache':'private, max-age=3600'});res.end(req.method==='HEAD'?undefined:bytes);
 }catch(e){if(res.headersSent){if(!res.destroyed)res.end();return;}json(res,{error:{code:e.code||'EINTERNAL',message:e.code==='ENOENT'?'文件不存在。':e.message||'操作失败。'}},e.status|| (e.code==='ENOENT'?404:500));}};
}
