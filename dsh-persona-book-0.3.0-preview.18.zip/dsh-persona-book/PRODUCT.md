# 设定集／人设本

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

喜爱二次元角色、希望在 DeepSeek Harness 原会话里获得角色陪伴，同时使用模型与 Agent 工具的中文用户。

## Product Purpose

在原 DSH 聊天窗口添加自由定制的人设、语气、主题、头像、角色展示及提示音。原输入框、会话、模型、Agent、工具和工作区继续由宿主管理。设置与资源编辑使用插件面板。

## Capabilities and Constraints

- 默认鲸鱼娘外观与用户设定包一致；默认自称“人家”、称用户“主人”，节制使用“喵”。低／中／高快捷档位保持 3／6／9。
- 内置设定原稿、个人版本、五个主题与五个头像保留。更换主题或头像不改变人设与会话。
- 安卓端作为本机 DSH 的目录插件运行，不依赖电脑持续开机；不是另一个 APK 聊天应用。
- 接收使用当前角色提示音，每轮首条可见正文一次；发送使用普通短消息音。
- 更新站点保持本人私有；设备首次需安全配置后台授权。凭据不随安装包分发。
- 独立核心仍有尚未完整接入原宿主窗口的群聊、情绪、存档等能力，不把这些描述为原窗口已实现。

## Brand Commitments

蓝白鲸鱼娘：长卷渐变蓝发、单根呆毛、鲸鳍耳、鲸尾、蓝白女仆装、少量金色细节。猫咪语气不改变鲸鱼外观。入口参考 dsh-web-all／Git 图插件的尺寸和接入方式。

## Evidence on Hand

原设定：resources/original；默认设定：resources/default-persona.json；现有立绘：app/public/art/whale-welcome-v3.png。真实 DSH 隔离联测截图与报告保存在工作区 outputs。原窗口和更新使用过协议模拟器与实际私有下载验证，安卓真机尚未验收。

## Product Principles

原会话优先；角色自由定制；设置简洁；默认资源随时可恢复；状态和兼容范围如实呈现。
