# 接入示例

运行 node examples/agent-bridge.mjs，在人设本连接中选择标准 Agent，地址填 http://127.0.0.1:4411。未设置 AI_URL 时为离线示例；设置 AI_URL、AI_MODEL、AI_KEY 后桥接真实兼容模型。AGENT_TOKEN 可启用桥接认证。

把自己的 Agent 运行器接在 bridge 中的 generate 位置，输出统一 text.delta、tool.start、tool.end、image、error 事件即可。密钥只读取服务端环境变量。

ocean-theme.json 可直接从工坊本地导入。workshop-catalog.json 的 example.com 是占位地址，替换成你自己的下载地址后再作为资源源使用。
