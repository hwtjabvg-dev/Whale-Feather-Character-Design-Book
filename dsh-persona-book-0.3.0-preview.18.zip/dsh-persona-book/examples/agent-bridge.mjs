/** 标准 Agent SSE 接入示例。设置 AI_URL、AI_MODEL、AI_KEY 可桥接真实模型。 */
import {createServer} from 'node:http';
import {generate} from '../app/adapters.mjs';
const provider=process.env.AI_URL?{kind:'openai',baseUrl:process.env.AI_URL,model:process.env.AI_MODEL||'deepseek-chat',apiKey:process.env.AI_KEY||''}:{kind:'demo'};
createServer(async(req,res)=>{
 if(req.url!=='/turns'||req.method!=='POST'){res.writeHead(404);res.end();return;}
 if(process.env.AGENT_TOKEN&&req.headers.authorization!=='Bearer '+process.env.AGENT_TOKEN){res.writeHead(401);res.end();return;}
 const controller=new AbortController();res.on('close',()=>{if(!res.writableEnded)controller.abort();});
 try{let size=0;const pieces=[];for await(const chunk of req){size+=chunk.length;if(size>1024*1024)throw Error('输入过大');pieces.push(chunk);}const input=JSON.parse(Buffer.concat(pieces));if(!Array.isArray(input.messages))throw Error('缺少 messages');res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache'});const emit=e=>res.write('data: '+JSON.stringify(e)+'\n\n');
 // 可在这里替换为你自己的 Agent 运行器；执行状态转换为 tool.start 和 tool.end。
 emit({type:'tool.start',name:'回复生成',status:'正在请求'});for await(const e of generate(provider,input.messages,{signal:controller.signal}))emit(e);emit({type:'tool.end',name:'回复生成',status:'完成'});res.end();
 }catch(e){if(!res.headersSent)res.writeHead(400,{'Content-Type':'application/json'});res.end(res.getHeader('Content-Type')?.includes('event-stream')?'data: '+JSON.stringify({type:'error',message:e.message})+'\n\n':JSON.stringify({error:{message:e.message}}));}
}).listen(Number(process.env.AGENT_PORT||4411),'127.0.0.1',()=>console.log('Agent 桥接启动：在人设本添加标准 Agent，地址 http://127.0.0.1:4411；未配置 AI_URL 时为离线示例。'));
