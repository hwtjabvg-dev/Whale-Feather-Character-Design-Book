/**
 * Deck tests: the 22-slide setting-collection deck is assembled from a sheet
 * and a folder of images, and every slide must survive the trip through the
 * OOXML writer. Fixtures only — the real sheet and images stay on the machine.
 */
import { access, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import test, { after } from 'node:test';

import { SHEET_PATH, buildDeck, bulletsOf, chaptersOf, deckSpec, paletteLines } from '../lib/deck.js';
import { readZip } from '../lib/zip.js';

const sandbox = await mkdtemp(join(tmpdir(), 'persona-book-deck-'));
after(async () => {
  await rm(sandbox, { recursive: true, force: true });
});

const SHEET = [
  '# 设定集',
  '',
  '## 封面',
  '',
  '# 小鲸鲸',
  '',
  '## 01｜核心角色档案',
  '',
  '### 角色基础档案',
  '',
  '| 项目 | 内容 |',
  '|---|---|',
  '| 本名 | 小鲸鲸 |',
  '',
  '- 元气、爱帮忙',
  '- 遇到难题会认真起来',
  '',
  '## 02｜色彩与材质规范',
  '',
  '| 色名 | Hex | 用途 |',
  '|---|---|---|',
  '| 深海藏蓝 | `#182A4D` | 外裙 |',
  '| 暖金 | `#D4B673` | 刺绣 |',
  '',
  '> 金色只做信息高光',
  '',
].join('\n');

/** A 1×1 JPEG: enough for the media scanner, small enough for a fixture. */
const JPEG_BASE64 =
  '/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0a' +
  'HBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAA' +
  'AAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q==';

test('chapters are read by their number, and bullets keep the useful lines', () => {
  const chapters = chaptersOf(SHEET);
  assert.deepEqual(
    chapters.map((chapter) => `${chapter.number}｜${chapter.title}`),
    ['01｜核心角色档案', '02｜色彩与材质规范'],
  );
  const bullets = bulletsOf(chapters[0]);
  assert.equal(bullets.includes('角色基础档案'), true);
  assert.equal(bullets.includes('元气、爱帮忙'), true);
  assert.equal(
    bullets.some((line) => line.startsWith('|')),
    false,
    'table rows are not bullets',
  );
  assert.deepEqual(paletteLines(SHEET), ['深海藏蓝 #182A4D — 外裙', '暖金 #D4B673 — 刺绣']);
});

test('the deck is 22 slides: cover, contents, twelve chapters, gallery, sources', async () => {
  const sheet = join(sandbox, 'sheet.md');
  const chapters = [];
  for (let index = 0; index < 12; index += 1) {
    chapters.push(`## ${String(index + 1).padStart(2, '0')}｜第 ${index + 1} 章`, '', `- 要点 ${index + 1}`, '');
  }
  await writeFile(sheet, ['# 设定集', '', ...chapters].join('\n'), 'utf8');
  const images = [];
  for (let index = 0; index < 15; index += 1) {
    const path = join(sandbox, `page-${index + 1}.jpg`);
    await writeFile(path, Buffer.from(JPEG_BASE64, 'base64'));
    images.push(path);
  }

  const spec = await deckSpec({ sheet, images });
  assert.equal(spec.slides.length, 22);
  assert.equal(spec.slides[0].kind, 'cover');
  assert.equal(spec.slides[1].kind, 'bullets');
  assert.equal(spec.slides[2].kind, 'section');
  assert.equal(spec.slides.filter((slide) => slide.kind === 'gallery').length, 5);
  assert.equal(spec.slides.filter((slide) => slide.kind === 'bullets').length, 15);
  assert.equal(spec.slides[21].title, '这份幻灯片是怎么来的');
});

/** Twelve chapters and fifteen page images: the shape of the real sheet. */
async function fullFixture() {
  const sheet = join(sandbox, 'full.md');
  const chapters = [];
  for (let index = 0; index < 12; index += 1) {
    chapters.push(`## ${String(index + 1).padStart(2, '0')}｜第 ${index + 1} 章`, '', `- 要点 ${index + 1}`, '');
  }
  await writeFile(sheet, ['# 设定集', '', ...chapters].join('\n'), 'utf8');
  const images = [];
  for (let index = 0; index < 15; index += 1) {
    const path = join(sandbox, `full-${index + 1}.jpg`);
    await writeFile(path, Buffer.from(JPEG_BASE64, 'base64'));
    images.push(path);
  }
  return { sheet, images };
}

test('the built deck is a real pptx: 22 slides, media embedded, deterministic', async () => {
  const { sheet, images } = await fullFixture();
  const { spec, data } = await buildDeck({ sheet, images, createdAt: '2025-01-01T00:00:00Z' });
  assert.equal(spec.slides.length, 22);
  const entries = readZip(data);
  assert.notEqual(entries, null);
  const names = entries.map((entry) => entry.name);
  assert.equal(names.filter((name) => /^ppt\/slides\/slide\d+\.xml$/.test(name)).length, 22);
  assert.equal(names.includes('ppt/presentation.xml'), true);
  assert.equal(names.includes('[Content_Types].xml'), true);
  const media = entries.filter((entry) => entry.name.startsWith('ppt/media/'));
  assert.equal(media.length, 15, 'every page image is embedded');
  assert.equal(media[0].data.equals(Buffer.from(JPEG_BASE64, 'base64')), true, 'bytes are not re-encoded');

  const again = await buildDeck({ sheet, images, createdAt: '2025-01-01T00:00:00Z' });
  assert.equal(Buffer.compare(data, again.data), 0, 'two builds are byte identical');
});

test('fewer chapters and no images still make an openable deck', async () => {
  const { data, spec } = await buildDeck({ sheet: join(sandbox, 'nope.md'), images: [], createdAt: '2025-01-01T00:00:00Z' });
  assert.equal(spec.slides.filter((slide) => slide.kind === 'gallery').length, 0);
  assert.equal(spec.slides.length >= 5, true);
  const names = readZip(data).map((entry) => entry.name);
  assert.equal(names.filter((name) => /^ppt\/slides\/slide\d+\.xml$/.test(name)).length, spec.slides.length);
});

test('the real setting collection on this machine makes exactly 22 pages', async (t) => {
  if (!(await access(SHEET_PATH).then(() => true, () => false))) {
    t.skip('the transcript is not on this machine');
    return;
  }
  const spec = await deckSpec();
  assert.equal(spec.slides.length, 22);
  assert.equal(spec.slides[1].bullets.length, 12, 'the contents list the twelve chapters');
  assert.equal(spec.slides.filter((slide) => slide.kind === 'gallery').length, 5);
});
