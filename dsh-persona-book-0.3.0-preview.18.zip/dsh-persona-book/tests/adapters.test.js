import test,{after} from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {generate,generateImage,streamJson,registerTextAdapter} from '../app/adapters.mjs';
import {PersonaService} from '../app/service.mjs';
const requests=[];const image=await readFile(new URL('./fixtures/formats/avatar.png',import.meta.url));
const server=createServer(async(req,res)=>{let text='';for await(const c of req)text+=c;let body={};try{body=JSON.parse(text);}catch{}requests.push({path:req.url,body,key:req.headers.authorization});
 const json=value=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify(value));};
 if(req.url==='/v1/chat/completions'){res.setHeader('Content-Type','text/event-stream');const bytes=Buffer.from('data: '+JSON.stringify({choices:[{delta:{content:'你好，主人'}}]})+'\n\ndata: [DONE]\n\n');res.write(bytes.subarray(0,50));res.end(bytes.subarray(50));}
 else if(req.url==='/ollama/api/chat'){res.setHeader('Content-Type','application/x-ndjson');res.end(JSON.stringify({message:{content:'本地模型连接成功'}})+'\n'+JSON.stringify({done:true})+'\n');}
 else if(req.url==='/agent/turns'){res.setHeader('Content-Type','text/event-stream');for(const e of [{type:'tool.start',name:'检索',status:'运行中'},{type:'text.delta',text:'Agent 完成'},{type:'tool.end',name:'检索',status:'已完成'}])res.write('data: '+JSON.stringify(e)+'\n\n');res.end();}
 else if(req.url==='/json/chat/completions')json({choices:[{message:{content:'非流式连接成功'}}]});
 else if(req.url==='/bad/chat/completions'){res.writeHead(401);res.end('bad key sk-hidden-secret');}
 else if(req.url==='/v1/images/generations')json({data:[{b64_json:image.toString('base64')}]});
 else if(req.url==='/comfy/prompt')json({prompt_id:'job-1'});
 else if(req.url==='/comfy/history/job-1')json({'job-1':{outputs:{9:{images:[{filename:'a.png',subfolder:'',type:'output'}]}}}});
 else if(req.url.startsWith('/comfy/view')){res.setHeader('Content-Type','image/png');res.end(image);}
 else{res.writeHead(404);res.end();}
});await new Promise(r=>server.listen(0,'127.0.0.1',r));const root='http://127.0.0.1:'+server.address().port;after(()=>new Promise(r=>server.close(r)));
for(const[kind,route,expected]of [['openai','v1','你好，主人'],['ollama','ollama','本地模型连接成功'],['agent','agent','Agent 完成'],['openai','json','非流式连接成功']])test('协议集成 '+kind+' '+route,async()=>{const events=[];for await(const e of generate({kind,baseUrl:root+'/'+route,model:'test',apiKey:'secret'},[{role:'user',content:'测试'}]))events.push(e);assert.equal(events.filter(e=>e.type==='text.delta').map(e=>e.text).join(''),expected);assert.equal(requests.at(-1).body.messages[0].content,'测试');assert.equal(requests.at(-1).key,'Bearer secret');if(kind==='agent')assert.ok(events.some(e=>e.type==='tool.start'));});
test('接口错误与密钥脱敏',async()=>{await assert.rejects(async()=>{for await(const e of generate({kind:'openai',baseUrl:root+'/bad',model:'test'},[])){}},e=>e.message.includes('401')&&!e.message.includes('sk-hidden-secret'));});
test('图片生成兼容接口与 ComfyUI API 工作流',async()=>{const a=await generateImage({kind:'openai',baseUrl:root+'/v1',model:'test'},'鲸鱼娘');assert.deepEqual(a.data,image);const b=await generateImage({kind:'comfyui',baseUrl:root+'/comfy',promptNode:'6',workflow:{6:{inputs:{text:'old'}}}},'蓝白鲸鱼娘');assert.deepEqual(b.data,image);assert.equal(requests.find(x=>x.path==='/comfy/prompt').body.prompt['6'].inputs.text,'蓝白鲸鱼娘');});
test('自然语言自拍生成图像 写入聊天和图库 重命名与删除',async()=>{const dir=await mkdtemp(join(tmpdir(),'pb-img-'));const s=await new PersonaService(dir).open();try{await s.action({action:'imageConnection',connection:{enabled:true,kind:'openai',baseUrl:root+'/v1',model:'test'}});const ev=[];await s.turn({conversationId:'welcome',text:'发一张自拍'},e=>ev.push(e));assert.ok(ev.some(e=>e.type==='image'));assert.equal(s.store.state.galleries.length,1);assert.ok(s.store.state.conversations[0].messages.at(-1).image);const id=s.store.state.galleries[0].id;await s.action({action:'gallery',id,title:'改名'});assert.equal(s.store.state.galleries[0].title,'改名');await s.action({action:'gallery',id,operation:'delete'});assert.equal(s.store.state.galleries.length,0);}finally{s.close();await rm(dir,{recursive:true,force:true});}});
test('自定义适配器扩展与清理',async()=>{const off=registerTextAdapter('custom',async function*(){yield{type:'text.delta',text:'自定义适配成功'};});const ev=[];for await(const e of generate({kind:'custom'},[]))ev.push(e);assert.equal(ev[0].text,'自定义适配成功');off();});
test('SSE UTF8 分包和未带换行的最终事件',async()=>{const bytes=Buffer.from('data: {"text":"小鲸鲸"}\n\ndata: {"done":true}');const stream=new ReadableStream({start(c){c.enqueue(bytes.subarray(0,18));c.enqueue(bytes.subarray(18));c.close();}}),out=[];for await(const e of streamJson(new Response(stream,{headers:{'Content-Type':'text/event-stream'}})))out.push(e);assert.equal(out[0].text,'小鲸鲸');assert.equal(out[1].done,true);});
