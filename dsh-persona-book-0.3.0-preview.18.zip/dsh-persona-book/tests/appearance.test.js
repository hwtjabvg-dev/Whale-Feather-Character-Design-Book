/**
 * 外观引擎测试：静态皮肤的红线（零 hex / 零强制覆盖 / 全 :where() / 只用官方锚点与令牌）、
 * 变量块的确定性与夹取、整页主题与气泡形状 / 材质、对比度与透明合成算法。
 * 全是纯函数，不碰磁盘、不碰浏览器。
 */
import assert from 'node:assert/strict';
import test from 'node:test';

import {
  AVATAR_SHAPES,
  BUBBLE_MATERIALS,
  BUBBLE_SHAPES,
  BUBBLE_THEMES,
  DEFAULT_BUBBLE_MATERIAL,
  DEFAULT_BUBBLE_SHAPE,
  SHAPES,
  SKIN_ATTR,
  SKIN_CSS,
  THEMES,
  WALLPAPER_FITS,
  WALLPAPER_SCENES,
  analyzeContrast,
  clampAppearance,
  composite,
  contrastRatio,
  renderThemeCss,
} from '../lib/appearance.js';
import { DEFAULT_PROFILES, MATERIAL_PRESETS } from '../lib/constants.js';

/** 拆 CSS 花括号：顶层规则收进 rules，@media/@supports 递归进去，@keyframes 整块跳过。 */
function collectRules(css, out = []) {
  const text = css.replace(/\/\*[\s\S]*?\*\//g, '');
  let buffer = '';
  let index = 0;
  while (index < text.length) {
    const char = text[index];
    if (char === '{') {
      const header = buffer.trim();
      buffer = '';
      let depth = 1;
      let cursor = index + 1;
      while (cursor < text.length && depth > 0) {
        if (text[cursor] === '{') depth += 1;
        else if (text[cursor] === '}') depth -= 1;
        cursor += 1;
      }
      const body = text.slice(index + 1, cursor - 1);
      if (header.startsWith('@')) {
        if (!/^@(keyframes|font-face)/.test(header)) collectRules(body, out);
      } else {
        out.push({ selector: header, body });
      }
      index = cursor;
      continue;
    }
    if (char === '}') buffer = '';
    else buffer += char;
    index += 1;
  }
  return out;
}

/** 列出所有 var() 里没给 fallback 的调用。 */
function bareVarCalls(css) {
  const bare = [];
  const pattern = /var\(/g;
  let match = pattern.exec(css);
  while (match !== null) {
    let depth = 1;
    let cursor = match.index + 4;
    let sawFallback = false;
    while (cursor < css.length && depth > 0) {
      const char = css[cursor];
      if (char === '(') depth += 1;
      else if (char === ')') depth -= 1;
      else if (char === ',' && depth === 1) sawFallback = true;
      cursor += 1;
    }
    if (!sawFallback) bare.push(css.slice(match.index, cursor));
    match = pattern.exec(css);
  }
  return bare;
}

/** 把 prelude 里带 in oklab 的 @supports 整块挖掉，剩下的文本里不该再有 oklab。 */
function withoutOklabSupports(css) {
  let out = '';
  let index = 0;
  while (index < css.length) {
    const at = css.indexOf('@supports', index);
    if (at === -1) {
      out += css.slice(index);
      break;
    }
    const brace = css.indexOf('{', at);
    if (brace === -1) {
      out += css.slice(index);
      break;
    }
    let depth = 1;
    let cursor = brace + 1;
    while (cursor < css.length && depth > 0) {
      if (css[cursor] === '{') depth += 1;
      else if (css[cursor] === '}') depth -= 1;
      cursor += 1;
    }
    out += css.slice(index, at);
    if (!css.slice(at, brace).includes('in oklab')) out += css.slice(at, cursor);
    index = cursor;
  }
  return out;
}

const RULES = collectRules(SKIN_CSS);

/** 声明体拆成 name/value，忽略空段。 */
const declarations = (body) =>
  body
    .split(';')
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part) => {
      const colon = part.indexOf(':');
      return { name: part.slice(0, colon).trim().toLowerCase(), value: part.slice(colon + 1).trim() };
    });

const OFFICIAL_ANCHORS = [
  'data-chat-flow-kind',
  'data-chat-turn',
  'data-chat-group-part',
  'data-turn-process',
  'data-step-process',
  'data-turn-tail',
  'data-actions-reveal',
  'data-streaming',
];
const OWN_ANCHORS = [
  'data-pb-skin',
  'data-pb-bubble',
  'data-pb-material',
  'data-pb-theme',
  'data-pb-bg',
  'data-pb-labels',
  'data-pb-tail',
  'data-pb-avatar',
  'data-pb-safe',
  'data-pb-label',
  'data-pb-panel',
  'data-pb-accent',
  'data-pb-wallpaper',
  'data-pb-wallpaper-kind',
];
const ALLOWED_TOKENS = [
  '--dsw-alias-bg-base',
  '--dsw-alias-bg-layer-1',
  '--dsw-alias-border-l1',
  '--dsw-alias-border-l2',
  '--dsw-alias-border-l3',
  '--dsw-alias-border-l4',
  '--dsw-alias-label-primary',
  '--dsw-alias-label-secondary',
  '--dsw-alias-label-tertiary',
  '--dsw-alias-markdown-code-block',
  '--dsw-alias-separator-primary',
  '--dsw-specific-bubble',
  '--dsw-radius-lg',
  '--dsw-radius-xl',
  '--dsw-elevation-panel',
  '--dsh-chat-content-width',
  '--dsh-chat-flow-gap',
  '--dsh-content-font-size',
];

/* ------------------------------------------------------------- 静态皮肤 */

test('SKIN_CSS 里一个 hex 色值都没有', () => {
  const hex = SKIN_CSS.match(/#[0-9a-fA-F]{3,8}(?![0-9a-zA-Z_-])/g) ?? [];
  assert.deepEqual(hex, [], `皮肤里混进了字面色值：${hex.join(', ')}`);
});

test('SKIN_CSS 不用强制覆盖，也不用 color-mix()', () => {
  assert.equal(SKIN_CSS.includes('!important'), false);
  assert.equal(SKIN_CSS.includes('color-mix('), false);
});

test('除整站配色外，皮肤规则都套在 :where() 里（零特异度）', () => {
  assert.ok(RULES.length > 20, `规则太少（${RULES.length}），解析或皮肤可能坏了`);
  const naked = RULES.filter((rule) => !rule.selector.includes(':where('))
    .filter((rule) => !rule.selector.startsWith("html[data-pb-skin='on']"))
    .map((rule) => rule.selector);
  assert.deepEqual(naked, [], `这些选择器没压特异度：${naked.join(' | ')}`);
});

test('选择器里没有构建哈希类名（点号与井号一律不出现）', () => {
  const classes = RULES.filter((rule) => /[.#]/.test(rule.selector)).map((rule) => rule.selector);
  assert.deepEqual(classes, []);
});

test('只吃白名单里的官方 data-* 锚点', () => {
  const allowed = new Set([...OFFICIAL_ANCHORS, ...OWN_ANCHORS]);
  const used = new Set();
  for (const rule of RULES) {
    for (const match of rule.selector.matchAll(/\[([a-z-]+)/g)) used.add(match[1]);
  }
  assert.ok(used.size >= 8);
  const unknown = [...used].filter((name) => !allowed.has(name));
  assert.deepEqual(unknown, [], `用到了未登记的锚点：${unknown.join(', ')}`);
});

test('只吃白名单里的官方令牌', () => {
  const allowed = new Set(ALLOWED_TOKENS);
  const used = new Set(SKIN_CSS.match(/--d(?:sw|sh)-[a-z0-9-]+/g) ?? []);
  assert.ok(used.size >= 8);
  const unknown = [...used].filter((name) => !allowed.has(name));
  assert.deepEqual(unknown, [], `用到了未登记的令牌：${unknown.join(', ')}`);
});

test('每个 var() 都给了 fallback，皮肤关掉也不会崩', () => {
  assert.deepEqual(bareVarCalls(SKIN_CSS), []);
});

test('每个 in oklab 都被 @supports 包住', () => {
  assert.ok(SKIN_CSS.includes('in oklab'), '至少要有一次 oklab 插值才谈得上守门');
  const rest = withoutOklabSupports(SKIN_CSS);
  assert.equal(rest.includes('in oklab'), false, '有裸的 in oklab，Chrome <=110 会让整条渐变消失');
  assert.ok(SKIN_CSS.includes('@supports (background: linear-gradient(in oklab, red, blue))'));
});

test('含 @supports not (backdrop-filter) 的降级分支', () => {
  assert.ok(SKIN_CSS.includes('@supports not (backdrop-filter: blur(1px))'));
});

test('四个 @media 降级都在', () => {
  for (const query of [
    '(prefers-reduced-transparency: reduce)',
    '(prefers-contrast: more)',
    '(prefers-reduced-motion: reduce)',
    '(pointer: coarse)',
  ]) {
    assert.ok(SKIN_CSS.includes(`@media ${query}`), `缺 ${query}`);
  }
});

test('玻璃只画在 ::before，容器上不放 backdrop-filter', () => {
  const offenders = [];
  for (const rule of RULES) {
    for (const entry of declarations(rule.body)) {
      if (!entry.name.endsWith('backdrop-filter')) continue;
      if (entry.value === 'none') continue;
      if (!rule.selector.endsWith('::before')) offenders.push(rule.selector);
    }
  }
  assert.deepEqual(offenders, [], `这些规则把滤镜放在了非 ::before 的元素上：${offenders.join(' | ')}`);
});

test('颗粒 data URI 不到 400 字节，且带 overlay 混合', () => {
  const match = SKIN_CSS.match(/url\("(data:image\/svg\+xml,[^"]+)"\)/);
  assert.ok(match, '找不到内联颗粒 data URI');
  assert.ok(match[1].length < 400, `颗粒 data URI ${match[1].length} 字节，超了 400`);
  assert.ok(match[1].includes('feTurbulence'));
  assert.ok(SKIN_CSS.includes('background-blend-mode: overlay'));
});

test('过程收起只压在过程锚点上，不碰正文与答案', () => {
  const collapse = RULES.filter((rule) => rule.body.includes('max-block-size'));
  assert.ok(collapse.length >= 2);
  for (const rule of collapse) {
    assert.ok(/data-(step|turn)-process/.test(rule.selector), rule.selector);
    assert.equal(/data-chat-flow-kind/.test(rule.selector), false, `不能收起消息本体：${rule.selector}`);
  }
});

/* --------------------------------------------------------------- 主题表 */

test('三套整页主题都在皮肤里有对应选择器，跟随系统另外镜像一段暗色', () => {
  assert.deepEqual(Object.keys(THEMES), ['deepsea', 'light', 'system']);
  for (const id of Object.keys(THEMES)) {
    assert.ok(SKIN_CSS.includes(`:where([data-pb-theme='${id}'])`), `缺主题选择器 ${id}`);
  }
  assert.ok(SKIN_CSS.includes('@media (prefers-color-scheme: dark)'), '跟随系统要有暗色镜像');
  // 气泡配色表照旧独立成套，面板的主题选择器还是从它渲染。
  assert.deepEqual(Object.keys(BUBBLE_THEMES), ['wechat', 'qq', 'deep', 'paper']);
});

test('主题表按计划给足字段', () => {
  for (const [id, theme] of Object.entries(THEMES)) {
    assert.equal(theme.id, id);
    assert.equal(typeof theme.label, 'string');
    assert.ok(theme.label.length > 0);
    assert.ok(theme.nameZh.length > 0, `${id} 缺中文名`);
    assert.ok(/^[A-Za-z][A-Za-z ]*$/.test(theme.nameEn), `${id} 的英文名不像英文`);
    for (const key of ['pageBg', 'pageFg', 'card', 'cardFg', 'accent', 'border']) {
      assert.match(theme[key], /^#[0-9A-F]{6}([0-9A-F]{2})?$/i, `${id}.${key} 不是 hex`);
    }
  }
  assert.deepEqual(Object.keys(THEMES.system.dark).sort(), ['accent', 'border', 'card', 'cardFg', 'pageBg', 'pageFg']);
  for (const key of ['pageBg', 'pageFg', 'card', 'cardFg', 'accent', 'border']) {
    assert.match(THEMES.system.dark[key], /^#[0-9A-F]{6}([0-9A-F]{2})?$/i, `system.dark.${key} 不是 hex`);
  }
  for (const [id, theme] of Object.entries(BUBBLE_THEMES)) {
    assert.equal(theme.id, id);
    assert.ok(theme.label.length > 0);
    for (const key of ['mine', 'mineText', 'theirs', 'theirsText', 'accent']) {
      assert.match(theme[key], /^#[0-9A-F]{6}$/i, `${id}.${key} 不是 6 位 hex`);
    }
    assert.match(theme.panelTint, /^rgba\(/);
  }
  assert.equal(BUBBLE_THEMES.wechat.mine, '#95EC69');
  assert.equal(BUBBLE_THEMES.qq.accent, '#12B7F5');
  assert.equal(BUBBLE_THEMES.deep.mine, '#335C8D');
  assert.equal(BUBBLE_THEMES.paper.mine, '#F1E7D6');
});

test('SKIN_ATTR 是皮肤总开关的属性名', () => {
  assert.equal(SKIN_ATTR, 'data-pb-skin');
  assert.ok(SKIN_CSS.includes(':where([data-pb-skin='));
});

/* ------------------------------------------- 气泡形状 / 气泡材质 */

test('三种气泡形状齐全，圆角 / 方角 / 无气泡各就各位', () => {
  assert.deepEqual(Object.keys(BUBBLE_SHAPES), ['round', 'square', 'none']);
  assert.equal(BUBBLE_SHAPES.round.label, '圆角气泡');
  assert.equal(BUBBLE_SHAPES.square.label, '方角气泡');
  assert.equal(BUBBLE_SHAPES.none.label, '无气泡');
  assert.equal(BUBBLE_SHAPES.round.radiusPx, SHAPES.radius.fallback);
  assert.equal(BUBBLE_SHAPES.square.radiusPx, 0);
  assert.equal(BUBBLE_SHAPES.none.radiusPx, 0);
  assert.equal(BUBBLE_SHAPES.round.tail, true);
  assert.equal(BUBBLE_SHAPES.square.tail, true);
  assert.equal(BUBBLE_SHAPES.none.tail, false);
  for (const [id, shape] of Object.entries(BUBBLE_SHAPES)) {
    assert.equal(shape.id, id);
    assert.equal(typeof shape.radiusPx, 'number');
  }
  assert.equal(DEFAULT_BUBBLE_SHAPE, 'round');
});

test('三种气泡材质齐全，默认是透明玻璃', () => {
  assert.deepEqual(Object.keys(BUBBLE_MATERIALS), ['transparent', 'glass', 'solid']);
  assert.equal(DEFAULT_BUBBLE_MATERIAL, 'transparent');
  assert.equal(DEFAULT_PROFILES.ui.appearance.bubble.material, 'transparent');
  assert.equal(DEFAULT_PROFILES.ui.appearance.bubble.shape, 'round');
  for (const [id, material] of Object.entries(BUBBLE_MATERIALS)) {
    assert.equal(material.id, id);
    assert.ok(material.label.length > 0);
    assert.equal(typeof material.border, 'string');
    assert.equal(typeof material.shadow, 'string');
  }
  // 透明档：极细描边 + 柔和阴影，没有实心底色。
  assert.match(BUBBLE_MATERIALS.transparent.border, /^0\.5px solid /);
  assert.equal(BUBBLE_MATERIALS.transparent.mineFill, 'transparent');
  assert.equal(BUBBLE_MATERIALS.transparent.theirsFill, 'transparent');
  assert.match(BUBBLE_MATERIALS.transparent.shadow, /^0 \d+px \d+px /);
  // 实心档才给不透明底色。
  assert.equal(BUBBLE_MATERIALS.solid.border, '0');
  assert.match(BUBBLE_MATERIALS.solid.mineFill, /var\(--pb-mine-bg,/);
});

test('形状与材质都是整体枚举，外观只认这四块', () => {
  assert.deepEqual(Object.keys(AVATAR_SHAPES), ['circle', 'rounded', 'square']);
  assert.deepEqual(Object.keys(WALLPAPER_FITS), ['cover', 'contain', 'tile']);
  assert.deepEqual(Object.keys(DEFAULT_PROFILES.ui.appearance), ['theme', 'bubble', 'avatar', 'wallpaper']);
});

test('SHAPES 数值域与计划一致', () => {
  assert.deepEqual([SHAPES.radius.min, SHAPES.radius.max], [0, 24]);
  assert.deepEqual([SHAPES.widthPct.min, SHAPES.widthPct.max], [40, 92]);
  assert.deepEqual(SHAPES.avatarSizes, [20, 24, 28, 32, 40]);
  assert.ok(SHAPES.gap.max > SHAPES.gap.min);
});

/* ------------------------------------------------------------- 变量块 */

test('renderThemeCss 以 SKIN_CSS 开头，再接一段 :root 变量块', () => {
  const css = renderThemeCss(DEFAULT_PROFILES.ui);
  assert.ok(css.startsWith(SKIN_CSS));
  assert.ok(css.includes('\n:root {'));
  const block = css.slice(css.indexOf('\n:root {'));
  for (const name of ['--pb-bub-r', '--pb-bub-max', '--pb-bub-gap', '--pb-tint', '--pb-shadow', '--pb-panel-r', '--pb-page-bg']) {
    assert.ok(block.includes(`${name}:`), `变量块缺 ${name}`);
  }
});

test('renderThemeCss 输出的变量名与客户端契约完全一致', () => {
  const css = renderThemeCss(DEFAULT_PROFILES.ui);
  const block = css.slice(css.indexOf('\n:root {'));
  const names = [...new Set(block.match(/--pb-(?!wall-)[a-z0-9-]+/g) ?? [])].sort();
  assert.deepEqual(names, [
    '--pb-accent',
    '--pb-avatar-user',
    '--pb-bg-blur',
    '--pb-bg-dim',
    '--pb-bg-grain',
    '--pb-border',
    '--pb-bub-avatar',
    '--pb-bub-gap',
    '--pb-bub-max',
    '--pb-bub-r',
    '--pb-card',
    '--pb-card-fg',
    '--pb-mat-blur',
    '--pb-mat-bri',
    '--pb-mat-op',
    '--pb-mat-sat',
    '--pb-mine-bg',
    '--pb-mine-fg',
    '--pb-noise',
    '--pb-page-bg',
    '--pb-page-fg',
    '--pb-panel-r',
    '--pb-panel-tint',
    '--pb-shadow',
    '--pb-spec',
    '--pb-theirs-bg',
    '--pb-theirs-fg',
    '--pb-tint',
    '--pb-tint-a',
  ]);
  // The wallpaper scenes ride along as variables, one per builtin.
  const walls = [...new Set(block.match(/--pb-wall-[a-z-]+/g) ?? [])].sort();
  assert.deepEqual(walls, [
    '--pb-wall-aurora',
    '--pb-wall-bubbles',
    '--pb-wall-coral-warm',
    '--pb-wall-deep-grid',
    '--pb-wall-deep-light',
    '--pb-wall-moon-sea',
    '--pb-wall-sea-glints',
    '--pb-wall-whale-fall',
  ]);
});

test('整站配色规则把主题摊到页面 / 卡片 / 边框，且全程零特异度', () => {
  const css = renderThemeCss({ appearance: { theme: 'light' } });
  const block = css.slice(css.indexOf('\n:root {'));
  assert.match(block, /--pb-page-bg: rgb\(245 247 251\);/);
  assert.match(block, /--pb-card: rgb\(255 255 255\);/);
  const deep = renderThemeCss({ appearance: { theme: 'deepsea' } });
  assert.match(deep.slice(deep.indexOf('\n:root {')), /--pb-page-bg: rgb\(10 22 38\);/);
  // 跟随系统：除了根变量，再镜像一段暗色。
  const sys = renderThemeCss({ appearance: { theme: 'system' } });
  assert.ok(sys.includes('@media (prefers-color-scheme: dark)'), '跟随系统要有暗色镜像');
  assert.match(sys, /--pb-page-bg: rgb\(11 18 32\);/);
  // 整站规则：body 与面板一起换色。宿主把 --dsw-alias-* 挂在 body{}（0,0,1），
  // 零特异度会输，所以这里刻意用 html[data-pb-skin='on'] 前缀（0,1,2），但绝不写 !important。
  const from = css.indexOf('⑨ 整站配色');
  const until = css.indexOf('/*', from + 1);
  const shop = until === -1 ? css.slice(from) : css.slice(from, until);
  assert.ok(shop.includes("html[data-pb-skin='on'] body"), '整站规则要落在 body 上');
  assert.ok(shop.includes("html[data-pb-skin='on'] [data-pb-panel]"), '面板也要跟着换');
  for (const line of shop.split('\n').filter((l) => l.includes('{'))) {
    assert.ok(line.startsWith("html[data-pb-skin='on']"), `整站规则要限定在插件皮肤打开时：${line}`);
  }
  assert.equal(/[.#][A-Za-z]/.test(shop), false, '整站规则里不许出现类名 / id 选择器');
  assert.equal(shop.includes('!important'), false);
  for (const token of ['--dsw-alias-bg-base', '--dsw-alias-label-primary', '--dsw-alias-border-l4']) {
    assert.ok(shop.includes(token), `整站配色没有交代 ${token}`);
  }
});

test('气泡规则只作用气泡本身，收口在 [data-pb-bubble=on]', () => {
  const css = renderThemeCss({ bubble: { on: true }, appearance: { bubble: { material: 'transparent', shape: 'round' } } });
  const tail = css.slice(css.indexOf('气泡形状 / 材质'));
  assert.ok(tail.length > 0, '要有单独一段气泡规则');
  for (const line of tail.split('\n').filter((l) => l.includes('{'))) {
    assert.ok(line.includes("data-pb-bubble='on'"), `气泡规则漏出闸门：${line}`);
  }
  // 三种形状各给不同的圆角结论。
  const radius = (shape) => {
    const out = renderThemeCss({ appearance: { bubble: { shape } } });
    return /--pb-bub-r: (\d+)px;/.exec(out.slice(out.indexOf('\n:root {')))[1];
  };
  assert.equal(radius('round'), String(SHAPES.radius.fallback));
  assert.equal(radius('square'), '0');
  assert.equal(radius('none'), '0');
  const none = renderThemeCss({ appearance: { bubble: { shape: 'none' } } });
  assert.ok(none.includes('border-radius: 0;'));
  assert.ok(none.includes('box-shadow: none;'));
  assert.ok(none.includes('display: none;'), '无气泡要把尾巴收掉');
  const round = renderThemeCss({ appearance: { bubble: { shape: 'round' } } });
  assert.equal(round.includes('--pb-bub-r: 18px;'), true);
  assert.ok(round.includes("border-inline-start: 6px solid var(--pb-mine-bg"), '圆角气泡要留尾巴');
});

test('三种材质的描边 / 阴影 / 底色各按档位出', () => {
  const tail = (material) => {
    const css = renderThemeCss({ appearance: { bubble: { material } } });
    return css.slice(css.indexOf('气泡形状 / 材质'));
  };
  const pick = (material, needle) => tail(material).includes(needle);
  assert.ok(pick('transparent', '0.5px solid var(--pb-border, rgb(140 160 190 / 0.32))'), '透明档给极细描边');
  assert.ok(pick('transparent', '0 2px 10px rgb(12 24 44 / 0.12)'), '透明档给柔和阴影');
  assert.ok(pick('glass', '0 8px 32px rgb(12 24 44 / 0.22)'), '磨砂档给更重的浮影');
  assert.ok(pick('solid', 'background-color: var(--pb-mine-bg, rgba(149, 236, 105, 0.94));'), '实心档给不透明底色');
  assert.ok(pick('transparent', 'background-color: transparent;'), '透明档没有实心底色');
  assert.ok(pick('transparent', "assistant-step'])::before"), '透明档要把对方气泡那层玻璃底抹掉');
  assert.equal(pick('glass', "assistant-step'])::before"), false, '磨砂档保留玻璃层，不抹底');
  assert.equal(pick('solid', '0.5px solid'), false, '实心档不带描边');
});


test('每个内置场景都能从样式表里解析出来，面板拿到的是同一份', () => {
  assert.deepEqual(Object.keys(WALLPAPER_SCENES).sort(), [
    'aurora',
    'bubbles',
    'coral-warm',
    'deep-grid',
    'deep-light',
    'moon-sea',
    'sea-glints',
    'whale-fall',
  ]);
  for (const [id, scene] of Object.entries(WALLPAPER_SCENES)) {
    assert.ok(scene.includes('gradient('), `${id} 应该是一串渐变`);
    assert.ok(scene.length > 60, `${id} 的场景太短，可能解析断了`);
    assert.ok(!scene.includes('}'), `${id} 的场景里混进了 CSS 结构`);
  }
  // And the stylesheet really paints them from the same text (whitespace
  // aside: the extractor folds newlines, the sheet keeps them).
  const flat = SKIN_CSS.replace(/\s+/g, ' ');
  for (const [id, scene] of Object.entries(WALLPAPER_SCENES)) {
    assert.ok(flat.includes(scene), `${id} 的场景在样式表里找不到同一份文本`);
  }
  const css = renderThemeCss({});
  assert.ok(css.includes(`--pb-wall-deep-light: ${WALLPAPER_SCENES['deep-light']};`), '变量里放的就是场景本身');
});

test('renderThemeCss 是确定性的，同一份输入字节完全相同', () => {
  const input = { bubble: { style: 'qq', shape: { cornerRadius: 11 } }, material: { kind: 'liquid' } };
  const once = renderThemeCss(input);
  const twice = renderThemeCss(structuredClone(input));
  assert.equal(once, twice);
  assert.equal(Buffer.byteLength(once), Buffer.byteLength(twice));
});

test('renderThemeCss 把越界输入夹进合法域', () => {
  const css = renderThemeCss({
    bubble: { shape: { cornerRadius: 999, maxWidthPct: -20, gap: 1e9 } },
    appearance: { wallpaper: { dim: 500, blur: -3, grain: 9 } },
    material: { blurPx: 9999, saturatePct: 10, brightnessPct: 999, noise: 5, opacity: -4, tint: { rgb: [999, -5, 300], a: 7 } },
  });
  const block = css.slice(css.indexOf('\n:root {'));
  assert.ok(block.includes('--pb-bub-r: 24px;'));
  assert.ok(block.includes('--pb-bub-max: 40%;'));
  assert.ok(block.includes('--pb-bub-gap: 32px;'));
  assert.ok(block.includes('--pb-mat-blur: 60px;'));
  assert.ok(block.includes('--pb-mat-sat: 100%;'));
  assert.ok(block.includes('--pb-mat-bri: 140%;'));
  assert.ok(block.includes('--pb-noise: 0.4;'));
  assert.ok(block.includes('--pb-mat-op: 0;'));
  assert.ok(block.includes('--pb-tint: 255 0 255;'));
  assert.ok(block.includes('--pb-tint-a: 1;'));
  assert.ok(block.includes('--pb-bg-dim: 0.6;'));
  assert.ok(block.includes('--pb-bg-blur: 0px;'));
  assert.ok(block.includes('--pb-bg-grain: 0.4;'));
});

test('renderThemeCss 的主题与强调色跟随状态', () => {
  const qq = renderThemeCss({ bubble: { style: 'qq' } });
  assert.match(qq, /--pb-mine-bg: #0099FF;/);
  assert.match(qq, /--pb-theirs-fg: #1A1A1A;/);
  assert.match(qq, /--pb-accent: #12B7F5;/, '没有自定义时强调色跟气泡配色走');
  const manual = renderThemeCss({
    bubble: { style: 'custom', colors: { mine: '#123456', mineText: '#FFFFFF', accent: '#ABCDEF' } },
  });
  assert.match(manual, /--pb-mine-bg: #123456;/);
  assert.match(manual, /--pb-accent: #ABCDEF;/);
  // 整页主题与气泡配色是两条线，互不干扰。
  const themed = renderThemeCss({ bubble: { style: 'qq' }, appearance: { theme: 'light' } });
  assert.match(themed, /--pb-mine-bg: #0099FF;/);
  assert.match(themed, /--pb-page-bg: rgb\(245 247 251\);/);
});

test('renderThemeCss 把自定义头像接进变量，没图就写 none', () => {
  assert.match(renderThemeCss({ avatar: { user: { assetId: 'a1b2-cat' } } }), /--pb-avatar-user: url\('\/api\/persona-book\/assets\/a1b2-cat\/preview'\);/);
  assert.match(renderThemeCss({}), /--pb-avatar-user: none;/);
});

/* ------------------------------------------------------------- 归一化 */

test('clampAppearance 永远返回 bubble / appearance / material 三块加 problem 清单', () => {
  for (const input of [undefined, null, 'nope', 42, {}, { bubble: 'x', appearance: [], material: 0 }]) {
    const state = clampAppearance(input);
    assert.deepEqual(Object.keys(state), ['bubble', 'appearance', 'material', 'problems']);
    assert.equal(typeof state.bubble.shape.cornerRadius, 'number');
    assert.equal(typeof state.material.opacity, 'number');
    assert.deepEqual(state.problems, [], '残缺输入不该报错');
  }
});

test('clampAppearance 对残缺输入回落到 DEFAULT_PROFILES.ui', () => {
  const state = clampAppearance({});
  assert.equal(state.bubble.style, DEFAULT_PROFILES.ui.bubble.style);
  assert.equal(state.appearance.theme, DEFAULT_PROFILES.ui.appearance.theme);
  assert.deepEqual(state.appearance.bubble, DEFAULT_PROFILES.ui.appearance.bubble);
  assert.deepEqual(state.appearance.avatar, DEFAULT_PROFILES.ui.appearance.avatar);
  assert.deepEqual(state.appearance.wallpaper, DEFAULT_PROFILES.ui.appearance.wallpaper);
  assert.equal(state.material.kind, DEFAULT_PROFILES.ui.material.kind);
  assert.equal(state.material.shadow, DEFAULT_PROFILES.ui.material.shadow);
  assert.deepEqual(state.material.tint.rgb, DEFAULT_PROFILES.ui.material.tint.rgb);
  assert.equal(state.bubble.shape.cornerRadius, SHAPES.radius.fallback);
});

test('clampAppearance 把未知枚举摁回默认，并给出中文 problem', () => {
  const state = clampAppearance({
    bubble: { style: 'neon' },
    appearance: {
      theme: 'cyber',
      bubble: { material: 'vapor', shape: 'triangle' },
      avatar: { shape: 'hexagon' },
      wallpaper: { fit: 'mosaic', dim: 500, blur: -3 },
    },
    material: { kind: 'vapor', shadow: 'dramatic' },
  });
  assert.equal(state.appearance.theme, DEFAULT_PROFILES.ui.appearance.theme);
  assert.equal(state.appearance.bubble.material, DEFAULT_BUBBLE_MATERIAL);
  assert.equal(state.appearance.bubble.shape, DEFAULT_BUBBLE_SHAPE);
  assert.equal(state.appearance.avatar.shape, DEFAULT_PROFILES.ui.appearance.avatar.shape);
  assert.equal(state.appearance.wallpaper.fit, DEFAULT_PROFILES.ui.appearance.wallpaper.fit);
  assert.equal(state.appearance.wallpaper.dim, SHAPES.dimPct.max);
  assert.equal(state.appearance.wallpaper.blur, 0);
  assert.equal(state.material.kind, 'frosted');
  assert.equal(state.material.shadow, 'soft');
  assert.ok(state.problems.length >= 6, '每个填错的值都该有一句中文说明');
  for (const line of state.problems) {
    assert.ok(typeof line === 'string' && line.length > 0);
    assert.match(line, /[\u4e00-\u9fa5]/, `problem 应该是中文：${line}`);
  }
  assert.ok(state.problems.some((line) => line.includes('cyber')), '要指出填错的是哪个值');
});

test('clampAppearance 认得出旧的 appearance.theme 对象，并支持三条气泡形状', () => {
  const legacy = clampAppearance({ appearance: { theme: { id: 'light', followSystem: true, accent: '#335C8D' } } });
  assert.equal(legacy.appearance.theme, 'light');
  assert.deepEqual(legacy.problems, []);
  for (const shape of Object.keys(BUBBLE_SHAPES)) {
    const state = clampAppearance({ appearance: { bubble: { shape } } });
    assert.equal(state.appearance.bubble.shape, shape);
    assert.deepEqual(state.problems, []);
  }
});

test('clampAppearance 丢弃旧版变形器设置，且不因此报错', () => {
  const state = clampAppearance({
    appearance: {
      deform: { radius: { px: 20 }, size: { preset: 'l' }, window: 'wallpaper' },
      style: { kind: 'plain' },
      shape: { radius: { preset: 'rect', px: 4 }, size: { preset: 's', widthPct: 65 } },
      labels: { showNames: true },
      background: { kind: 'wallpaper', dimPct: 40 },
      system: { accent: '#335C8D', panelRadius: 18 },
    },
  });
  assert.deepEqual(Object.keys(state.appearance), ['theme', 'bubble', 'avatar', 'wallpaper']);
  assert.equal('deform' in state.appearance, false);
  assert.equal('style' in state.appearance, false);
  assert.equal('background' in state.appearance, false);
  assert.equal('system' in state.appearance, false);
  assert.deepEqual(state.problems, []);
});

test('clampAppearance 认不出的颜色回落，头像尺寸也跟着来', () => {
  const state = clampAppearance({
    bubble: { colors: { mine: 'not-a-color', accent: '#ABC' }, shape: { avatar: false } },
    avatar: { assistant: { size: 999 } },
  });
  assert.equal(state.bubble.colors.mine, DEFAULT_PROFILES.ui.bubble.colors.mine);
  assert.equal(state.bubble.colors.accent, '#ABC');
  assert.equal(state.bubble.shape.avatar, false);
  assert.equal(state.bubble.shape.avatarSize, SHAPES.avatar.max);
  assert.equal(MATERIAL_PRESETS[state.material.kind].opacity, state.material.opacity);
});

/* ------------------------------------------------------------- 对比度 */

test('contrastRatio 认出 21:1 与 1:1 的边界', () => {
  assert.ok(Math.abs(contrastRatio('#FFFFFF', '#000000') - 21) < 0.01);
  assert.ok(Math.abs(contrastRatio('#FFF', '#000') - 21) < 0.01);
  assert.ok(Math.abs(contrastRatio('rgb(255, 255, 255)', 'rgb(0, 0, 0)') - 21) < 0.01);
  assert.ok(Math.abs(contrastRatio('#FFFFFF', '#FFFFFF') - 1) < 0.01);
  assert.ok(Math.abs(contrastRatio('white', 'black') - 21) < 0.01);
});

test('contrastRatio 支持 #RRGGBBAA 与带 alpha 的 rgb()，先合成再算', () => {
  const opaque = contrastRatio('#000000', '#FFFFFF');
  const half = contrastRatio('#00000080', '#FFFFFF');
  const bare = contrastRatio('rgba(0, 0, 0, 0.5)', '#FFFFFF');
  assert.ok(half > 1 && half < opaque, `半透明黑应介于 1 与 ${opaque} 之间，实际 ${half}`);
  assert.ok(Math.abs(half - bare) < 0.05, `#00000080 与 rgba(0,0,0,.5) 该几乎同值：${half} vs ${bare}`);
  assert.ok(Math.abs(half - 4) < 0.02, `白底上半透明黑应约 4:1，实际 ${half}`);
  assert.ok(Math.abs(half - contrastRatio('#808080', '#FFFFFF')) < 0.1);
});

test('contrastRatio 遇到认不出的颜色会报错，不猜', () => {
  assert.throws(() => contrastRatio('nope', '#FFFFFF'), TypeError);
  assert.throws(() => contrastRatio('#FFFFFF', 'rgb(1 2)'), TypeError);
});

test('composite 的透明叠加是已知值', () => {
  assert.equal(composite('rgba(255, 0, 0, 0.5)', '#FFFFFF'), 'rgba(255, 128, 128, 1)');
  assert.equal(composite('#FF0000', '#0000FF'), 'rgba(255, 0, 0, 1)');
  // 源覆盖：alpha = .25 + .5×.75 = .625，色值 = 255×.5×.75 / .625 = 153
  assert.equal(composite('rgba(0, 0, 0, 0.25)', 'rgba(255, 255, 255, 0.5)'), 'rgba(153, 153, 153, 0.625)');
  // 上层不透明时，下层连 alpha 一起被吃掉
  assert.equal(composite('#000000', 'rgba(255, 255, 255, 0.5)'), 'rgba(0, 0, 0, 1)');
  assert.equal(composite('transparent', '#FFFFFF'), 'rgba(255, 255, 255, 1)');
  assert.equal(composite('rgba(0, 0, 0, 0)', 'rgba(1, 2, 3, 0.4)'), 'rgba(1, 2, 3, 0.4)');
});

test('analyzeContrast 给出双方比例、等级与明暗方案', () => {
  const report = analyzeContrast({ theme: 'wechat' });
  assert.deepEqual(Object.keys(report), ['mine', 'theirs', 'scheme']);
  assert.equal(report.scheme, 'light');
  assert.ok(report.mine.pass, '微信绿底黑字该过 AA');
  for (const side of [report.mine, report.theirs]) {
    assert.equal(typeof side.ratio, 'number');
    assert.ok(['AAA', 'AA', 'AA-large', 'fail'].includes(side.level));
    assert.equal(side.pass, side.ratio >= 4.5);
    assert.equal(side.largePass, side.ratio >= 3);
  }
});

test('analyzeContrast 抓得住白底白字，也认 behind 合成', () => {
  const bad = analyzeContrast({ mineBg: '#FFFFFF', mineFg: '#FFFFFF', theirsBg: '#FFFFFF', theirsFg: '#111111' });
  assert.equal(bad.mine.pass, false);
  assert.equal(bad.mine.level, 'fail');
  assert.ok(Math.abs(bad.mine.ratio - 1) < 0.01);
  assert.equal(bad.theirs.pass, true);
  const grown = analyzeContrast({ mineBg: 'rgba(255, 255, 255, 0.2)', mineFg: '#FFFFFF', behind: '#000000' });
  assert.ok(grown.mine.ratio > 10, `暗底上的白字应远超 10，实际 ${grown.mine.ratio}`);
});

test('analyzeContrast 收到垃圾输入也不抛，回落主题', () => {
  const report = analyzeContrast({ mine: 'garbage', mineText: 42, theme: 'nope' });
  assert.ok(report.mine.ratio > 0);
  assert.equal(typeof report.scheme, 'string');
});

test('八套内置壁纸各有一段场景规则，上传的图走 --pb-bg-image', () => {
  for (const id of ['deep-light', 'whale-fall', 'sea-glints', 'aurora', 'coral-warm', 'moon-sea', 'bubbles', 'deep-grid']) {
    assert.ok(
      SKIN_CSS.includes(`[data-pb-bg='wallpaper'][data-pb-wallpaper='${id}']`),
      `壁纸 ${id} 没有场景规则`,
    );
  }
  assert.ok(SKIN_CSS.includes("[data-pb-wallpaper-kind='image']"), '缺少自定义图片壁纸的钩子');
  assert.ok(SKIN_CSS.includes('background-image: var(--pb-bg-image, none);'), '自定义壁纸必须读 --pb-bg-image 并有回落');
  assert.ok(SKIN_CSS.includes('background-size: cover;'), '壁纸铺满，不拉伸变形');
  assert.ok(SKIN_CSS.includes('@keyframes pb-bg-float'), '气泡壁纸的动画只动 transform');
});

test('壁纸规则只动 transform / opacity，不碰布局属性', () => {
  const blocks = SKIN_CSS.split('\n}\n').filter((block) => block.includes("[data-pb-wallpaper='"));
  assert.ok(blocks.length >= 8);
  for (const block of blocks) {
    assert.ok(!/\b(width|height|margin|padding|top|left|right|bottom):/.test(block), `壁纸规则里出现了布局属性：${block.slice(0, 60)}`);
  }
});
