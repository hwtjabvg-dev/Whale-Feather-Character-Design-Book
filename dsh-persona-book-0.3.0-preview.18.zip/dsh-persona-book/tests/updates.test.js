import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {mkdtemp,mkdir,readFile,writeFile,rename,rm,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createHash,generateKeyPairSync,sign} from 'node:crypto';
import {PluginUpdater,compareVersions,updateUrl} from '../app/updater.mjs';
import {DomainError} from '../app/store.mjs';
import {writeZip,readZip} from '../lib/zip.js';
const sha=data=>createHash('sha256').update(data).digest('hex');
const keys=generateKeyPairSync('ed25519'),publicKey=keys.publicKey.export({type:'spki',format:'pem'});
function archive(version='0.3.0-preview.4',mutate){
 const files=[
  {path:'package.json',data:Buffer.from(JSON.stringify({name:'dsh-persona-book',version,main:'lib/index.js',dsh:{client:{platform:'web'}}}))},
  {path:'lib/index.js',data:Buffer.from('export const name="dsh-persona-book";')},
  {path:'lib/client.js',data:Buffer.from('/* client */')},
  {path:'cordis.patch.yml',data:Buffer.from('- insert: []')},
  {path:'app/public/app.js',data:Buffer.from('/* built UI */')},
  {path:'resources/update-channel.json',data:Buffer.from(JSON.stringify({publicKey,url:''}))},
 ];
 if(mutate)mutate(files);
 const manifest={format:'dsh-persona-book-directory/v1',version,files:files.map(f=>({path:f.path,bytes:f.data.length,sha256:sha(f.data)}))};
 files.push({path:'mobile/package-manifest.json',data:Buffer.from(JSON.stringify(manifest))});
 return writeZip(files.map(f=>({name:'dsh-persona-book/'+f.path,data:f.data})));
}
function feed(zip,{version='0.3.0-preview.4',badSignature=false,badHash=false}={}){
 const payload=Buffer.from(JSON.stringify({format:'persona-book-update/v1',name:'dsh-persona-book',version,nodeMinimum:22,notes:'新增手机更新按钮',package:{url:'package.zip',bytes:zip.length,sha256:badHash?'0'.repeat(64):sha(zip)}}));
 return JSON.stringify({payload:payload.toString('base64'),signature:(badSignature?Buffer.alloc(64):sign(null,payload,keys.privateKey)).toString('base64')});
}
async function setup(t,{zip=archive(),feedOptions={},renameFile}={}){
 const temp=await mkdtemp(join(tmpdir(),'pb-update-test-')),root=join(temp,'plugin'),data=join(temp,'userdata');await mkdir(root);await mkdir(data);
 await writeFile(join(root,'package.json'),JSON.stringify({name:'dsh-persona-book',version:'0.3.0-preview.3'}));await writeFile(join(root,'old.txt'),'original');await writeFile(join(data,'personal.json'),'user-settings-and-history');
 const server=createServer((req,res)=>{if(req.url==='/latest.json'){res.setHeader('Content-Type','application/json');res.end(feed(zip,feedOptions));}else if(req.url==='/package.zip')res.end(zip);else res.writeHead(404).end();});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const channel={url:'http://127.0.0.1:'+server.address().port+'/latest.json',publicKey};
 const updater=await new PluginUpdater({root,dataDir:data,canInstall:true,channel,renameFile}).open();
 t.after(async()=>{server.closeAllConnections();await new Promise(r=>server.close(r));assert.ok(temp.startsWith(join(tmpdir(),'pb-update-test-')));await rm(temp,{recursive:true,force:true});});return {updater,root,data,temp,channel};
}
test('版本比较区分数字预览版、正式版和降级',()=>{assert.ok(compareVersions('0.3.0-preview.10','0.3.0-preview.9')>0);assert.ok(compareVersions('0.3.0','0.3.0-preview.99')>0);assert.equal(compareVersions('0.3.0-preview.4','0.3.0-preview.4'),0);assert.throws(()=>compareVersions('main','0.3.0'));});
test('更新源拒绝明文远程地址和嵌入凭证，允许本机测试源',()=>{assert.throws(()=>updateUrl('http://example.com/latest.json'));assert.throws(()=>updateUrl('https://user:password@example.com/a'));assert.match(updateUrl('http://127.0.0.1:1234/latest.json'),/^http:/);});
test('没有发布地址时如实显示未配置，不能安装',async t=>{const {updater}=await setup(t);updater.sourceUrl='';const s=await updater.check();assert.equal(s.configured,false);assert.equal(s.phase,'unconfigured');await assert.rejects(updater.install('0.3.0-preview.4'),/检查新版/);});
test('签名目录通过真实 HTTP 检查，新版带版本和说明',async t=>{const {updater}=await setup(t);const s=await updater.check();assert.equal(s.available,true);assert.equal(s.latestVersion,'0.3.0-preview.4');assert.equal(s.notes,'新增手机更新按钮');});
test('伪造签名被拒绝，已安装文件保持不变',async t=>{const {updater,root}=await setup(t,{feedOptions:{badSignature:true}});await assert.rejects(updater.check(),/签名/);assert.equal(await readFile(join(root,'old.txt'),'utf8'),'original');assert.equal(updater.status().available,false);});
test('旧版本不提示更新且不能降级安装',async t=>{const zip=archive('0.3.0-preview.2');const {updater}=await setup(t,{zip,feedOptions:{version:'0.3.0-preview.2'}});assert.equal((await updater.check()).available,false);await assert.rejects(updater.install('0.3.0-preview.2'),/检查新版/);});
test('下载校验失败不替换插件',async t=>{const {updater,root}=await setup(t,{feedOptions:{badHash:true}});await updater.check();await assert.rejects(updater.install('0.3.0-preview.4'),/校验/);assert.equal(await readFile(join(root,'old.txt'),'utf8'),'original');});
test('一键更新暂存替换并保留用户数据和旧版备份，重启后消除提示',async t=>{const {updater,root,data,temp,channel}=await setup(t);await updater.check();const s=await updater.install('0.3.0-preview.4');assert.equal(s.restartRequired,true);assert.equal(JSON.parse(await readFile(join(root,'package.json'),'utf8')).version,'0.3.0-preview.4');assert.equal(await readFile(join(data,'personal.json'),'utf8'),'user-settings-and-history');const backup=(await readdir(temp)).find(x=>x.startsWith('.pb-update-backup-'));assert.equal(await readFile(join(temp,backup,'old.txt'),'utf8'),'original');await assert.rejects(updater.install('0.3.0-preview.4'),/重启/);const restarted=await new PluginUpdater({root,dataDir:data,canInstall:true,channel}).open();assert.equal(restarted.status().restartRequired,false);});
test('目录替换失败自动回退旧版，用户数据不变',async t=>{const renameFile=async(from,to)=>{if(from.includes('.pb-update-stage-'))throw Error('模拟安装目标不可写');return rename(from,to);};const {updater,root,data}=await setup(t,{renameFile});await updater.check();await assert.rejects(updater.install('0.3.0-preview.4'),/安装失败/);assert.equal(await readFile(join(root,'old.txt'),'utf8'),'original');assert.equal(await readFile(join(data,'personal.json'),'utf8'),'user-settings-and-history');assert.equal(updater.status().restartRequired,false);});
test('签名包中路径越界被拒绝且不会写出文件',async t=>{const zip=archive('0.3.0-preview.4',files=>files.push({path:'../../outside.txt',data:Buffer.from('no')}));const {updater,root,temp}=await setup(t,{zip});await updater.check();await assert.rejects(updater.install('0.3.0-preview.4'),/损坏|路径/);assert.equal(await readFile(join(root,'old.txt'),'utf8'),'original');assert.ok(!(await readdir(temp)).includes('outside.txt'));});
test('包含用户数据的插件目录不允许自动替换',async t=>{const {updater,root}=await setup(t);updater.data=join(root,'data');await mkdir(updater.data);await updater.check();await assert.rejects(updater.install('0.3.0-preview.4'),/用户数据/);assert.equal(await readFile(join(root,'old.txt'),'utf8'),'original');});
test('更新包不允许更换发布公钥',async t=>{const zip=archive('0.3.0-preview.4',files=>{files.find(f=>f.path==='resources/update-channel.json').data=Buffer.from(JSON.stringify({publicKey:'other'}));});const {updater,root}=await setup(t,{zip});await updater.check();await assert.rejects(updater.install('0.3.0-preview.4'),/验证信息/);assert.equal(await readFile(join(root,'old.txt'),'utf8'),'original');});
test('外层包签名正确但内部文件清单被篡改时拒绝安装',async t=>{const entries=readZip(archive());entries.find(f=>f.name.endsWith('lib/client.js')).data=Buffer.from('changed');const {updater,root}=await setup(t,{zip:writeZip(entries)});await updater.check();await assert.rejects(updater.install('0.3.0-preview.4'),/内部文件校验/);assert.equal(await readFile(join(root,'old.txt'),'utf8'),'original');});
test('下载期间出现新聊天任务时提交前中止，保持旧版',async t=>{const {updater,root}=await setup(t);await updater.check();await assert.rejects(updater.install('0.3.0-preview.4',()=>{throw new DomainError(409,'EBUSY','新的聊天正在生成');}),/新的聊天/);assert.equal(await readFile(join(root,'old.txt'),'utf8'),'original');});

test('私人通道未授权时拒绝检查，不把私有站点当公网目录',async t=>{const {updater}=await setup(t);updater.channel.private=true;await assert.rejects(updater.check(),e=>e.code==='EUPDATEAUTH');assert.equal(updater.status().authorizationConfigured,false);});
test('私人更新授权绑定来源且不出现在状态，保存后重启保留',async t=>{const {updater,root,data,channel}=await setup(t);const token='private-device-test-only';await updater.configureAccess(token);assert.equal(updater.status().authorizationConfigured,true);assert.ok(!JSON.stringify(updater.status()).includes(token));const restarted=await new PluginUpdater({root,dataDir:data,channel}).open();assert.equal(restarted.status().authorizationConfigured,true);await restarted.configure('http://127.0.0.1:1/latest.json');assert.equal(restarted.status().authorizationConfigured,false);await assert.rejects(restarted.configureAccess('invalid\nheader'),/格式/);});
test('私人授权仅发给绑定站点，下载包和目录均继承授权',async t=>{const {updater}=await setup(t);const zip=archive(),envelope=feed(zip),seen=[];const server=createServer((req,res)=>{seen.push(req.headers['x-whale-device-authorization']);if(req.headers['oai-sites-authorization']!=='Bearer device-test-only'||req.headers['x-whale-device-authorization']!=='Bearer device-test-only'){res.writeHead(401).end();return;}res.end(req.url==='/latest.json'?envelope:zip);});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{server.closeAllConnections();server.close(r)}));await updater.configure('http://127.0.0.1:'+server.address().port+'/latest.json');updater.channel.private=true;await updater.configureAccess('device-test-only');await updater.check();await updater.install('0.3.0-preview.4');assert.deepEqual(seen,['Bearer device-test-only','Bearer device-test-only']);});
test('私人下载重定向到另一源时停止，不泄露授权凭据',async t=>{const {updater}=await setup(t);let exposed=false;const other=createServer((req,res)=>{exposed=true;res.end('{}')});await new Promise(r=>other.listen(0,'127.0.0.1',r));const server=createServer((req,res)=>res.writeHead(302,{location:'http://127.0.0.1:'+other.address().port+'/latest.json'}).end());await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>Promise.all([server,other].map(s=>new Promise(r=>{s.closeAllConnections();s.close(r)}))));await updater.configure('http://127.0.0.1:'+server.address().port+'/latest.json');await updater.configureAccess('device-test-only');await assert.rejects(updater.check(),e=>e.code==='EUPDATEAUTH');assert.equal(exposed,false);});
test('私人授权失效显示中文授权错误，清除后状态不含凭据',async t=>{const {updater}=await setup(t);const server=createServer((req,res)=>res.writeHead(403).end());await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{server.closeAllConnections();server.close(r)}));await updater.configure('http://127.0.0.1:'+server.address().port+'/latest.json');await updater.configureAccess('expired-test-only');await assert.rejects(updater.check(),e=>e.code==='EUPDATEAUTH'&&e.message.includes('授权'));await updater.configureAccess('');assert.equal(updater.status().authorizationConfigured,false);});
test('分段下载校验范围、重试临时失败并验证整包，保留个人数据',async t=>{
 const {updater,data}=await setup(t),zip=archive(),encoded=JSON.parse(feed(zip)),release=JSON.parse(Buffer.from(encoded.payload,'base64'));release.package.chunkBytes=524288;const payload=Buffer.from(JSON.stringify(release)),envelope=JSON.stringify({payload:payload.toString('base64'),signature:sign(null,payload,keys.privateKey).toString('base64')});let attempts=0;
 const server=createServer((req,res)=>{if(req.url==='/latest.json'){res.end(envelope);return;}attempts++;if(!req.headers.range){res.writeHead(400).end();return;}if(attempts===1){res.writeHead(503).end();return;}const [,start,end]=req.headers.range.match(/^bytes=(\d+)-(\d+)$/)||[];assert.equal(Number(start),0);assert.equal(Number(end),zip.length-1);res.writeHead(206,{'Content-Range':`bytes ${start}-${end}/${zip.length}`});res.end(zip);});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{server.closeAllConnections();server.close(r);}));await updater.configure('http://127.0.0.1:'+server.address().port+'/latest.json');await updater.check();await updater.install(release.version);assert.equal(attempts,2);assert.equal(await readFile(join(data,'personal.json'),'utf8'),'user-settings-and-history');
});
