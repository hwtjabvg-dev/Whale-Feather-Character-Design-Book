/**
 * Asset library tests: what is accepted, what is refused and why, how uploads
 * dedupe, and how references protect a file from deletion. Everything runs in a
 * sandbox directory, never against the real `~/.agents` tree.
 */
import { mkdtemp, readdir, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import test, { after } from 'node:test';

const sandbox = await mkdtemp(join(tmpdir(), 'persona-book-assets-'));
process.env.DSH_PERSONA_BOOK_DIR = join(sandbox, 'personas');
process.env.DSH_AGENTS_HOME = join(sandbox, 'agents');

const { ASSETS_DIR, DEFAULT_PROFILES, LIBRARY_LIMITS } = await import('../lib/constants.js');
const assets = await import('../lib/assets.js');
const { loadAssetIndex, saveAssetIndex } = await import('../lib/repo.js');

after(async () => {
  await rm(sandbox, { recursive: true, force: true });
});

/** A PNG signature plus an IHDR chunk header: enough to sniff, never decoded. */
function png(width, height, tail = '') {
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(25);
  ihdr.writeUInt32BE(13, 0);
  ihdr.write('IHDR', 4, 'latin1');
  ihdr.writeUInt32BE(width, 8);
  ihdr.writeUInt32BE(height, 12);
  return Buffer.concat([signature, ihdr, Buffer.from(tail, 'latin1')]);
}

/** A JPEG header with an SOF0 marker. */
function jpeg(width, height) {
  const buffer = Buffer.alloc(24);
  buffer[0] = 0xff;
  buffer[1] = 0xd8;
  buffer[2] = 0xff;
  buffer[3] = 0xc0;
  buffer.writeUInt16BE(17, 4);
  buffer[6] = 8;
  buffer.writeUInt16BE(height, 7);
  buffer.writeUInt16BE(width, 9);
  return buffer;
}

/** A WAV header (RIFF/WAVE), which the sniffer reads as audio. */
function wav() {
  const buffer = Buffer.alloc(44);
  buffer.write('RIFF', 0, 'latin1');
  buffer.writeUInt32LE(36, 4);
  buffer.write('WAVE', 8, 'latin1');
  buffer.write('fmt ', 12, 'latin1');
  return buffer;
}

test('a wallpaper keeps its pixels, its real format and its aspect hint', async () => {
  const wide = jpeg(8000, 1200);
  const { entry, reused } = await assets.addAsset({ kind: 'wallpaper', name: '超宽海景.jpg', data: wide });
  assert.equal(reused, false);
  assert.equal(entry.kind, 'wallpaper');
  assert.equal(entry.ext, 'jpg');
  assert.equal(entry.mime, 'image/jpeg');
  assert.equal(entry.width, 8000);
  assert.equal(entry.height, 1200);
  assert.equal(entry.bytes, wide.length);
  assert.equal(entry.ratio, 8000 / 1200);
  assert.equal(entry.extreme, true, 'a 6.7:1 picture is flagged for the crop hint');
  assert.match(entry.id, /^w-[0-9a-f]{16}$/);
  assert.equal(entry.url, `/api/persona-book/assets/${entry.id}`);
  const stored = await stat(join(ASSETS_DIR, 'wallpaper', `${entry.id}.jpg`));
  assert.equal(stored.size, wide.length);
});

test('resolution and file size are never a reason to reject', async () => {
  const huge = png(12000, 9000);
  const { entry } = await assets.addAsset({ kind: 'wallpaper', name: '巨图.png', data: huge });
  assert.equal(entry.width, 12000);
  assert.equal(entry.extreme, false);
});

test('identical bytes dedupe onto one asset', async () => {
  const data = png(64, 64, 'same');
  const first = await assets.addAsset({ kind: 'avatar', name: '头像.png', data });
  const second = await assets.addAsset({ kind: 'avatar', name: '另一个名字.png', data });
  assert.equal(second.reused, true);
  assert.equal(second.entry.id, first.entry.id);
  assert.equal(second.entry.name, '头像.png', 'the first name wins');
  const library = await assets.listAssets();
  assert.equal(library.avatars.filter((row) => row.id === first.entry.id).length, 1);
});

test('a sound file is refused as a wallpaper and the other way round', async () => {
  await assert.rejects(
    () => assets.addAsset({ kind: 'wallpaper', name: '声音.wav', data: wav() }),
    (error) => error.code === 'EUNSUPPORTED' && error.status === 400,
  );
  await assert.rejects(
    () => assets.addAsset({ kind: 'sound', name: '图.png', data: png(4, 4) }),
    (error) => error.code === 'EUNSUPPORTED',
  );
});

test('unknown bytes, empty bodies and unknown kinds each get their own code', async () => {
  await assert.rejects(
    () => assets.addAsset({ kind: 'avatar', name: 'x.bin', data: Buffer.from('not an image at all') }),
    (error) => error.code === 'EUNSUPPORTED',
  );
  await assert.rejects(
    () => assets.addAsset({ kind: 'avatar', name: 'x.png', data: Buffer.alloc(0) }),
    (error) => error.code === 'EEMPTY',
  );
  await assert.rejects(
    () => assets.addAsset({ kind: 'sticker', name: 'x.png', data: png(4, 4) }),
    (error) => error.code === 'EINVALID',
  );
});

test('an SVG carrying a script is refused with the reason attached', async () => {
  const safe = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"></svg>');
  const accepted = await assets.addAsset({ kind: 'avatar', name: '安全.svg', data: safe });
  assert.equal(accepted.entry.ext, 'svg');
  const dangerous = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');
  await assert.rejects(
    () => assets.addAsset({ kind: 'avatar', name: '坏.svg', data: dangerous }),
    (error) => error.code === 'EBADSVG' && /脚本标签/.test(error.message),
  );
});

test('the library cap is a 409 with the number in it', async () => {
  const index = await loadAssetIndex();
  const filler = Array.from({ length: LIBRARY_LIMITS.wallpaper }, (_, i) => ({
    id: `w-fill${String(i).padStart(12, '0')}`,
    kind: 'wallpaper',
    name: `预置 ${i}`,
    ext: 'png',
    mime: 'image/png',
    bytes: 10,
    addedAt: new Date(2020, 0, 1 + (i % 27)).toISOString(),
  }));
  index.wallpapers = filler;
  await saveAssetIndex(index);
  await assert.rejects(
    () => assets.addAsset({ kind: 'wallpaper', name: '再来一张.png', data: png(9, 9, 'overflow') }),
    (error) => error.code === 'ELIMIT' && error.status === 409 && error.message.includes(String(LIBRARY_LIMITS.wallpaper)),
  );
  index.wallpapers = [];
  await saveAssetIndex(index);
});

test('deleting an asset that a profile still points at needs `force`', async () => {
  const { entry } = await assets.addAsset({ kind: 'wallpaper', name: '在用.png', data: png(300, 200, 'used') });
  const profiles = { ...DEFAULT_PROFILES, ui: { ...DEFAULT_PROFILES.ui, wallpaper: { kind: 'asset', id: entry.id } } };
  const used = assets.referencesTo(profiles, entry.id);
  assert.deepEqual(used, ['wallpaper']);
  await assert.rejects(
    () => assets.removeAsset(entry.id, { usedBy: used }),
    (error) => error.code === 'ECONFLICT' && error.status === 409,
  );
  const removed = await assets.removeAsset(entry.id, { force: true });
  assert.equal(removed.id, entry.id);
  assert.equal(await assets.readAsset(entry.id), null);
  await assert.rejects(() => assets.removeAsset(entry.id), (error) => error.code === 'ENOTFOUND');
});

test('壁纸挂在 appearance.wallpaper 上时也算被引用（换过形状的新文档）', async () => {
  const { entry } = await assets.addAsset({ kind: 'wallpaper', name: '新形状.png', data: png(320, 200, 'newshape') });
  const profiles = {
    ...DEFAULT_PROFILES,
    ui: { ...DEFAULT_PROFILES.ui, appearance: { ...DEFAULT_PROFILES.ui.appearance, wallpaper: { id: entry.id } } },
  };
  const used = assets.referencesTo(profiles, entry.id);
  assert.ok(used.includes('appearance.wallpaper'), `应认出新形状壁纸引用，实际：${used.join(',')}`);
  await assert.rejects(
    () => assets.removeAsset(entry.id, { usedBy: used }),
    (error) => error.code === 'ECONFLICT' && error.status === 409,
  );
  await assets.removeAsset(entry.id, { force: true });
});

test('an upload streamed to a file lands by rename, without copying it', async () => {
  const tmp = join(sandbox, 'incoming.part');
  const bytes = png(120, 90, 'streamed');
  await writeFile(tmp, bytes);
  const { entry } = await assets.addAssetFromFile({
    kind: 'avatar',
    name: '流式.png',
    tmpPath: tmp,
    head: bytes.subarray(0, 4096),
    bytes: bytes.length,
  });
  assert.equal(entry.width, 120);
  const read = await assets.readAsset(entry.id);
  assert.equal(read.bytes.length, bytes.length);
  await assert.rejects(() => stat(tmp), 'the temp file is gone after the rename');
});

test('a rejected streamed upload leaves no temp file behind', async () => {
  const tmp = join(sandbox, 'rejected.part');
  await writeFile(tmp, Buffer.from('definitely not an image'));
  await assert.rejects(
    () =>
      assets.addAssetFromFile({
        kind: 'avatar',
        name: 'x.bin',
        tmpPath: tmp,
        head: Buffer.from('definitely not an image'),
        bytes: 23,
      }),
    (error) => error.code === 'EUNSUPPORTED',
  );
  await assert.rejects(() => stat(tmp));
});

test('the usage meter reports bytes, files and the caps', async () => {
  const usage = await assets.libraryUsage();
  assert.ok(usage.files >= 1);
  assert.ok(usage.bytes > 0);
  assert.equal(usage.quota, 512 * 1024 * 1024);
  assert.deepEqual(usage.limits, LIBRARY_LIMITS);
  assert.ok(usage.uploads.wallpaper > usage.uploads.sound);
});

test('the orphan sweep is opt-in and clears stale temp files', async () => {
  const { entry } = await assets.addAsset({ kind: 'avatar', name: '孤儿.png', data: png(8, 8, 'orphan') });
  await writeFile(join(ASSETS_DIR, 'avatar', 'a-deadbeefdeadbeef.png'), png(1, 1));
  const gentle = await assets.sweepOrphans();
  assert.ok(gentle.removed >= 0);
  assert.ok(await stat(join(ASSETS_DIR, 'avatar', `${entry.id}.png`)), 'a real asset survives');
  const grown = await stat(join(ASSETS_DIR, 'avatar', 'a-deadbeefdeadbeef.png'));
  assert.equal(grown.size > 0, true, 'orphans survive the gentle sweep');
  const thorough = await assets.sweepOrphans({ orphans: true });
  assert.ok(thorough.removed >= 1);
  await assert.rejects(() => stat(join(ASSETS_DIR, 'avatar', 'a-deadbeefdeadbeef.png')));
});

/** Distinct WAV-ish bytes, so the library cap is exercised without dedupe. */
const wavish = (index) => Buffer.concat([wav(), Buffer.from(`#${index}`, 'latin1')]);

test('a deduped streamed upload still takes its temp file with it', async () => {
  const bytes = png(64, 64, 'twice');
  const first = join(sandbox, 'first.part');
  await writeFile(first, bytes);
  const one = await assets.addAssetFromFile({
    kind: 'wallpaper',
    name: '第一次.png',
    tmpPath: first,
    head: bytes.subarray(0, 4096),
    bytes: bytes.length,
  });
  assert.equal(one.reused, false);

  const second = join(sandbox, 'second.part');
  await writeFile(second, bytes);
  const two = await assets.addAssetFromFile({
    kind: 'wallpaper',
    name: '第二次.png',
    tmpPath: second,
    head: bytes.subarray(0, 4096),
    bytes: bytes.length,
  });
  assert.equal(two.reused, true, 'identical bytes reuse the stored copy');
  assert.equal(two.entry.id, one.entry.id);
  await assert.rejects(() => stat(second), '上传被复用时也要删掉临时文件');
  const leftover = await readdir(join(ASSETS_DIR, '.tmp')).catch(() => []);
  assert.deepEqual(leftover, [], '暂存目录里不留东西');
});

test('a full library refuses the upload and still cleans up after itself', async () => {
  const kind = 'sound';
  for (let i = 0; i < LIBRARY_LIMITS.sound; i += 1) {
    await assets.addAsset({ kind, name: `音效-${i}.wav`, data: wavish(i) });
  }
  const tmp = join(sandbox, 'overflow.part');
  await writeFile(tmp, Buffer.from(wavish(999)));
  await assert.rejects(
    () =>
      assets.addAssetFromFile({
        kind,
        name: '再多一个.wav',
        tmpPath: tmp,
        head: Buffer.from(wavish(999)).subarray(0, 64),
        bytes: 64,
      }),
    (error) => error.code === 'ELIMIT',
  );
  await assert.rejects(() => stat(tmp), '被拒绝的上传不留临时文件');
});

test('the usage meter counts stored pictures only, never the index', async () => {
  const before = await assets.libraryUsage();
  const kinds = await Promise.all(
    ['wallpaper', 'avatar', 'sound'].map((kind) =>
      readdir(join(ASSETS_DIR, kind)).catch(() => []),
    ),
  );
  const stored = kinds.flat();
  assert.equal(before.files, stored.length, '库里几个文件就报几个');
  assert.ok(
    before.bytes < 1_000_000,
    'index.json 与 .tmp 不该算进额度',
  );
});
