/**
 * PPTX writer tests: the package is unzipped again with a reader written here,
 * so every assertion is made against the real bytes rather than against the
 * writer's own bookkeeping. Pictures are hand-built headers (the same trick as
 * `tests/assets.test.js`): no binary fixture files are checked in.
 */
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import test, { after } from 'node:test';
import { inflateRawSync } from 'node:zlib';

import { SLIDE_H, SLIDE_W, buildPptx, crc32 } from '../lib/pptx.js';

const sandbox = await mkdtemp(join(tmpdir(), 'persona-book-pptx-'));
const MARGIN_X = 838200;
const MARGIN_Y = 609600;

after(async () => {
  await rm(sandbox, { recursive: true, force: true });
});

/* ------------------------------------------------------------- fixtures --- */

/** PNG signature plus an IHDR chunk: enough for `probe` to read the size. */
function png(width, height, tail = '') {
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(25);
  ihdr.writeUInt32BE(13, 0);
  ihdr.write('IHDR', 4, 'latin1');
  ihdr.writeUInt32BE(width, 8);
  ihdr.writeUInt32BE(height, 12);
  return Buffer.concat([signature, ihdr, Buffer.from(tail, 'latin1')]);
}

/** JPEG SOI plus an SOF0 segment carrying the size. */
function jpeg(width, height, tail = '') {
  const buffer = Buffer.alloc(24);
  buffer[0] = 0xff;
  buffer[1] = 0xd8;
  buffer[2] = 0xff;
  buffer[3] = 0xc0;
  buffer.writeUInt16BE(17, 4);
  buffer[6] = 8;
  buffer.writeUInt16BE(height, 7);
  buffer.writeUInt16BE(width, 9);
  return Buffer.concat([buffer, Buffer.from(tail, 'latin1')]);
}

/** A GIF header, which `probe` recognises but the writer must refuse. */
function gif(width, height) {
  const buffer = Buffer.alloc(13);
  buffer.write('GIF89a', 0, 'latin1');
  buffer.writeUInt16LE(width, 6);
  buffer.writeUInt16LE(height, 8);
  return buffer;
}

/** Write bytes into the sandbox and return the absolute path. */
async function fixture(name, bytes) {
  const path = join(sandbox, name);
  await writeFile(path, bytes);
  return path;
}

/* ----------------------------------------------------------- zip reader --- */

/** Walk EOCD → central directory → local headers, inflating each entry. */
function readZip(buffer) {
  const signature = Buffer.from([0x50, 0x4b, 0x05, 0x06]);
  const eocd = buffer.lastIndexOf(signature);
  assert.notEqual(eocd, -1, 'the archive ends with an EOCD record');
  const count = buffer.readUInt16LE(eocd + 10);
  const directorySize = buffer.readUInt32LE(eocd + 12);
  const directoryStart = buffer.readUInt32LE(eocd + 16);
  assert.equal(directoryStart + directorySize, eocd, 'the central directory abuts the EOCD');
  assert.equal(buffer.readUInt16LE(eocd + 8), count, 'both entry counts agree');

  const entries = new Map();
  let cursor = directoryStart;
  for (let index = 0; index < count; index += 1) {
    assert.equal(buffer.readUInt32LE(cursor), 0x02014b50, 'central directory header signature');
    const method = buffer.readUInt16LE(cursor + 10);
    const time = buffer.readUInt16LE(cursor + 12);
    const date = buffer.readUInt16LE(cursor + 14);
    const checksum = buffer.readUInt32LE(cursor + 16);
    const compressedSize = buffer.readUInt32LE(cursor + 20);
    const rawSize = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const commentLength = buffer.readUInt16LE(cursor + 32);
    const localOffset = buffer.readUInt32LE(cursor + 42);
    const name = buffer.subarray(cursor + 46, cursor + 46 + nameLength).toString('utf8');

    assert.equal(buffer.readUInt32LE(localOffset), 0x04034b50, `${name}: local header signature`);
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    assert.equal(
      buffer.subarray(localOffset + 30, localOffset + 30 + localNameLength).toString('utf8'),
      name,
      `${name}: local and central names agree`,
    );
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    const stored = buffer.subarray(dataStart, dataStart + compressedSize);
    const data = method === 8 ? inflateRawSync(stored) : Buffer.from(stored);
    assert.equal(data.length, rawSize, `${name}: uncompressed size matches`);
    entries.set(name, { name, method, time, date, checksum, compressedSize, rawSize, data });
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  assert.equal(cursor, directoryStart + directorySize, 'the directory walk consumed exactly its size');
  return entries;
}

const text = (entries, name) => entries.get(name).data.toString('utf8');

/** Relationship rows of one `.rels` part, keyed by Id. */
function relationships(xml) {
  return new Map(
    [...xml.matchAll(/<Relationship Id="([^"]+)" Type="([^"]+)" Target="([^"]+)"/g)]
      .map((match) => [match[1], { type: match[2], target: match[3] }]),
  );
}

const slideXml = (entries, index) => text(entries, `ppt/slides/slide${index}.xml`);
const slideRels = (entries, index) => relationships(text(entries, `ppt/slides/_rels/slide${index}.xml.rels`));

/** Resolve a slide-relative media target (`../media/image1.png`) to a part name. */
const resolveMedia = (target) => `ppt/${target.replace(/^\.\.\//, '')}`;

/** The `<p:pic>` frames of a slide, in document order. */
function pictures(xml) {
  return [...xml.matchAll(/<p:pic>[\s\S]*?<\/p:pic>/g)].map((match) => {
    const chunk = match[0];
    const embed = /<a:blip r:embed="([^"]+)"/.exec(chunk)[1];
    const off = /<a:off x="(-?\d+)" y="(-?\d+)"\/>/.exec(chunk);
    const ext = /<a:ext cx="(\d+)" cy="(\d+)"\/>/.exec(chunk);
    return {
      embed,
      x: Number(off[1]),
      y: Number(off[2]),
      cx: Number(ext[1]),
      cy: Number(ext[2]),
    };
  });
}

/* --------------------------------------------------------------- specs --- */

const TEXT_SPEC = {
  title: '角色设定集',
  subtitle: 'DeepSeek娘 / 小鲸鲸',
  author: 'dsh-persona-book',
  slides: [
    { kind: 'cover', title: '封面大标题', subtitle: '副标题在这里' },
    { kind: 'section', title: '第一章', subtitle: '人物档案' },
    { kind: 'bullets', title: '基础设定', bullets: ['名字：小鲸鲸', '语气：温柔'] },
  ],
};

/* --------------------------------------------------------------- tests --- */

test('every required part of the OOXML package is present', async () => {
  const entries = readZip(await buildPptx(TEXT_SPEC));
  const required = [
    '[Content_Types].xml',
    '_rels/.rels',
    'ppt/presentation.xml',
    'ppt/_rels/presentation.xml.rels',
    'ppt/slideMasters/slideMaster1.xml',
    'ppt/slideMasters/_rels/slideMaster1.xml.rels',
    'ppt/slideLayouts/slideLayout1.xml',
    'ppt/slideLayouts/_rels/slideLayout1.xml.rels',
    'ppt/theme/theme1.xml',
    'ppt/slides/slide1.xml',
    'ppt/slides/_rels/slide1.xml.rels',
    'ppt/slides/slide2.xml',
    'ppt/slides/_rels/slide2.xml.rels',
    'ppt/slides/slide3.xml',
    'ppt/slides/_rels/slide3.xml.rels',
  ];
  for (const name of required) assert.ok(entries.has(name), `missing part: ${name}`);
  assert.ok(!entries.has('ppt/slides/slide4.xml'), 'no slide part beyond the spec');
  assert.deepEqual(
    [...entries.keys()].filter((name) => name.startsWith('ppt/notesSlides/')),
    [],
    'no notes slides are written',
  );
});

test('the slide canvas is the 16:9 size the API promises', async () => {
  const entries = readZip(await buildPptx(TEXT_SPEC));
  assert.equal(SLIDE_W, 12192000);
  assert.equal(SLIDE_H, 6858000);
  assert.match(text(entries, 'ppt/presentation.xml'), new RegExp(`<p:sldSz cx="${SLIDE_W}" cy="${SLIDE_H}"/>`));
});

test('cover, section and bullet text all land in their own slide part', async () => {
  const entries = readZip(await buildPptx(TEXT_SPEC));
  const cover = slideXml(entries, 1);
  const section = slideXml(entries, 2);
  const bullets = slideXml(entries, 3);
  assert.match(cover, /封面大标题/);
  assert.match(cover, /副标题在这里/);
  assert.match(section, /第一章/);
  assert.match(section, /人物档案/);
  assert.match(bullets, /基础设定/);
  assert.match(bullets, /名字：小鲸鲸/);
  assert.match(bullets, /语气：温柔/);
  assert.doesNotMatch(cover, /第一章/, 'a slide never leaks another slide text');
  assert.doesNotMatch(section, /封面大标题/);
  assert.doesNotMatch(bullets, /人物档案/);
});

test('every run carries the CJK-safe font stack', async () => {
  const entries = readZip(await buildPptx(TEXT_SPEC));
  const stack = /<a:latin typeface="Segoe UI"\/><a:ea typeface="Microsoft YaHei"\/><a:cs typeface="Microsoft YaHei"\/>/g;
  for (const index of [1, 2, 3]) {
    const xml = slideXml(entries, index);
    const runs = [...xml.matchAll(/<a:r>/g)].length;
    const fonts = [...xml.matchAll(stack)].length;
    assert.ok(runs > 0, `slide ${index} has text`);
    assert.equal(fonts, runs, `slide ${index}: one font stack per run`);
  }
});

test('image bytes are embedded verbatim and every r:embed resolves', async () => {
  const tall = png(600, 1200, 'tall');
  const photo = jpeg(800, 600, 'photo');
  const spec = {
    title: '图deck',
    slides: [
      { kind: 'image', title: '竖版立绘', imagePath: await fixture('tall.png', tall), caption: '立绘' },
      { kind: 'gallery', title: '画廊', images: [{ path: await fixture('photo.jpg', photo), caption: '夏日' }] },
    ],
  };
  const entries = readZip(await buildPptx(spec));
  const media = [...entries.keys()].filter((name) => name.startsWith('ppt/media/'));
  assert.deepEqual(media, ['ppt/media/image1.png', 'ppt/media/image2.jpeg']);
  assert.ok(entries.get('ppt/media/image1.png').data.equals(tall), 'a PNG is stored byte for byte');
  assert.ok(entries.get('ppt/media/image2.jpeg').data.equals(photo), 'a JPEG is stored byte for byte');

  for (const index of [1, 2]) {
    const rels = slideRels(entries, index);
    const embeds = [...slideXml(entries, index).matchAll(/r:embed="(rId\d+)"/g)].map((match) => match[1]);
    assert.ok(embeds.length > 0);
    for (const embed of embeds) {
      const rel = rels.get(embed);
      assert.ok(rel, `slide ${index}: ${embed} has a relationship`);
      assert.match(rel.type, /\/image$/);
      assert.ok(entries.has(resolveMedia(rel.target)), `${embed} points at ${resolveMedia(rel.target)}`);
    }
  }
});

test('content types declare both media defaults and override every XML part', async () => {
  const spec = { slides: [{ kind: 'image', imagePath: await fixture('ct.png', png(300, 400, 'ct')) }] };
  const entries = readZip(await buildPptx(spec));
  const types = text(entries, '[Content_Types].xml');
  assert.match(types, /<Default Extension="jpeg" ContentType="image\/jpeg"\/>/);
  assert.match(types, /<Default Extension="png" ContentType="image\/png"\/>/);
  assert.match(types, /<Default Extension="rels" ContentType="application\/vnd\.openxmlformats-package\.relationships\+xml"\/>/);
  assert.match(types, /<Default Extension="xml" ContentType="application\/xml"\/>/);
  for (const name of entries.keys()) {
    if (!name.endsWith('.xml') || name === '[Content_Types].xml') continue;
    assert.ok(types.includes(`<Override PartName="/${name}"`), `missing Override for ${name}`);
  }
  const overrides = [...types.matchAll(/<Override /g)].length;
  assert.equal(overrides, 6, 'presentation, master, layout, theme, core and the one slide');
});

test('slide count, slide order and the rId chain all agree', async () => {
  const entries = readZip(await buildPptx(TEXT_SPEC));
  const presentation = text(entries, 'ppt/presentation.xml');
  const ids = [...presentation.matchAll(/<p:sldId id="\d+" r:id="(rId\d+)"\/>/g)].map((match) => match[1]);
  assert.equal(ids.length, TEXT_SPEC.slides.length);
  assert.deepEqual(ids, ['rId2', 'rId3', 'rId4'], 'slide rIds start after the master and stay contiguous');
  const used = [...presentation.matchAll(/r:id="(rId\d+)"/g)].map((match) => match[1]);
  const rels = relationships(text(entries, 'ppt/_rels/presentation.xml.rels'));
  for (const id of used) assert.ok(rels.has(id), `${id} is resolved by presentation.xml.rels`);
  assert.equal(rels.get('rId1').target, 'slideMasters/slideMaster1.xml');
  assert.equal(rels.get(`rId${TEXT_SPEC.slides.length + 2}`).target, 'theme/theme1.xml');
  for (let index = 1; index <= TEXT_SPEC.slides.length; index += 1) {
    assert.equal(rels.get(`rId${index + 1}`).target, `slides/slide${index}.xml`);
  }
});

test('the same spec twice produces byte-identical output', async () => {
  const spec = {
    ...TEXT_SPEC,
    slides: [...TEXT_SPEC.slides, { kind: 'image', imagePath: await fixture('once.png', png(600, 1200, 'deterministic')), caption: '同一张' }],
  };
  const first = await buildPptx(spec);
  const second = await buildPptx(spec);
  assert.equal(Buffer.compare(first, second), 0);
  assert.equal(first.length, second.length);
});

test('the embedded frame keeps the original aspect ratio within 1%', async () => {
  const spec = {
    slides: [
      { kind: 'image', imagePath: await fixture('wide.jpg', jpeg(1600, 900, 'ratio')) },
      { kind: 'image', imagePath: await fixture('portrait.png', png(900, 1600, 'ratio')) },
    ],
  };
  const entries = readZip(await buildPptx(spec));
  const expected = [1600 / 900, 900 / 1600];
  for (const index of [1, 2]) {
    const [picture] = pictures(slideXml(entries, index));
    const actual = picture.cx / picture.cy;
    assert.ok(
      Math.abs(actual - expected[index - 1]) <= expected[index - 1] * 0.01,
      `slide ${index}: ${actual} vs ${expected[index - 1]}`,
    );
    assert.ok(picture.cx <= SLIDE_W && picture.cy <= SLIDE_H, 'the frame stays on the canvas');
    assert.ok(picture.cx > 0 && picture.cy > 0);
  }
  const [wide] = pictures(slideXml(entries, 1));
  assert.equal(wide.cy, SLIDE_H - MARGIN_Y * 2, 'a landscape picture is limited by the height');
});

test('an image slide without a title uses the whole canvas height', async () => {
  const spec = { slides: [{ kind: 'image', imagePath: await fixture('notitle.png', png(600, 1200, 'notitle')) }] };
  const entries = readZip(await buildPptx(spec));
  const [picture] = pictures(slideXml(entries, 1));
  assert.equal(picture.cy, SLIDE_H - MARGIN_Y * 2);
  assert.equal(picture.y, MARGIN_Y);
  assert.equal(picture.x, Math.round((SLIDE_W - picture.cx) / 2));
});

test('a gallery lays its pictures out in rows and columns', async () => {
  const paths = [];
  for (const name of ['g1.png', 'g2.png', 'g3.png']) {
    paths.push(await fixture(name, png(400, 600, name)));
  }
  const spec = {
    slides: [{
      kind: 'gallery',
      title: '三连拍',
      columns: 2,
      images: paths.map((path, index) => ({ path, caption: `第${index + 1}张` })),
    }],
  };
  const entries = readZip(await buildPptx(spec));
  const xml = slideXml(entries, 1);
  const frames = pictures(xml);
  assert.equal(frames.length, 3);
  assert.equal(new Set(frames.map((frame) => frame.y)).size, 2, 'two columns means two rows');
  assert.equal(new Set(frames.map((frame) => frame.x)).size, 2);
  assert.match(xml, /第1张/);
  assert.match(xml, /第3张/);
  assert.deepEqual(
    [...entries.keys()].filter((name) => name.startsWith('ppt/media/')),
    ['ppt/media/image1.png', 'ppt/media/image2.png', 'ppt/media/image3.png'],
  );
  assert.equal(slideRels(entries, 1).size, 3);
  assert.deepEqual(new Set(frames.map((frame) => frame.embed)), new Set(['rId1', 'rId2', 'rId3']));
});

test('a GIF or a text file is refused with a Chinese message', async () => {
  const badGif = await fixture('animation.gif', gif(16, 16));
  const badText = await fixture('notes.txt', Buffer.from('这其实是一段文字，不是图片。'));
  await assert.rejects(() => buildPptx({ slides: [{ kind: 'image', imagePath: badGif }] }), (error) => {
    assert.match(error.message, /只支持/);
    assert.match(error.message, /^Unsupported image /);
    assert.ok(error.message.includes(badGif));
    return true;
  });
  await assert.rejects(() => buildPptx({ slides: [{ kind: 'gallery', images: [{ path: badText }] }] }), /只支持/);
  await assert.rejects(
    () => buildPptx({ slides: [{ kind: 'image', imagePath: '/definitely/missing.png' }] }),
    (error) => error.code === 'ENOENT',
  );
});

test('a text-only deck builds with no media and empty slide relationships', async () => {
  const entries = readZip(await buildPptx({ title: '只有文字', slides: [{ kind: 'bullets', title: '无图', bullets: ['一', '二'] }] }));
  assert.deepEqual([...entries.keys()].filter((name) => name.startsWith('ppt/media/')), []);
  assert.match(text(entries, 'ppt/slides/_rels/slide1.xml.rels'), /^<\?xml [^>]*\?>\n<Relationships xmlns="[^"]+"\/>$/);
  assert.ok(!/r:embed=/.test(slideXml(entries, 1)));
});

test('an empty or unknown-shaped spec still yields a readable package', async () => {
  const empty = readZip(await buildPptx({ slides: [] }));
  assert.ok(empty.has('ppt/presentation.xml'));
  assert.match(text(empty, 'ppt/presentation.xml'), /<p:sldIdLst\/>/);
  assert.ok(!empty.has('ppt/slides/slide1.xml'));
  const loose = readZip(await buildPptx(undefined));
  assert.ok(loose.has('[Content_Types].xml'));
  assert.match(text(loose, 'ppt/_rels/presentation.xml.rels'), /theme/);
  assert.match(text(loose, 'ppt/presentation.xml'), /<p:sldSz cx="12192000" cy="6858000"\/>/);
});

test('every entry is deflated, CRC32-clean and stamped 1980-01-01', async () => {
  const entries = readZip(await buildPptx(TEXT_SPEC));
  assert.ok(entries.size >= 12);
  for (const entry of entries.values()) {
    assert.equal(entry.method, 8, `${entry.name}: deflate`);
    assert.equal(crc32(entry.data), entry.checksum, `${entry.name}: CRC32 round trips`);
    assert.equal(entry.time, 0, `${entry.name}: no clock is stored`);
    assert.equal(entry.date, 0x0021, `${entry.name}: fixed 1980-01-01 DOS date`);
  }
});

test('author and createdAt only appear when the spec supplies them', async () => {
  const bare = readZip(await buildPptx(TEXT_SPEC));
  const core = text(bare, 'docProps/core.xml');
  assert.match(core, /<dc:title>角色设定集<\/dc:title>/);
  assert.match(core, /<dc:creator>dsh-persona-book<\/dc:creator>/);
  assert.doesNotMatch(core, /dcterms:created/, 'no clock is written unless asked');
  assert.match(text(bare, '_rels/.rels'), /docProps\/core\.xml/);

  const stampedSpec = { ...TEXT_SPEC, createdAt: '2024-05-06T07:08:09Z' };
  const stamped = readZip(await buildPptx(stampedSpec));
  assert.match(
    text(stamped, 'docProps/core.xml'),
    /<dcterms:created xsi:type="dcterms:W3CDTF">2024-05-06T07:08:09Z<\/dcterms:created>/,
  );
  assert.equal(Buffer.compare(await buildPptx(stampedSpec), await buildPptx(stampedSpec)), 0);
});
