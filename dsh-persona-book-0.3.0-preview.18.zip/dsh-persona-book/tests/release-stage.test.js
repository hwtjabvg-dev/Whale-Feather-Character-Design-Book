import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm,cp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {generateKeyPairSync,sign,createHash} from 'node:crypto';

async function fixture(t){
 const dir=await mkdtemp(join(tmpdir(),'pb-stage-'));t.after(()=>rm(dir,{recursive:true,force:true}));
 const site=join(dir,'site'),release=join(dir,'release');await mkdir(join(site,'.openai'),{recursive:true});await mkdir(join(site,'dist'));await mkdir(release);
 await writeFile(join(site,'.openai/hosting.json'),JSON.stringify({project_id:'private-site',static:{directory:'dist'}}));
 await writeFile(join(site,'dist/index.html'),'existing private site');await writeFile(join(site,'dist/release-info.json'),JSON.stringify({version:'0.3.0-preview.7'}));
 const keys=generateKeyPairSync('ed25519'),channel={private:true,url:'https://example.com/latest.json',publicKey:keys.publicKey.export({type:'spki',format:'pem'})};
 const bytes=Buffer.from('test release archive'),name='dsh-persona-book-0.3.0-preview.11.zip';
 const payload=Buffer.from(JSON.stringify({format:'persona-book-update/v1',name:'dsh-persona-book',version:'0.3.0-preview.11',notes:'tested change',package:{url:name,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')}}));
 await writeFile(join(release,name),bytes);await writeFile(join(release,'latest.json'),JSON.stringify({payload:payload.toString('base64'),signature:sign(null,payload,keys.privateKey).toString('base64')}));
 return {site,release,channel,name,options:{siteRoot:site,releaseDirectory:release,channel,projectId:'private-site',expectedVersion:'0.3.0-preview.11'}};
}
async function loadStage(){const module=await import('../tools/stage-update-site.mjs').catch(()=>({}));assert.equal(typeof module.stageRelease,'function','signed release staging must be available');return module.stageRelease;}
test('a signed release stages the matching catalog, package and notes together',async t=>{
 const f=await fixture(t),stage=await loadStage(),r=await stage(f.options);
 assert.equal(r.version,'0.3.0-preview.11');assert.equal(r.published,false);
 assert.equal(await readFile(join(f.site,'dist/index.html'),'utf8'),'existing private site');
 assert.equal(JSON.parse(await readFile(join(f.site,'dist/release-info.json'),'utf8')).package,f.name);
 assert.equal(await readFile(join(f.site,'dist',f.name),'utf8'),'test release archive');
});
test('tampered package leaves the old live-source catalog intact',async t=>{
 const f=await fixture(t),stage=await loadStage();await writeFile(join(f.release,f.name),'corrupt');
 await assert.rejects(stage(f.options),/校验/);
 assert.equal(JSON.parse(await readFile(join(f.site,'dist/release-info.json'),'utf8')).version,'0.3.0-preview.7');
});
test('publishing cannot redirect to another site or silently roll back versions',async t=>{
 const f=await fixture(t),stage=await loadStage();
 await assert.rejects(stage({...f.options,projectId:'other-site'}),/站点/);
 await writeFile(join(f.site,'dist/release-info.json'),JSON.stringify({version:'0.3.0-preview.12'}));
 await assert.rejects(stage(f.options),/版本/);
});
test('signature, version and private channel are checked before touching site files',async t=>{
 const f=await fixture(t),stage=await loadStage();
 await assert.rejects(stage({...f.options,channel:{...f.channel,private:null}}),/明确声明/);
 await assert.rejects(stage({...f.options,expectedVersion:'0.3.0-preview.10'}),/版本/);
 const e=JSON.parse(await readFile(join(f.release,'latest.json'),'utf8'));e.signature=Buffer.alloc(64).toString('base64');await writeFile(join(f.release,'latest.json'),JSON.stringify(e));
 await assert.rejects(stage(f.options),/签名/);
 assert.equal(JSON.parse(await readFile(join(f.site,'dist/release-info.json'),'utf8')).version,'0.3.0-preview.7');
});
test('a private runtime site stages release files separately from Worker build output',async t=>{
 const f=await fixture(t),stage=await loadStage();await cp(join(f.site,'dist'),join(f.site,'release-assets'),{recursive:true});await writeFile(join(f.site,'.openai/hosting.json'),JSON.stringify({project_id:'private-site',r2:'RELEASES'}));
 const r=await stage(f.options);assert.equal(r.assetDirectory,join(f.site,'release-assets'));assert.equal(JSON.parse(await readFile(join(f.site,'release-assets/release-info.json'),'utf8')).version,'0.3.0-preview.11');assert.equal(JSON.parse(await readFile(join(f.site,'dist/release-info.json'),'utf8')).version,'0.3.0-preview.7');
});
