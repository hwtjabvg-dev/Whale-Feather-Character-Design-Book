import test from 'node:test';import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,rm} from 'node:fs/promises';import {join} from 'node:path';import {tmpdir} from 'node:os';import {createServer} from 'node:http';import {generateKeyPairSync,createHash,sign} from 'node:crypto';import {writeZip} from '../lib/zip.js';
const hash=b=>createHash('sha256').update(b).digest('hex');
async function module(){const m=await import('../mobile/online-install.mjs').catch(()=>({}));assert.equal(typeof m.installOnline,'function','online installer must be implemented');return m;}
async function fixture(t,{corrupt=false,publicChannel=false}={}){
 const dir=await mkdtemp(join(tmpdir(),'whale-online-'));t.after(()=>rm(dir,{recursive:true,force:true}));
 const keys=generateKeyPairSync('ed25519'),publicKey=keys.publicKey.export({type:'spki',format:'pem'}),version='0.3.0-preview.14',token='private-test-authorization',seen=[];
 let channel;const server=createServer((req,res)=>{seen.push(req.headers['oai-sites-authorization']);if(!publicChannel&&req.headers['oai-sites-authorization']!=='Bearer '+token){res.writeHead(401).end();return;}const files=[['package.json',JSON.stringify({name:'dsh-persona-book',version,main:'lib/index.js',dsh:{client:{platform:'web'}}})],['lib/index.js','export const name="dsh-persona-book"'],['lib/client.js','/* client */'],['cordis.patch.yml','- insert: []'],['app/public/app.js','/* ui */'],['resources/update-channel.json',JSON.stringify(channel)]].map(([path,data])=>({path,data:Buffer.from(data)}));const manifest={format:'dsh-persona-book-directory/v1',version,files:files.map(f=>({path:f.path,bytes:f.data.length,sha256:hash(f.data)}))};files.push({path:'mobile/package-manifest.json',data:Buffer.from(JSON.stringify(manifest))});const zip=writeZip(files.map(f=>({name:'dsh-persona-book/'+f.path,data:f.data}))),payload=Buffer.from(JSON.stringify({format:'persona-book-update/v1',name:'dsh-persona-book',version,package:{url:'package.zip',bytes:zip.length,sha256:corrupt?'0'.repeat(64):hash(zip)}}));res.end(req.url==='/latest.json'?JSON.stringify({payload:payload.toString('base64'),signature:sign(null,payload,keys.privateKey).toString('base64')}):zip);});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{server.closeAllConnections();server.close(r);}));channel={private:!publicChannel,url:'http://127.0.0.1:'+server.address().port+'/latest.json',publicKey};
 const home=join(dir,'home'),dshHome=join(dir,'host'),authorizationFile=join(dir,'whale-device-access.json');await mkdir(home);await writeFile(authorizationFile,JSON.stringify({format:'whale-device-authorization/v1',origin:new URL(channel.url).origin,token}));let calls=0;
 const options={home,dshHome,channel,authorizationFile,register:async()=>{calls++;return {registered:true,configurationVerified:true,activationVerified:true};}};
 return {options,home,dir,token,seen,authorizationFile,get calls(){return calls;}};
}
test('private online install verifies signed package, registers DSH and keeps data outside plugin',async t=>{
 const f=await fixture(t),{installOnline}=await module();const result=await installOnline(f.options);
 assert.equal(result.version,'0.3.0-preview.14');assert.equal(result.registered,true);assert.equal(f.calls,1);assert.equal(JSON.parse(await readFile(join(result.pluginRoot,'package.json'),'utf8')).name,'dsh-persona-book');assert.ok(!result.dataDir.startsWith(result.pluginRoot));assert.equal(JSON.parse(await readFile(join(result.dataDir,'updates/access.json'),'utf8')).token,f.token);assert.ok(!JSON.stringify(result).includes(f.token));assert.ok(f.seen.every(h=>h==='Bearer '+f.token));
 const again=await installOnline(f.options);assert.equal(again.alreadyInstalled,true);assert.equal(f.calls,2);
});
test('corrupt remote package never registers a plugin or replaces user data',async t=>{
 const f=await fixture(t,{corrupt:true}),{installOnline}=await module();const personal=join(f.home,'.dsh/persona-book/.play');await mkdir(personal,{recursive:true});await writeFile(join(personal,'state.json'),'existing user data');
 await assert.rejects(installOnline(f.options),/校验/);assert.equal(f.calls,0);assert.equal(await readFile(join(personal,'state.json'),'utf8'),'existing user data');
});
test('authorization origin is checked and secrets are not accepted through arbitrary URLs',async t=>{
 const f=await fixture(t),{installOnline}=await module();await writeFile(f.authorizationFile,JSON.stringify({format:'whale-device-authorization/v1',origin:'https://wrong.example',token:f.token}));await assert.rejects(installOnline(f.options),/授权/);assert.equal(f.seen.length,0);
});
test('failed registration is reported and a retry uses verified files without destroying personal state',async t=>{
 const f=await fixture(t),{installOnline}=await module();await assert.rejects(installOnline({...f.options,register:async()=>{throw Error('宿主安装命令失败');}}),/宿主/);const result=await installOnline({...f.options,consumeAuthorization:true});assert.equal(result.registered,true);await assert.rejects(readFile(f.authorizationFile),{code:'ENOENT'});
});
test('password authorization upgrades an existing installation and saves the name discovery skill',async t=>{
 const f=await fixture(t),{installOnline}=await module();const first=await installOnline(f.options),pkgPath=join(first.pluginRoot,'package.json'),manifestPath=join(first.pluginRoot,'mobile/package-manifest.json');
 const pkg=JSON.parse(await readFile(pkgPath,'utf8'));pkg.version='0.3.0-preview.13';const bytes=Buffer.from(JSON.stringify(pkg));await writeFile(pkgPath,bytes);const manifest=JSON.parse(await readFile(manifestPath,'utf8'));manifest.version=pkg.version;const item=manifest.files.find(x=>x.path==='package.json');item.bytes=bytes.length;item.sha256=hash(bytes);await writeFile(manifestPath,JSON.stringify(manifest));
 await writeFile(join(first.dataDir,'personal.json'),'personal settings');const upgraded=await installOnline(f.options);
 assert.equal(upgraded.version,'0.3.0-preview.14');assert.equal(upgraded.updateAvailable,false);assert.equal(await readFile(join(first.dataDir,'personal.json'),'utf8'),'personal settings');
 assert.match(await readFile(join(f.home,'.agents/skills/whale-persona-book-install/SKILL.md'),'utf8'),/鲸语人设本/);
});

test('public online installation requires neither password nor authorization file',async t=>{
 const f=await fixture(t,{publicChannel:true}),{installOnline}=await module();const result=await installOnline({...f.options,authorizationFile:undefined});assert.equal(result.registered,true);assert.equal(result.configurationVerified,true);assert.ok(f.seen.every(x=>x===undefined));await assert.rejects(readFile(join(result.dataDir,'updates/access.json')),{code:'ENOENT'});
});

test('failed host preflight stops before any remote package request',async t=>{
 const f=await fixture(t,{publicChannel:true}),{installOnline}=await module();
 await assert.rejects(installOnline({...f.options,register:undefined,executable:process.execPath,entry:['-e','process.exit(3)','--']}),/DSH/);
 assert.equal(f.seen.length,0);
});
test('offline installer copies to persistent host storage and needs no network',async t=>{
 const f=await fixture(t,{publicChannel:true}),{installOnline}=await module(),first=await installOnline(f.options);
 const {installLocal}=await import('../mobile/install-local.mjs');const before=f.seen.length;
 const result=await installLocal({source:first.pluginRoot,dshHome:join(f.dir,'offline-host'),command:{executable:process.execPath,entry:['-e','process.exit(0)','--']},register:async()=>({registered:true,configurationVerified:true})});
 assert.equal(result.offline,true);assert.equal(result.configurationVerified,true);assert.notEqual(result.pluginRoot,first.pluginRoot);
 assert.equal(f.seen.length,before);assert.equal(JSON.parse(await readFile(join(result.pluginRoot,'package.json'),'utf8')).version,first.version);
});
