import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {resolveHostCommand,runHostCommand} from '../mobile/host-command.mjs';
test('Android host wrapper is found without requiring an additional Node installation',async t=>{
 const root=await mkdtemp(join(tmpdir(),'whale-host-'));t.after(()=>rm(root,{recursive:true,force:true}));
 await mkdir(join(root,'bin'));await writeFile(join(root,'bin/dsh'),'#!/system/bin/sh');
 const found=await resolveHostCommand({home:root,env:{PATH:join(root,'bin')},platform:'android'});
 assert.equal(found.executable,join(root,'bin/dsh'));assert.deepEqual(found.entry,[]);
});
test('host command keeps arguments literal and excludes legacy authorization',async()=>{
 const output=await runHostCommand({executable:process.execPath,entry:['-e','console.log(JSON.stringify({args:process.argv.slice(1),token:process.env.DSH_PERSONA_BOOK_UPDATE_TOKEN}))','--']},['link:a path;literal'],{env:{...process.env,DSH_PERSONA_BOOK_UPDATE_TOKEN:'do-not-forward'}});
 assert.deepEqual(JSON.parse(output),{args:['link:a path;literal']});
});
test('stuck host command times out instead of hanging installation',async()=>{
 await assert.rejects(runHostCommand({executable:process.execPath,entry:['-e','setInterval(()=>{},1000)']},[],{timeout:150}),/超时/);
});
test('explicit host command is respected',async()=>{
 assert.deepEqual(await resolveHostCommand({executable:'existing-host',entry:['--flag','entry.js']}),{executable:'existing-host',entry:['--flag','entry.js']});
});
