/**
 * Route tests: mount the plugin against a fake Cordis context and a real HTTP
 * server on an ephemeral port, then exercise the panel's whole surface —
 * snapshot, master switch, persona CRUD, tone levels, docs and diagnostics.
 */
import { createServer } from 'node:http';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import test, { after } from 'node:test';

const sandbox = await mkdtemp(join(tmpdir(), 'persona-book-routes-'));
process.env.DSH_PERSONA_BOOK_DIR = join(sandbox, 'personas');
process.env.DSH_AGENTS_HOME = join(sandbox, 'agents');

const plugin = await import('../lib/index.js');

const routes = [];

/** Minimal host context: enough for `apply` to register its routes. */
const ctx = {
  inject(_deps, fn) {
    return fn({
      effect(fn2) {
        return fn2();
      },
      webServer: {
        register(route) {
          routes.push({ kind: route.kind, path: route.path, handler: route.handler });
        },
      },
      connection: { requestRejection: () => undefined },
    });
  },
};

plugin.apply(ctx);
assert.ok(routes.length >= 3, 'expected the plugin to register its routes');

/** Route lookup that mirrors the host server: exact first, then longest prefix. */
const lookup = (pathname) => {
  const exact = routes.find((route) => route.kind === 'exact' && route.path === pathname);
  if (exact !== undefined) return exact.handler;
  let best;
  for (const route of routes) {
    if (route.kind !== 'prefix') continue;
    if (pathname !== route.path && !pathname.startsWith(`${route.path}/`)) continue;
    if (best === undefined || route.path.length > best.path.length) best = route;
  }
  return best?.handler;
};

const server = createServer((req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname.replace(/\/+$/, '');
  const handler = lookup(pathname);
  if (handler === undefined) {
    res.writeHead(404).end('no route');
    return;
  }
  void handler(req, res);
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const base = `http://127.0.0.1:${server.address().port}`;

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  await rm(sandbox, { recursive: true, force: true });
});

const get = async (path) => {
  const response = await fetch(`${base}${path}`);
  return { status: response.status, body: await response.json() };
};

const post = async (path, payload) => {
  const response = await fetch(`${base}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return { status: response.status, body: await response.json() };
};

const upload = async (path, bytes, name) => {
  const response = await fetch(`${base}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: bytes,
  });
  void name;
  return { status: response.status, body: await response.json() };
};

const put = async (path, payload) => {
  const response = await fetch(`${base}${path}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return { status: response.status, body: await response.json() };
};

test('snapshot: fresh install creates defaults and one persona', async () => {
  const { status, body } = await get('/api/persona-book');
  assert.equal(status, 200);
  assert.equal(body.profiles.masterOn, true);
  assert.equal(body.personas.length >= 1, true);
  assert.equal(body.builtin.materials.frosted.blurPx, 30);
  assert.equal(body.builtin.apple.regular.opacity, 0.55);
  assert.equal(body.builtin.wallpapers.length, 8);
  assert.equal(body.builtin.cues.length, 8);
  assert.equal(body.docs.length, 3);
  assert.ok(Array.isArray(body.problems));
});

test('bubble + material settings round-trip through setUi', async () => {
  const snapshot = await get('/api/persona-book');
  const rev = snapshot.body.rev;
  const { status, body } = await put('/api/persona-book', {
    action: 'setUi',
    baseRev: rev,
    section: 'bubble',
    patch: { on: true, style: 'qq', shape: { cornerRadius: 22 } },
  });
  assert.equal(status, 200);
  assert.equal(body.ui.bubble.style, 'qq');
  assert.equal(body.ui.bubble.shape.cornerRadius, 22);
  assert.equal(body.ui.bubble.shape.maxWidthPct, 75, 'untouched defaults survive the patch');

  const again = await get('/api/persona-book');
  assert.equal(again.body.profiles.ui.bubble.on, true);
});

test('the panel language travels with the profile and unknown ones land back on Chinese', async () => {
  const snapshot = await get('/api/persona-book');
  assert.equal(snapshot.body.profiles.ui.panel.lang, 'zh', '默认中文');
  const en = await put('/api/persona-book', {
    action: 'setUi',
    baseRev: snapshot.body.rev,
    section: 'panel',
    patch: { lang: 'en' },
  });
  assert.equal(en.status, 200);
  assert.equal(en.body.ui.panel.lang, 'en');
  assert.equal(en.body.ui.panel.width, 900, '同一节里别的设置不受影响');

  const again = await get('/api/persona-book');
  assert.equal(again.body.profiles.ui.panel.lang, 'en', '写进配置，重启后还在');

  const auto = await put('/api/persona-book', {
    action: 'setUi',
    baseRev: again.body.rev,
    section: 'panel',
    patch: { lang: 'auto' },
  });
  assert.equal(auto.body.ui.panel.lang, 'auto', '跟随浏览器也是合法值');
});

test('stale revisions are refused with 409', async () => {
  const { status, body } = await put('/api/persona-book', { action: 'setMaster', on: false, baseRev: 0 });
  assert.equal(status, 409);
  assert.equal(body.error.code, 'ESTALE');
});

test('master switch parks and restores the generated skill', async () => {
  const snapshot = await get('/api/persona-book');
  const created = await put('/api/persona-book', { action: 'createPersona', id: 'route-demo', title: '路由演示' });
  assert.equal(created.status, 200);
  const active = created.body.active;
  assert.equal(active, 'route-demo');

  const off = await put('/api/persona-book', { action: 'setMaster', on: false, baseRev: created.body.rev });
  assert.equal(off.status, 200);
  assert.equal(off.body.masterOn, false);

  const parked = await get('/api/persona-book/diagnose');
  assert.equal(parked.status, 200);
  assert.equal(parked.body.counts.installed, 0);
  assert.equal(parked.body.counts.parked >= 1, true);

  const on = await put('/api/persona-book', { action: 'setMaster', on: true, baseRev: off.body.rev });
  assert.equal(on.status, 200);
  const diagnosis = await get('/api/persona-book/diagnose');
  assert.equal(diagnosis.body.counts.installed >= 1, true);
  assert.match(diagnosis.body.version, /^\d+\.\d+\.\d+/);
  assert.equal(typeof snapshot.body.rev, 'number');
});

test('persona CRUD: update tone levels, then delete', async () => {
  const update = await put('/api/persona-book', {
    action: 'updatePersona',
    id: 'route-demo',
    def: {
      title: '路由演示 · 改',
      levels: [
        { id: 'light', name: '轻', ratio: 0.3, intensity: 3 },
        { id: 'heavy', name: '重', ratio: 1, intensity: 9, examples: ['哼，人家才不管呢。'] },
      ],
    },
  });
  assert.equal(update.status, 200);
  assert.equal(update.body.persona.title, '路由演示 · 改');
  assert.equal(update.body.persona.levels.length, 2);

  const snapshot = await get('/api/persona-book');
  const row = snapshot.body.personas.find((entry) => entry.id === 'route-demo');
  assert.deepEqual(
    row.levels.map((level) => level.name),
    ['轻', '重'],
  );

  const removed = await put('/api/persona-book', { action: 'deletePersona', id: 'route-demo' });
  assert.equal(removed.status, 200);
  const after = await get('/api/persona-book');
  assert.equal(after.body.personas.some((entry) => entry.id === 'route-demo'), false);
});

test('importing a SKILL.md creates a persona, conflicts get a suffix', async () => {
  const text = [
    '---',
    'name: imported-kitten',
    'description: 从别的 AI 搬来的小猫腔。',
    'whenToUse: 用户点名要小猫腔时。',
    'metadata:',
    '  persona:',
    '    schemaVersion: 1',
    '    title: 搬来的小猫',
    '    emoji: 🐱',
    '    version: 1.0.0',
    '    source: import',
    '---',
    '',
    '# 搬来的小猫',
    '',
    '## 身份',
    '- 自称：人家',
    '- 称呼用户：主人',
    '- 语言：zh-CN',
    '',
    '## 默认设定',
    '- 句尾习惯：喵',
    '- 默认强度：6/10',
    '- 表情政策：sparse',
    '- 情绪用词：无',
    '- 口头禅：哼',
    '- 忌讳：无',
    '',
    '## 语气档位',
    '',
    '| id | 名称 | 触发 | 强度 | 比例 |',
    '| --- | --- | --- | --- | --- |',
    '| light | 轻 | 闲聊 | 3 | 0.3 |',
    '',
    '## 硬边界（不可删）',
    '- 不替换助手身份',
    '',
    '## 锚点',
    '- 视觉：无',
    '- 语气：自称人家',
    '',
  ].join('\n');

  const first = await put('/api/persona-book', { action: 'importSkillText', text });
  assert.equal(first.status, 200);
  assert.equal(first.body.id, 'imported-kitten');

  const second = await put('/api/persona-book', { action: 'importSkillText', text });
  assert.equal(second.body.id, 'imported-kitten-2');

  const snapshot = await get('/api/persona-book');
  const imported = snapshot.body.personas.find((entry) => entry.id === 'imported-kitten');
  assert.equal(imported.title, '搬来的小猫');
});

test('bad input is rejected in Chinese with a stable code', async () => {
  const badId = await put('/api/persona-book', { action: 'createPersona', id: '坏 id' });
  assert.equal(badId.status, 400);
  assert.equal(badId.body.error.code, 'EINVALID');
  assert.match(badId.body.error.message, /英文小写字母/);

  const unknown = await put('/api/persona-book', { action: 'nope' });
  assert.equal(unknown.status, 400);
  assert.equal(unknown.body.error.code, 'EBADREQ');

  const missing = await get('/api/persona-book/docs?doc=nope');
  assert.equal(missing.status, 404);

  const wrongMethod = await fetch(`${base}/api/persona-book`, { method: 'DELETE' });
  assert.equal(wrongMethod.status, 405);
});

test('cross-origin requests are refused', async () => {
  const response = await fetch(`${base}/api/persona-book`, { headers: { Origin: 'http://evil.example' } });
  assert.equal(response.status, 403);
  const body = await response.json();
  assert.equal(body.error.code, 'EORIGIN');
});

test('the manual is served like any other document', async () => {
  const { status, body } = await get('/api/persona-book/docs?doc=manual');
  assert.equal(status, 200);
  assert.match(body.doc.text, /使用手册/);
  assert.match(body.doc.text, /导入导出/);
  const missing = await get('/api/persona-book/docs?doc=nope');
  assert.equal(missing.status, 404);
});

test('docs route serves the character sheet for the advanced tab', async () => {
  const { status, body } = await get('/api/persona-book/docs?doc=book');
  assert.equal(status, 200);
  assert.equal(body.doc.id, 'book');
  assert.equal(body.doc.missing, false);
  assert.ok(body.doc.text.length > 100);
});

test('theme.css serves the deterministic skin sheet, and only to the right method', async () => {
  const first = await fetch(`${base}/api/persona-book/theme.css?rev=1`);
  assert.equal(first.status, 200);
  assert.match(first.headers.get('content-type') ?? '', /^text\/css/);
  const css = await first.text();
  assert.ok(css.includes(':root {'), 'the variable block is appended');
  assert.ok(css.includes('--pb-bub-r:'), 'the bubbble radius variable is present');
  assert.ok(!css.includes('!important'), 'no forced overrides');

  const second = await fetch(`${base}/api/persona-book/theme.css?rev=1`);
  assert.equal(await second.text(), css, 'same revision, same bytes');

  const wrongMethod = await fetch(`${base}/api/persona-book/theme.css`, { method: 'POST' });
  assert.equal(wrongMethod.status, 405);

  const crossOrigin = await fetch(`${base}/api/persona-book/theme.css`, { headers: { Origin: 'http://evil.example' } });
  assert.equal(crossOrigin.status, 403);
});

test('the snapshot carries the preset tables the appearance tab renders from', async () => {
  const { status, body } = await get('/api/persona-book');
  assert.equal(status, 200);
  const presets = body.presets;
  assert.ok(Object.keys(presets.themes).length >= 4, 'theme table');
  assert.ok(presets.shapes.radius.min >= 0, 'shape ranges');
  assert.ok(presets.material.frosted.blurPx > 0, 'material ladder');
  assert.ok(presets.apple.thin.opacity > 0, 'apple ladder');
  assert.equal(presets.defaults.bubble.shape.cornerRadius, 18, 'defaults stay factory-fresh while profiles.ui drifts');
  assert.equal(presets.defaults.material.blurPx, 30, 'the factory material numbers are exposed for the restore buttons');
});

test('uploading an asset streams the bytes in and serves them back immutably', async () => {
  const bytes = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.from('raster payload')]);
  const uploaded = await fetch(`${base}/api/persona-book/assets?kind=wallpaper&name=%E6%B5%B7%E6%99%AF.png`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: bytes,
  });
  assert.equal(uploaded.status, 200);
  const body = await uploaded.json();
  assert.equal(body.reused, false);
  assert.match(body.entry.id, /^w-[0-9a-f]{16}$/);
  assert.equal(body.entry.name, '海景.png');
  assert.ok(body.usage.files >= 1);

  const served = await fetch(`${base}${body.entry.url}`);
  assert.equal(served.status, 200);
  assert.equal(served.headers.get('content-type'), 'image/png');
  assert.equal(served.headers.get('cache-control'), 'public, max-age=31536000, immutable');
  assert.equal(Buffer.from(await served.arrayBuffer()).length, bytes.length);

  const cached = await fetch(`${base}${body.entry.url}`, { headers: { 'If-None-Match': served.headers.get('etag') } });
  assert.equal(cached.status, 304);

  const preview = await fetch(`${base}${body.entry.preview}`);
  assert.equal(preview.status, 200);

  const listed = await get('/api/persona-book/assets');
  assert.equal(listed.status, 200);
  assert.equal(listed.body.assets.wallpapers.some((row) => row.id === body.entry.id), true);

  const again = await fetch(`${base}/api/persona-book/assets?kind=wallpaper`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: bytes,
  });
  assert.equal((await again.json()).reused, true, 'the same bytes are one asset');

  const removed = await fetch(`${base}${body.entry.url}`, { method: 'DELETE' });
  assert.equal(removed.status, 200);
  assert.equal((await removed.json()).removed.id, body.entry.id);
  const gone = await fetch(`${base}${body.entry.url}`);
  assert.equal(gone.status, 404);
});

test('an upload the sniffer refuses answers with a code the panel can render', async () => {
  const response = await fetch(`${base}/api/persona-book/assets?kind=avatar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: Buffer.from('this is a text file, not a picture'),
  });
  assert.equal(response.status, 400);
  assert.equal((await response.json()).error.code, 'EUNSUPPORTED');
});

test('an asset id that does not exist is a 404, and bad methods are a 405', async () => {
  const missing = await fetch(`${base}/api/persona-book/assets/w-0000000000000000`);
  assert.equal(missing.status, 404);
  const wrong = await fetch(`${base}/api/persona-book/assets`, { method: 'DELETE' });
  assert.equal(wrong.status, 405);
  assert.equal((await wrong.json()).error.code, 'EMETHOD');
});

test('import: a SillyTavern card is recognised, then committed as a persona', async () => {
  const card = Buffer.from(
    JSON.stringify({ spec: 'chara_card_v2', data: { name: '来自星星的猫', description: '一只会修电脑的猫', personality: '懒散', first_mes: '喵？' } }),
    'utf8',
  );
  const dry = await fetch(`${base}/api/persona-book/import?name=star-cat.json`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: card,
  });
  assert.equal(dry.status, 200);
  const found = await dry.json();
  assert.equal(found.kind, 'stcard');
  assert.equal(found.persona.title, '来自星星的猫');
  assert.match(found.source, /角色卡/);
  assert.ok(Array.isArray(found.problems));
  assert.ok(found.preview.includes('chara_card_v2'));
  assert.equal(found.formats.length, 5);

  const committed = await post('/api/persona-book/import/commit', { token: found.token, name: found.name });
  assert.equal(committed.status, 200);
  assert.ok(committed.body.id.length > 0);
  const again = await post('/api/persona-book/import/commit', { token: found.token, name: found.name });
  assert.equal(again.status, 404, '令牌用过就没了');

  const snapshot = await get('/api/persona-book');
  const imported = snapshot.body.personas.find((row) => row.id === committed.body.id);
  assert.ok(imported, '新人设出现在快照里');
  assert.equal(imported.title, '来自星星的猫');
});

test('import: the same card twice gets a fresh id instead of a 409', async () => {
  const text = Buffer.from('自称：人家\n句尾：喵\n# 傲娇小猫', 'utf8');
  const one = await fetch(`${base}/api/persona-book/import?name=cat.txt`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: text,
  }).then((response) => response.json());
  const first = await post('/api/persona-book/import/commit', { token: one.token, name: one.name });
  assert.equal(first.status, 200);
  const two = await fetch(`${base}/api/persona-book/import?name=cat.txt`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: text,
  }).then((response) => response.json());
  const second = await post('/api/persona-book/import/commit', { token: two.token, name: two.name });
  assert.equal(second.status, 200);
  assert.notEqual(second.body.id, first.body.id, '重名会自动加后缀');
  assert.equal(second.body.id, `${first.body.id}-2`);
});

test('import: rubbish, unknown formats and a stale token each say why', async () => {
  const junk = await fetch(`${base}/api/persona-book/import?name=x.bin`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: Buffer.from([0x00, 0x01, 0x02, 0x03]),
  });
  assert.equal(junk.status, 400);
  assert.equal((await junk.json()).error.code, 'EUNSUPPORTED');

  const empty = await fetch(`${base}/api/persona-book/import?name=x.bin`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: Buffer.alloc(0),
  });
  assert.equal(empty.status, 400);

  const stale = await post('/api/persona-book/import/commit', {
    token: '00000000-0000-4000-8000-000000000000',
    name: 'x.json',
  });
  assert.equal(stale.status, 404);

  const badToken = await post('/api/persona-book/import/commit', { token: '../etc/passwd', name: 'x.json' });
  assert.equal(badToken.status, 400);
});

test('export: all five shapes come back as downloads with the right bytes', async () => {
  const snapshot = await get('/api/persona-book');
  const id = snapshot.body.personas[0].id;

  for (const format of ['persona', 'skill', 'stcard', 'prompt', 'bundle']) {
    const response = await fetch(`${base}/api/persona-book/export?format=${format}&id=${encodeURIComponent(id)}`);
    assert.equal(response.status, 200, format);
    const disposition = response.headers.get('content-disposition') ?? '';
    assert.match(disposition, /attachment; filename\*=UTF-8''/, `${format} 是附件下载`);
    assert.match(disposition, new RegExp(format === 'persona' ? '\\.persona\\.json' : ''), `${format} 的文件名`);
    const bytes = Buffer.from(await response.arrayBuffer());
    assert.ok(bytes.length > 0, `${format} 有内容`);
    if (format === 'persona') assert.equal(JSON.parse(bytes.toString()).persona.id, id);
    if (format === 'stcard') assert.equal(JSON.parse(bytes.toString()).spec, 'chara_card_v2');
    if (format === 'bundle') {
      const { readZip } = await import('../lib/zip.js');
      const entries = readZip(bytes).map((entry) => entry.name);
      assert.deepEqual(entries, ['persona.json', 'SKILL.md', 'stcard.json', 'README.md']);
    }
  }

  const missing = await fetch(`${base}/api/persona-book/export?format=persona&id=nope`);
  assert.equal(missing.status, 404);
  const noId = await fetch(`${base}/api/persona-book/export?format=persona`);
  assert.equal(noId.status, 400);
  const weird = await fetch(`${base}/api/persona-book/export?format=nope&id=${encodeURIComponent(id)}`);
  assert.equal(weird.status, 400);
});

test('the deck downloads as a pptx, and only by GET', async () => {
  const response = await fetch(`${base}/api/persona-book/ppt`);
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type') ?? '', /presentationml/);
  assert.match(response.headers.get('content-disposition') ?? '', /attachment; filename\*=UTF-8''/);
  const bytes = Buffer.from(await response.arrayBuffer());
  assert.equal(bytes.subarray(0, 2).toString('latin1'), 'PK', 'a zip container');
  const { readZip } = await import('../lib/zip.js');
  const names = readZip(bytes).map((entry) => entry.name);
  assert.equal(names.filter((name) => /^ppt\/slides\/slide\d+\.xml$/.test(name)).length >= 3, true);
  const wrong = await fetch(`${base}/api/persona-book/ppt`, { method: 'POST' });
  assert.equal(wrong.status, 405);
});

test('uninstall parks the skills and says what is left to do', async () => {
  const snapshot = await get('/api/persona-book');
  const { status, body } = await put('/api/persona-book', { action: 'uninstall', baseRev: snapshot.body.rev });
  assert.equal(status, 200);
  assert.equal(body.masterOn, false);
  assert.equal(body.instructions.length, 3);
  assert.match(body.instructions.join(' '), /插件管理器/);
  const after = await get('/api/persona-book');
  assert.equal(after.body.profiles.masterOn, false);
});
