/**
 * Core tests: data contracts, SKILL.md round trip, media sniffing and the
 * repository's master switch. Runs against a sandbox directory, never the real
 * `~/.agents` tree.
 */
import { mkdtemp, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import test, { after, before } from 'node:test';

const sandbox = await mkdtemp(join(tmpdir(), 'persona-book-'));
process.env.DSH_PERSONA_BOOK_DIR = join(sandbox, 'personas');
process.env.DSH_AGENTS_HOME = join(sandbox, 'agents');

const { blankPersona, idProblem, normalizePersona, normalizeProfiles } = await import('../lib/schema.js');
const { renderSkill, parseSkill } = await import('../lib/generate.js');
const { probe, svgDanger, isExtreme } = await import('../lib/media.js');
const repo = await import('../lib/repo.js');

after(async () => {
  await rm(sandbox, { recursive: true, force: true });
});

/** A 1x1 PNG built by hand, so the probe test needs no fixture file. */
function tinyPng() {
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(25);
  ihdr.writeUInt32BE(13, 0);
  ihdr.write('IHDR', 4, 'latin1');
  ihdr.writeUInt32BE(2, 8);
  ihdr.writeUInt32BE(1, 12);
  return Buffer.concat([signature, ihdr]);
}

/** A JPEG header with an SOF0 marker declaring 4000x2000. */
function jpegHeader(width, height) {
  const buffer = Buffer.alloc(24);
  buffer[0] = 0xff;
  buffer[1] = 0xd8;
  buffer[2] = 0xff;
  buffer[3] = 0xc0;
  buffer.writeUInt16BE(17, 4);
  buffer[6] = 8;
  buffer.writeUInt16BE(height, 7);
  buffer.writeUInt16BE(width, 9);
  return buffer;
}

test('persona ids follow the skill name rule', () => {
  assert.equal(idProblem('kitten-arrogant'), null);
  assert.notEqual(idProblem('Bad Name'), null);
  assert.notEqual(idProblem('-leading'), null);
  assert.notEqual(idProblem(''), null);
});

test('normalizePersona fills every branch and keeps the author text', () => {
  const { value, problems } = normalizePersona({ id: 'demo', title: '演示', defaults: { catchphrases: ['喵'] } });
  assert.deepEqual(problems, []);
  assert.equal(value.id, 'demo');
  assert.deepEqual(value.defaults.catchphrases, ['喵']);
  assert.equal(value.identity.keepAssistantIdentity, true);
  assert.equal(value.levels.length, 0);
  assert.ok(value.defaults.boundaries.length >= 3);
});

test('profiles merge from defaults and reject an unknown material', () => {
  const { value, problems } = normalizeProfiles({ ui: { material: { kind: 'nope' }, bubble: { on: true } } });
  assert.equal(value.ui.bubble.on, true);
  assert.equal(value.ui.material.kind, 'frosted');
  assert.equal(problems.length, 1);
  assert.equal(value.ui.bubble.colors.mine, '#95EC69');
});

test('profiles keep only the new appearance shape, and say so in Chinese', () => {
  const { value, problems } = normalizeProfiles({
    ui: {
      appearance: {
        theme: 'cyber',
        bubble: { material: 'vapor', shape: 'triangle' },
        avatar: { shape: 'hexagon' },
        wallpaper: { id: 'builtin:deep-light', fit: 'mosaic', dim: 500, blur: -3, fullscreen: true },
      },
    },
  });
  assert.deepEqual(Object.keys(value.ui.appearance), ['theme', 'bubble', 'avatar', 'wallpaper']);
  assert.equal(value.ui.appearance.theme, 'deepsea');
  assert.equal(value.ui.appearance.bubble.material, 'transparent');
  assert.equal(value.ui.appearance.bubble.shape, 'round');
  assert.equal(value.ui.appearance.avatar.shape, 'circle');
  assert.equal(value.ui.appearance.wallpaper.fit, 'cover');
  assert.equal(value.ui.appearance.wallpaper.dim, 60);
  assert.equal(value.ui.appearance.wallpaper.blur, 0);
  assert.equal(value.ui.appearance.wallpaper.fullscreen, true);
  assert.ok(problems.length >= 5);
  for (const line of problems) assert.match(line, /[\u4e00-\u9fa5]/);
});

test('the retired deformer is dropped from old documents without an error', () => {
  const { value, problems } = normalizeProfiles({
    schemaVersion: 0,
    ui: {
      appearance: {
        deform: { radius: { preset: 'rect', px: 4 }, window: 'wallpaper' },
        style: { kind: 'plain' },
        shape: { radius: { preset: 'round', px: 14 } },
        background: { kind: 'wallpaper', dimPct: 40 },
        theme: { id: 'light', followSystem: true, accent: '#335C8D' },
      },
    },
  });
  assert.equal('deform' in value.ui.appearance, false);
  assert.equal('style' in value.ui.appearance, false);
  assert.equal('background' in value.ui.appearance, false);
  assert.equal('system' in value.ui.appearance, false);
  assert.equal(value.ui.appearance.theme, 'light');
  assert.equal(problems.length, 1);
  assert.match(problems[0], /变形器/);
});

test('blankPersona is ready to use', () => {
  const def = blankPersona('my-persona');
  assert.equal(def.levels.length, 3);
  assert.equal(def.schemaVersion, 2);
});

test('SKILL.md survives a render → parse round trip', () => {
  const def = blankPersona('kitten-arrogant', '傲娇小猫');
  def.summary = '嘴硬心软的小猫脾气。';
  def.defaults.sentenceEnders = ['喵', '嘛'];
  def.defaults.catchphrases = ['人家才不是……'];
  def.defaults.emotionWords = { happy: '尾巴翘起来' };
  def.levels[2].examples = ['人家才不会承认呢，喵！'];
  def.blocks = [{ id: 'block-1', title: '额外规则', body: '不确定的事要直说。' }];
  def.anchors = { visual: ['深海蓝长发', '白围裙'], voice: ['自称人家'] };
  const text = renderSkill(def);
  assert.match(text, /^---\nname: kitten-arrogant\n/);
  assert.match(text, /## 硬边界（不可删）/);

  const parsed = parseSkill(text);
  assert.deepEqual(parsed.problems, []);
  assert.equal(parsed.value.id, 'kitten-arrogant');
  assert.equal(parsed.value.title, '傲娇小猫');
  assert.equal(parsed.value.summary, def.summary);
  assert.deepEqual(parsed.value.defaults.sentenceEnders, ['喵', '嘛']);
  assert.deepEqual(parsed.value.defaults.catchphrases, ['人家才不是……']);
  assert.equal(parsed.value.defaults.emotionWords.happy, '尾巴翘起来');
  assert.equal(parsed.value.levels.length, 3);
  assert.deepEqual(parsed.value.levels[2].examples, ['人家才不会承认呢，喵！']);
  assert.equal(parsed.value.blocks[0].title, '额外规则');
  assert.deepEqual(parsed.value.anchors.visual, ['深海蓝长发', '白围裙']);
});

test('renderSkill is deterministic', () => {
  const def = blankPersona('deterministic');
  assert.equal(renderSkill(def), renderSkill(structuredClone(def)));
});

test('media sniffing reads sizes from headers only', () => {
  const png = probe(tinyPng());
  assert.equal(png.format, 'png');
  assert.equal(png.width, 2);
  assert.equal(png.height, 1);

  const jpeg = probe(jpegHeader(4000, 2000));
  assert.equal(jpeg.format, 'jpeg');
  assert.equal(jpeg.width, 4000);
  assert.equal(jpeg.height, 2000);

  const gif = Buffer.concat([Buffer.from('GIF89a', 'latin1'), Buffer.from([0x10, 0x00, 0x08, 0x00, 0x00])]);
  assert.equal(probe(gif).format, 'gif');
  assert.equal(probe(gif).width, 16);

  assert.equal(probe(Buffer.from('not an image at all')), null);
});

test('an extreme aspect ratio is flagged, a normal one is not', () => {
  assert.equal(isExtreme(probe(jpegHeader(1080, 12000))), true);
  assert.equal(isExtreme(probe(jpegHeader(1920, 1080))), false);
});

test('dangerous SVG is refused, a plain one is accepted', () => {
  const evil = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');
  assert.equal(probe(evil).format, 'svg');
  assert.ok(svgDanger(evil) !== null);
  const plain = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><circle r="4"/></svg>');
  assert.equal(svgDanger(plain), null);
});

test('repository: create, edit, master switch and parking', async () => {
  const { value: profiles } = await repo.loadProfiles();
  assert.equal(profiles.masterOn, true);
  assert.equal(profiles.active, null);

  const def = blankPersona('smoke-persona', '烟雾测试');
  const created = await repo.createPersona(def);
  assert.equal(created.rev, 1);

  const skillsRoot = join(process.env.DSH_AGENTS_HOME, 'skills');
  const skillFile = join(skillsRoot, 'smoke-persona', 'SKILL.md');
  // Creating a document is not the same as installing it: only an active
  // persona under a running master switch gets a skill file.
  await assert.rejects(readFile(skillFile, 'utf8'));

  const summaries = await repo.personaSummaries();
  assert.equal(summaries.length, 1);
  assert.equal(summaries[0].title, '烟雾测试');

  // Master switch on + active persona keeps the skill installed.
  const on = await repo.saveProfiles({ ...profiles, masterOn: true, active: 'smoke-persona' }, profiles.rev);
  assert.equal(on.active, 'smoke-persona');
  assert.match(await readFile(skillFile, 'utf8'), /烟雾测试/);

  // Turning it off parks the directory outside the watched root.
  const off = await repo.saveProfiles({ ...on, masterOn: false }, on.rev);
  assert.equal(off.masterOn, false);
  await assert.rejects(readFile(skillFile, 'utf8'));
  const parked = join(process.env.DSH_AGENTS_HOME, 'personas-off', 'smoke-persona', 'SKILL.md');
  assert.match(await readFile(parked, 'utf8'), /name: smoke-persona/);

  // And back on restores it.
  await repo.saveProfiles({ ...off, masterOn: true }, off.rev);
  assert.match(await readFile(skillFile, 'utf8'), /烟雾测试/);

  // Stale revisions are refused rather than silently overwriting.
  await assert.rejects(repo.saveProfiles({ ...off, masterOn: true }, 0), (error) => error.code === 'ESTALE');

  // History keeps the previous generations.
  const historyDir = join(process.env.DSH_PERSONA_BOOK_DIR, '.history', 'profiles');
  assert.ok((await readdir(historyDir)).length >= 3);
});

test('repository: writing a persona twice bumps its revision', async () => {
  const def = blankPersona('rev-persona');
  const first = await repo.createPersona(def);
  const second = await repo.writePersona({ ...def, title: '改过名字' }, first.rev);
  assert.equal(second.rev, first.rev + 1);
  const read = await repo.readPersona('rev-persona');
  assert.equal(read.value.title, '改过名字');
  await assert.rejects(repo.writePersona(def, 0), (error) => error.code === 'ESTALE');
});

test('repository: a corrupt profile file is repaired, not fatal', async () => {
  const profilesPath = join(process.env.DSH_PERSONA_BOOK_DIR, 'profiles.json');
  await writeFile(profilesPath, '{ not json');
  const { value, problems } = await repo.loadProfiles();
  assert.equal(value.rev, 0);
  assert.equal(problems.length, 1);
  assert.match(problems[0], /重建/);
});

test('repository: delete removes persona and both skill locations', async () => {
  await repo.createPersona(blankPersona('doomed-persona'));
  await repo.deletePersona('doomed-persona');
  await assert.rejects(readFile(join(process.env.DSH_PERSONA_BOOK_DIR, 'doomed-persona', 'persona.json'), 'utf8'));
  assert.equal((await repo.listPersonaIds()).includes('doomed-persona'), false);
});

test('repository: assets usage counts the buckets, never the bookkeeping', async () => {
  const assets = join(process.env.DSH_PERSONA_BOOK_DIR, 'assets');
  await mkdir(join(assets, 'wallpaper'), { recursive: true });
  await mkdir(join(assets, '.tmp'), { recursive: true });
  await writeFile(join(assets, 'wallpaper', 'a.bin'), Buffer.alloc(1200));
  // Neither the index nor a half-written upload eats into the quota.
  await writeFile(join(assets, 'index.json'), Buffer.alloc(5000));
  await writeFile(join(assets, '.tmp', 'half.part'), Buffer.alloc(700));
  const usage = await repo.assetUsage();
  assert.equal(usage.bytes, 1200, '账本与暂存不算进额度');
  assert.equal(usage.files, 1);
});

test('面板语言只认中文/英文/跟随浏览器，别的值回到默认', () => {
  const bad = normalizeProfiles({ ui: { panel: { lang: 'fr' } } });
  assert.equal(bad.value.ui.panel.lang, 'zh');
  assert.equal(bad.problems.length, 1);
  assert.equal(normalizeProfiles({ ui: { panel: { lang: 'en' } } }).value.ui.panel.lang, 'en');
  assert.equal(normalizeProfiles({ ui: { panel: { lang: 'auto' } } }).value.ui.panel.lang, 'auto');
  assert.equal(normalizeProfiles({}).value.ui.panel.lang, 'zh', '老配置没有这一项时补中文');
});
