# 人设本第一版 API 与接入指南

本文面向模型服务和 Agent 开发者。独立版 API 前缀为 /api；DSH 版为 /api/persona-book/play。浏览器请求使用启动器建立的同源会话，开发脚本可使用启动令牌的 Bearer 认证。

## 主要接口

| 方法与路径 | 内容 |
| --- | --- |
| GET /state | 公开状态，移除服务密钥 |
| POST /action | 设置、人设、会话、记忆、存档、连接、资源操作 |
| POST /turn | 请求回复，返回 SSE 事件 |
| POST /stop | 停止指定 conversationId |
| POST /upload?kind=avatar或sound&name=文件名 | 原始文件体，返回资源引用 |
| POST /persona/import?name=文件名 | 人设 JSON、ZIP、SKILL、文本、角色卡 PNG |
| GET /persona/export?id=人设id&format=bundle | bundle、persona、skill、stcard、prompt |
| POST /chat/import 和 GET /chat/export | 完整会话 JSON 与 Markdown 导出 |
| GET /workshop | 内置与自定义工坊目录 |
| POST /workshop/preview 和 /workshop/install | 暂存预览与 token 提交安装 |
| POST /connection/test | 测试保存的文字连接 |
| POST /voice/generate | text 与 voice，使用保存的 TTS 设置 |
| GET /proactive/insights?personaId=人设id | 源规则配置、冷却时间、触发类型与记录 |

POST /action 的示例为 action=settings、patch={fontSize:16}。savePersona 传完整 persona，修改内置原稿返回新个人 id；applyPersona 将新角色应用到现有会话。connection 保存 kind、baseUrl、model、apiKey，可设置 useDefault。空密钥保留原密钥。action=engine 可控制记忆、情绪及主动调度参数。

接口失败返回 error.code 和 error.message；陈旧版本为 ESTALE，越界路径为 EPATH，资源格式为 EFORMAT，下载为 EDOWNLOAD，暂存校验为 ECHECKSUM。流式失败使用 error 事件，不能仅根据 HTTP 200 判断回复成功。

## 文本接入

OpenAI 兼容连接的 baseUrl 填写到 v1 根地址，服务请求 /chat/completions，传 model、messages、stream 和 max_tokens，接收 SSE，也接受非流式 choices.message.content。Ollama 填根地址例如 http://127.0.0.1:11434，服务请求 /api/chat 并读取 NDJSON。默认连接是本项目保存的首选配置；不自动读取其他程序的密钥。

标准 Agent 填服务根地址，接收 POST /turns，正文包含 messages 和 stream。SSE 的每个 data 行是一个 JSON，支持 text.delta、tool.start、tool.end、image 和 error。text.delta 包含 text；工具事件包含 name 和 status；image 可包含 image.url 或 image.b64_json；error 包含 message。事件只描述工具执行状态，具体执行和权限由 Agent 服务负责。

自定义协议可调用 registerTextAdapter(kind, asyncGenerator) 或 registerImageAdapter(kind, function)，两者返回注销函数。适配器接收连接、messages 或 prompt 以及 signal，输出统一事件或图片二进制。这样可接入新的模型网关和 Agent，无需改聊天界面。

## 生图和 TTS

兼容生图使用 /images/generations，接收 data.b64_json 或图片 URL。ComfyUI 使用 API 工作流 JSON，将提示词写入指定 promptNode 的 inputs.text，再请求 /prompt、/history 和 /view。自然语言自拍或图片请求会将人设视觉锚点加入提示词，并保存到聊天和图库。

兼容 TTS 使用 /audio/speech，传 model、input、voice、speed 和 response_format。不填 TTS 地址时，Windows 使用已经安装的 Microsoft Huihui Desktop 中文女声；其他系统使用上传音频或配置 TTS 服务。内置短语音已经生成，播放不需要联网。

## 参考文档

协议实现依据 [Ollama Chat API](https://docs.ollama.com/api/chat)、[ComfyUI 服务路由](https://docs.comfy.org/development/comfyui-server/comms_routes) 和固定 [EchoText 源码](https://github.com/mattjaybe/SillyTavern-EchoText/tree/35a7940f77691807be08c4e2e153118341a90c6e)。实际模型输出、工具质量和图片风格需要用用户选择的服务单独审核。

## dsh-web-all 0.4.6 插槽接入

客户端声明 locale 与 conversation 公共依赖，必需服务为 slots、locale；ui-chat 的 configForms 为可选能力，缺失时不阻止插件界面加载。入口优先通过 slots.inject 等待 conversation.input.selector.context 声明，再以 order=110 注册 persona-book-context，排在 Git 图的 order=100 之后。

未声明 context 时等待 2000ms 后撤销原等待，并降级到 conversation.input.dock。降级只在空白会话展示；能够定位当前 composer 的 heroWorkspaceRow 时通过 React portal 与工作区、预设并排。晚到的 context 不再重复挂载。卸载撤销等待、计时器、插槽入口、样式、窗口和 MutationObserver。

胶囊使用 GET /api/persona-book/play/state 读取共享角色，POST /api/persona-book/play/action 的 selectConversation 或 createConversation 切换角色聊天。选择人设控制人设本的共享聊天，不将它声明为已更改宿主 Standard Agent 预设。保留 sidebar.footer.action 与 shell.overlay 两个原入口。

iframe 使用 ?embedded=1&view=settings 或 view=workshop 直接进入对应页。persona-book:ready / host-theme 同步外壳令牌，persona-book:close 支持 iframe 内 Esc 关闭；host-context / host-context-result 保留关联上下文读取。所有桥接消息核对同源和指定窗口，主题颜色限定为已知令牌与有效 CSS 颜色，不传送连接密钥。
