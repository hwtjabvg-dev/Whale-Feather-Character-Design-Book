# dsh-persona-book · 人设本

给 DSH Web 的助手一张能改的脸和一副能换的嗓子：语气档位、气泡聊天、整站主题、壁纸与头像、提示音，外加跨 AI 的人设导入导出和一份能打开的设定集幻灯片。

> 它只改「怎么说、长什么样」。助手的身份、判断力和权限一概不动。

## 安装

```bash
# 在 DSH 的 profile 里把这个包加进 bundles（本机开发时用 link:）
#   "bundles": [..., "dsh-persona-book"]
#   "dsh-persona-book": "link:/root/dsha-persona-book"
dsh web --profile web --dump-config | grep dsh-persona-book   # 确认已挂上
dsh web --no-open                                             # 重启后新宿主与新面板才会加载
```

宿主（`lib/index.js`）是启动时加载的：装完**必须重启一次** `dsh web`，侧栏底部才会出现小鲸鱼按钮。

## 语言

面板自带 中 / EN / 跟随浏览器 三个开关（存在 `profiles.ui.panel.lang`，默认中文）：
面板不跟着宿主界面语言走，中英文用户各看各的。按钮、诊断日志、报错文案都在字典里，
构建时检查两份字典键一一对应。

## 面板五个标签

| 标签 | 做什么 |
|---|---|
| 人设 | 选人设（新建 / 复制 / 删除 / 设为生效）+ **低 / 中 / 高** 三个大按钮；详细档位收进折叠行 |
| 外观 | 整站主题（深海 / 浅色 / 跟随系统）、气泡材质（透明 / 玻璃 / 纯色）、气泡形状（圆角 / 方角 / 无）、头像形状 |
| 壁纸 | 一个「+」加号加图（任意格式、可拖拽）、缩略图网格、全屏开关、铺满 / 完整 / 平铺、暗度与模糊 |
| 音效 | 八枚现场合成的提示音、事件绑定、音量、限流 |
| 更多 | 导入（六种识别）/ 导出（五种）/ 自检与修复（诊断、安全模式、日志）/ 高级（原始 JSON）/ 移除插件 |

## 目录

```
lib/                宿主：路由、仓库、皮肤引擎、素材库、导入导出、PPTX
lib/appearance.js   生成皮肤 CSS（零 hex、零 !important；气泡规则套 :where()，整站配色用 html[skin] 前缀压过宿主 body{}）
lib/pptx.js         零依赖 OOXML 写作器（deflateRawSync + 自算 CRC32）
src/client/*.js     客户端分片，tools/build-client.mjs 拼成 lib/client.js
tests/              node:test，124 个用例
tools/check.mjs     产物一致性、体积、红线、字典与错误码的静态检查
docs/使用手册.md     面向用户的手册（面板「高级」页可读）
```

## 开发

```bash
node tools/build-client.mjs      # 分片 → lib/client.js（产物必须与分片一致）
node tools/check.mjs             # 静态红线：产物、体积、颜色令牌、字典、错误码
node --test "tests/*.test.js"    # 全量测试
```

约定：

- 客户端是**分片拼接**的，永远不要手改 `lib/client.js`；改 `src/client/*.js` 后重新构建，`check.mjs` 会逐字节比对。
- 面板样式只用 `pb-` 前缀类，颜色一律走 `var(--dsw-*, 回退值)`，不写 `!important`。
- 宿主错误统一 `new RequestError(status, 'CODE')`，`CODE` 必须在 `lib/constants.js` 的 `ERROR_MESSAGES` 里有中文文案，客户端字典也要有。
- 人设库的根目录同时住着素材库、导入暂存与历史快照：**只有含 `persona.json` 的目录才算人设**。

## 磁盘布局

```
/root/personas/                     人设库（DSH_PERSONA_BOOK_DIR 可覆盖）
  <id>/persona.json                 人设本体（rev 用于乐观锁）
  <id>/.history/                    写盘前的历史快照，保留最近 20 份
  assets/wallpapers|avatars|sounds  素材，按内容哈希命名
  .import/                          导入暂存（确认前不写盘）
~/.agents/skills/<id>/SKILL.md      生效人设生成的技能（DSH_AGENTS_HOME 可覆盖）
~/.agents/personas-off/<id>/        停放区
```

## 许可

MIT。设定集内容来自用户提供的立绘与文字设定，非官方品牌规范。
