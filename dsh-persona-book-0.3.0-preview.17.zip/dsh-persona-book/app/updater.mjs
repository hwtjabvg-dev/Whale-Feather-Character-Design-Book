import {readFile,writeFile,mkdir,rename,rm,realpath} from 'node:fs/promises';
import {join,dirname,resolve,relative,isAbsolute} from 'node:path';
import {randomUUID,createHash,verify} from 'node:crypto';
import {readZip} from '../lib/zip.js';
import {DomainError} from './store.mjs';
const fail=(code,message,status=400)=>{throw new DomainError(status,code,message);};
const sha=data=>createHash('sha256').update(data).digest('hex');
const PACKAGE='dsh-persona-book';

export function compareVersions(a,b){
 const parse=v=>{const m=/^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(v);if(!m)fail('EVERSION','版本号格式不正确。');return [Number(m[1]),Number(m[2]),Number(m[3]),m[4]?.split('.')];};
 const x=parse(a),y=parse(b);for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]>y[i]?1:-1;
 if(!x[3]||!y[3])return !x[3]&&!y[3]?0:!x[3]?1:-1;
 for(let i=0;i<Math.max(x[3].length,y[3].length);i++){const p=x[3][i],q=y[3][i];if(p===q)continue;if(p===undefined)return -1;if(q===undefined)return 1;const pn=/^\d+$/.test(p),qn=/^\d+$/.test(q);if(pn&&qn)return Number(p)>Number(q)?1:-1;if(pn!==qn)return pn?-1:1;return p>q?1:-1;}return 0;
}
export function updateUrl(value,base){
 let u;try{u=new URL(value,base);}catch{fail('EURL','请输入有效的更新目录地址。');}
 if(u.username||u.password||u.hash)fail('EURL','更新地址不能包含账号密码或锚点。');
 const loopback=['127.0.0.1','localhost','[::1]'].includes(u.hostname);
 if(u.protocol!=='https:'&&!(u.protocol==='http:'&&loopback))fail('EURL','更新源需使用 HTTPS。');return u.href;
}
async function download(url,max,timeout,access,range){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout);timer.unref?.();
 try{
  let address=updateUrl(url),res;
  for(let n=0;n<6;n++){const headers={'Cache-Control':'no-cache',...(range?{Range:`bytes=${range.start}-${range.end}`}:{})};if(access?.token){if(new URL(address).origin!==access.origin)fail('EUPDATEAUTH','私人更新跳转到其他站点，已停止发送授权。',401);headers['X-Whale-Device-Authorization']='Bearer '+access.token;if(!access.token.startsWith('wd1.'))headers['OAI-Sites-Authorization']='Bearer '+access.token;}res=await fetch(address,{redirect:'manual',signal:controller.signal,headers});if([401,403].includes(res.status)){await res.body?.cancel();fail('EUPDATEAUTH','私人更新需要设备授权，或授权已失效。',401);}if(res.status>=300&&res.status<400){const next=res.headers.get('location');await res.body?.cancel();if(!next)fail('EDOWNLOAD','更新地址重定向无效。');address=updateUrl(next,address);continue;}break;}
  if(!res?.ok)fail('EDOWNLOAD','更新服务暂时不可用，请稍后重试。',502);
  if(range&&(res.status!==206||res.headers.get('content-range')!==`bytes ${range.start}-${range.end}/${range.total}`)){await res.body?.cancel();fail('EFORMAT','分段下载范围不匹配，已停止安装。');}
  const declared=Number(res.headers.get('content-length')||0);if(declared>max)fail('ETOOLARGE','更新文件超过大小限制。',413);
  const chunks=[];let size=0;for await(const chunk of res.body){size+=chunk.length;if(size>max){controller.abort();fail('ETOOLARGE','更新文件超过大小限制。',413);}chunks.push(chunk);}return {data:Buffer.concat(chunks),url:address};
 }catch(e){if(e.status)throw e;fail('EDOWNLOAD','网络连接失败或超时，当前插件保持不变。',502);}finally{clearTimeout(timer);}
}
async function downloadPackage(file,access){
 if(!file.chunkBytes)return download(file.url,64*1024*1024,120000,access);
 if(file.chunkBytes!==524288)fail('EFORMAT','分段下载参数不兼容。');
 const count=Math.ceil(file.bytes/file.chunkBytes),parts=new Array(count);let next=0;
 const worker=async()=>{while(next<count){const index=next++,start=index*file.chunkBytes,end=Math.min(file.bytes,start+file.chunkBytes)-1;let result;for(let attempt=0;attempt<3;attempt++){try{result=await download(file.url,end-start+1,30000,access,{start,end,total:file.bytes});break;}catch(e){if(e.code!=='EDOWNLOAD'||attempt===2)throw e;}}if(result.data.length!==end-start+1)fail('ECHECKSUM','下载分段不完整，当前版本保持不变。');parts[index]=result.data;}};
 const results=await Promise.allSettled(Array.from({length:Math.min(4,count)},worker));const failed=results.find(x=>x.status==='rejected');if(failed)throw failed.reason;
 return {data:Buffer.concat(parts),url:file.url};
}
const contains=(parent,child)=>{const r=relative(parent,child);return r===''||(!r.startsWith('..')&&!isAbsolute(r));};

export class PluginUpdater{
 constructor({root,dataDir,canInstall=false,channel,renameFile=rename}){this.root=resolve(root);this.data=resolve(dataDir);this.canInstall=canInstall;this.channelOverride=channel;this.rename=renameFile;this.phase='idle';this.error='';this.latest=null;this.lock=false;}
 async open(){
  this.currentVersion=JSON.parse(await readFile(join(this.root,'package.json'),'utf8')).version;
  this.channel=this.channelOverride||await readFile(join(this.root,'resources/update-channel.json'),'utf8').then(JSON.parse).catch(e=>{if(e.code==='ENOENT')return {url:'',publicKey:''};throw e;});
  const read=async file=>readFile(join(this.data,'updates',file),'utf8').then(JSON.parse).catch(e=>{if(e.code==='ENOENT')return {};throw e;});
  this.config=await read('config.json');this.pending=await read('pending.json');this.access=await read('access.json');
  if(this.pending.version===this.currentVersion){await this.save('pending.json',{});this.pending={};}
  this.sourceUrl=this.config.url||this.channel.url||'';this.checkedAt=0;return this;
 }
 async save(name,value){const dir=join(this.data,'updates');await mkdir(dir,{recursive:true});const target=join(dir,name),tmp=target+'.tmp-'+randomUUID();try{await writeFile(tmp,JSON.stringify(value,null,2),{mode:0o600});await rename(tmp,target);}finally{await rm(tmp,{force:true}).catch(()=>{});}}
 accessForSource(){if(this.channel.private===false&&this.sourceUrl&&new URL(this.sourceUrl).origin===new URL(this.channel.url).origin)return null;const origin=this.sourceUrl?new URL(this.sourceUrl).origin:'';if(this.access?.origin===origin&&this.access.token)return this.access;const token=process.env.DSH_PERSONA_BOOK_UPDATE_TOKEN;if(token&&origin===new URL(this.channel.url||'https://invalid.example').origin)return {origin,token};return null;}
 status(){return {currentVersion:this.currentVersion,sourceUrl:this.sourceUrl,private:!!this.channel.private,authorizationConfigured:!!this.accessForSource(),configured:!!(this.sourceUrl&&this.channel.publicKey),canInstall:this.canInstall,available:!!this.latest&&compareVersions(this.latest.version,this.pending.version||this.currentVersion)>0,latestVersion:this.latest?.version||'',notes:this.latest?.notes||'',bytes:this.latest?.package.bytes||0,checkedAt:this.checkedAt,phase:this.phase,error:this.error,pendingVersion:this.pending.version||'',restartRequired:!!this.pending.version};}
 async configureAccess(token){if(this.lock)fail('EBUSY','更新正在进行，请稍后修改授权。',409);if(typeof token!=='string'||token.length>8192||/[^\x21-\x7e]/.test(token))fail('EUPDATEAUTH','授权凭据格式不正确。',400);if(token&&!this.sourceUrl)fail('EURL','请先配置更新地址。');const next=token?{origin:new URL(this.sourceUrl).origin,token}:{};await this.save('access.json',next);this.access=next;this.latest=null;this.error='';this.checkedAt=0;return this.status();}
 async configure(url){if(this.lock)fail('EBUSY','更新正在进行，请稍后修改来源。',409);const next=url?updateUrl(String(url).trim()):'';await this.save('config.json',{url:next});this.config={url:next};this.sourceUrl=next||this.channel.url||'';this.latest=null;this.error='';this.checkedAt=0;return this.status();}
 async check(){
  if(this.lock)fail('EBUSY','更新正在进行，请稍后再试。',409);
  if(!this.sourceUrl){this.phase='unconfigured';return this.status();}
  if(!this.channel.publicKey)fail('EUPDATEKEY','当前安装包未配置发布验证信息。');
  this.lock=true;this.phase='checking';this.error='';
  try{
   const access=this.accessForSource();if(this.channel.private&&!access)fail('EUPDATEAUTH','这是私人更新站点，请先授权当前设备。',401);
   const fetched=await download(this.sourceUrl,128*1024,20000,access);let envelope;try{envelope=JSON.parse(fetched.data);}catch{if(this.channel.private)fail('EUPDATEAUTH','私人更新授权未通过，请重新授权当前设备。',401);fail('EFORMAT','更新目录不是有效 JSON。');}
   if(typeof envelope.payload!=='string'||typeof envelope.signature!=='string')fail('ESIGNATURE','更新目录缺少发布签名。');
   const payload=Buffer.from(envelope.payload,'base64');let valid=false;try{valid=verify(null,payload,this.channel.publicKey,Buffer.from(envelope.signature,'base64'));}catch{}if(!valid)fail('ESIGNATURE','更新目录签名不匹配，请检查发布来源。');
   let release;try{release=JSON.parse(payload);}catch{fail('EFORMAT','发布信息损坏。');}
   if(release.format!=='persona-book-update/v1'||release.name!==PACKAGE||!release.package||!/^[0-9a-f]{64}$/.test(release.package.sha256)||!Number.isInteger(release.package.bytes)||release.package.bytes<=0||release.package.bytes>64*1024*1024)fail('EFORMAT','发布信息不完整或不兼容。');
   compareVersions(release.version,this.currentVersion);
   if((release.nodeMinimum||22)>Number(process.versions.node.split('.')[0]))fail('ENODE','新版需要更新安卓 DSH 的 Node 运行时。');
   release.package.url=updateUrl(release.package.url,fetched.url);release.notes=String(release.notes||'').slice(0,10000);
   this.latest=release;this.checkedAt=Date.now();this.phase='idle';return this.status();
  }catch(e){this.latest=null;this.phase='error';this.error=e.message;throw e;}finally{this.lock=false;}
 }
 async install(version,beforeCommit){
  if(!this.canInstall)fail('EUPDATEHOST','请在安装到 DSH 的插件中更新。');
  if(this.lock)fail('EBUSY','更新正在进行。',409);
  if(this.pending.version)fail('ERESTART','上次更新已安装，请先重启 DSH 引擎。',409);
  if(!this.latest||version!==this.latest.version||compareVersions(version,this.currentVersion)<=0)fail('ESTALE','请先检查新版，再点击更新。',409);
  this.lock=true;this.error='';let stage,backup,swapped=false;
  try{
   const realRoot=await realpath(this.root),realData=await realpath(this.data);
   if(realRoot!==this.root||contains(realRoot,realData))fail('EUPDATEPATH','当前安装目录包含用户数据或使用了软链接，请通过宿主插件管理器更新。');
   const parent=dirname(realRoot),id=randomUUID();stage=join(parent,'.pb-update-stage-'+id);backup=join(parent,'.pb-update-backup-'+id);
   this.phase='downloading';const fetched=await downloadPackage(this.latest.package,this.accessForSource()),zip=fetched.data;
   if(zip.length!==this.latest.package.bytes||sha(zip)!==this.latest.package.sha256)fail('ECHECKSUM','下载文件校验失败，当前版本保持不变。');
   this.phase='verifying';const entries=readZip(zip);if(!entries)fail('EFORMAT','更新包损坏或超过解压限制。');
   const seen=new Set(),files=[];
   for(const entry of entries){if(!entry.name.startsWith(PACKAGE+'/'))continue;const name=entry.name.slice(PACKAGE.length+1);if(!name||seen.has(name)||name.includes('\\')||name.split('/').some(x=>!x||x==='..'||x==='.')||name.includes(':')||/^(?:data|runtime|\.git|\.credentials)(?:\/|$)/.test(name)||/\.(?:exe|dll|node|apk|jks|pem|keystore)$/i.test(name))fail('EPATH','更新包包含重复或不支持的路径。');seen.add(name);files.push({path:name,data:entry.data});}
   const item=name=>files.find(f=>f.path===name);
   let pkg,manifest,nextChannel;try{pkg=JSON.parse(item('package.json').data);manifest=JSON.parse(item('mobile/package-manifest.json').data);nextChannel=JSON.parse(item('resources/update-channel.json').data);}catch{fail('EFORMAT','更新包缺少必要文件。');}
   if(pkg.name!==PACKAGE||pkg.version!==version||pkg.main!=='lib/index.js'||pkg.dsh?.client?.platform!=='web'||!item('lib/client.js')||!item('cordis.patch.yml')||!item('app/public/app.js'))fail('EFORMAT','更新包的版本或 DSH 入口不匹配。');
   if(nextChannel.publicKey!==this.channel.publicKey)fail('EUPDATEKEY','更新包的发布验证信息发生变化。');
   if(manifest.format!=='dsh-persona-book-directory/v1'||manifest.version!==version||!Array.isArray(manifest.files)||manifest.files.length!==files.length-1)fail('EFORMAT','更新资源清单不完整。');
   const declared=new Set();for(const file of manifest.files){const actual=item(file.path);if(!actual||declared.has(file.path)||actual.data.length!==file.bytes||sha(actual.data)!==file.sha256)fail('ECHECKSUM','更新包内部文件校验失败。');declared.add(file.path);}
   await mkdir(stage);for(const file of files){const target=resolve(stage,file.path);if(!contains(stage,target))fail('EPATH','更新解压路径不合法。');await mkdir(dirname(target),{recursive:true});await writeFile(target,file.data,{mode:0o600});}
   if(beforeCommit)await beforeCommit();
   this.phase='installing';await this.rename(realRoot,backup);
   try{await this.rename(stage,realRoot);swapped=true;}catch(e){await this.rename(backup,realRoot);throw e;}
   const pending={version,previousVersion:this.currentVersion,backup,installedAt:Date.now()};
   try{await this.save('pending.json',pending);}catch(e){await this.rename(realRoot,stage);swapped=false;await this.rename(backup,realRoot);throw e;}
   this.pending=pending;this.phase='restart';return this.status();
  }catch(e){const error=e.status?e:new DomainError(500,'EUPDATEINSTALL','更新安装失败，请检查插件目录写权限；旧版备份与用户数据保留。');this.phase='error';this.error=error.message;throw error;}finally{
   this.lock=false;
   if(stage&&!swapped){const parent=dirname(this.root);if(dirname(stage)===parent&&stage.startsWith(join(parent,'.pb-update-stage-')))await rm(stage,{recursive:true,force:true}).catch(()=>{});}
   // Keep the old package for recovery. Never delete the host or user data.
  }
 }
}
