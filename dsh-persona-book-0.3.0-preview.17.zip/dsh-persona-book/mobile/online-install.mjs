/** Private online installation. No credentials in argv, output, or distributed code. */
import {readFile,writeFile,mkdir,mkdtemp,realpath,rename,rm,stat,readdir} from 'node:fs/promises';
import {join,resolve,dirname} from 'node:path';import {homedir} from 'node:os';import {fileURLToPath} from 'node:url';import {createHash} from 'node:crypto';import {spawn} from 'node:child_process';
import {PluginUpdater,compareVersions} from '../app/updater.mjs';
import {INSTALL_SKILL} from './install-guide.mjs';
import channelDefault from '../resources/update-channel.json' with {type:'json'};
const json=async path=>JSON.parse(await readFile(path,'utf8'));
const exists=async path=>stat(path).then(()=>true,e=>{if(e.code==='ENOENT')return false;throw e;});
async function atomicJson(path,value){await mkdir(dirname(path),{recursive:true});const temp=path+'.tmp-'+process.pid;try{await writeFile(temp,JSON.stringify(value,null,2)+'\n',{mode:0o600});await rename(temp,path);}finally{await rm(temp,{force:true});}}
export async function findAuthorizationFile(home=homedir()){
 const old=join(process.env.DSH_PERSONA_BOOK_DIR||join(home,'.dsh/persona-book'),'.play/updates/access.json');if(await exists(old))return old;
 for(const dir of [...new Set([join(home,'Downloads'),join(home,'Download'),'/sdcard/Download',process.cwd()])]){
  const names=await readdir(dir).catch(()=>[]),items=[];
  for(const name of names.slice(0,2000))if(/^whale-device-access(?:\s*\(\d+\)|-\d+)?\.json$/i.test(name)){const path=join(dir,name),s=await stat(path);if(s.isFile())items.push({path,time:s.mtimeMs});}
  if(items.length)return items.sort((a,b)=>b.time-a.time)[0].path;
 }
 return null;
}
export async function registerDsh(root,{profile='web',executable='dsh',entry,env=process.env}={}){
 const safeEnv={...env};delete safeEnv.DSH_PERSONA_BOOK_UPDATE_TOKEN;
 const command=Array.isArray(entry)?entry:entry?[entry]:[];
 const run=args=>new Promise((done,reject)=>{const child=spawn(executable,[...command,...args],{env:safeEnv,stdio:['ignore','pipe','pipe'],shell:false});let output='';child.stdout.on('data',b=>{output+=b;if(output.length>2*1024*1024)child.kill();});child.stderr.on('data',()=>{});child.once('error',()=>reject(Error('找不到 DSH 安装命令，请启用宿主命令工具。')));child.once('close',code=>code===0?done(output):reject(Error('DSH 安装命令失败；已校验的插件目录保留，可重试。')));});
 await run(['plugin','--profile',profile,'add','link:'+root,'--offline','--ignore-scripts']);
 const composed=await run(['--profile',profile,'--dump-config']);
 if(!composed.includes('dsh-persona-book'))throw Error('DSH 未确认插件接入，请检查宿主插件管理。');
 return {registered:true,configurationVerified:true,activationVerified:false};
}
async function verifyInstalled(root){
 const pkg=await json(join(root,'package.json')),manifest=await json(join(root,'mobile/package-manifest.json'));
 if(pkg.name!=='dsh-persona-book'||manifest.version!==pkg.version)throw Error('目标目录不是完整的鲸语人设本插件，已停止覆盖。');
 for(const file of manifest.files){if(typeof file.path!=='string'||file.path.startsWith('/')||file.path.includes('\\')||file.path.split('/').some(p=>p==='..'||p==='.')||file.path.includes(':'))throw Error('插件清单路径校验失败。');const bytes=await readFile(join(root,file.path));if(bytes.length!==file.bytes||createHash('sha256').update(bytes).digest('hex')!==file.sha256)throw Error('已安装文件校验失败，请通过宿主修复后重试。');}
 return pkg;
}
export async function installOnline(options={}){
 if(Number(process.versions.node.split('.')[0])<22)throw Error('需要 Node 22 或以上，请更新安卓 DSH 宿主。');
 const home=resolve(options.home||homedir()),dshHome=resolve(options.dshHome||process.env.DSH_HOME||join(home,'.dsh')),profile=options.profile||'web',channel=options.channel||channelDefault;
 if(!/^[a-z0-9_-]+$/i.test(profile))throw Error('DSH 配置名称不正确。');
 const origin=new URL(channel.url).origin,authorizationFile=channel.private?options.authorizationFile||await findAuthorizationFile(home):null;
 const access=channel.private?(authorizationFile?await json(authorizationFile):{origin,token:process.env.DSH_PERSONA_BOOK_UPDATE_TOKEN}):{origin};
 if(channel.private&&(access.origin!==origin||typeof access.token!=='string'||!access.token||/[^\x21-\x7e]/.test(access.token)))throw Error('当前私人安装源需要设备授权。');
 if(access.format&&access.format!=='whale-device-authorization/v1')throw Error('设备授权文件格式不兼容。');
 const dataDir=resolve(process.env.DSH_PERSONA_BOOK_DIR||join(home,'.dsh/persona-book'),'.play');
 const parent=join(dshHome,'plugins');await mkdir(parent,{recursive:true});const canonicalParent=await realpath(parent),defaultRoot=join(canonicalParent,'dsh-persona-book');
 const profileDir=join(dshHome,'profiles',profile),profilePackage=await json(join(profileDir,'package.json')).catch(e=>{if(e.code==='ENOENT')return {};throw e;});
 const dependency=profilePackage.dependencies?.['dsh-persona-book'];
 const linked=typeof dependency==='string'&&dependency.startsWith('link:')?resolve(profileDir,dependency.slice(5)):null;
 if(dependency&&!linked)throw Error('宿主已有其他来源的鲸语插件，请使用插件内更新入口，避免重复安装。');
 let pluginRoot=linked?await realpath(linked):defaultRoot;
 const stage=await mkdtemp(join(canonicalParent,'.whale-online-'));let pkg,latest,alreadyInstalled=false;
 try{
  const root=join(stage,'plugin'),temporaryData=join(stage,'data');await mkdir(root);await mkdir(temporaryData);await writeFile(join(root,'package.json'),JSON.stringify({name:'dsh-persona-book',version:'0.0.0'}));
  const updater=await new PluginUpdater({root,dataDir:temporaryData,channel,canInstall:true}).open();if(channel.private)updater.access={origin,token:access.token};const status=await updater.check();latest=status.latestVersion;
  if(await exists(pluginRoot)){
   pkg=await verifyInstalled(pluginRoot);alreadyInstalled=true;await mkdir(dataDir,{recursive:true});
   if(compareVersions(latest,pkg.version)>0){const current=await new PluginUpdater({root:pluginRoot,dataDir,channel,canInstall:true}).open();current.access={origin,token:access.token};await current.check();if(current.pending.version&&current.pending.version!==latest)throw Error('上一次更新需要先重启引擎，请重启后重试。');if(!current.pending.version)await current.install(latest);pkg=await verifyInstalled(pluginRoot);}
  }
  else{await updater.install(latest);pkg=await verifyInstalled(root);await rename(root,pluginRoot);}
  const receiptFile=join(dataDir,'updates/online-install.json'),receipt=await json(receiptFile).catch(e=>{if(e.code==='ENOENT')return {};throw e;});
  let registration={registered:true,configurationVerified:!!receipt.configurationVerified,activationVerified:!!receipt.activationVerified};
  if(!(receipt.pluginRoot===pluginRoot&&receipt.registered&&receipt.configurationVerified))registration=await(options.register||registerDsh)(pluginRoot,{profile,executable:options.executable||'dsh',entry:options.entry,env:{...process.env,DSH_HOME:dshHome}});
  if(!registration.registered)throw Error('DSH 尚未确认插件安装成功。');
  if(channel.private)await atomicJson(join(dataDir,'updates/access.json'),{origin,token:access.token});
  const skillsRoot=resolve(options.skillsHome||(!options.home&&process.env.DSH_AGENTS_HOME)||join(home,'.agents'),'skills/whale-persona-book-install');await mkdir(skillsRoot,{recursive:true});
  const skillFile=join(skillsRoot,'SKILL.md'),oldSkill=await readFile(skillFile,'utf8').catch(e=>{if(e.code==='ENOENT')return '';throw e;});
  // Do not overwrite a personal skill that happens to use the same directory name.
  if(!oldSkill||/<!-- whale-install-guide:v[23] -->/.test(oldSkill))await writeFile(skillFile,INSTALL_SKILL,{mode:0o600});
  const result={name:'dsh-persona-book',title:'Whale Feather Character Design Book',version:pkg.version,latestVersion:latest,pluginRoot,dataDir,profile,registered:true,configurationVerified:!!registration.configurationVerified,activationVerified:!!registration.activationVerified,alreadyInstalled,updateAvailable:pkg.version!==latest,restartRequired:true,next:pkg.version===latest?'接入配置完成，按宿主要求重启 DSH 引擎后验证生效。':'插件已存在，请通过聊天内更新入口升级。'};
  await atomicJson(receiptFile,{...result,installedAt:new Date().toISOString()});
  if(options.consumeAuthorization&&authorizationFile&&access.format==='whale-device-authorization/v1')await rm(authorizationFile);
  return result;
 }finally{if(dirname(stage)!==canonicalParent||!stage.startsWith(join(canonicalParent,'.whale-online-')))throw Error('安装暂存目录异常。');await rm(stage,{recursive:true,force:true});}
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const args=process.argv.slice(2),option=k=>{const i=args.indexOf(k);return i<0?undefined:args[i+1];};
 try{console.log(JSON.stringify(await installOnline({authorizationFile:option('--authorization-file'),consumeAuthorization:args.includes('--consume-authorization'),profile:option('--profile'),executable:option('--dsh-executable'),entry:option('--dsh-entry')}),null,2));}
 catch(error){console.error(error.message);process.exitCode=1;}
}
