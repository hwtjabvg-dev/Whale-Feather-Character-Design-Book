#!/system/bin/sh
# 在安卓 DSH 自带终端执行：sh /绝对路径/dsh-persona-book/mobile/install-in-dsh.sh
set -eu
PB_PLUGIN_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
if ! command -v dsh >/dev/null 2>&1; then
  printf '%s\n' '当前终端没有 dsh 命令。请在安卓宿主的插件管理页选择本地目录安装。' "$PB_PLUGIN_DIR"
  exit 1
fi
if ! command -v node >/dev/null 2>&1; then
  printf '%s\n' '当前终端没有 Node 运行时。请使用安卓 DSH 宿主自带的终端。'
  exit 1
fi
node "$PB_PLUGIN_DIR/mobile/check-package.mjs"
dsh plugin --profile web add "link:$PB_PLUGIN_DIR"
printf '%s\n' '插件已提交安装。请在安卓宿主里重启引擎，然后打开人设本。' '请保留插件目录；用户数据与插件目录分开保存。'
