import test from 'node:test';
import assert from 'node:assert/strict';
import{mkdtemp,rm}from'node:fs/promises';
import{join}from'node:path';
import{tmpdir}from'node:os';
import{PersonaService}from'../app/service.mjs';
import{receiveFiles,VOICE_PACKS}from'../app/feedback.mjs';
import{readZip}from'../lib/zip.js';
test('近景WebP头像在人设包导出再导入时保留正确格式和原设定',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'pb-living-'));const s=await new PersonaService(dir).open();
 try{const p=s.snapshot().personas[0];await s.action({action:'avatar',personaId:p.id,id:'builtin:portrait'});const pack=await s.exportPersona(p.id,'bundle'),entry=readZip(pack.data).find(x=>x.name==='media/avatar.webp');assert.ok(entry);assert.equal(entry.data.subarray(0,4).toString(),'RIFF');const imported=await s.importPersona(pack.data,'avatar-roundtrip.zip');assert.equal(imported.persona.identity.selfName,p.identity.selfName);assert.equal(imported.persona.levels.length,p.levels.length);assert.equal(s.snapshot().avatars.find(a=>a.id===imported.persona.presentation.avatarId).format,'webp');}
 finally{s.close();assert.ok(dir.startsWith(join(tmpdir(),'pb-living-')));await rm(dir,{recursive:true,force:true});}
});
test('真人语音预设保存后重启保留，移除旧合成音后仍保留自定义优先级',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'pb-living-'));let s=await new PersonaService(dir).open();
 try{const role=s.snapshot().personas[0],tone=role.defaults.toneIntensity;await s.action({action:'roleVoice',personaId:role.id,patch:{packId:'greeting'}});s.close();s=await new PersonaService(dir).open();const state=s.snapshot(),saved=state.personas.find(p=>p.id===role.id);assert.equal(saved.defaults.toneIntensity,tone);assert.deepEqual(receiveFiles(state,saved),['sounds/voice/yoho1.mp3']);assert.deepEqual(VOICE_PACKS.map(p=>p.id),['message','greeting','hum','dingdong']);assert.deepEqual(receiveFiles(state,{...saved,defaults:{...saved.defaults,toneIntensity:9},voice:{packId:'legacy'}}),['sounds/voice/messagegakiteruyo1.mp3']);assert.deepEqual(receiveFiles({...state,assets:[{id:'mine',file:'media/my-voice.ogg'}]}, {...saved,voice:{packId:'greeting',assetId:'mine'}}),['media/my-voice.ogg']);}
 finally{s.close();assert.ok(dir.startsWith(join(tmpdir(),'pb-living-')));await rm(dir,{recursive:true,force:true});}
});
test('已保存的旧版接收音升级后回退到现有默认，个人上传和人设保持不变',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'pb-voice-retire-'));let s=await new PersonaService(dir).open();
 try{
  const role=s.snapshot().personas[0],identity=structuredClone(role.identity),tone=role.defaults.toneIntensity;
  await s.store.transact(state=>{state.settings.receivePack='legacy';state.settings.receiveSoundId='my-upload';state.personas[0].voice={...state.personas[0].voice,packId:'legacy',assetId:'my-upload',receive:['receive-low.wav','receive-mid.wav','receive-high.wav']};state.assets.push({id:'my-upload',kind:'sound',file:'media/personal.wav'});});
  s.close();s=await new PersonaService(dir).open();const state=s.snapshot(),p=state.personas[0];
  assert.equal(state.settings.receivePack,'message');assert.equal(p.voice.packId,'message');assert.deepEqual(p.voice.receive,['voice/messagegakiteruyo1.mp3']);
  assert.equal(p.voice.assetId,'my-upload');assert.deepEqual(receiveFiles(state,p),['media/personal.wav']);assert.deepEqual(p.identity,identity);assert.equal(p.defaults.toneIntensity,tone);
 }finally{s.close();await rm(dir,{recursive:true,force:true});}
});
test('上版真人预设迁移到已审核的A，上传覆盖仍优先且不依赖语气档位',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'pb-approved-voice-'));let s=await new PersonaService(dir).open();
 try{
  await s.store.transact(state=>{state.settings.receivePack='sweet';state.personas[0].voice={...state.personas[0].voice,packId:'playful',receive:['voice/hai1.mp3','voice/yobimashita1.mp3']};});
  s.close();s=await new PersonaService(dir).open();const state=s.snapshot(),p=state.personas[0];assert.equal(state.settings.receivePack,'message');assert.equal(p.voice.packId,'message');
  for(const toneIntensity of [3,6,9])assert.deepEqual(receiveFiles(state,{...p,defaults:{...p.defaults,toneIntensity}}),['sounds/voice/messagegakiteruyo1.mp3']);
 }finally{s.close();await rm(dir,{recursive:true,force:true});}
});
