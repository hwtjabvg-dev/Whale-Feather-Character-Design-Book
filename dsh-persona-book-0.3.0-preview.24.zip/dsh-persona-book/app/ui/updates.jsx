import React,{useEffect,useRef,useState} from 'react';
export function useUpdates(request){
 const [status,setStatus]=useState(null),checking=useRef(false);
 const refresh=async()=>{const s=await request('/updates/status');setStatus(s);return s;};
 const check=async(silent=false)=>{if(checking.current)return;checking.current=true;try{const s=await request('/updates/check',{});setStatus(s);return s;}catch(e){await refresh().catch(()=>{});if(!silent)throw e;}finally{checking.current=false;}};
 useEffect(()=>{
  let live=true;const poll=async()=>{if(document.hidden||window.__pbPanelVisible===false)return;try{const s=await request('/updates/status');if(!live)return;setStatus(s);if(s.configured&&(!s.private||s.authorizationConfigured)&&!s.restartRequired&&!['checking','downloading','verifying','installing'].includes(s.phase)&&Date.now()-s.checkedAt>=60000)await check(true);}catch{}};
  poll();const timer=setInterval(poll,60000);document.addEventListener('visibilitychange',poll);
  return()=>{live=false;clearInterval(timer);document.removeEventListener('visibilitychange',poll);};
 },[]);
 return {status,setStatus,refresh,check};
}
export default function UpdatesPanel({updates,request,notify,chatBusy}){
 const {status,refresh,check,setStatus}=updates,[working,setWorking]=useState(false),[source,setSource]=useState(status?.sourceUrl||'');
 useEffect(()=>{refresh().then(s=>setSource(s.sourceUrl)).catch(notify);},[]);
 const busy=working||['checking','downloading','verifying','installing'].includes(status?.phase);
 useEffect(()=>{if(!working)return;const timer=setInterval(()=>refresh().catch(()=>{}),1000);return()=>clearInterval(timer);},[working]);
 const perform=async fn=>{setWorking(true);try{await fn();}catch(e){notify(e);}finally{await refresh().catch(()=>{});setWorking(false);}};
 const [accessToken,setAccessToken]=useState('');
 if(!status)return <p>正在读取更新信息…</p>;
 return <div className="updates-panel">
  <div className="section-intro"><p>打开时自动检查；有新版时，你决定什么时候更新。</p></div>
  <div className="installed"><div><strong>当前版本 {status.currentVersion}</strong><small>{status.checkedAt?'上次检查：'+new Date(status.checkedAt).toLocaleString('zh-CN'):'尚未检查'}</small></div><button disabled={busy||!status.configured} onClick={()=>perform(()=>check())}>检查更新</button></div>
  {!status.configured&&<p className="muted">发布地址尚未配置。接入后，手机会自动提示新版本。</p>}
  {status.private&&<div className="installed"><div><strong>私人更新站点</strong><small>{status.authorizationConfigured?'当前设备已保存授权；检查时验证有效性。':'当前设备尚未授权，授权后可自动检查和安装。'}</small><a href={status.sourceUrl?new URL('/',status.sourceUrl).href:'#'} target="_blank" rel="noreferrer">登录私人站点</a></div></div>}
  {status.private&&<details open={!status.authorizationConfigured}><summary>设备更新授权</summary><form onSubmit={e=>{e.preventDefault();perform(async()=>{setStatus(await request('/updates/access',{token:accessToken.trim()}));setAccessToken('');notify('设备授权已保存，请检查更新。');});}}><label className="field"><span>授权凭据</span><input type="password" autoComplete="off" value={accessToken} onChange={e=>setAccessToken(e.target.value)} placeholder="由站点维护者给当前设备配置"/></label><button disabled={busy||!accessToken.trim()}>保存授权</button>{status.authorizationConfigured&&<button type="button" disabled={busy} onClick={()=>perform(async()=>{setStatus(await request('/updates/access',{token:''}));setAccessToken('');notify('已清除本机保存的授权。');})}>清除本机授权</button>}</form><p className="muted">只保存在设备服务端，不显示已保存凭据。网页账号登录和后台更新授权分开；安装包不携带私人凭据。</p></details>}
  {status.configured&&status.checkedAt&&!status.available&&!status.restartRequired&&!status.error&&!busy&&<p role="status">已是最新版本。</p>}
  {status.available&&!status.restartRequired&&<div className="install-preview"><h3>发现新版 {status.latestVersion}</h3><p>{(status.bytes/1024/1024).toFixed(1)} MB</p><p style={{whiteSpace:'pre-wrap'}}>{status.notes||'功能调整与体验改进。'}</p><button className="primary" disabled={busy||chatBusy||!status.canInstall} onClick={()=>perform(async()=>{setStatus(await request('/updates/install',{version:status.latestVersion}));notify('更新已安装，请在宿主里重启 DSH 引擎。');})}>更新到 {status.latestVersion}</button>{chatBusy&&<p className="muted">等待当前回复完成后即可更新。</p>}{!status.canInstall&&<p className="muted">请在 DSH 插件窗口里执行安装。</p>}</div>}
  {status.restartRequired&&<div className="install-preview"><h3>{status.pendingVersion} 已安装</h3><p>请在安卓宿主中重启 DSH 引擎，再重新打开人设本。聊天、个人设置和素材保持原位。</p></div>}
  {busy&&<p role="status">{({checking:'正在检查新版…',downloading:'正在下载更新…',verifying:'正在校验文件…',installing:'正在安装更新…'})[status.phase]||'正在处理更新…'}</p>}
  {status.error&&<p role="alert">{status.error}</p>}
  <details><summary>更新来源</summary><form onSubmit={e=>{e.preventDefault();perform(async()=>{const s=await request('/updates/source',{url:source});setStatus(s);notify(source?'更新来源已保存。':'更新来源已清除。');});}}><label className="field"><span>发布目录地址</span><input type="url" value={source} onChange={e=>setSource(e.target.value)} placeholder="HTTPS 地址，指向 latest.json"/></label><button disabled={busy} type="submit">保存来源</button></form><p className="muted">新版由项目发布工具生成并验证；安装失败保留原版。修改代码后发布新版本，手机才会提示更新。</p></details>
 </div>;
}
