/** Keep settings interactive while serializing and coalescing durable writes. */
export function mergeSnapshot(current,incoming,overlay={}) {
 const base=current&&current.rev>incoming.rev?current:incoming;
 return Object.keys(overlay).length?{...base,settings:{...base.settings,...overlay}}:base;
}
export function createSettingsWriter({send,onOptimistic,onCommit,onFailure}) {
 let pending={},desired={},waiters=[],running=false;
 async function drain(){
  running=true;
  while(Object.keys(pending).length){
   const patch=pending,batch=waiters;pending={};waiters=[];
   try{
    const response=await send(patch);
    for(const key of Object.keys(patch))if(!Object.hasOwn(pending,key))delete desired[key];
    onCommit(response.state);for(const item of batch)item.resolve(response.result);
   }catch(error){
    for(const key of Object.keys(patch))if(!Object.hasOwn(pending,key))delete desired[key];
    onFailure(error);for(const item of batch)item.reject(error);
   }
  }
  running=false;
 }
 return {overlay:()=>({...desired}),write:patch=>{
  if(!patch||!Object.keys(patch).length)return Promise.resolve({});
  Object.assign(pending,patch);Object.assign(desired,patch);onOptimistic(patch);
  const result=new Promise((resolve,reject)=>waiters.push({resolve,reject}));
  void result.catch(()=>{});if(!running)void drain();return result;
 }};
}
