/** One default click for every interface action; retired pack preferences safely use it. */
export function interactionFiles(){return {tap:'sounds/ui/tap.wav',select:'sounds/ui/tap.wav',open:'sounds/ui/tap.wav'};}
export const VOICE_PACKS=[
 {id:'message',name:'A · 元气新消息',note:'真人日语 · 有消息来啦 · 1.34 秒',files:['voice/messagegakiteruyo1.mp3']},
 {id:'greeting',name:'B · 少女打招呼',note:'真人日语 · 呀吼／嗨 · 1.01 秒',files:['voice/yoho1.mp3']},
 {id:'hum',name:'D · 轻唤嗯？',note:'非词句人声 · 嗯？ · 1.01 秒',files:['voice/n1.mp3']},
 {id:'dingdong',name:'F · 人声叮咚',note:'真人拟声 · 模仿叮咚提示 · 2.56 秒',files:['voice/pinponpanpon1.mp3']}
];
export function selectedVoicePack(state,role){return VOICE_PACKS.find(x=>x.id===(role.voice?.packId||state.settings.receivePack))||VOICE_PACKS[0];}
export function receiveFiles(state,role){
 const custom=state.assets.find(a=>a.id===(role.voice?.assetId||state.settings.receiveSoundId));if(custom)return[custom.file];
 const pack=selectedVoicePack(state,role);
 return pack.files.map(f=>'sounds/'+f);
}
export function retireLegacyVoice(state){
 let changed=false;
 const retired=['legacy','soft','sweet','playful'];
 const oldFile=f=>/^(?:sounds\/)?receive-(?:low|mid|high)\.wav$/.test(f)||/^(?:sounds\/)?voice\/(?:hai1|yobimashita1|ehehe1|kusukusu1|haihaai1|yondakana1)\.mp3$/.test(f);
 if(retired.includes(state.settings.receivePack)){state.settings.receivePack='message';changed=true;}
 for(const role of state.personas){
  if(!role.voice)continue;
  if(retired.includes(role.voice.packId)){role.voice.packId='message';changed=true;}
  if(role.voice.receive?.some(oldFile)){
   const retained=role.voice.receive.filter(f=>!oldFile(f));
   role.voice.receive=retained.length?retained:[...VOICE_PACKS[0].files];changed=true;
  }
 }
 return changed;
}
