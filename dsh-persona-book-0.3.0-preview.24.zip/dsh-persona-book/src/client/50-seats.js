/**
 * Shard 50: the seats this plugin occupies.
 *
 * `sidebar.footer.action` gives the panel its entry point (the seat receives
 * `{ wide }`, which is false in the collapsed sidebar), and `shell.overlay`
 * hosts the panel itself. Both render the same brand mark, so the place you
 * click and the place that opens look like one thing.
 */

/** The whale-tail mark, inlined so the sidebar needs no extra request. */
function BrandMark({ size = 22, className = null }) {
  return h('svg',{viewBox:'0 0 96 96',width:size,height:size,className,role:'img','aria-label':'人设本 · 月海鲸娘',fill:'none'},
    h('path',{d:'M67 7C36-2 8 22 10 51c2 23 22 40 46 36C35 80 24 66 26 48 28 27 45 12 67 7Z',fill:'#d8eaff'}),
    h('path',{d:'M25 63c9-12 22-16 39-8 8 3 14 3 19-2-3-9 0-18 10-22 2 9-1 17-7 21 5 1 8 5 9 11-8 2-13-1-16-6-8 18-32 22-49 11',fill:'#9fc9f5'}),
    h('path',{d:'M24 65c12-6 24-1 35 2 12 4 23 3 31-4M18 76c14-8 26-2 37 1 12 4 24 3 34-3',stroke:'currentColor',strokeWidth:2,strokeLinecap:'round'}),
    h('path',{d:'M46 42c-4-7-10-9-12-16 9 0 14 4 15 11 2-8 8-11 16-9-3 8-10 9-15 14-2 4-1 8-2 13-6-4-7-9-2-13Z',fill:'currentColor'}),
    h('circle',{cx:36,cy:61,r:1.7,fill:'#183556'}),h('path',{d:'m60 13 1.4 4.6L66 19l-4.6 1.4L60 25l-1.4-4.6L54 19l4.6-1.4Z',fill:'currentColor'}));
}

/** The sidebar entry point. */
function OpenButton({ wide = true, tr }) {
  return h('div',{className:'pb-sidebar-entry'},h(UsageMeter,{wide}),h(
    'button',
    {
      type: 'button',
      className: 'pb-sidebar-button',
      'data-wide': String(wide),
      title: tr('openHint'),
      onClick: () => openPanel(),
    },
    h(PbAvatar, { ui: useStore().snapshot?.profiles?.ui, seat: 'sidebarIcon', size: 22, fallback: h(BrandMark, { size: 22 }) }),
    h('span', { className: 'pb-sidebar-label' }, tr('open')),
  ));
}

/** The overlay seat: renders the panel while it is open. */
function PanelSeat({ tr }) {
  const state = useStore(),native = useHostState();
  const [warm,setWarm] = React.useState(false);
  const sessionId = state.open ? state.hostSessionId||'' : native?.sessionId||state.hostSessionId||'';
  React.useEffect(() => {
    if(state.discardPanel)return;
    const idle=typeof requestIdleCallback==='function';
    const task=idle?requestIdleCallback(()=>setWarm(true),{timeout:1200}):setTimeout(()=>setWarm(true),200);
    return()=>{if(idle)cancelIdleCallback(task);else clearTimeout(task);};
  },[state.discardPanel]);
  React.useEffect(() => ensureStyle(), []);
  React.useEffect(() => {
    if (state.open && state.snapshot === null && !state.loading) void loadSnapshot();
  }, [state.open, state.snapshot, state.loading]);
  React.useEffect(() => {
    if (!state.open) return undefined;
    const onKey = (event) => {
      if (event.key === 'Escape' && !state.busy) closePanel();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [state.open, state.busy]);
  const cached = React.useRef(false);
  if (state.discardPanel) cached.current = false;
  else if (state.open) cached.current = true;
  return h(React.Fragment,null,h(HostRoomSeat),!state.discardPanel&&(cached.current||warm)?h(SharedChatSeat,{tr,sessionId,key:sessionId}):null);
}

function SharedChatSeat({ tr,sessionId }) {
  const state = {...useStore(),hostSessionId:sessionId};
  const [full, setFull] = React.useState(false);
  const frame = React.useRef(null);
  const scrim = React.useRef(null);
  const [source] = React.useState(() => PB_PLAY+'/ui/index.html?embedded=1&host=1&sessionId='+encodeURIComponent(state.hostSessionId||'')+'&persona='+encodeURIComponent(pbHostState?.role?.id||'')+'&view='+encodeURIComponent(state.sharedView||'settings')+'&tab='+encodeURIComponent(state.sharedTab||'persona'));
  const lastTheme = React.useRef('');
  React.useEffect(() => {
    // Android WebView may resize only its visual viewport when the IME opens.
    const viewport = window.visualViewport;
    const resize = () => {
      if (window.innerWidth > 640) {
        scrim.current?.style.removeProperty('--pb-native-height');
        return;
      }
      scrim.current?.style.setProperty('--pb-native-height', `${Math.round(viewport?.height || window.innerHeight)}px`);
    };
    resize();
    viewport?.addEventListener('resize', resize);
    window.addEventListener('resize', resize);
    return () => {
      viewport?.removeEventListener('resize', resize);
      window.removeEventListener('resize', resize);
    };
  }, []);
  React.useEffect(() => {
    const sendView = () => frame.current?.contentWindow?.postMessage({type:'persona-book:panel',open:state.open,view:state.sharedView||'settings',tab:state.sharedTab||'persona'},location.origin);
    const sendTheme = () => {
      const style = getComputedStyle(document.body);
      const tokens = {};
      for (const name of ['alias-bg-base','alias-bg-overlay','specific-menu','alias-label-primary','alias-label-secondary','alias-label-tertiary','alias-border-l1','alias-border-l2','alias-interactive-bg-hover','alias-interactive-bg-hover-solid','alias-brand-primary']) {
        const value = style.getPropertyValue('--dsw-' + name).trim();
        if (value) tokens[name] = value;
      }
      const message={type:'persona-book:host-theme',tokens,motion:pbRoomEffects,dark:document.documentElement.dataset.pbWorld==='night'?!['day','paper','rose'].includes(document.documentElement.dataset.pbScene):document.body.hasAttribute('data-ds-dark-theme')};
      const signature=JSON.stringify(message);
      if(lastTheme.current===signature)return;
      lastTheme.current=signature;frame.current?.contentWindow?.postMessage(message,location.origin);
    };
    const bridge = (event) => {
      if (event.origin !== location.origin || event.source !== frame.current?.contentWindow) return;
      if (event.data?.type === 'persona-book:feedback') { pbInteractionCue(event.data.kind); return; }
      if (event.data?.type === 'persona-book:ready') { lastTheme.current='';sendTheme();sendView();return; }
      if (event.data?.type === 'persona-book:resource-change') { void pbHostRefresh(state.hostSessionId,event.data.rev,false,false).catch(()=>{}); return; }
      if (event.data?.type === 'persona-book:close') { closePanel(); return; }

    };
    let scheduled=null;
    const observer = new MutationObserver(() => {if(scheduled===null)scheduled=requestAnimationFrame(()=>{scheduled=null;sendTheme();});});
    const options={attributes:true,attributeFilter:['class','style','data-ds-dark-theme','data-pb-world','data-pb-scene','data-pb-motion']};
    observer.observe(document.body,options);
    observer.observe(document.documentElement,options);
    window.addEventListener('message',bridge);
    sendView();sendTheme();
    return () => { observer.disconnect();if(scheduled!==null)cancelAnimationFrame(scheduled);window.removeEventListener('message',bridge); };
  },[state.hostSessionId,state.open,state.sharedView,state.sharedTab]);
  return h('div', {ref:scrim,hidden:!state.open,style:state.open?undefined:{display:'none'},className:'pb-native-scrim','data-dsh-plugin':'persona-book',onClick:e=>{if(e.target===e.currentTarget)closePanel();}},
    h('section',{className:'pb-native-dialog',role:'dialog','aria-modal':'true','aria-label':'人设本设置','data-full':String(full),'data-dsh-part':'dialog'},
      h('header',{className:'pb-native-header'},
        h(BrandMark,{size:24}),
        h('div',{className:'pb-native-heading'},h('h3',null,'Whale Feather Character Design Book'),h('p',null,'当前 DSH 会话 · 人设与主题')),
        h('button',{onClick:()=>setFull(v=>!v),'aria-label':full?'退出全屏':'展开窗口',className:'pb-native-icon'},h(PbRoomIcon,{name:full?'restore':'expand'})),
        h('button',{onClick:closePanel,'aria-label':'关闭人设本',className:'pb-native-icon'},h(PbRoomIcon,{name:'close'}))),
      h('iframe',{ref:frame,title:'人设本设置与资源',src:source,className:'pb-native-frame'})));
}

/** Open the panel (and lazily fetch the snapshot). */
function openPanel(view = 'settings', sessionId = pbHostSession, sharedTab = 'persona') {
  setState({ open: true, discardPanel: false, sharedView: view || 'settings', hostSessionId: sessionId || '', sharedTab });
}

/** Close the panel, keeping the draft so nothing typed is lost. */
function closePanel() {
  setState({ open: false, error: null });
  void pbHostRefresh().catch(() => {});
}
