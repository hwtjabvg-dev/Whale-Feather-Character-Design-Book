/** Small, preloaded library sounds. No synthesised UI tones or second message transport. */
let pbReceiveCursor=0,pbLastCue=0,pbUiAudio=null,pbUiAudioFile='';
function pbNextReceive(state){const files=state.receiveFiles?.length?state.receiveFiles:[state.receiveFile];return files[pbReceiveCursor++%files.length];}
function pbInteractionCue(kind='tap'){
 const settings=pbHostState?.settings;if(!settings||!settings.sound||settings.interactionSound===false||document.hidden)return;
 const now=performance.now();if(now-pbLastCue<70)return;pbLastCue=now;
 const file={tap:'tap',select:'select',open:'open'}[kind]||'tap';
 try{const url=pbHostAsset(pbHostState?.interactionFiles?.[file]||'sounds/ui/tap.wav');if(!pbUiAudio||pbUiAudioFile!==url){pbUiAudio?.pause?.();pbUiAudio=new Audio(url);pbUiAudioFile=url;pbUiAudio.preload='auto';}else{pbUiAudio.pause?.();pbUiAudio.currentTime=0;}pbUiAudio.volume=Math.min(.5,Math.max(0,settings.interactionVolume??.22));pbUiAudio.play().catch(()=>{});}catch{}
}
function pbMountFeedback(){
 const click=e=>{
  const el=e.target.closest?.('button,summary');
  if(!el){const art=document.querySelector('.pb-night-stage .pb-room-art'),b=art?.getBoundingClientRect();if(b&&e.target.closest?.('[data-pb-host-region]')&&!e.target.closest('a,input,textarea,[contenteditable],[data-composer-seat],[data-pb-host-body],[data-turn-process]')&&e.clientX>=b.left&&e.clientX<=b.right&&e.clientY>=b.top&&e.clientY<=b.bottom)window.dispatchEvent(new Event('persona-book:companion-touch'));return;}
  if(el.disabled||!el.closest('.pb-host-controls,.pb-host-room,.pb-native-dialog,.pb-context-popover,.pb-sidebar-button,[data-pb-host-region]'))return;
  if(/^(发送|Send)/.test(el.getAttribute('aria-label')||''))return;
  const kind=el.closest('.pb-room-levels')?'select':el.closest('summary')||el.classList.contains('pb-room-quick')?'open':'tap';pbInteractionCue(kind);
 };
 document.addEventListener('click',click,true);
 return()=>{document.removeEventListener('click',click,true);pbUiAudio?.pause?.();pbUiAudio=null;};
}
const PB_FEEDBACK_CSS=`
.pb-host-controls button,.pb-room-menu>summary,.pb-native-header button,.pb-context-item{transition:none}
.pb-host-controls button:hover,.pb-room-menu>summary:hover{box-shadow:inset 0 0 0 1px rgb(175 210 248 / .55)}
.pb-host-controls button:active,.pb-native-header button:active,.pb-context-item:active{transform:scale(.95)}
.pb-night-stage .pb-companion-touch{position:absolute;inset:8% 18% 20% 7%;border:0;background:none;pointer-events:auto;cursor:pointer;border-radius:40%;color:transparent}
.pb-companion-touch:focus-visible{outline:2px solid #c5e2ff;outline-offset:4px}
.pb-companion-touch:hover{background:radial-gradient(ellipse at 40% 40%,rgb(188 222 255 / .08),transparent 65%)}
.pb-companion-line{position:absolute;bottom:18%;left:9%;max-width:230px;padding:12px 17px;background:rgb(17 36 63 / .96);border:1px solid #8ba7cb;border-radius:14px 14px 14px 3px;color:#edf5ff;font-size:13px;line-height:1.7;z-index:3;animation:none}
.pb-night-stage[data-reacting=true] .pb-room-art>img{animation:pb-companion-nod 700ms cubic-bezier(.16,1,.3,1) both;transform-origin:50% 80%}
@keyframes pb-companion-nod{0%{transform:translateY(0) rotate(0)}35%{transform:translateY(-7px) rotate(-1.2deg)}70%{transform:translateY(1px) rotate(.4deg)}100%{transform:none}}
@keyframes pb-companion-line{from{opacity:.2;transform:translateY(7px) scale(.97)}to{opacity:1;transform:none}}
.pb-night-stage[data-pose=standing][data-compact=false] .pb-room-art{right:1%;width:49%;height:75%;aspect-ratio:auto;bottom:115px}
.pb-night-stage[data-pose=standing] .pb-room-art>img{object-fit:contain;object-position:center bottom;mask-image:linear-gradient(#000 88%,transparent)}
.pb-night-stage[data-pose=standing][data-compact=true] .pb-room-art>img{object-fit:cover;object-position:50% 16%}
.pb-night-stage[data-compact=true] .pb-companion-line{bottom:5px;left:3%;font-size:11px;max-width:170px;padding:7px 10px}
html[data-pb-host=on][data-pb-world=night]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) body{color-scheme:light;--dsw-alias-bg-base:#edf2f8;--dsw-alias-bg-overlay:#fff;--dsw-specific-menu:#fff;--dsw-specific-sidebar-fill:#e8eef6;--dsw-alias-label-primary:#233853;--dsw-alias-label-secondary:#526680;--dsw-alias-label-tertiary:#526680;--dsw-alias-label-caption:#526680;--dsw-alias-border-l1:#bbcada;--dsw-alias-border-l2:#b2c3d9;--dsw-alias-border-l3:#b2c3d9;--dsw-alias-brand-primary:#315e8f;--dsw-alias-state-business-primary:#315e8f;--dsw-alias-button-elevated-fill:#dce7f3;--dsw-alias-button-elevated-hover:#c9d9ec;--dsw-alias-interactive-bg-hover:#dce7f3;--dsw-alias-interactive-bg-hover-solid:#dce7f3;background:#edf2f8;color:#233853}
html[data-pb-host=on][data-pb-world=night] [data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]){background-image:linear-gradient(90deg,rgb(242 247 253 / .88),rgb(242 247 253 / .72) 43%,rgb(242 247 253 / .06) 75%),var(--pb-host-scene)}
[data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) [data-pb-host-body=assistant]{background:rgb(255 253 250 / .93);color:var(--pb-host-text);border-color:var(--pb-host-border)}
[data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) [data-pb-host-body=user]{background:var(--pb-host-mine);color:var(--pb-host-text);border-color:var(--pb-host-border)}
[data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) [data-pb-host-body]::before{background-color:#e6eff9;border-color:#9cb4cf;box-shadow:none;color:#35597e}
[data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) [data-pb-host-body]::after{color:#526680}
[data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) [data-composer-seat]{background:linear-gradient(transparent,rgb(238 244 250 / .87))}
[data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) [data-composer-card]{background:rgb(250 253 255 / .96);border-color:#859dbb}
[data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) [data-composer-placeholder]{color:#5c718d}
[data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) .pb-host-controls{color:#35516f}
.pb-night-stage[data-light=true] .pb-night-title h2{color:#233d61;text-shadow:0 2px 12px #ffffff}
.pb-night-stage[data-light=true] .pb-room-heading p{color:#405a7a;text-shadow:0 2px 8px #ffffff}
.pb-night-stage[data-light=true] .pb-night-frame{border-color:rgb(71 103 144 / .5)}
.pb-night-stage[data-light=true] .pb-room-icon{background:#edf4fc;color:#35516f}
html[data-pb-host=on]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) .pb-sidebar-button{color:#31557d}
html[data-pb-host=on]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) .pb-native-dialog{background:#f8fbff;border-color:#859dbb}
html[data-pb-host=on]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) .pb-native-header{background:#edf3fb;color:#233853;border-color:#bbcada}
html[data-pb-host=on]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) .pb-native-header h3{color:#233853}
html[data-pb-host=on]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) .pb-native-header p,html[data-pb-host=on]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]) .pb-native-header button{color:#405a7a}
.pb-night-stage[data-light=true][data-compact=true]{background:linear-gradient(90deg,rgb(241 246 253 / .95),rgb(241 246 253 / .2))}
@media(max-width:940px){html[data-pb-host=on][data-pb-world=night] [data-pb-host-region]:is([data-pb-scene=day],[data-pb-scene=paper],[data-pb-scene=rose]){background-image:linear-gradient(rgb(242 247 253 / .3),rgb(242 247 253 / .85) 30%),var(--pb-host-scene)}}
html[data-pb-motion=off] .pb-host-controls *,html[data-pb-motion=off] .pb-companion-line,html[data-pb-motion=off] .pb-native-header button{animation:none;transition:none}
html[data-pb-motion=off] .pb-host-controls button:active{transform:none}
@media(prefers-reduced-motion:reduce){.pb-host-controls *,.pb-night-stage[data-reacting=true] .pb-room-art>img,.pb-companion-line,.pb-native-header button{animation:none;transition:none}}
`;
