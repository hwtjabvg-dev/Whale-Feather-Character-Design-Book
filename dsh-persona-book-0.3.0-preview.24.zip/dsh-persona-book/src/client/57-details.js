/** Selected journal skin and lightweight confirmed-usage meter. */
const PB_DETAIL_CSS=`
[data-pb-host-region][data-pb-bubble=journal] [data-pb-host-body]{background:linear-gradient(140deg,color-mix(in srgb,var(--pb-host-theirs) 88%,var(--pb-host-accent)),var(--pb-host-theirs));border:1px solid color-mix(in srgb,var(--pb-host-border) 65%,var(--pb-host-text));border-radius:17px 17px 17px 5px;box-shadow:inset 0 0 0 3px var(--pb-host-panel);--pb-tail-color:var(--pb-host-theirs)}
[data-pb-host-region][data-pb-bubble=journal] [data-pb-host-body=user]{background:linear-gradient(140deg,color-mix(in srgb,var(--pb-host-mine) 82%,var(--pb-host-accent)),var(--pb-host-mine));border-radius:17px 5px 17px 17px;--pb-tail-color:var(--pb-host-mine)}
[data-pb-host-region] .pb-bubble-tail{position:absolute;top:14px;left:-6px;width:10px;height:10px;background:var(--pb-tail-color);border-left:1px solid color-mix(in srgb,var(--pb-host-border) 65%,var(--pb-host-text));border-bottom:1px solid color-mix(in srgb,var(--pb-host-border) 65%,var(--pb-host-text));transform:rotate(45deg);pointer-events:none}
[data-pb-host-region][data-pb-user-avatar=signature] [data-pb-host-body=user]{margin-right:0}
[data-pb-host-region][data-pb-user-avatar=signature] [data-pb-host-body=user]::before{content:none;display:none}
[data-pb-host-region][data-pb-user-avatar=signature] [data-pb-host-body=user]::after{content:'你';position:absolute;top:-23px;left:0;font-size:11px;color:var(--pb-host-muted);line-height:18px}
.pb-night-stage[data-pose=standing][data-compact=false] .pb-room-art{height:calc(100% - 190px);max-height:75%;bottom:116px}
.pb-night-stage[data-pose=standing] .pb-room-art>img{mask-image:none;object-fit:contain;object-position:center bottom}
.pb-night-stage[data-pose=standing][data-compact=true] .pb-room-art{right:3%;width:42%;height:96%;top:2%}
.pb-sidebar-entry{width:100%;min-width:0}
.pb-usage{box-sizing:border-box;width:100%;padding:12px 13px;margin:8px 0 10px;border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:linear-gradient(140deg,var(--dsw-alias-bg-overlay),transparent);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;line-height:1.5}
.pb-usage header,.pb-usage-line{display:flex;justify-content:space-between;align-items:baseline;gap:8px}.pb-usage header{color:var(--dsw-alias-label-secondary);font-size:11px}.pb-usage button{border:0;padding:0;background:none;color:var(--dsw-alias-brand-primary);font:inherit;cursor:pointer}.pb-usage strong{font-size:23px;font-weight:600;font-variant-numeric:tabular-nums}.pb-usage small{font-size:10px;color:var(--dsw-alias-label-secondary)}.pb-usage-track{height:5px;display:flex;gap:2px;margin:7px 0;border-radius:4px;overflow:hidden;background:var(--dsw-alias-border-l1)}.pb-usage-track i{min-width:0;background:#a6c8f3}.pb-usage-track i:nth-child(2){background:#86cbb9}.pb-usage-track i:nth-child(3){background:#c1acf0}.pb-usage-legend{font-size:10px;color:var(--dsw-alias-label-secondary);display:flex;justify-content:space-between;gap:5px;flex-wrap:wrap}
`;
function pbUsageSummary(value,rates){
 const u=value?.values?.tokenUsage,keys=['uncachedInputTokens','cacheReadTokens','cacheWriteTokens','outputTokens'];
 if(!u||keys.some(k=>!Number.isSafeInteger(u[k])||u[k]<0))return null;
 const input=u.uncachedInputTokens+u.cacheWriteTokens,cache=u.cacheReadTokens,output=u.outputTokens,total=input+cache+output;
 if(!Number.isSafeInteger(total))return null;
 const valid=rate=>rate!==''&&rate!==null&&rate!==undefined&&Number.isFinite(Number(rate))&&Number(rate)>=0;
 const cost=rates&&['input','cache','output'].every(k=>valid(rates[k]))?(input*Number(rates.input)+cache*Number(rates.cache)+output*Number(rates.output))/1e6:null;
 return{input,cache,output,total,cost:Number.isFinite(cost)?cost:null,seq:value.asOfSeq};
}
function UsageMeter({wide=true}){
 const native=useHostState(),sid=native?.sessionId||'',enabled=native?.enabled!==false;
 const [sample,setSample]=React.useState(null),[failed,setFailed]=React.useState(false);
 React.useEffect(()=>{
  setSample(null);setFailed(false);if(!wide||!sid||!enabled)return;
  let disposed=false,busy=false,controller=null,lastSeq=-1;
  const refresh=async()=>{
   if(disposed||busy||document.hidden)return;busy=true;controller=new AbortController();const timeout=setTimeout(()=>controller?.abort(),8000);
   try{
    const method='session/projections',response=await fetch('/api/'+method,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({type:'client-request',rpcId:crypto.randomUUID(),method,payload:{args:{request:{sessionId:sid}}}}),signal:controller.signal});
    if(!response.ok)throw Error('usage unavailable');const result=(await response.json()).result;
    if(!result?.ok||!result.value)throw Error('usage unavailable');const value=result.value;
    if(!disposed&&value.asOfSeq>=lastSeq){lastSeq=value.asOfSeq;setSample(old=>old?.sessionId===sid&&old?.asOfSeq===value.asOfSeq?old:{sessionId:sid,asOfSeq:value.asOfSeq,values:{tokenUsage:value.values?.tokenUsage}});setFailed(false);}
   }catch{if(!disposed)setFailed(true);}finally{clearTimeout(timeout);busy=false;}
  };
  const visible=()=>{if(document.hidden)controller?.abort();else void refresh();};
  void refresh();const timer=setInterval(refresh,2000);document.addEventListener('visibilitychange',visible);window.addEventListener('persona-book:reply-visible',refresh);
  return()=>{disposed=true;clearInterval(timer);controller?.abort();document.removeEventListener('visibilitychange',visible);window.removeEventListener('persona-book:reply-visible',refresh);};
 },[sid,wide,enabled]);
 if(!wide||!enabled)return null;
 const data=pbUsageSummary(sample?.sessionId===sid?sample:null,native?.settings?.usageRates),fmt=n=>n.toLocaleString('zh-CN'),short=n=>n>=1000?(n/1000).toFixed(1)+'k':String(n);
 return h('section',{className:'pb-usage','aria-label':'当前会话用量',title:'宿主确认用量，每两秒更新；推理 token 已包含在输出中。费用按手动单价统一估算，非实际扣费。'},
  h('header',null,h('span',null,'当前会话 · '+(failed?'更新失败':data?'已确认用量':sid?'读取中':'请选择会话')),h('button',{type:'button',onClick:()=>openPanel('settings',sid,'more')},'计价')),
  h('div',{className:'pb-usage-line'},h('div',null,h('strong',null,data?fmt(data.total):'—'),h('small',null,' token')),h('span',null,data?.cost!==null&&data?.cost!==undefined?'≈ ¥'+data.cost.toFixed(4):'¥ —')),
  h('div',{className:'pb-usage-track','aria-hidden':'true'},...(data?[data.input,data.cache,data.output].map((n,i)=>h('i',{key:i,style:{flex:n||0}})):[])),
  h('div',{className:'pb-usage-legend'},...(data?[['输入',data.input],['缓存',data.cache],['输出',data.output]].map(([label,n])=>h('span',{key:label},label+' '+short(n))):[h('span',{key:'empty'},'等待宿主用量数据')])),
  h('small',null,data?.cost!==null&&data?.cost!==undefined?'手动单价估算 · 非实际扣费':'尚未设置计价 · 不计作零费用'));
}
