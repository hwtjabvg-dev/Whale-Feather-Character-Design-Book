/** The companion seat lives alongside DSH, never inside a replacement chat. */
let pbRoomLayout=null;
let pbRoomClosed=(()=>{try{return window.localStorage.getItem('pb-room-collapsed')==='1';}catch{return false;}})();
let pbRoomMobileOpen=false;
let pbRoomNightMobileClosed=false;
let pbRoomEffects=(()=>{try{return window.localStorage.getItem('pb-room-effects')!=='off';}catch{return true;}})();
function pbRoomToggleEffects(){pbRoomEffects=!pbRoomEffects;try{window.localStorage.setItem('pb-room-effects',pbRoomEffects?'on':'off');}catch{}pbHostNotify();window.dispatchEvent(new Event('persona-book:changed'));}
function PbRoomIcon({name,size=18}){
  const paths={close:'m6 6 12 12M6 18 18 6',portrait:'M5 3h14v18H5zM9 9a3 3 0 1 0 6 0 3 3 0 0 0-6 0M8 18c0-5 8-5 8 0',more:'M5 12h.01M12 12h.01M19 12h.01',dress:'m8 3 4 3 4-3 5 5-4 3v10H7V11L3 8z',settings:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4',volume:'M11 5 6 9H3v6h3l5 4V5M15 8a6 6 0 0 1 0 8',update:'M20 7v5h-5M4 17v-5h5M6 7a7 7 0 0 1 12-1l2 3M4 15l2 3a7 7 0 0 0 12-1'};
  Object.assign(paths,{motion:'M3 8c4-6 6 6 10 0s6 0 8 0M3 16c4-6 6 6 10 0s6 0 8 0',expand:'M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5',restore:'M9 3v6H3m12 12v-6h6M9 9l-6-6m12 12 6 6'});
  return h('svg',{width:size,height:size,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:1.6,strokeLinecap:'round',strokeLinejoin:'round','aria-hidden':'true'},h('path',{d:paths[name]||paths.more}));
}
function pbRoomToggle(force){
  if(pbRoomLayout?.compact&&pbRoomLayout.world==='night')pbRoomNightMobileClosed=force===undefined?!pbRoomNightMobileClosed:!force;
  else if(pbRoomLayout?.compact)pbRoomMobileOpen=force===undefined?!pbRoomMobileOpen:force;
  else{pbRoomClosed=force===undefined?!pbRoomClosed:!force;try{window.localStorage.setItem('pb-room-collapsed',pbRoomClosed?'1':'0');}catch{}}
  pbHostNotify();window.dispatchEvent(new Event('persona-book:changed'));
}
function useRoomLayout(){const[,update]=React.useState(0);React.useEffect(()=>{const fn=()=>update(n=>n+1);pbHostListeners.add(fn);return()=>pbHostListeners.delete(fn);},[]);return pbRoomLayout;}
function HostRoomSeat(){
  const layout=useRoomLayout(),state=useHostState(layout?.sessionId);
  const [reaction,setReaction]=React.useState(0),reactionTimer=React.useRef(null),reactionCount=React.useRef(0);
  const greet=()=>{setReaction(++reactionCount.current);clearTimeout(reactionTimer.current);reactionTimer.current=setTimeout(()=>setReaction(0),2300);};
  React.useEffect(()=>{const reply=()=>{if(pbRoomEffects)greet();},touch=()=>{greet();pbInteractionCue('open');};window.addEventListener('persona-book:reply-visible',reply);window.addEventListener('persona-book:companion-touch',touch);return()=>{window.removeEventListener('persona-book:reply-visible',reply);window.removeEventListener('persona-book:companion-touch',touch);clearTimeout(reactionTimer.current);};},[]);
  const close=React.useRef(null);
  const open=!!layout&&!!state?.enabled&&(layout.compact?(layout.world==='night'?!pbRoomNightMobileClosed:pbRoomMobileOpen):!pbRoomClosed)&&!layout.keyboard;
  React.useEffect(()=>{if(!open)return;const onKey=e=>{if(e.key==='Escape'){pbRoomToggle(false);e.stopPropagation();}};window.addEventListener('keydown',onKey);return()=>window.removeEventListener('keydown',onKey);},[open]);
  if(!open)return null;
  const region=[...document.querySelectorAll('[data-pb-host-region]')].find(el=>el.dataset.conversationSession===layout.sessionId&&el.isConnected&&el.getClientRects().length&&!el.closest('[hidden],[aria-hidden=true]'));
  if(!region)return null;
  let portal;try{portal=require('react-dom').createPortal;}catch{return null;}
  if(typeof portal!=='function')return null;
  const render=(...args)=>portal(h(...args),region);
  const role=state.role,name=role.title.replace(/^DeepSeek娘\s*·\s*/,''),level=role.defaults.toneIntensity;
  const original=role.id==='tsundere-kitten-persona'||role.presentation?.basePersonaId==='tsundere-kitten-persona';
  const vars=Object.fromEntries(Object.entries(layout.tokens).map(([key,value])=>['--pb-host-'+key,value]));
  const night=layout.world==='night',scene=layout.scene||{};
  if(night)return render('aside',{key:scene.id||'night',className:'pb-host-room pb-night-stage','aria-label':'鲸娘会客室','data-world':'night','data-reacting':String(!!reaction),'data-pose':scene.pose||'recline','data-light':String(!!scene.light),'data-effects':String(pbRoomEffects),'data-compact':String(layout.compact),style:{...vars,position:'absolute',top:layout.insetTop??12,right:layout.insetRight??12,width:layout.width,height:layout.height}},
    h('div',{className:'pb-night-frame','aria-hidden':'true'},...[0,1,2,3].map(n=>h('i',{key:n,'data-corner':n}))),
    h('header',{className:'pb-room-heading'},h('div',{className:'pb-night-title'},h('h2',null,scene.title||'深海私语'),h('p',{style:{whiteSpace:'pre-line'}},scene.caption||'这一份温柔的夜晚，\n只想说给你听。')),h('button',{ref:close,type:'button',onClick:()=>pbRoomToggle(false),'aria-label':'收起立绘',className:'pb-room-icon'},h(PbRoomIcon,{name:'close'}))),
    h('div',{key:role.id,className:'pb-room-art','data-original':String(original)},original?h('img',{src:pbHostAsset(scene.portrait||'art/whale-recline-c.webp'),alt:name+'的角色立绘',decoding:'async'}):null,reaction>0&&h('span',{key:reaction,className:'pb-companion-line',role:'status'},original?['嗯？主人，人家在听。','哼……才不是特意等主人呢。','好啦，慢慢说，人家陪着。'][(reaction-1)%3]:'嗯，正在听你说。')));
  return render('aside',{key:layout.world,className:'pb-host-room','aria-label':'鲸娘会客室','data-world':layout.world,'data-effects':String(pbRoomEffects),'data-compact':String(layout.compact),style:{...vars,position:'absolute',top:layout.insetTop??12,right:layout.insetRight??12,width:layout.width,height:layout.height}},
    h('header',{className:'pb-room-heading'},h('div',null,night?h('div',{className:'pb-night-title'},h(BrandMark,{size:38}),h('h2',null,'深海私语')):h('h2',null,name),h('p',null,night?name+' · 鲸娘会客室':'鲸娘会客室')),h('button',{ref:close,type:'button',onClick:()=>pbRoomToggle(false),'aria-label':'收起立绘',className:'pb-room-icon'},h(PbRoomIcon,{name:'close'}))),
    h('div',{key:role.id,className:'pb-room-art'},original?h('img',{src:pbHostAsset('art/whale-welcome-v3.webp'),alt:name+'的角色立绘',decoding:'async'}):null),
    h('div',{className:'pb-room-caption'},h('span',{className:'pb-room-line'}),h('span',null,night&&original?'月色正好，慢慢说给人家听。':'在这段对话里，慢慢熟悉彼此。')),
    h('footer',{className:'pb-room-footer'},h('div',{className:'pb-room-current'},h('span',null,'当前会话人设'),h('strong',null,(level<=3?'低档':level<=6?'中档':'高档')+' · '+level+'/10')),
      h('div',{className:'pb-room-actions'},h('button',{type:'button',onClick:()=>openPanel('settings',layout.sessionId,'theme')},h(PbRoomIcon,{name:'dress'}),'换装'),h('button',{type:'button',onClick:()=>openPanel('settings',layout.sessionId,'persona')},h(PbRoomIcon,{name:'settings'}),'人设设置'))));
}
