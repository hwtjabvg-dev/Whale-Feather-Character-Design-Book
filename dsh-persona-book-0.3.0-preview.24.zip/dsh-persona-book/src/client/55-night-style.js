/** 深海私语: a shared moonlit stage on the original DSH conversation. */
const PB_NIGHT_CSS=`
@font-face{font-family:WhaleNightDisplay;src:url("${pbHostAsset('fonts/whale-night-serif.woff2')}") format('woff2');font-style:normal;font-weight:400;font-display:swap}
html[data-pb-host=on][data-pb-world=night] body{color-scheme:dark;--dsw-alias-bg-base:#0c172a;--dsw-alias-bg-overlay:#15243b;--dsw-specific-menu:#15243b;--dsw-specific-sidebar-fill:#0d1b30;--dsw-alias-border-l3:#344b6c;--shiki-background:#0d1c31;--shiki-foreground:#d7e4f8;--shiki-token-keyword:#b8bfff;--shiki-token-string:#b9dfb2;--shiki-token-function:#add8ff;--shiki-token-constant:#f2cea8;--shiki-token-punctuation:#c4d3e9;--dsw-alias-label-primary:#edf3fb;--dsw-alias-label-secondary:#b2c3db;--dsw-alias-label-tertiary:#a8bad3;--dsw-alias-label-caption:#a8bad3;--dsw-alias-border-l1:#344b6c;--dsw-alias-border-l2:#425b7d;--dsw-alias-interactive-bg-hover:#233a5b;--dsw-alias-interactive-bg-hover-solid:#233a5b;--dsw-alias-brand-primary:#a5ceff;--dsw-alias-state-business-primary:#a5ceff;background:#0c172a;color:#edf3fb}
html[data-pb-host=on][data-pb-world=night] ::selection{background:#355a86;color:#fff}
html[data-pb-host=on][data-pb-world=night] [data-rightbar-collapsed]:has(> [data-rightbar-col]){overflow:clip}
html[data-pb-host=on][data-pb-world=night] body{--dsw-alias-button-elevated-fill:#1a2e49;--dsw-alias-button-elevated-hover:#2a4568;--dsw-alias-markdown-code-block:#0c1b30;--dsw-alias-markdown-code-block-banner:#172c48}
html[data-pb-host=on][data-pb-world=night] :focus-visible{outline-color:#a5ceff;outline-offset:3px}
html[data-pb-host=on] [data-pb-host-region][data-pb-world=night]{--dsw-alias-bg-base:transparent;background-color:#0b1425;background-image:linear-gradient(90deg,rgb(7 17 35 / .64),rgb(9 19 39 / .44) 40%,rgb(9 19 39 / .05) 70%,transparent),var(--pb-host-scene);background-size:cover;background-position:center;scrollbar-color:#4b6384 #111d31}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body]{border:1px solid rgb(126 158 200 / .28);line-height:1.9;padding:12px 16px;box-shadow:none}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body=assistant]{background:rgb(24 47 79 / .90);border-radius:4px 14px 14px;color:#edf3fb}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body=user]{background:rgb(63 99 153 / .90);border-radius:14px 4px 14px 14px;color:#f4f7ff}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body]::before{border:1px solid #5b7aa3;border-radius:50%;background-color:#192b46}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body=assistant]::after{color:#c2d5f2;font-size:12px}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body] pre{background:#0b192d;border:1px solid #344b6c;border-radius:8px}
[data-pb-world=night][data-pb-host-region] [data-code-wrap]{background:#0c1b30;border:1px solid #354f73;border-radius:10px;overflow:hidden;--shiki-background:transparent;--shiki-foreground:#d7e4f8;--shiki-token-keyword:#b8bfff;--shiki-token-string:#b9dfb2;--shiki-token-function:#add8ff;--shiki-token-constant:#f2cea8;--shiki-token-comment:#a2b5d0}
[data-pb-world=night][data-pb-host-region] [data-code-wrap]{--shiki-token-string-expression:#b9dfb2;--shiki-token-parameter:#f2cea8;--shiki-token-link:#add8ff}
[data-pb-world=night][data-pb-host-region] [data-composer-seat]{background:linear-gradient(0deg,#0c172a 5%,rgb(12 23 42 / .94) 66%,transparent)}
[data-pb-world=night][data-pb-host-region] [data-composer-card]{background:rgb(16 31 53 / .97);border:1px solid #657f9e;border-radius:12px;box-shadow:0 12px 32px rgb(0 6 18 / .22)}
[data-pb-world=night] .pb-host-controls{color:#bdcce2;padding:10px 2px 12px;gap:12px}
[data-pb-world=night] .pb-host-controls .pb-room-role{color:#edf3fb}
[data-pb-world=night] .pb-room-mini-avatar{border-radius:50%;box-shadow:0 0 0 1px #637fa4}
[data-pb-world=night] .pb-room-levels{border:1px solid #456183;background:#14253e;border-radius:8px;padding:3px}
[data-pb-world=night] .pb-room-levels button{color:#b4c6e1;min-width:31px}
[data-pb-world=night] .pb-room-levels button[data-active=true]{background:#c1dcff;color:#10223e;font-weight:600}
[data-pb-world=night] .pb-room-menu[open]>div{background:#14243c;border-color:#5b769b;box-shadow:0 14px 32px rgb(0 5 18 / .35);transform-origin:bottom right;animation:none}
html[data-pb-world=night] .pb-sidebar-button{color:#c6defe}html[data-pb-world=night] .pb-sidebar-button:hover{background:#223958}
html[data-pb-world=night] .pb-native-scrim{background:rgb(3 10 23 / .58);backdrop-filter:none}
html[data-pb-world=night] .pb-native-dialog{border:1px solid #536f94;border-radius:16px;background:#14243c;box-shadow:0 24px 72px rgb(0 4 14 / .5);animation:none}
html[data-pb-world=night] .pb-native-header{background:#112138;color:#edf3fb;border-color:#354f72}html[data-pb-world=night] .pb-native-header h3{color:#edf3fb}html[data-pb-world=night] .pb-native-header p{color:#b2c3db}
html[data-pb-world=night] .pb-native-header button{color:#bcd2ee}html[data-pb-world=night] .pb-native-icon:hover,html[data-pb-world=night] .pb-native-text:hover{background:#29415f}
html[data-pb-motion=on] [data-pb-host-arrive]{animation:none}
@keyframes pb-night-seat{from{opacity:.6;transform:translateX(14px)}to{opacity:1;transform:none}}
@keyframes pb-night-curtain{from{opacity:.55;clip-path:inset(0 16% 0 0)}to{opacity:1;clip-path:inset(0)}}
@keyframes pb-night-menu{from{opacity:.8;transform:translateY(5px) scale(.98)}to{opacity:1;transform:none}}
@keyframes pb-night-dialog{from{opacity:.8;transform:translateY(10px)}to{opacity:1;transform:none}}
@keyframes pb-night-message{from{opacity:.75;transform:translateY(5px)}to{opacity:1;transform:none}}

/* C: one illustrated room, left transcript, wide character and continuous input rail. */
html[data-pb-host=on] [data-pb-host-region][data-pb-world=night]{padding-inline-end:0;container-type:inline-size;background-position:right center}
[data-pb-world=night][data-pb-host-region] [data-chat-flow]{box-sizing:border-box;width:100%;max-width:none;padding:28px 28px 20px;margin:0;gap:10px}
[data-pb-world=night][data-pb-stage-visible][data-pb-room-side] [data-chat-flow]{width:48%;min-width:440px}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body]{margin-top:22px;margin-bottom:5px;max-width:calc(100% - 44px);font-size:var(--pb-host-font);line-height:1.8}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body=assistant]{margin-left:40px}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body=user]{margin-left:40px;margin-right:0}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body]::before{width:30px;height:30px;left:-40px;right:auto;box-shadow:0 0 0 3px rgb(11 25 45 / .5)}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body=user]::before{left:-40px;right:auto}
[data-pb-world=night][data-pb-host-region] [class$=_userRow]{align-items:stretch}
[data-pb-world=night][data-pb-host-region] [class$=_userStack]{max-width:100%;width:100%;align-items:stretch}
[data-pb-world=night][data-pb-host-region] [data-turn-process]{font-size:11px;min-height:24px;padding:0;border:0;opacity:.85}
[data-pb-world=night][data-pb-host-region] [data-turn-tail]{font-size:11px;min-height:24px}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body] p{margin-block:0 9px}
[data-pb-world=night][data-pb-host-region] [data-pb-host-body] p:last-child{margin-bottom:0}
.pb-host-room.pb-night-stage[data-world=night]{padding:0;display:block;pointer-events:none;background:none;border:0;border-radius:0;overflow:hidden;box-shadow:none;z-index:12;isolation:auto;animation:none}
.pb-night-stage .pb-night-frame{position:absolute;inset:0;border:1px solid rgb(160 194 230 / .38);border-radius:13px;pointer-events:none}
.pb-night-frame::after{content:'';position:absolute;inset:5px;border:1px solid rgb(160 194 230 / .14);border-radius:9px}
.pb-night-frame i{position:absolute;width:86px;height:86px;background:url("${pbHostAsset('art/night-corner.svg')}") center/contain no-repeat;opacity:.8}
.pb-night-frame i[data-corner="0"]{top:-1px;left:-1px}.pb-night-frame i[data-corner="1"]{top:-1px;right:-1px;transform:rotate(90deg)}.pb-night-frame i[data-corner="2"]{bottom:-1px;right:-1px;transform:rotate(180deg)}.pb-night-frame i[data-corner="3"]{bottom:-1px;left:-1px;transform:rotate(270deg)}
.pb-night-stage[data-world=night] .pb-room-heading{position:static;display:block;text-align:right;padding:0}
.pb-night-stage .pb-night-title{position:absolute;right:38px;top:40px;z-index:2;max-width:42%}
.pb-night-title h2{font:500 clamp(30px,3vw,42px)/1.5 WhaleNightDisplay,serif;letter-spacing:.1em;margin:0;color:#edf5ff;text-shadow:0 3px 16px #07152c}
.pb-night-stage .pb-room-heading p{font:400 14px/1.9 WhaleNightDisplay,serif;color:#d8e6fa;margin:10px 0 0;letter-spacing:.06em;text-shadow:0 2px 8px #09162c}
.pb-night-stage .pb-room-icon{position:absolute;top:8px;right:8px;width:28px;height:28px;border:1px solid rgb(154 185 221 / .4);background:rgb(14 30 51 / .7);color:#cfdef2;pointer-events:auto;z-index:4}
.pb-night-stage[data-world=night] .pb-room-art{position:absolute;bottom:116px;right:-60px;width:59%;height:auto;aspect-ratio:1.5;margin:0;overflow:visible;display:flex;animation:none}
.pb-night-stage[data-world=night] .pb-room-art>img{width:100%;height:100%;object-fit:contain;filter:drop-shadow(-10px 18px 20px rgb(0 5 20 / .25));mask-image:linear-gradient(#000 88%,transparent);object-position:center bottom}
[data-pb-world=night][data-pb-host-region] [data-composer-seat]{background:linear-gradient(transparent,rgb(8 18 36 / .8) 70%);padding:0 28px 14px;z-index:18}
[data-pb-world=night] [class*=_composerStack]{position:relative;width:100%;max-width:none;padding:0;gap:0}
[data-pb-world=night] [data-slot="conversation.composer.bar"]>[class$=_root]{width:100%;max-width:none;margin:0;padding:0}
[data-pb-world=night] [data-slot="conversation.input.dock"]{display:contents}
[data-pb-world=night] .pb-host-controls{position:absolute;right:68px;top:9px;width:auto;min-height:36px;padding:0;margin:0;gap:6px;z-index:3;color:#d2e3fa}
[data-pb-world=night] .pb-host-controls .pb-room-role{width:30px;max-width:30px;padding:0;justify-content:center}
[data-pb-world=night] .pb-room-role>span:last-child{display:none}
[data-pb-world=night] .pb-room-levels{border:1px solid #627c9f;background:#182c49;border-radius:18px;padding:2px}
[data-pb-world=night] .pb-room-levels button{height:25px;min-width:28px;border-radius:15px;padding:1px 6px}
[data-pb-world=night] .pb-room-levels button[data-active=true]{background:#c1dcff;color:#11294a}
[data-pb-world=night] .pb-host-controls .pb-room-quick{display:inline-flex;border:1px solid #5e789c;background:#152b49;border-radius:18px;padding:4px 11px;height:32px;color:#e6f0ff;font-size:12px}
[data-pb-world=night] .pb-host-controls .pb-room-stage-toggle{margin-left:0;width:26px;padding:0}
[data-pb-world=night] .pb-room-stage-label{display:none}
[data-pb-world=night] .pb-room-menu>summary{width:24px;padding:0}
[data-pb-world=night][data-pb-host-region] [data-composer-card]{box-sizing:border-box;width:100%;max-width:none;gap:0;position:relative;border:1px solid #90a7c8;border-radius:26px;background:rgb(13 28 49 / .94);box-shadow:0 12px 32px rgb(0 6 18 / .2);padding-top:5px;overflow:visible}
[data-pb-world=night][data-pb-host-region] [data-input-scroll]{width:calc(100% - 460px);min-height:44px;max-height:180px;margin:0 0 0 8px;padding:0}
[data-pb-world=night][data-pb-host-region] [data-composer-input]{min-height:44px;padding:10px 14px;line-height:24px;font-size:13px}
[data-pb-world=night][data-pb-host-region] [data-composer-placeholder]{top:10px;left:14px;right:8px;font-size:13px;color:#b9c8df;line-height:24px}
[data-pb-world=night] [data-composer-card]>[class$=_row]{height:35px;min-height:35px;padding:0 14px 4px;margin:0;border-top:1px solid rgb(132 162 199 / .2)}
[data-pb-world=night] [data-composer-card] [class$=_primary]{position:absolute;right:10px;top:10px;width:32px;height:32px;border:1px solid #9ab6da;background:#c7dfff;color:#153152;border-radius:50%}
[data-pb-world=night] [data-composer-card] [class$=_primary]:disabled{background:#314764;color:#b9cbe4;border-color:#5b7190}
[data-pb-world=night] [data-composer-card] [class$=_trailing]{padding:0;gap:8px}
[data-pb-world=night] [data-composer-card] [class$=_tools]{gap:8px}
[data-pb-world=night] [data-composer-card] [class$=_model]{font-size:11px}
[data-pb-world=night] [data-composer-card] [class$=_add]{width:24px;height:24px;background:transparent;border:1px solid #7f9bbf;color:#ccddf5}
[data-pb-world=night] [class$=_dock]:has([data-composer-stats]){height:22px;min-height:22px;padding:0;margin-top:2px}
html[data-pb-host=on][data-pb-world=night] [data-sidebar]{border:1px solid rgb(145 178 218 / .3)}
@container(max-width:939px){
 [data-pb-world=night][data-pb-stage-visible] [data-conversation-scroll]{margin-top:190px;height:calc(100% - 190px);max-height:calc(100% - 190px)}
 [data-pb-world=night][data-pb-host-region] [data-chat-flow]{padding-inline:14px;min-width:0;width:100%}
 [data-pb-world=night][data-pb-host-region] [data-composer-seat]{padding:0 12px 8px}
 [data-pb-world=night][data-pb-host-region] [data-input-scroll]{width:calc(100% - 44px);margin-left:0;max-height:130px}
 [data-pb-world=night][data-pb-host-region] [data-composer-card]{border-radius:16px;padding-bottom:0}
 [data-pb-world=night][data-pb-host-region] [data-composer-card]>[class$=_row]{margin-top:36px;padding-inline:8px;height:37px}
 [data-pb-world=night] .pb-host-controls{top:51px;right:0;left:0;justify-content:center;gap:5px;width:100%;padding:0 6px;box-sizing:border-box}
 [data-pb-world=night] .pb-host-controls .pb-room-quick{font-size:11px;padding:3px 7px;gap:4px;min-width:0}
 [data-pb-world=night] .pb-room-levels button{min-width:24px;padding:1px 4px}
 [data-pb-world=night] .pb-room-mini-avatar{width:22px;height:22px}
 [data-pb-world=night] .pb-host-controls .pb-room-role{width:24px;max-width:24px}
}
.pb-host-room.pb-night-stage[data-world=night][data-compact=true]{display:block;padding:0;gap:0;box-shadow:none;background:linear-gradient(90deg,rgb(10 23 43 / .9),transparent 65%);border-radius:12px;overflow:hidden}
@container(max-width:339px){
 [data-pb-world=night] .pb-host-controls{flex-wrap:wrap;min-height:64px;height:auto;align-content:center;gap:4px}
 [data-pb-world=night] .pb-host-controls .pb-room-role{display:none}
 [data-pb-world=night][data-pb-host-region] [data-composer-card]>[class$=_row]{margin-top:72px}
}
.pb-night-stage[data-world=night][data-compact=true] .pb-room-heading{position:static;text-align:left}
.pb-night-stage[data-compact=true] .pb-night-title{top:25px;left:18px;right:auto;max-width:48%;z-index:3}
.pb-night-stage[data-compact=true] .pb-night-title h2{font-size:27px;letter-spacing:.06em}
.pb-night-stage[data-compact=true] .pb-room-heading p{font-size:10px;line-height:1.8;margin:7px 0 0}
.pb-night-stage[data-world=night][data-compact=true] .pb-room-art{position:absolute;top:4px;right:-55px;bottom:auto;width:82%;height:100%;margin:0;aspect-ratio:auto}
.pb-night-stage[data-compact=true] .pb-room-art>img{object-fit:cover;object-position:20% top;mask-image:linear-gradient(#000 80%,transparent)}
.pb-night-stage[data-compact=true] .pb-room-art[data-original=false]{right:5%;width:40%;align-items:center}
.pb-night-stage[data-compact=true] .pb-room-icon{position:absolute;top:8px;right:8px;width:28px;height:28px;z-index:4}
.pb-night-stage[data-compact=true] .pb-night-frame i{width:55px;height:55px}
@media(max-width:940px){html[data-pb-host=on] [data-pb-host-region][data-pb-world=night]{background-image:linear-gradient(rgb(8 19 38 / .35),rgb(8 19 38 / .68) 35%),var(--pb-host-scene);background-position:70% top}}

html[data-pb-host][data-pb-motion=off] .pb-host-room[data-world],html[data-pb-host][data-pb-motion=off] .pb-host-room[data-world] *,html[data-pb-motion=off] .pb-room-menu>div,html[data-pb-motion=off] .pb-native-dialog,html[data-pb-motion=off] [data-pb-host-arrive]{animation:none;transition:none}
@media(prefers-reduced-motion:reduce){html[data-pb-host] .pb-host-room[data-world],html[data-pb-host] .pb-host-room[data-world] *,html[data-pb-host] .pb-room-menu>div,html[data-pb-host] .pb-native-dialog,html[data-pb-host] [data-pb-host-arrive]{animation:none;transition:none}}
`;
