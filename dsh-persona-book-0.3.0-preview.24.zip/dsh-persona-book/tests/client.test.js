/**
 * Client bundle tests: load `lib/client.js` the way the browser module loader
 * does (with stubbed `window` and `react`), then check the module's public
 * surface and the seats it registers. No DOM required.
 */
import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

/** A minimal React stand-in: enough to build element trees without a DOM. */
const ReactStub = {
  Fragment: Symbol('Fragment'),
  createElement(type, props, ...children) {
    return { type, props: props ?? {}, children };
  },
  useState(initial) {
    return [typeof initial === 'function' ? initial() : initial, () => {}];
  },
  useEffect() {},
  useMemo(factory) {
    return factory();
  },
  useRef(value) {
    return { current: value };
  },
};

/** Evaluate the bundle and hand back the module it loaded. */
async function loadBundle() {
  const source = await readFile(join(root, 'lib', 'client.js'), 'utf8');
  let loaded = null;
  const windowStub = {
    __ModuleLoader__: {
      load(module) {
        loaded = module;
      },
    },
    addEventListener() {},
    removeEventListener() {},
    dispatchEvent() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
    localStorage: {
      store: new Map(),
      getItem(key) {
        return this.store.has(key) ? this.store.get(key) : null;
      },
      setItem(key, value) {
        this.store.set(key, String(value));
      },
      removeItem(key) {
        this.store.delete(key);
      },
    },
    location: { search: '', href: 'http://localhost/' },
  };
  const elementStub = () => ({
    attributes: {},
    dataset: {},
    style: {},
    children: [],
    textContent: '',
    append() {},
    remove() {},
    setAttribute(key, value) {
      this.attributes[key] = String(value);
    },
    removeAttribute(key) {
      delete this.attributes[key];
    },
    getAttribute(key) {
      return Object.prototype.hasOwnProperty.call(this.attributes, key) ? this.attributes[key] : null;
    },
    addEventListener() {},
    removeEventListener() {},
    querySelector: () => null,
    querySelectorAll: () => [],
  });
  const documentStub = {
    documentElement: elementStub(),
    head: elementStub(),
    body: elementStub(),
    readyState: 'complete',
    createElement: () => elementStub(),
    querySelector: () => null,
    querySelectorAll: () => [],
    getElementById: () => null,
    addEventListener() {},
    removeEventListener() {},
  };
  const requireStub = (name) => {
    if (name === 'react') return ReactStub;
    throw new Error(`unexpected require(${name})`);
  };
  // The bundle is a classic script: run it with the stubs in scope.
  const run = new Function('window', 'document', 'require', 'MutationObserver', 'setInterval', 'clearInterval', 'requestAnimationFrame', 'fetch', source);
  run(windowStub, documentStub, requireStub,
    class {observe(){} disconnect(){}},()=>0,()=>{},fn=>fn(),async()=>{throw Error('No network in registration test');});
  assert.ok(loaded !== null, 'the bundle must call __ModuleLoader__.load');
  assert.equal(loaded.id, 'dsh-persona-book');
  return loaded.factory(requireStub);
}

test('the bundle loads and exposes the module surface', async () => {
  const module = await loadBundle();
  assert.equal(module.NS, 'personaBook');
  assert.equal(typeof module.apply, 'function');
  assert.deepEqual(module.inject, ['slots', 'locale']);
});

test('apply registers the sidebar button and the overlay panel', async () => {
  const module = await loadBundle();
  const registered = [];
  const dictionaries = [];
  const effects = [];
  const ctx = {
    locale: {
      bind: (ns) => (key, ...args) => `${ns}:${key}${args.length > 0 ? `:${args.join(',')}` : ''}`,
      register: (ns, dict) => dictionaries.push({ ns, dict }),
    },
    configForms: { get: () => null },
    effect: (fn, label) => {
      effects.push(label);
      return fn();
    },
    slots: {
      inject: (_name, fn) => fn(),
      register: (definition, component) => registered.push({ definition, component }),
    },
  };
  module.apply(ctx);

  assert.equal(dictionaries.length, 1);
  assert.equal(dictionaries[0].ns, 'personaBook');
  assert.ok(dictionaries[0].dict.zh.title.includes('设定集'));
  assert.ok(dictionaries[0].dict.en.title.length > 0);

  const sidebar = registered.find((entry) => entry.definition.name === 'sidebar.footer.action');
  const overlay = registered.find((entry) => entry.definition.name === 'shell.overlay');
  assert.ok(sidebar !== undefined, 'sidebar.footer.action seat');
  assert.ok(overlay !== undefined, 'shell.overlay seat');
  assert.equal(sidebar.definition.order, 30);
  assert.equal(sidebar.definition.id, 'persona-book');
  assert.equal(overlay.definition.id, 'persona-book-panel');

  // The button renders from the translated props without touching the DOM.
  const tr = (key) => key;
  const entry = sidebar.component({ wide: true, tr });
  const button = entry.children[1];
  assert.equal(button.type, 'button');
  assert.equal(button.props.className, 'pb-sidebar-button');
  assert.equal(button.props['data-wide'], 'true');
  assert.ok(button.children.length >= 2, 'brand mark plus a label');

  const collapsed = sidebar.component({ wide: false, tr });
  assert.equal(collapsed.children[1].props['data-wide'], 'false');
});

test('the debug surface exposes only pure helpers', async () => {
  const module = await loadBundle();
  const debug = module.__debug;
  assert.ok(debug !== null && typeof debug === 'object');
  for (const name of ['pbcEffectivePalette', 'pbcAudit', 'pbcSurface', 'pbVarList', 'pbcRatio']) {
    assert.equal(typeof debug[name], 'function', `${name} must be a function`);
  }
});

function contextHarness(names = []) {
  const declared = new Set(names), waiters = [], entries = [], timers = new Map();
  let next = 0;
  const slots = {
    inject(name, fn) {
      const waiter = {name, fn, active:true}; waiters.push(waiter);
      if (declared.has(name)) fn();
      return () => { waiter.active = false; };
    },
    register(definition, component) {
      assert.ok(declared.has(definition.name));
      const entry = {definition,component,active:true}; entries.push(entry);
      return () => {entry.active=false;};
    },
  };
  return {slots,entries,clock:{setTimeout(fn,ms){const id=++next;timers.set(id,{fn,ms});return id;},clearTimeout(id){timers.delete(id);}},
    declare(name){declared.add(name);for(const w of waiters)if(w.name===name&&w.active)w.fn();},
    tick(){for(const [id,t] of [...timers]){timers.delete(id);assert.equal(t.ms,2000);t.fn();}},
    timers,
  };
}

test('人设胶囊优先挂到已声明的 context 插槽并完整撤销', async () => {
  const {pbMountContext} = (await loadBundle()).__debug;
  const env=contextHarness(['conversation.input.selector.context','conversation.input.dock']);
  const dispose=pbMountContext(env.slots,()=>null,()=>({}),env.clock);
  assert.equal(env.entries.length,1);assert.equal(env.entries[0].definition.name,'conversation.input.selector.context');
  assert.equal(env.entries[0].definition.order,110);assert.equal(env.timers.size,0);
  dispose();assert.equal(env.entries[0].active,false);env.tick();assert.equal(env.entries.length,1);
});

test('延迟声明在兼容等待内到达不会重复挂载 dock', async () => {
  const {pbMountContext}=(await loadBundle()).__debug,env=contextHarness(['conversation.input.dock']);
  const dispose=pbMountContext(env.slots,()=>null,()=>({}),env.clock);
  env.declare('conversation.input.selector.context');env.tick();
  assert.equal(env.entries.length,1);assert.equal(env.entries[0].definition.name,'conversation.input.selector.context');dispose();
});

test('缺失 context 时降级到 dock，迟到的 context 不增加入口', async () => {
  const {pbMountContext}=(await loadBundle()).__debug,env=contextHarness(['conversation.input.dock']);
  const dispose=pbMountContext(env.slots,()=>null,()=>({}),env.clock);env.tick();env.declare('conversation.input.selector.context');
  assert.equal(env.entries.length,1);assert.equal(env.entries[0].definition.name,'conversation.input.dock');dispose();assert.equal(env.entries[0].active,false);
});

test('等待期间卸载取消计时与两个插槽等待，不残留入口', async () => {
  const {pbMountContext}=(await loadBundle()).__debug,env=contextHarness();
  const dispose=pbMountContext(env.slots,()=>null,()=>({}),env.clock);dispose();env.tick();env.declare('conversation.input.selector.context');env.declare('conversation.input.dock');
  assert.equal(env.timers.size,0);assert.equal(env.entries.length,0);
});

test('人设入口读取当前单聊或群聊成员，不覆盖人设内容', async () => {
  const {pbSharedRole}=(await loadBundle()).__debug;
  const snapshot={activeConversation:'c',personas:[{id:'a'},{id:'b'}],conversations:[{id:'c',members:['a','b'],activeMember:'b'}]};
  assert.equal(pbSharedRole(snapshot).id,'b');delete snapshot.conversations[0].activeMember;assert.equal(pbSharedRole(snapshot).id,'a');assert.equal(pbSharedRole(null),undefined);
});

test('the palette follows the theme, and custom opts out', async () => {
  const { pbcEffectivePalette } = (await loadBundle()).__debug;
  const themes = { deepsea: { mine: '#123456', mineText: '#ffffff', theirs: '#eeeeee', theirsText: '#000000', accent: '#07C160' } };
  const colors = { mine: '#95EC69', mineText: '#111111', theirs: '#FFFFFF', theirsText: '#111111', accent: '#abcdef' };
  const base = { appearance: { theme: 'deepsea' }, bubble: { colors } };
  const themed = pbcEffectivePalette(base, { themes });
  assert.equal(themed.mine, '#123456', 'the theme wins while it is active');
  assert.equal(themed.themed, true);

  const custom = pbcEffectivePalette({ ...base, appearance: { theme: 'custom' } }, { themes });
  assert.equal(custom.mine, '#95EC69', 'custom uses the stored colours');
  assert.equal(custom.themed, false);

  const unknown = pbcEffectivePalette({ ...base, appearance: { theme: 'nope' } }, { themes });
  assert.equal(unknown.themed, false, 'an unknown theme is not a theme');

  // A profile written before the 2.0 contract only carries `bubble.style`.
  const legacy = pbcEffectivePalette({ bubble: { style: 'deepsea', colors } }, { themes });
  assert.equal(legacy.mine, '#123456', 'the flat style still resolves');
});

test('every variable the client writes is one the skin sheet reads', async () => {
  const { pbVarList } = (await loadBundle()).__debug;
  const { DEFAULT_PROFILES } = await import('../lib/constants.js');
  const { renderThemeCss } = await import('../lib/appearance.js');
  const css = renderThemeCss(DEFAULT_PROFILES.ui);
  const written = pbVarList(DEFAULT_PROFILES.ui).map(([name]) => name);
  assert.ok(written.length >= 20, 'the client writes the whole appearance surface');
  // A variable is fine when the sheet either declares it or reads it: the
  // wallpaper url is set inline by the client and only ever read back.
  const orphans = written.filter((name) => !css.includes(`${name}:`) && !css.includes(`var(${name}`));
  assert.deepEqual(orphans, [], 'a variable nobody reads is a typo waiting to happen');
  assert.ok(css.includes('var(--pb-bg-image'), 'the uploaded wallpaper url is read by the sheet');
  // And the values agree for the pairs both halves spell out.
  for (const [name, value] of pbVarList(DEFAULT_PROFILES.ui)) {
    if (value === null || value === undefined) continue;
    if (!/^--pb-(bub-r|bub-max|bub-gap|panel-r)$/.test(name)) continue;
    const match = css.match(new RegExp(`${name}: ([^;]+);`));
    assert.ok(match !== null, `${name} is in the sheet`);
    assert.equal(match[1], String(value), `${name} agrees on both sides`);
  }
  // The material triple is the client's call: `appearance.bubble.material`
  // decides it, and the values it writes are what switch the glass layer off.
  const clear = new Map(pbVarList(DEFAULT_PROFILES.ui));
  assert.equal(clear.get('--pb-mat-op'), '0', 'transparent leaves no tint layer');
  assert.equal(clear.get('--pb-mat-blur'), '0px', 'transparent leaves no blur');
  assert.equal(clear.get('--pb-mat-sat'), '100%');
  const glassUi = structuredClone(DEFAULT_PROFILES.ui);
  glassUi.appearance.bubble.material = 'glass';
  const glass = new Map(pbVarList(glassUi));
  assert.equal(glass.get('--pb-mat-op'), '0.55');
  assert.equal(glass.get('--pb-mat-blur'), '30px');
  assert.equal(glass.get('--pb-mat-sat'), '180%');
});

test('the panel is five tabs: persona, appearance, wallpaper, sound, more', async () => {
  const mod = await loadBundle();
  const { tabDefs, EXTRA_TABS, pbWallpaperOf, pbVarList } = mod.__debug;
  const extraIds = EXTRA_TABS.map((tab) => tab.id);
  assert.deepEqual(extraIds, ['appearance', 'wallpaper', 'sound', 'more'], 'the four extra tabs, in shard order');
  assert.equal(new Set(extraIds).size, extraIds.length, 'no duplicate tab ids');
  assert.deepEqual(
    tabDefs().map((tab) => tab.id),
    ['persona', 'appearance', 'wallpaper', 'sound', 'more'],
    'five tabs, nothing else',
  );

  const builtin = pbWallpaperOf({ appearance: { wallpaper: { id: 'builtin:aurora' } } });
  assert.deepEqual(builtin, { id: 'aurora', kind: 'builtin', image: null });

  const upload = pbWallpaperOf({ appearance: { wallpaper: { id: 'asset:w-a1b2' } } });
  assert.equal(upload.kind, 'image');
  assert.equal(upload.image, "url('/api/persona-book/assets/w-a1b2/preview')");

  // "No wallpaper" must say so instead of painting a scene nobody picked.
  assert.deepEqual(pbWallpaperOf({ appearance: { wallpaper: { id: '' } } }), { id: '', kind: 'none', image: null });

  const { DEFAULT_PROFILES } = await import('../lib/constants.js');
  const withUpload = structuredClone(DEFAULT_PROFILES.ui);
  withUpload.appearance.wallpaper.id = 'asset:w-a1b2';
  const vars = new Map(pbVarList(withUpload));
  assert.equal(vars.get('--pb-bg-image'), "url('/api/persona-book/assets/w-a1b2/preview')");
});

test('the 2.0 look contract reads new and old profiles alike', async () => {
  const { pbThemeOf, pbMaterialOf, pbBubbleShapeOf, pbAvatarShapeOf, PB_THEMES, PB_BUBBLE_MATERIALS, PB_BUBBLE_SHAPES } =
    (await loadBundle()).__debug;
  assert.deepEqual(PB_BUBBLE_MATERIALS, ['transparent', 'glass', 'solid']);
  assert.deepEqual(PB_BUBBLE_SHAPES, ['round', 'square', 'none']);

  const modern = { appearance: { theme: 'light', bubble: { material: 'glass', shape: 'square' }, avatar: { shape: 'rounded' } } };
  assert.equal(pbThemeOf(modern), 'light');
  assert.equal(pbMaterialOf(modern), 'glass');
  assert.equal(pbBubbleShapeOf(modern), 'square');
  assert.equal(pbAvatarShapeOf(modern), 'rounded');

  // A profile written before the contract keeps working.
  const legacy = { appearance: { theme: { id: 'deep' } }, material: { kind: 'rough' }, bubble: { shape: { cornerRadius: 0 } } };
  assert.equal(pbThemeOf(legacy), 'deepsea');
  assert.equal(pbMaterialOf(legacy), 'solid');
  assert.equal(pbBubbleShapeOf(legacy), 'square');

  assert.deepEqual(PB_THEMES, ['deepsea', 'light', 'system']);
  assert.equal(pbThemeOf({}), 'deepsea', 'deepsea is the default theme');
  assert.equal(pbMaterialOf({}), 'transparent', 'clear glass is the default bubble');
  assert.equal(pbBubbleShapeOf({}), 'round');
  assert.equal(pbAvatarShapeOf({}), 'circle');
});

/** Walk an element tree, calling function components, without a DOM. */
function renderTree(node, depth = 0) {
  if (depth > 60) throw new Error('render tree is too deep — a component is recursing');
  if (node === null || node === undefined || typeof node === 'boolean') return null;
  if (Array.isArray(node)) return node.map((child) => renderTree(child, depth + 1));
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  const { type, props, children } = node;
  if (typeof type === 'function') {
    const all = { ...(props ?? {}) };
    if (children !== undefined && children.length > 0) all.children = children.length === 1 ? children[0] : children;
    return renderTree(type(all), depth + 1);
  }
  return { tag: type, props: props ?? {}, children: renderTree(children ?? [], depth + 1) };
}

/** A snapshot with every table the tabs read, built from the real defaults. */
async function fakeSnapshot() {
  const { DEFAULT_PROFILES, BUILTIN_WALLPAPERS, MATERIAL_PRESETS, APPLE_PRESETS, SOUND_CUES } = await import('../lib/constants.js');
  const { THEMES, BUBBLE_SHAPES, BUBBLE_MATERIALS, AVATAR_SHAPES, WALLPAPER_FITS } = await import('../lib/appearance.js');
  const { blankPersona } = await import('../lib/schema.js');
  const persona = blankPersona('demo');
  return {
    name: 'dsh-persona-book',
    version: '0.2.0',
    rev: 1,
    profiles: { rev: 1, masterOn: true, active: 'demo', ui: structuredClone(DEFAULT_PROFILES.ui), personas: [] },
    personas: [{ id: 'demo', title: persona.title, emoji: persona.emoji, problems: [] }],
    personaDocs: { demo: persona },
    personaSkills: { demo: { text: '---\nname: demo\n---\n', problems: [] } },
    activePersona: persona,
    activeProblems: [],
    docs: [{ id: 'book', label: 'book', preview: 'x', path: '/tmp/x', guard: 'non-empty', hint: '' }],
    builtin: { wallpapers: BUILTIN_WALLPAPERS, cues: SOUND_CUES, materials: MATERIAL_PRESETS, apple: APPLE_PRESETS },
    presets: {
      themes: THEMES,
      shapes: BUBBLE_SHAPES,
      materials: BUBBLE_MATERIALS,
      avatars: AVATAR_SHAPES,
      fits: WALLPAPER_FITS,
      material: MATERIAL_PRESETS,
      apple: APPLE_PRESETS,
      defaults: DEFAULT_PROFILES.ui,
    },
    assets: { usage: { bytes: 0, files: 0, quota: 1024 }, limits: {}, library: { wallpaper: 60, avatar: 40, sound: 20 }, wallpapers: [], avatars: [], sounds: [] },
    problems: [],
  };
}

test('every tab renders for a default profile without throwing', async () => {
  const module = await loadBundle();
  const { tabDefs, setState, getState } = module.__debug;
  setState({ snapshot: await fakeSnapshot(), loading: false, open: true, error: null });
  assert.equal(getState().snapshot.rev, 1, 'the store took the snapshot');
  const tr = (key) => key;
  const forms = { get: () => ({ value: undefined }), set: () => {}, available: () => false };
  const tabs = tabDefs();
  assert.ok(tabs.length >= 5, `expected the panel to have tabs, got ${tabs.length}`);
  for (const tab of tabs) {
    assert.equal(typeof tab.render, 'function', `tab ${tab.id} must render itself`);
    const tree = renderTree(tab.render({ tr, forms }));
    assert.notEqual(tree, null, `tab ${tab.id} rendered nothing`);
  }
});

test('每一声提示音都有一段能播出来的配方', async () => {
  const debug = (await loadBundle()).__debug;
  assert.deepEqual(debug.pbCueIds.sort(), [
    'bell-cat',
    'bubble',
    'off',
    'shell-ding',
    'star-tap',
    'water-drop',
    'whale-call',
    'whale-song',
  ]);
  for (const id of debug.pbCueIds) {
    const events = debug.pbCueEvents(id);
    if (id === 'off') {
      assert.deepEqual(events, [], '静默就该是空的');
      continue;
    }
    assert.ok(events.length >= 1, `${id} 至少要有一个音`);
    for (const event of events) {
      assert.ok(['tone', 'noise'].includes(event.kind), `${id} 的事件种类`);
      if (event.kind === 'tone') {
        assert.ok(event.from >= 20 && event.from <= 16000, `${id} 的频率要落在人耳范围`);
        assert.ok(event.to >= 20 && event.to <= 16000, `${id} 的滑音终点也要在范围内`);
      }
      assert.ok(event.at >= 0 && event.until <= 2, `${id} 要在两秒内结束`);
      assert.ok(event.until > event.at, `${id} 的时长得是正的`);
      assert.ok(event.gain > 0 && event.gain <= 1, `${id} 的增益要夹在 0–1`);
    }
  }
  assert.ok(debug.pbCueEvents('不存在的音').length === 0, '认不出的名字当作静默');
});

test('事件与提示音的绑定是全纯的，静默与关掉都要真的不响', async () => {
  const { pbCueFor } = (await loadBundle()).__debug;
  const base = { sound: { enabled: true, volume: 0.4, events: { sent: 'whale-call', received: 'water-drop', error: 'off', done: null } } };
  assert.deepEqual(pbCueFor(base, 'sent'), { cue: 'whale-call', volume: 0.4 });
  assert.equal(pbCueFor(base, 'error'), null, 'off 是不响');
  assert.equal(pbCueFor(base, 'done'), null, 'null 也是不响');
  assert.equal(pbCueFor({ sound: { ...base.sound, enabled: false } }, 'sent'), null, '总开关关掉就不响');
  assert.deepEqual(pbCueFor({ sound: { ...base.sound, events: { sent: 'custom:s-123' } } }, 'sent'), {
    custom: 's-123',
    volume: 0.4,
  });
  assert.equal(pbCueFor({ sound: { ...base.sound, events: { sent: '并 不 存 在' } } }, 'sent'), null);
  assert.equal(pbCueFor({ sound: { ...base.sound, volume: 9 } }, 'sent').volume, 1, '音量被夹到 1');
});

test('没有 WebAudio 的环境里播放安静地失败，不抛错', async () => {
  const { pbSoundPlay, pbSoundState } = (await loadBundle()).__debug;
  const ui = { sound: { enabled: true, volume: 0.5, events: { sent: 'whale-call' }, rateLimitMs: 0 } };
  assert.equal(pbSoundPlay(ui, 'sent'), false, 'Node 里没有 AudioContext，应当安静返回 false');
  const status = pbSoundState();
  assert.equal(status.available, false);
  assert.equal(typeof status.resumed, 'boolean');
});

test('面板语言自己选：中文优先，切到英文整片跟着变，非法值回默认', async () => {
  const { pbTr, pbLangUse, pbLangNow, pbLangPrefGet } = (await loadBundle()).__debug;
  assert.equal(pbLangPrefGet(), 'zh', '默认是中文');
  assert.equal(pbTr('saved'), '已保存');
  assert.equal(pbTr('assets.files', { count: 3 }), '3 个文件');
  assert.equal(pbTr('tabs.more'), '更多');
  pbLangUse('en');
  assert.equal(pbLangNow(), 'en');
  assert.equal(pbTr('saved'), 'Saved');
  assert.equal(pbTr('assets.files', { count: 3 }), '3 files');
  pbLangUse('zh');
  assert.equal(pbTr('failed'), '出错了：');
  assert.equal(pbTr('这个键不存在'), '这个键不存在', '缺键时把键名原样还回去');
  assert.equal(pbTr('assets.files', { count: 2, extra: 'x' }), '2 个文件');
  pbLangUse('fr');
  assert.equal(pbLangPrefGet(), 'zh', '不认识的语言回到中文');
  pbLangUse('auto');
  assert.ok(['zh', 'en'].includes(pbLangNow()), 'auto 只解析成两种语言之一');
});


test('confirmed usage sums disjoint buckets and leaves unpriced costs unknown',async()=>{
 const {pbUsageSummary:sum}=(await loadBundle()).__debug;
 const value={asOfSeq:43,values:{tokenUsage:{uncachedInputTokens:36067,cacheReadTokens:62208,cacheWriteTokens:0,outputTokens:326,reasoningTokens:100}}};
 const data=sum(value);assert.equal(data.total,98601);assert.equal(data.cost,null);
 assert.equal(sum(value,{input:'',cache:0,output:0}).cost,null);
 assert.equal(sum(value,{input:'bad',cache:0,output:0}).cost,null);
 assert.equal(sum(value,{input:-1,cache:0,output:0}).cost,null);
 assert.equal(sum(value,{input:0,cache:0,output:0}).cost,0);
 const cost=sum(value,{input:2,cache:0.2,output:3}).cost;
 assert.ok(Math.abs(cost-((36067*2+62208*0.2+326*3)/1e6))<1e-10);
 assert.equal(sum(value).total,sum(value).total); // snapshots replace, never accumulate
 assert.equal(sum({values:{}}),null);
 assert.equal(sum({values:{tokenUsage:{...value.values.tokenUsage,outputTokens:-1}}}),null);
});
