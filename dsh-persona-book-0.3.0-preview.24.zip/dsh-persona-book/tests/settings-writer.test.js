import test from 'node:test';
import assert from 'node:assert/strict';
import {createSettingsWriter,mergeSnapshot} from '../app/ui/settings-writer.mjs';
const tick=()=>new Promise(r=>setImmediate(r));
test('快速设置先显示最新值，只保留一个在途写入并合并后续保存',async()=>{
 const sent=[],committed=[],optimistic=[];let release;
 const writer=createSettingsWriter({send:async patch=>{sent.push(patch);if(sent.length===1)await new Promise(r=>release=r);return {state:{rev:sent.length,settings:patch},result:{}};},onOptimistic:p=>optimistic.push(p),onCommit:s=>committed.push(mergeSnapshot(null,s,writer.overlay())),onFailure:e=>{throw e;}});
 const first=writer.write({volume:.1}),second=writer.write({volume:.2}),third=writer.write({volume:.4,sound:false}),last=writer.write({volume:.5});
 assert.equal(sent.length,1);assert.deepEqual(writer.overlay(),{volume:.5,sound:false});assert.equal(optimistic.length,4);
 release();await Promise.all([first,second,third,last]);assert.deepEqual(sent,[{volume:.1},{volume:.5,sound:false}]);assert.equal(committed[0].settings.volume,.5);assert.deepEqual(writer.overlay(),{});
});
test('写入失败不丢掉后续设置，清除失败的乐观值并返回错误',async()=>{
 let fail;const sent=[],errors=[];const writer=createSettingsWriter({send:async patch=>{sent.push(patch);if(sent.length===1)await new Promise((_,reject)=>fail=reject);return {state:{rev:2,settings:patch},result:{}};},onOptimistic:()=>{},onCommit:()=>{},onFailure:e=>errors.push(e.message)});
 const first=writer.write({sound:false,volume:.1}).catch(e=>e.message),next=writer.write({volume:.6});fail(Error('保存失败'));assert.equal(await first,'保存失败');await next;assert.deepEqual(sent,[{sound:false,volume:.1},{volume:.6}]);assert.deepEqual(writer.overlay(),{});assert.deepEqual(errors,['保存失败']);
});
test('延迟到达的旧快照不会覆盖新版本，待保存的界面设置保持最新',()=>{
 const current={rev:8,settings:{volume:.8}},old={rev:7,settings:{volume:.1}};assert.equal(mergeSnapshot(current,old),current);assert.equal(mergeSnapshot(current,old,{volume:.9}).settings.volume,.9);assert.equal(mergeSnapshot(current,{rev:9,settings:{volume:.3}}).settings.volume,.3);
});
